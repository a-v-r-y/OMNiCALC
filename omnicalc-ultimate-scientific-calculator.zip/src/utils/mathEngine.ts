import * as math from 'mathjs';
import { AngleUnit, PrecisionMode, ResultDisplayFormat } from '../types/calc';

// Create base math instance
const baseMath = math.create(math.all);

// Configure custom trig functions based on angle mode
export function getMathInstance(angleUnit: AngleUnit = 'rad', precision: PrecisionMode = 16) {
  const instance = math.create(math.all, {
    precision,
    number: precision > 16 ? 'BigNumber' : 'number'
  });

  const degToRad = (deg: number) => (deg * Math.PI) / 180;
  const radToDeg = (rad: number) => (rad * 180) / Math.PI;
  const gradToRad = (grad: number) => (grad * Math.PI) / 200;
  const radToGrad = (rad: number) => (rad * 200) / Math.PI;

  const toRad = (val: number) => {
    if (angleUnit === 'deg') return degToRad(val);
    if (angleUnit === 'grad') return gradToRad(val);
    return val;
  };

  const fromRad = (val: number) => {
    if (angleUnit === 'deg') return radToDeg(val);
    if (angleUnit === 'grad') return radToGrad(val);
    return val;
  };

  // Override standard trig functions to adhere to current angle mode
  instance.import({
    sin: (x: any) => {
      if (typeof x === 'number') return Math.sin(toRad(x));
      return instance.sin(x);
    },
    cos: (x: any) => {
      if (typeof x === 'number') return Math.cos(toRad(x));
      return instance.cos(x);
    },
    tan: (x: any) => {
      if (typeof x === 'number') {
        const rad = toRad(x);
        // Check for asymptotic singularity
        if (Math.abs(Math.cos(rad)) < 1e-15) return Infinity;
        return Math.tan(rad);
      }
      return instance.tan(x);
    },
    sec: (x: any) => {
      if (typeof x === 'number') return 1 / Math.cos(toRad(x));
      return instance.sec(x);
    },
    csc: (x: any) => {
      if (typeof x === 'number') return 1 / Math.sin(toRad(x));
      return instance.csc(x);
    },
    cot: (x: any) => {
      if (typeof x === 'number') return 1 / Math.tan(toRad(x));
      return instance.cot(x);
    },
    asin: (x: any) => {
      if (typeof x === 'number') return fromRad(Math.asin(x));
      return instance.asin(x);
    },
    acos: (x: any) => {
      if (typeof x === 'number') return fromRad(Math.acos(x));
      return instance.acos(x);
    },
    atan: (x: any) => {
      if (typeof x === 'number') return fromRad(Math.atan(x));
      return instance.atan(x);
    },
    // Additional helpers
    nCr: (n: number, r: number) => instance.combinations(n, r),
    nPr: (n: number, r: number) => instance.permutations(n, r),
    fact: (n: number) => instance.factorial(n),
    root: (x: number, n: number) => Math.pow(x, 1 / n),
    ln: (x: number) => Math.log(x),
    log10: (x: number) => Math.log10(x),
    log2: (x: number) => Math.log2(x),
  }, { override: true });

  return instance;
}

// Convert decimal number to best fraction string (e.g. 0.75 -> 3/4)
export function toExactFraction(val: number, tolerance: number = 1e-9): string | null {
  if (isNaN(val) || !isFinite(val)) return null;
  if (Number.isInteger(val)) return null;

  try {
    const frac = baseMath.fraction(val) as any;
    if (frac && frac.d && frac.d <= 1000000 && frac.d > 1) {
      const sign = frac.s < 0 ? '-' : '';
      return `${sign}${frac.n}/${frac.d}`;
    }
  } catch {
    // Continue with continued fraction approximation
  }

  // Continued fraction algorithm for high precision rational approximation
  let h1 = 1, h2 = 0, k1 = 0, k2 = 1;
  let b = val;
  do {
    const a = Math.floor(b);
    let aux = h1;
    h1 = a * h1 + h2;
    h2 = aux;
    aux = k1;
    k1 = a * k1 + k2;
    k2 = aux;
    b = 1 / (b - a);
  } while (Math.abs(val - h1 / k1) > val * tolerance && k1 < 100000);

  if (k1 > 1 && k1 <= 100000) {
    return `${h1}/${k1}`;
  }
  return null;
}

// Format number in engineering notation (power of 10 is multiple of 3)
export function toEngineering(val: number, sigFigs: number = 6): string {
  if (val === 0) return '0';
  const exp = Math.floor(Math.log10(Math.abs(val)));
  const engExp = Math.floor(exp / 3) * 3;
  const engVal = val / Math.pow(10, engExp);
  return `${engVal.toPrecision(sigFigs).replace(/\.?0+$/, '')} × 10^${engExp}`;
}

// DMS (Degrees, Minutes, Seconds) conversion
export function decimalToDMS(deg: number): { degrees: number; minutes: number; seconds: number; formatted: string } {
  const absolute = Math.abs(deg);
  const degrees = Math.floor(absolute);
  const minutesNotTruncated = (absolute - degrees) * 60;
  const minutes = Math.floor(minutesNotTruncated);
  const seconds = Math.round((minutesNotTruncated - minutes) * 60 * 100) / 100;
  const sign = deg < 0 ? '-' : '';
  return {
    degrees: deg < 0 ? -degrees : degrees,
    minutes,
    seconds,
    formatted: `${sign}${degrees}° ${minutes}' ${seconds}"`
  };
}

export function dmsToDecimal(degrees: number, minutes: number, seconds: number): number {
  const sign = degrees < 0 ? -1 : 1;
  return sign * (Math.abs(degrees) + minutes / 60 + seconds / 3600);
}

export interface EvalResult {
  success: boolean;
  resultString: string;
  latex?: string;
  numericValue?: number;
  exactFraction?: string;
  engineering?: string;
  type?: string;
  error?: string;
}

// Main evaluation function
export function evaluateExpression(
  expr: string,
  scope: Record<string, any> = {},
  angleUnit: AngleUnit = 'rad',
  precision: PrecisionMode = 16,
  displayFormat: ResultDisplayFormat = 'auto'
): EvalResult {
  if (!expr || !expr.trim()) {
    return { success: false, resultString: '', error: 'Empty expression' };
  }

  try {
    const mathInstance = getMathInstance(angleUnit, precision);
    
    // Normalize user friendly syntax: × -> *, ÷ -> /, √ -> sqrt
    let cleaned = expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/π/g, 'pi')
      .replace(/√\((.*?)\)/g, 'sqrt($1)')
      .replace(/√([a-zA-Z0-9.]+)/g, 'sqrt($1)');

    const parsed = mathInstance.parse(cleaned);
    const compiled = parsed.compile();
    const evaluated = compiled.evaluate(scope);

    let resultString = '';
    let numericValue: number | undefined = undefined;
    let exactFraction: string | undefined = undefined;
    let engineering: string | undefined = undefined;
    let latex: string | undefined = undefined;

    try {
      latex = parsed.toTex({ parenthesis: 'auto' });
    } catch {
      latex = undefined;
    }

    if (evaluated !== undefined && evaluated !== null) {
      if (typeof evaluated === 'number') {
        numericValue = evaluated;
        if (displayFormat === 'engineering') {
          resultString = toEngineering(evaluated);
        } else if (displayFormat === 'scientific') {
          resultString = evaluated.toExponential(6);
        } else if (displayFormat === 'fraction') {
          const frac = toExactFraction(evaluated);
          resultString = frac ? frac : evaluated.toString();
        } else {
          // Auto format
          if (Math.abs(evaluated) < 1e-6 && evaluated !== 0) {
            resultString = evaluated.toExponential(6);
          } else if (Math.abs(evaluated) >= 1e12) {
            resultString = evaluated.toExponential(6);
          } else {
            // Round floating-point noise e.g. 0.1 + 0.2
            resultString = parseFloat(evaluated.toFixed(12)).toString();
          }
        }
        exactFraction = toExactFraction(evaluated) || undefined;
        engineering = toEngineering(evaluated);
      } else if (typeof evaluated === 'object' && evaluated.isComplex) {
        const re = parseFloat(evaluated.re.toFixed(8));
        const im = parseFloat(evaluated.im.toFixed(8));
        resultString = `${re >= 0 ? '' : '-'}${Math.abs(re)} ${im >= 0 ? '+' : '-'} ${Math.abs(im)}i`;
        numericValue = Math.sqrt(evaluated.re ** 2 + evaluated.im ** 2);
      } else if (typeof evaluated === 'object' && evaluated.isFraction) {
        resultString = `${evaluated.s < 0 ? '-' : ''}${evaluated.n}/${evaluated.d}`;
        numericValue = evaluated.valueOf();
      } else if (typeof evaluated === 'object' && evaluated.isBigNumber) {
        resultString = evaluated.toString();
        numericValue = evaluated.toNumber();
      } else if (Array.isArray(evaluated) || (evaluated && evaluated.isMatrix)) {
        resultString = mathInstance.format(evaluated, { precision: 8 });
      } else if (typeof evaluated === 'function') {
        resultString = `[Function: ${expr}]`;
      } else {
        resultString = String(evaluated);
      }
    }

    return {
      success: true,
      resultString,
      latex,
      numericValue,
      exactFraction,
      engineering,
      type: typeof evaluated
    };
  } catch (err: any) {
    return {
      success: false,
      resultString: '',
      error: err.message || 'Syntax or calculation error'
    };
  }
}

// Symbolic CAS tools
export function symbolicSimplify(expr: string): string {
  try {
    const node = baseMath.simplify(expr);
    return node.toString();
  } catch (err: any) {
    return `Error: ${err.message}`;
  }
}

export function symbolicDerivative(expr: string, variable: string = 'x'): string {
  try {
    const node = baseMath.derivative(expr, variable);
    return baseMath.simplify(node).toString();
  } catch (err: any) {
    return `Error: ${err.message}`;
  }
}

// Evaluate function at value x
export function evalFunctionAt(expr: string, xVal: number, angleUnit: AngleUnit = 'rad'): number {
  try {
    const instance = getMathInstance(angleUnit);
    const compiled = instance.compile(expr);
    const res = compiled.evaluate({ x: xVal });
    return typeof res === 'number' ? res : NaN;
  } catch {
    return NaN;
  }
}
