// Comprehensive Financial Solvers Engine

export interface AmortizationRow {
  period: number;
  startingBalance: number;
  payment: number;
  principalPaid: number;
  interestPaid: number;
  endingBalance: number;
  totalInterestPaid: number;
}

export interface AmortizationSummary {
  monthlyEMI: number;
  totalPayment: number;
  totalInterest: number;
  payoffMonths: number;
  interestSavings: number;
  schedule: AmortizationRow[];
  yearlySummary: {
    year: number;
    principalPaid: number;
    interestPaid: number;
    endingBalance: number;
  }[];
}

// 1. Simple Interest
export function calculateSimpleInterest(
  principal: number,
  ratePct: number,
  timeYears: number
): {
  interest: number;
  totalAmount: number;
  annualInterest: number;
} {
  const r = ratePct / 100;
  const interest = principal * r * timeYears;
  const totalAmount = principal + interest;
  const annualInterest = principal * r;

  return {
    interest: parseFloat(interest.toFixed(2)),
    totalAmount: parseFloat(totalAmount.toFixed(2)),
    annualInterest: parseFloat(annualInterest.toFixed(2))
  };
}

// 2. Compound Interest with Periodic Deposits
export type CompoundingFrequency = 1 | 2 | 4 | 12 | 365 | 0; // 0 for continuous

export function calculateCompoundInterest(
  principal: number,
  annualRatePct: number,
  years: number,
  frequency: CompoundingFrequency = 12,
  monthlyDeposit: number = 0
): {
  finalBalance: number;
  totalPrincipal: number;
  totalDeposits: number;
  totalInterest: number;
  effectiveAnnualRate: number;
  breakdown: { year: number; balance: number; interestEarned: number }[];
} {
  const r = annualRatePct / 100;
  const totalDeposits = monthlyDeposit * 12 * years;
  const totalPrincipal = principal + totalDeposits;

  let finalBalance = 0;
  let ear = 0;
  const breakdown: { year: number; balance: number; interestEarned: number }[] = [];

  if (frequency === 0) {
    // Continuous compounding
    ear = (Math.exp(r) - 1) * 100;
    // Without deposits simple continuous; with deposits approximate monthly step
    let bal = principal;
    for (let yr = 1; yr <= years; yr++) {
      for (let m = 0; m < 12; m++) {
        bal = (bal + monthlyDeposit) * Math.exp(r / 12);
      }
      breakdown.push({
        year: yr,
        balance: parseFloat(bal.toFixed(2)),
        interestEarned: parseFloat((bal - principal - monthlyDeposit * 12 * yr).toFixed(2))
      });
    }
    finalBalance = bal;
  } else {
    const n = frequency;
    ear = (Math.pow(1 + r / n, n) - 1) * 100;

    let bal = principal;
    for (let yr = 1; yr <= years; yr++) {
      for (let p = 0; p < n; p++) {
        // Add proportional deposit per compound period
        const depositPerPeriod = (monthlyDeposit * 12) / n;
        bal = (bal + depositPerPeriod) * (1 + r / n);
      }
      breakdown.push({
        year: yr,
        balance: parseFloat(bal.toFixed(2)),
        interestEarned: parseFloat((bal - principal - monthlyDeposit * 12 * yr).toFixed(2))
      });
    }
    finalBalance = bal;
  }

  const totalInterest = Math.max(0, finalBalance - totalPrincipal);

  return {
    finalBalance: parseFloat(finalBalance.toFixed(2)),
    totalPrincipal: parseFloat(totalPrincipal.toFixed(2)),
    totalDeposits: parseFloat(totalDeposits.toFixed(2)),
    totalInterest: parseFloat(totalInterest.toFixed(2)),
    effectiveAnnualRate: parseFloat(ear.toFixed(3)),
    breakdown
  };
}

// 3. Present Value (PV) & Future Value (FV)
export function calculatePV(
  futureValue: number,
  annualRatePct: number,
  years: number,
  compoundingPerYear: number = 1
): {
  presentValue: number;
  discountFactor: number;
  totalDiscount: number;
} {
  const r = annualRatePct / 100;
  const n = compoundingPerYear;
  const factor = Math.pow(1 + r / n, n * years);
  const presentValue = futureValue / factor;

  return {
    presentValue: parseFloat(presentValue.toFixed(2)),
    discountFactor: parseFloat((1 / factor).toFixed(4)),
    totalDiscount: parseFloat((futureValue - presentValue).toFixed(2))
  };
}

export function calculateFV(
  presentValue: number,
  annualRatePct: number,
  years: number,
  compoundingPerYear: number = 1
): {
  futureValue: number;
  growthMultiplier: number;
  totalGain: number;
} {
  const r = annualRatePct / 100;
  const n = compoundingPerYear;
  const factor = Math.pow(1 + r / n, n * years);
  const futureValue = presentValue * factor;

  return {
    futureValue: parseFloat(futureValue.toFixed(2)),
    growthMultiplier: parseFloat(factor.toFixed(4)),
    totalGain: parseFloat((futureValue - presentValue).toFixed(2))
  };
}

// 4. Annuities (Ordinary vs Annuity Due)
export function calculateAnnuity(
  payment: number,
  annualRatePct: number,
  periods: number,
  frequencyPerYear: number = 12,
  isDue: boolean = false
): {
  futureValue: number;
  presentValue: number;
  totalPayments: number;
  totalInterestFV: number;
  totalInterestPV: number;
} {
  const r = annualRatePct / 100 / frequencyPerYear;
  const dueFactor = isDue ? 1 + r : 1;
  const totalPayments = payment * periods;

  let fv = 0;
  let pv = 0;

  if (r === 0) {
    fv = totalPayments;
    pv = totalPayments;
  } else {
    fv = payment * ((Math.pow(1 + r, periods) - 1) / r) * dueFactor;
    pv = payment * ((1 - Math.pow(1 + r, -periods)) / r) * dueFactor;
  }

  return {
    futureValue: parseFloat(fv.toFixed(2)),
    presentValue: parseFloat(pv.toFixed(2)),
    totalPayments: parseFloat(totalPayments.toFixed(2)),
    totalInterestFV: parseFloat((fv - totalPayments).toFixed(2)),
    totalInterestPV: parseFloat((totalPayments - pv).toFixed(2))
  };
}

// 5. Loans, EMI & Full Amortization Schedule
export function calculateAmortizationSchedule(
  principal: number,
  annualRatePct: number,
  tenureMonths: number,
  extraMonthlyPayment: number = 0
): AmortizationSummary {
  const monthlyRate = annualRatePct / (12 * 100);

  // Standard EMI without extra payment
  let standardEMI = 0;
  if (monthlyRate === 0) {
    standardEMI = principal / tenureMonths;
  } else {
    const factor = Math.pow(1 + monthlyRate, tenureMonths);
    standardEMI = (principal * monthlyRate * factor) / (factor - 1);
  }

  const schedule: AmortizationRow[] = [];
  let balance = principal;
  let totalInterest = 0;
  let totalPayment = 0;
  let period = 1;

  while (balance > 0.005 && period <= tenureMonths * 2) {
    const startingBal = balance;
    const interestPart = balance * monthlyRate;
    let payment = standardEMI + extraMonthlyPayment;

    if (payment > startingBal + interestPart) {
      payment = startingBal + interestPart;
    }

    const principalPart = Math.min(startingBal, payment - interestPart);
    const endingBal = Math.max(0, startingBal - principalPart);

    totalInterest += interestPart;
    totalPayment += payment;

    schedule.push({
      period,
      startingBalance: parseFloat(startingBal.toFixed(2)),
      payment: parseFloat(payment.toFixed(2)),
      principalPaid: parseFloat(principalPart.toFixed(2)),
      interestPaid: parseFloat(interestPart.toFixed(2)),
      endingBalance: parseFloat(endingBal.toFixed(2)),
      totalInterestPaid: parseFloat(totalInterest.toFixed(2))
    });

    balance = endingBal;
    period++;
  }

  // Yearly Summary
  const yearlySummary: {
    year: number;
    principalPaid: number;
    interestPaid: number;
    endingBalance: number;
  }[] = [];

  let currentYear = 1;
  let yrPrincipal = 0;
  let yrInterest = 0;

  for (let i = 0; i < schedule.length; i++) {
    const row = schedule[i];
    yrPrincipal += row.principalPaid;
    yrInterest += row.interestPaid;

    if ((i + 1) % 12 === 0 || i === schedule.length - 1) {
      yearlySummary.push({
        year: currentYear,
        principalPaid: parseFloat(yrPrincipal.toFixed(2)),
        interestPaid: parseFloat(yrInterest.toFixed(2)),
        endingBalance: row.endingBalance
      });
      currentYear++;
      yrPrincipal = 0;
      yrInterest = 0;
    }
  }

  // Standard total interest without extra payments
  const standardTotalPayment = standardEMI * tenureMonths;
  const standardTotalInterest = standardTotalPayment - principal;
  const interestSavings = Math.max(0, standardTotalInterest - totalInterest);

  return {
    monthlyEMI: parseFloat(standardEMI.toFixed(2)),
    totalPayment: parseFloat(totalPayment.toFixed(2)),
    totalInterest: parseFloat(totalInterest.toFixed(2)),
    payoffMonths: schedule.length,
    interestSavings: parseFloat(interestSavings.toFixed(2)),
    schedule,
    yearlySummary
  };
}

// 6. Depreciation Methods
export type DepreciationMethod = 'straight_line' | 'double_declining' | 'sum_of_years';

export function calculateDepreciation(
  cost: number,
  salvageValue: number,
  usefulLifeYears: number,
  method: DepreciationMethod
): {
  method: DepreciationMethod;
  depreciableBase: number;
  schedule: {
    year: number;
    depreciationExpense: number;
    accumulatedDepreciation: number;
    endingBookValue: number;
  }[];
} {
  const depreciableBase = Math.max(0, cost - salvageValue);
  const n = Math.max(1, Math.round(usefulLifeYears));
  const schedule: {
    year: number;
    depreciationExpense: number;
    accumulatedDepreciation: number;
    endingBookValue: number;
  }[] = [];

  let bookValue = cost;
  let accumulated = 0;

  if (method === 'straight_line') {
    const annualDepr = depreciableBase / n;
    for (let yr = 1; yr <= n; yr++) {
      const expense = yr === n ? Math.max(0, bookValue - salvageValue) : annualDepr;
      accumulated += expense;
      bookValue = Math.max(salvageValue, cost - accumulated);
      schedule.push({
        year: yr,
        depreciationExpense: parseFloat(expense.toFixed(2)),
        accumulatedDepreciation: parseFloat(accumulated.toFixed(2)),
        endingBookValue: parseFloat(bookValue.toFixed(2))
      });
    }
  } else if (method === 'double_declining') {
    const rate = 2 / n;
    for (let yr = 1; yr <= n; yr++) {
      let expense = bookValue * rate;
      if (bookValue - expense < salvageValue) {
        expense = Math.max(0, bookValue - salvageValue);
      }
      accumulated += expense;
      bookValue = Math.max(salvageValue, bookValue - expense);
      schedule.push({
        year: yr,
        depreciationExpense: parseFloat(expense.toFixed(2)),
        accumulatedDepreciation: parseFloat(accumulated.toFixed(2)),
        endingBookValue: parseFloat(bookValue.toFixed(2))
      });
    }
  } else if (method === 'sum_of_years') {
    const syd = (n * (n + 1)) / 2;
    for (let yr = 1; yr <= n; yr++) {
      const fraction = (n - yr + 1) / syd;
      const expense = depreciableBase * fraction;
      accumulated += expense;
      bookValue = Math.max(salvageValue, cost - accumulated);
      schedule.push({
        year: yr,
        depreciationExpense: parseFloat(expense.toFixed(2)),
        accumulatedDepreciation: parseFloat(accumulated.toFixed(2)),
        endingBookValue: parseFloat(bookValue.toFixed(2))
      });
    }
  }

  return {
    method,
    depreciableBase: parseFloat(depreciableBase.toFixed(2)),
    schedule
  };
}

// 7. Profit / Loss & Margin / Markup
export function calculateProfitLoss(
  costPrice: number,
  sellingPrice: number,
  units: number = 1
): {
  isProfit: boolean;
  absoluteDiff: number;
  totalCost: number;
  totalRevenue: number;
  totalDiff: number;
  percentageProfitLoss: number;
  grossMarginPct: number;
  markupPct: number;
} {
  const diff = sellingPrice - costPrice;
  const isProfit = diff >= 0;
  const totalCost = costPrice * units;
  const totalRevenue = sellingPrice * units;
  const totalDiff = diff * units;

  const pct = costPrice !== 0 ? (diff / costPrice) * 100 : 0;
  const margin = sellingPrice !== 0 ? (diff / sellingPrice) * 100 : 0;
  const markup = costPrice !== 0 ? (diff / costPrice) * 100 : 0;

  return {
    isProfit,
    absoluteDiff: parseFloat(Math.abs(diff).toFixed(2)),
    totalCost: parseFloat(totalCost.toFixed(2)),
    totalRevenue: parseFloat(totalRevenue.toFixed(2)),
    totalDiff: parseFloat(Math.abs(totalDiff).toFixed(2)),
    percentageProfitLoss: parseFloat(pct.toFixed(2)),
    grossMarginPct: parseFloat(margin.toFixed(2)),
    markupPct: parseFloat(markup.toFixed(2))
  };
}

// 8. Percentage Change
export function calculatePercentageChange(
  initialValue: number,
  finalValue: number
): {
  absoluteChange: number;
  percentageChange: number;
  multiplier: number;
  isIncrease: boolean;
} {
  const diff = finalValue - initialValue;
  const pct = initialValue !== 0 ? (diff / Math.abs(initialValue)) * 100 : 0;
  const multiplier = initialValue !== 0 ? finalValue / initialValue : 0;

  return {
    absoluteChange: parseFloat(diff.toFixed(4)),
    percentageChange: parseFloat(pct.toFixed(2)),
    multiplier: parseFloat(multiplier.toFixed(4)),
    isIncrease: diff >= 0
  };
}

// 9. CAGR (Compound Annual Growth Rate)
export function calculateCAGR(
  beginningValue: number,
  endingValue: number,
  years: number
): {
  cagrPct: number;
  totalGain: number;
  totalReturnPct: number;
  doublingTimeYears: number;
} {
  if (beginningValue <= 0 || endingValue <= 0 || years <= 0) {
    return { cagrPct: 0, totalGain: 0, totalReturnPct: 0, doublingTimeYears: 0 };
  }

  const cagr = Math.pow(endingValue / beginningValue, 1 / years) - 1;
  const totalGain = endingValue - beginningValue;
  const totalReturnPct = (totalGain / beginningValue) * 100;
  const doublingTime = cagr > 0 ? Math.log(2) / Math.log(1 + cagr) : 0;

  return {
    cagrPct: parseFloat((cagr * 100).toFixed(2)),
    totalGain: parseFloat(totalGain.toFixed(2)),
    totalReturnPct: parseFloat(totalReturnPct.toFixed(2)),
    doublingTimeYears: parseFloat(doublingTime.toFixed(1))
  };
}

// 10. Break-Even Calculations
export function calculateBreakEven(
  fixedCosts: number,
  variableCostPerUnit: number,
  sellingPricePerUnit: number,
  targetProfit: number = 0
): {
  contributionMarginUnit: number;
  contributionMarginRatioPct: number;
  breakEvenUnits: number;
  breakEvenRevenue: number;
  targetUnits: number;
  targetRevenue: number;
  isViable: boolean;
} {
  const cm = sellingPricePerUnit - variableCostPerUnit;
  const isViable = cm > 0;

  if (!isViable) {
    return {
      contributionMarginUnit: parseFloat(cm.toFixed(2)),
      contributionMarginRatioPct: 0,
      breakEvenUnits: 0,
      breakEvenRevenue: 0,
      targetUnits: 0,
      targetRevenue: 0,
      isViable: false
    };
  }

  const cmRatio = (cm / sellingPricePerUnit) * 100;
  const beUnits = Math.ceil(fixedCosts / cm);
  const beRevenue = beUnits * sellingPricePerUnit;
  const targetUnits = Math.ceil((fixedCosts + targetProfit) / cm);
  const targetRevenue = targetUnits * sellingPricePerUnit;

  return {
    contributionMarginUnit: parseFloat(cm.toFixed(2)),
    contributionMarginRatioPct: parseFloat(cmRatio.toFixed(2)),
    breakEvenUnits: beUnits,
    breakEvenRevenue: parseFloat(beRevenue.toFixed(2)),
    targetUnits,
    targetRevenue: parseFloat(targetRevenue.toFixed(2)),
    isViable: true
  };
}

// 11. Financial Formulas Reference List
export interface FinancialFormula {
  title: string;
  category: string;
  latex: string;
  description: string;
  variables: { name: string; desc: string }[];
}

export const FINANCIAL_FORMULAS: FinancialFormula[] = [
  {
    title: 'Simple Interest',
    category: 'Interest & TVM',
    latex: 'I = P \\cdot r \\cdot t, \\quad A = P(1 + r \\cdot t)',
    description: 'Interest calculated only on the initial principal balance over time.',
    variables: [
      { name: 'P', desc: 'Principal amount invested or borrowed' },
      { name: 'r', desc: 'Annual interest rate in decimal' },
      { name: 't', desc: 'Time duration in years' },
      { name: 'I', desc: 'Total interest accrued' }
    ]
  },
  {
    title: 'Compound Interest',
    category: 'Interest & TVM',
    latex: 'A = P \\left(1 + \\frac{r}{n}\\right)^{n \\cdot t}',
    description: 'Accumulated amount where interest earns interest on previous periods.',
    variables: [
      { name: 'A', desc: 'Final balance after compounding' },
      { name: 'n', desc: 'Compounding frequency per year' },
      { name: 'r', desc: 'Annual nominal interest rate' }
    ]
  },
  {
    title: 'Present Value (Discounting)',
    category: 'Interest & TVM',
    latex: 'PV = \\frac{FV}{(1 + r)^t}',
    description: 'Current purchasing value of a designated future sum discounted at rate r.',
    variables: [
      { name: 'PV', desc: 'Present discounted value' },
      { name: 'FV', desc: 'Future nominal sum' },
      { name: 'r', desc: 'Discount or inflation rate' }
    ]
  },
  {
    title: 'Future Value of Ordinary Annuity',
    category: 'Annuities & Payouts',
    latex: 'FV_{\\text{ann}} = PMT \\cdot \\left[\\frac{(1 + r)^n - 1}{r}\\right]',
    description: 'Sum of equal payments made at the end of each period compounded at rate r.',
    variables: [
      { name: 'PMT', desc: 'Periodic regular payment' },
      { name: 'n', desc: 'Total number of payment periods' },
      { name: 'r', desc: 'Periodic discount/growth rate' }
    ]
  },
  {
    title: 'Present Value of Ordinary Annuity',
    category: 'Annuities & Payouts',
    latex: 'PV_{\\text{ann}} = PMT \\cdot \\left[\\frac{1 - (1 + r)^{-n}}{r}\\right]',
    description: 'Capitalized current lump-sum value required to fund n periodic withdrawals.',
    variables: [
      { name: 'PMT', desc: 'Periodic annuity withdrawal' },
      { name: 'n', desc: 'Number of withdrawal periods' }
    ]
  },
  {
    title: 'Loan EMI (Equated Monthly Installment)',
    category: 'Loans & Credit',
    latex: 'EMI = P \\cdot i \\cdot \\frac{(1 + i)^n}{(1 + i)^n - 1}',
    description: 'Equal monthly payment amortizing principal balance P to zero over n months.',
    variables: [
      { name: 'i', desc: 'Monthly interest rate = Annual Rate / 1200' },
      { name: 'n', desc: 'Loan duration in months' }
    ]
  },
  {
    title: 'Compound Annual Growth Rate (CAGR)',
    category: 'Growth & Metrics',
    latex: '\\text{CAGR} = \\left(\\frac{V_{\\text{end}}}{V_{\\text{start}}}\\right)^{\\frac{1}{t}} - 1',
    description: 'Mean annual growth rate of an investment over a multi-year horizon.',
    variables: [
      { name: 'V_start', desc: 'Initial asset value' },
      { name: 'V_end', desc: 'Final valuation' },
      { name: 't', desc: 'Holding period in years' }
    ]
  },
  {
    title: 'Break-Even Point (Quantity & Revenue)',
    category: 'Corporate & Management',
    latex: 'Q_{\\text{BE}} = \\frac{FC}{P - VC}, \\quad R_{\\text{BE}} = Q_{\\text{BE}} \\cdot P',
    description: 'The sales volume where total revenue exactly covers fixed and variable expenses.',
    variables: [
      { name: 'FC', desc: 'Total fixed costs' },
      { name: 'P', desc: 'Selling price per unit' },
      { name: 'VC', desc: 'Variable expense per unit' },
      { name: 'P - VC', desc: 'Unit contribution margin' }
    ]
  },
  {
    title: 'Gross Margin & Markup',
    category: 'Corporate & Management',
    latex: '\\text{Margin} = \\frac{SP - CP}{SP}, \\quad \\text{Markup} = \\frac{SP - CP}{CP}',
    description: 'Profitability ratios relative to selling price (margin) and cost price (markup).',
    variables: [
      { name: 'SP', desc: 'Selling price' },
      { name: 'CP', desc: 'Cost of goods sold (COGS)' }
    ]
  },
  {
    title: 'Straight-Line Depreciation',
    category: 'Depreciation',
    latex: 'D = \\frac{\\text{Cost} - \\text{Salvage}}{\\text{Useful Life}}',
    description: 'Constant annual expense charged against an asset over its operating lifetime.',
    variables: [
      { name: 'Cost', desc: 'Historical asset acquisition cost' },
      { name: 'Salvage', desc: 'Estimated residual salvage value' }
    ]
  },
  {
    title: 'Double Declining Balance (DDB)',
    category: 'Depreciation',
    latex: 'D_t = \\text{BookValue}_{t-1} \\cdot \\left(\\frac{2}{\\text{Life}}\\right)',
    description: 'Accelerated depreciation front-loading deductions during early years.',
    variables: [
      { name: 'BookValue', desc: 'Net carrying balance of asset' },
      { name: '2/Life', desc: 'Twice the straight-line rate' }
    ]
  },
  {
    title: 'Rule of 72 (Doubling Time)',
    category: 'Growth & Metrics',
    latex: 'T_{\\text{double}} \\approx \\frac{72}{r_{\\%}}',
    description: 'Quick heuristic estimation of the years required to double money at compound rate r.',
    variables: [
      { name: 'r_%', desc: 'Annual compounding rate percentage' }
    ]
  }
];
