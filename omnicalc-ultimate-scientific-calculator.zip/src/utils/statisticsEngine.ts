export interface SummaryStats {
  count: number;
  mean: number;
  median: number;
  mode: number[];
  sum: number;
  varianceSample: number;
  variancePop: number;
  stdevSample: number;
  stdevPop: number;
  min: number;
  max: number;
  range: number;
  q1: number;
  q3: number;
  iqr: number;
}

export function calculateSummaryStats(data: number[]): SummaryStats | null {
  if (!data || data.length === 0) return null;
  const sorted = [...data].sort((a, b) => a - b);
  const n = sorted.length;
  const sum = sorted.reduce((acc, val) => acc + val, 0);
  const mean = sum / n;

  // Median
  const median = n % 2 === 0 ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 : sorted[Math.floor(n / 2)];

  // Mode
  const counts: Record<number, number> = {};
  let maxCount = 0;
  for (const num of sorted) {
    counts[num] = (counts[num] || 0) + 1;
    if (counts[num] > maxCount) maxCount = counts[num];
  }
  const mode = maxCount > 1 ? Object.keys(counts).filter(k => counts[Number(k)] === maxCount).map(Number) : [];

  // Variance & Stdev
  const sumSqDiff = sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
  const variancePop = sumSqDiff / n;
  const varianceSample = n > 1 ? sumSqDiff / (n - 1) : 0;
  const stdevPop = Math.sqrt(variancePop);
  const stdevSample = Math.sqrt(varianceSample);

  // Quartiles
  const getPercentile = (p: number) => {
    const pos = (n - 1) * p;
    const base = Math.floor(pos);
    const rest = pos - base;
    if (sorted[base + 1] !== undefined) {
      return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
    }
    return sorted[base];
  };

  const q1 = getPercentile(0.25);
  const q3 = getPercentile(0.75);
  const iqr = q3 - q1;

  return {
    count: n,
    mean: parseFloat(mean.toFixed(6)),
    median: parseFloat(median.toFixed(6)),
    mode,
    sum: parseFloat(sum.toFixed(6)),
    varianceSample: parseFloat(varianceSample.toFixed(6)),
    variancePop: parseFloat(variancePop.toFixed(6)),
    stdevSample: parseFloat(stdevSample.toFixed(6)),
    stdevPop: parseFloat(stdevPop.toFixed(6)),
    min: sorted[0],
    max: sorted[n - 1],
    range: sorted[n - 1] - sorted[0],
    q1: parseFloat(q1.toFixed(6)),
    q3: parseFloat(q3.toFixed(6)),
    iqr: parseFloat(iqr.toFixed(6))
  };
}

// Linear Regression: y = mx + b
export interface LinearRegressionResult {
  slope: number;
  intercept: number;
  r: number;
  r2: number;
  equation: string;
}

export function linearRegression(xArr: number[], yArr: number[]): LinearRegressionResult | null {
  const n = Math.min(xArr.length, yArr.length);
  if (n < 2) return null;

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
  for (let i = 0; i < n; i++) {
    const x = xArr[i];
    const y = yArr[i];
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumX2 += x * x;
    sumY2 += y * y;
  }

  const denom = n * sumX2 - sumX * sumX;
  if (Math.abs(denom) < 1e-12) return null;

  const slope = (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;

  // Pearson r
  const rDenom = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
  const r = rDenom === 0 ? 0 : (n * sumXY - sumX * sumY) / rDenom;
  const r2 = r * r;

  const sign = intercept >= 0 ? '+ ' : '- ';
  return {
    slope: parseFloat(slope.toFixed(6)),
    intercept: parseFloat(intercept.toFixed(6)),
    r: parseFloat(r.toFixed(6)),
    r2: parseFloat(r2.toFixed(6)),
    equation: `y = ${parseFloat(slope.toFixed(4))}x ${sign}${Math.abs(parseFloat(intercept.toFixed(4)))}`
  };
}

// Error function erf for normal distribution
export function erf(x: number): number {
  // Abramowitz and Stegun formula 7.1.26
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x);
  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);
  return sign * y;
}

// Normal Distribution: mu, sigma
export function normalPDF(x: number, mu: number = 0, sigma: number = 1): number {
  if (sigma <= 0) return 0;
  return (1 / (sigma * Math.sqrt(2 * Math.PI))) * Math.exp(-0.5 * Math.pow((x - mu) / sigma, 2));
}

export function normalCDF(x: number, mu: number = 0, sigma: number = 1): number {
  if (sigma <= 0) return 0;
  return 0.5 * (1 + erf((x - mu) / (sigma * Math.sqrt(2))));
}

// Binomial PMF: nCk * p^k * (1-p)^(n-k)
export function binomialPMF(n: number, k: number, p: number): number {
  if (k < 0 || k > n || p < 0 || p > 1) return 0;
  // Compute log combinations for numerical stability
  const logFact = (m: number) => {
    let sum = 0;
    for (let i = 1; i <= m; i++) sum += Math.log(i);
    return sum;
  };
  const logComb = logFact(n) - logFact(k) - logFact(n - k);
  const logProb = logComb + k * Math.log(p) + (n - k) * Math.log(1 - p);
  return Math.exp(logProb);
}

// Poisson PMF: (lambda^k * e^-lambda) / k!
export function poissonPMF(lambda: number, k: number): number {
  if (lambda <= 0 || k < 0) return 0;
  let logFact = 0;
  for (let i = 1; i <= k; i++) logFact += Math.log(i);
  return Math.exp(k * Math.log(lambda) - lambda - logFact);
}

// 1-sample Z-test
export function zTestOneSample(sampleMean: number, popMean: number, popStdev: number, n: number): {
  zScore: number;
  pValueTwoTail: number;
} {
  const se = popStdev / Math.sqrt(n);
  const z = (sampleMean - popMean) / se;
  const pOneTail = 1 - normalCDF(Math.abs(z));
  return {
    zScore: parseFloat(z.toFixed(4)),
    pValueTwoTail: parseFloat((2 * pOneTail).toFixed(6))
  };
}

// Monte Carlo Simulation of an expression over N trials
export function runMonteCarlo(
  evaluateFn: () => number,
  trials: number = 5000
): { mean: number; stdev: number; min: number; max: number; samples: number[] } {
  const samples: number[] = [];
  let sum = 0;
  let min = Infinity;
  let max = -Infinity;

  for (let i = 0; i < trials; i++) {
    const val = evaluateFn();
    samples.push(val);
    sum += val;
    if (val < min) min = val;
    if (val > max) max = val;
  }

  const mean = sum / trials;
  const varSum = samples.reduce((acc, v) => acc + (v - mean) ** 2, 0);
  const stdev = Math.sqrt(varSum / trials);

  return {
    mean: parseFloat(mean.toFixed(5)),
    stdev: parseFloat(stdev.toFixed(5)),
    min: parseFloat(min.toFixed(5)),
    max: parseFloat(max.toFixed(5)),
    samples: samples.slice(0, 100) // First 100 for display
  };
}
