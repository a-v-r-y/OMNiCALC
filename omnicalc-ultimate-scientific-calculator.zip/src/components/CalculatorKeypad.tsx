import React, { useState } from 'react';
import { playClickSound, playActionSound, playEqualsSound } from '../utils/audioFeedback';

interface CalculatorKeypadProps {
  onInsert: (val: string) => void;
  onClear: () => void;
  onBackspace: () => void;
  onEvaluate: () => void;
  onAns: () => void;
  onSmartBrackets?: () => void;
  onSquareBrackets?: (curly?: boolean) => void;
  onMemoryAdd?: () => void;
  onMemorySub?: () => void;
  onMemoryRecall?: () => void;
  onMemoryClear?: () => void;
}

export const CalculatorKeypad: React.FC<CalculatorKeypadProps> = ({
  onInsert,
  onClear,
  onBackspace,
  onEvaluate,
  onAns,
  onSmartBrackets,
  onSquareBrackets,
  onMemoryAdd,
  onMemorySub,
  onMemoryRecall,
  onMemoryClear
}) => {
  const [isSecond, setIsSecond] = useState(false);
  const [isHyp, setIsHyp] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'standard' | 'trig' | 'calculus_algebra' | 'discrete_constants'>('standard');

  const insert = (str: string) => {
    playClickSound();
    onInsert(str);
  };

  const handleClear = () => {
    playActionSound();
    onClear();
  };

  const handleBackspace = () => {
    playActionSound();
    onBackspace();
  };

  const handleEvaluate = () => {
    playEqualsSound();
    onEvaluate();
  };

  const handleAns = () => {
    playClickSound();
    onAns();
  };

  const btnBase =
    'relative select-none font-medium transition-all duration-150 active:scale-95 rounded-lg flex items-center justify-center text-sm sm:text-base border shadow-sm cursor-pointer';
  const numBtn = `${btnBase} bg-slate-800/90 hover:bg-slate-750 text-slate-100 border-slate-700/80 hover:border-slate-600 hover:text-white`;
  const opBtn = `${btnBase} bg-indigo-950/70 hover:bg-indigo-900/80 text-indigo-200 border-indigo-800/60 hover:border-indigo-700`;
  const fnBtn = `${btnBase} bg-slate-900/90 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700 text-xs sm:text-sm`;
  const actionBtn = `${btnBase} bg-amber-950/60 hover:bg-amber-900/70 text-amber-300 border-amber-800/60 hover:border-amber-700`;
  const bracketBtn = `${btnBase} bg-slate-800/90 hover:bg-slate-750 text-indigo-200 hover:text-white border-slate-700/80 hover:border-indigo-500/50 font-mono font-semibold text-sm sm:text-base`;
  const equalsBtn = `${btnBase} bg-blue-600 hover:bg-blue-500 text-white font-semibold border-blue-500 shadow-blue-900/30 text-lg`;

  return (
    <div className="w-full flex flex-col gap-2.5">
      {/* Category Tabs & Modifiers */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-slate-800 text-xs">
        <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
          <button
            type="button"
            onClick={() => setActiveCategory('standard')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              activeCategory === 'standard' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Basic & Sci
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('trig')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              activeCategory === 'trig' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Trig & Hyp
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('calculus_algebra')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              activeCategory === 'calculus_algebra' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Calculus & CAS
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('discrete_constants')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              activeCategory === 'discrete_constants' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Discrete & Const
          </button>
        </div>

        {/* 2nd & Hyp toggles */}
        <div className="flex items-center gap-1.5 ml-auto">
          <button
            type="button"
            onClick={() => setIsSecond(!isSecond)}
            className={`px-2 py-0.5 rounded font-mono font-semibold text-xs border transition-colors ${
              isSecond
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
          >
            2nd
          </button>
          <button
            type="button"
            onClick={() => setIsHyp(!isHyp)}
            className={`px-2 py-0.5 rounded font-mono font-semibold text-xs border transition-colors ${
              isHyp
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/60'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
          >
            hyp
          </button>
        </div>
      </div>

      {/* Memory mini bar */}
      <div className="grid grid-cols-5 gap-1.5 text-xs text-slate-400">
        <button
          type="button"
          onClick={onMemoryClear}
          className="py-1 bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 rounded hover:text-slate-200"
          title="Memory Clear"
        >
          MC
        </button>
        <button
          type="button"
          onClick={onMemoryRecall}
          className="py-1 bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 rounded hover:text-slate-200"
          title="Memory Recall"
        >
          MR
        </button>
        <button
          type="button"
          onClick={onMemoryAdd}
          className="py-1 bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 rounded hover:text-slate-200"
          title="Memory Add"
        >
          M+
        </button>
        <button
          type="button"
          onClick={onMemorySub}
          className="py-1 bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 rounded hover:text-slate-200"
          title="Memory Subtract"
        >
          M−
        </button>
        <button
          type="button"
          onClick={handleAns}
          className="py-1 bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 rounded text-indigo-300 font-semibold"
          title="Previous Answer"
        >
          Ans
        </button>
      </div>

      {/* Dynamic Function Row based on Category */}
      <div className="grid grid-cols-5 gap-1.5">
        {activeCategory === 'standard' && (
          <>
            <button type="button" onClick={() => insert(isSecond ? '^3' : '^2')} className={fnBtn}>
              {isSecond ? 'x³' : 'x²'}
            </button>
            <button type="button" onClick={() => insert(isSecond ? 'cbrt(' : 'sqrt(')} className={fnBtn}>
              {isSecond ? '³√x' : '√x'}
            </button>
            <button type="button" onClick={() => insert('^')} className={fnBtn}>
              xⁿ
            </button>
            <button type="button" onClick={() => insert(isSecond ? '10^(' : 'log10(')} className={fnBtn}>
              {isSecond ? '10ˣ' : 'log₁₀'}
            </button>
            <button type="button" onClick={() => insert(isSecond ? 'e^(' : 'ln(')} className={fnBtn}>
              {isSecond ? 'eˣ' : 'ln'}
            </button>
            <button type="button" onClick={() => insert('(')} className={fnBtn}>
              (
            </button>
            <button type="button" onClick={() => insert(')')} className={fnBtn}>
              )
            </button>
            <button type="button" onClick={() => insert('1/(')} className={fnBtn}>
              1/x
            </button>
            <button type="button" onClick={() => insert('!')} className={fnBtn}>
              x!
            </button>
            <button type="button" onClick={() => insert('abs(')} className={fnBtn}>
              |x|
            </button>
          </>
        )}

        {activeCategory === 'trig' && (
          <>
            <button
              type="button"
              onClick={() => insert(isHyp ? (isSecond ? 'asinh(' : 'sinh(') : isSecond ? 'asin(' : 'sin(')}
              className={fnBtn}
            >
              {isHyp ? (isSecond ? 'sinh⁻¹' : 'sinh') : isSecond ? 'sin⁻¹' : 'sin'}
            </button>
            <button
              type="button"
              onClick={() => insert(isHyp ? (isSecond ? 'acosh(' : 'cosh(') : isSecond ? 'acos(' : 'cos(')}
              className={fnBtn}
            >
              {isHyp ? (isSecond ? 'cosh⁻¹' : 'cosh') : isSecond ? 'cos⁻¹' : 'cos'}
            </button>
            <button
              type="button"
              onClick={() => insert(isHyp ? (isSecond ? 'atanh(' : 'tanh(') : isSecond ? 'atan(' : 'tan(')}
              className={fnBtn}
            >
              {isHyp ? (isSecond ? 'tanh⁻¹' : 'tanh') : isSecond ? 'tan⁻¹' : 'tan'}
            </button>
            <button type="button" onClick={() => insert('sec(')} className={fnBtn}>
              sec
            </button>
            <button type="button" onClick={() => insert('csc(')} className={fnBtn}>
              csc
            </button>
            <button type="button" onClick={() => insert('cot(')} className={fnBtn}>
              cot
            </button>
            <button type="button" onClick={() => insert('pi')} className={fnBtn}>
              π
            </button>
            <button type="button" onClick={() => insert('deg')} className={fnBtn}>
              deg
            </button>
            <button type="button" onClick={() => insert('rad')} className={fnBtn}>
              rad
            </button>
            <button type="button" onClick={() => insert('atan2(')} className={fnBtn}>
              atan2
            </button>
          </>
        )}

        {activeCategory === 'calculus_algebra' && (
          <>
            <button type="button" onClick={() => insert('derivative("')} className={fnBtn} title="Symbolic derivative">
              d/dx
            </button>
            <button type="button" onClick={() => insert('simplify("')} className={fnBtn} title="Symbolic simplify">
              simplify
            </button>
            <button type="button" onClick={() => insert('x')} className={fnBtn}>
              x
            </button>
            <button type="button" onClick={() => insert('y')} className={fnBtn}>
              y
            </button>
            <button type="button" onClick={() => insert('z')} className={fnBtn}>
              z
            </button>
            <button type="button" onClick={() => insert('i')} className={fnBtn} title="Imaginary unit">
              i
            </button>
            <button type="button" onClick={() => insert('e')} className={fnBtn}>
              e
            </button>
            <button type="button" onClick={() => insert('sum(')} className={fnBtn}>
              Σ
            </button>
            <button type="button" onClick={() => insert('prod(')} className={fnBtn}>
              Π
            </button>
            <button type="button" onClick={() => insert('Infinity')} className={fnBtn}>
              ∞
            </button>
          </>
        )}

        {activeCategory === 'discrete_constants' && (
          <>
            <button type="button" onClick={() => insert('gcd(')} className={fnBtn}>
              gcd
            </button>
            <button type="button" onClick={() => insert('lcm(')} className={fnBtn}>
              lcm
            </button>
            <button type="button" onClick={() => insert('combinations(')} className={fnBtn}>
              nCr
            </button>
            <button type="button" onClick={() => insert('permutations(')} className={fnBtn}>
              nPr
            </button>
            <button type="button" onClick={() => insert('mod ')} className={fnBtn}>
              mod
            </button>
            <button type="button" onClick={() => insert('c')} className={fnBtn} title="Speed of light">
              c
            </button>
            <button type="button" onClick={() => insert('h')} className={fnBtn} title="Planck constant">
              h
            </button>
            <button type="button" onClick={() => insert('G')} className={fnBtn} title="Gravitational constant">
              G
            </button>
            <button type="button" onClick={() => insert('floor(')} className={fnBtn}>
              floor
            </button>
            <button type="button" onClick={() => insert('ceil(')} className={fnBtn}>
              ceil
            </button>
          </>
        )}
      </div>

      {/* Main Keypad Matrix: 4 columns */}
      <div className="grid grid-cols-4 gap-1.5 h-72 sm:h-80">
        {/* Row 0: Dedicated Brackets Controls */}
        <button
          id="btn-bracket-open"
          type="button"
          onClick={() => insert('(')}
          className={bracketBtn}
          title="Open Bracket ("
        >
          (
        </button>
        <button
          id="btn-bracket-close"
          type="button"
          onClick={() => insert(')')}
          className={bracketBtn}
          title="Close Bracket )"
        >
          )
        </button>
        <button
          id="btn-bracket-smart"
          type="button"
          onClick={() => (onSmartBrackets ? onSmartBrackets() : insert('('))}
          className={`${bracketBtn} bg-indigo-950/70 text-indigo-200 hover:bg-indigo-900/80 border-indigo-800/60 hover:border-indigo-600/70`}
          title="Brackets: Auto open/close or wrap selection"
        >
          <div className="flex items-center gap-1">
            <span className="font-mono font-bold text-sm sm:text-base">( )</span>
            <span className="text-[10px] text-indigo-300 font-sans hidden xs:inline uppercase tracking-tight font-medium">Brackets</span>
          </div>
        </button>
        <button
          id="btn-bracket-square"
          type="button"
          onClick={() => (onSquareBrackets ? onSquareBrackets(isSecond) : insert(isSecond ? '{' : '['))}
          className={bracketBtn}
          title={isSecond ? 'Curly Braces { }' : 'Square Brackets [ ]'}
        >
          {isSecond ? '{ }' : '[ ]'}
        </button>

        {/* Row 1 */}
        <button id="btn-calc-ac" type="button" onClick={handleClear} className={actionBtn} title="All Clear">
          AC
        </button>
        <button id="btn-calc-backspace" type="button" onClick={handleBackspace} className={actionBtn} title="Backspace">
          ⌫
        </button>
        <button id="btn-calc-percent" type="button" onClick={() => insert('%')} className={opBtn} title="Percentage">
          %
        </button>
        <button id="btn-calc-divide" type="button" onClick={() => insert(' / ')} className={opBtn} title="Divide">
          ÷
        </button>

        {/* Row 2 */}
        <button type="button" onClick={() => insert('7')} className={numBtn}>
          7
        </button>
        <button type="button" onClick={() => insert('8')} className={numBtn}>
          8
        </button>
        <button type="button" onClick={() => insert('9')} className={numBtn}>
          9
        </button>
        <button type="button" onClick={() => insert(' * ')} className={opBtn}>
          ×
        </button>

        {/* Row 3 */}
        <button type="button" onClick={() => insert('4')} className={numBtn}>
          4
        </button>
        <button type="button" onClick={() => insert('5')} className={numBtn}>
          5
        </button>
        <button type="button" onClick={() => insert('6')} className={numBtn}>
          6
        </button>
        <button type="button" onClick={() => insert(' - ')} className={opBtn}>
          −
        </button>

        {/* Row 4 */}
        <button type="button" onClick={() => insert('1')} className={numBtn}>
          1
        </button>
        <button type="button" onClick={() => insert('2')} className={numBtn}>
          2
        </button>
        <button type="button" onClick={() => insert('3')} className={numBtn}>
          3
        </button>
        <button type="button" onClick={() => insert(' + ')} className={opBtn}>
          +
        </button>

        {/* Row 5 */}
        <button type="button" onClick={() => insert('0')} className={numBtn}>
          0
        </button>
        <button type="button" onClick={() => insert('.')} className={numBtn}>
          .
        </button>
        <button type="button" onClick={() => insert('(-)')} className={numBtn} title="Sign change">
          ±
        </button>
        <button type="button" onClick={handleEvaluate} className={equalsBtn} title="Evaluate expression">
          =
        </button>
      </div>
    </div>
  );
};
