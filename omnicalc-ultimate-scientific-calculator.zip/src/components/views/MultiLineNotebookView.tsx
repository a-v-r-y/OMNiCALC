import React, { useState, useEffect } from 'react';
import { AngleUnit, PrecisionMode, MultiLineStatement } from '../../types/calc';
import { evaluateExpression } from '../../utils/mathEngine';
import { MathView } from '../MathView';
import {
  Play,
  Plus,
  Trash2,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  BookOpen,
  Download,
  Share2
} from 'lucide-react';

interface MultiLineNotebookViewProps {
  angleUnit: AngleUnit;
  precision: PrecisionMode;
  onInsertToMain?: (expr: string) => void;
}

const TEMPLATES: { name: string; lines: string[] }[] = [
  {
    name: 'Cylinder Volume & Surface',
    lines: ['r = 8', 'h = 20', 'baseArea = pi * r^2', 'volume = baseArea * h', 'lateralArea = 2 * pi * r * h', 'totalArea = 2 * baseArea + lateralArea']
  },
  {
    name: 'Kinematics Free Fall',
    lines: ['g = 9.80665', 't = 4.5', 'v0 = 12', 'vFinal = v0 + g * t', 'displacement = v0 * t + 0.5 * g * t^2']
  },
  {
    name: 'Compound Interest',
    lines: ['P = 5000', 'r = 0.065', 'n = 12', 't = 5', 'A = P * (1 + r / n)^(n * t)', 'totalInterest = A - P']
  },
  {
    name: 'Quadratic Roots',
    lines: ['a = 2', 'b = -7', 'c = 3', 'discriminant = b^2 - 4 * a * c', 'x1 = (-b + sqrt(discriminant)) / (2 * a)', 'x2 = (-b - sqrt(discriminant)) / (2 * a)']
  }
];

export const MultiLineNotebookView: React.FC<MultiLineNotebookViewProps> = ({
  angleUnit,
  precision,
  onInsertToMain
}) => {
  const [statements, setStatements] = useState<MultiLineStatement[]>([
    { id: '1', expression: 'radius = 12', result: '12' },
    { id: '2', expression: 'height = 25', result: '25' },
    { id: '3', expression: 'volume = pi * radius^2 * height', result: '11309.7335529' },
    { id: '4', expression: 'mass = volume * 2.7', result: '30536.280593' }
  ]);

  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Evaluate all statements in sequence with cascading scope
  const evaluateAll = () => {
    let currentScope: Record<string, any> = {};
    const updated = statements.map(stmt => {
      if (!stmt.expression.trim()) {
        return { ...stmt, result: '', error: undefined, latex: undefined };
      }

      const res = evaluateExpression(stmt.expression, currentScope, angleUnit, precision);

      if (res.success) {
        // If it was an assignment like x = 10, mathjs handles it in scope
        return {
          ...stmt,
          result: res.resultString,
          latex: res.latex,
          error: undefined
        };
      } else {
        return {
          ...stmt,
          result: '',
          error: res.error || 'Syntax error'
        };
      }
    });

    setStatements(updated);
  };

  useEffect(() => {
    evaluateAll();
  }, [angleUnit, precision]);

  const handleUpdateExpr = (id: string, newExpr: string) => {
    setStatements(prev =>
      prev.map(s => (s.id === id ? { ...s, expression: newExpr } : s))
    );
  };

  const handleAddLine = (index?: number) => {
    const newStmt: MultiLineStatement = {
      id: Date.now().toString() + Math.random().toString(36).substring(2, 5),
      expression: '',
      result: ''
    };

    if (index !== undefined) {
      const next = [...statements];
      next.splice(index + 1, 0, newStmt);
      setStatements(next);
    } else {
      setStatements(prev => [...prev, newStmt]);
    }
  };

  const handleRemoveLine = (id: string) => {
    if (statements.length <= 1) {
      setStatements([{ id: '1', expression: '', result: '' }]);
      return;
    }
    setStatements(prev => prev.filter(s => s.id !== id));
  };

  const handleLoadTemplate = (lines: string[]) => {
    const newStmts: MultiLineStatement[] = lines.map((l, i) => ({
      id: (i + 1).toString(),
      expression: l,
      result: ''
    }));
    setStatements(newStmts);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleExportNotebook = () => {
    const content = statements
      .map((s, idx) => `Line ${idx + 1}: ${s.expression} => ${s.result}`)
      .join('\n');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `omnicalc_notebook_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Top Banner & Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">
              Multi-Line Mathematical Notebook
            </h2>
            <p className="text-xs text-slate-400 font-sans">
              Evaluate multi-statement systems with cascading variable scope and natural textbook rendering
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Templates Dropdown */}
          <select
            onChange={e => {
              const tmpl = TEMPLATES.find(t => t.name === e.target.value);
              if (tmpl) handleLoadTemplate(tmpl.lines);
            }}
            defaultValue=""
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 font-sans focus:outline-none"
          >
            <option value="" disabled>
              Load Example Template...
            </option>
            {TEMPLATES.map(t => (
              <option key={t.name} value={t.name}>
                {t.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={evaluateAll}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Run All</span>
          </button>

          <button
            type="button"
            onClick={handleExportNotebook}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs transition-colors"
            title="Export Notebook"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Multi-Line Statements Sheet */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col gap-3">
        <div className="divide-y divide-slate-800/80">
          {statements.map((stmt, idx) => (
            <div
              key={stmt.id}
              className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
            >
              {/* Line Index & Input */}
              <div className="flex items-center gap-3 flex-1">
                <span className="font-mono text-xs font-bold text-slate-500 w-7 text-right select-none">
                  {idx + 1}
                </span>

                <div className="flex-1 flex flex-col gap-1">
                  <input
                    type="text"
                    value={stmt.expression}
                    onChange={e => handleUpdateExpr(stmt.id, e.target.value)}
                    onBlur={evaluateAll}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        evaluateAll();
                        handleAddLine(idx);
                      }
                    }}
                    placeholder={`e.g. y${idx + 1} = 2 * x + 5`}
                    className="w-full bg-slate-950/80 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-sm font-mono text-white placeholder-slate-600 focus:outline-none"
                  />

                  {/* Textbook Math Notation Preview */}
                  {stmt.latex && (
                    <div className="text-xs text-slate-400 pl-1 overflow-x-auto">
                      <MathView math={stmt.latex} rawText={stmt.expression} />
                    </div>
                  )}

                  {stmt.error && (
                    <span className="text-[11px] font-mono text-rose-400 pl-1">
                      {stmt.error}
                    </span>
                  )}
                </div>
              </div>

              {/* Output Result */}
              <div className="flex items-center justify-end gap-3 pl-10 sm:pl-0 shrink-0">
                <div className="flex items-baseline gap-1.5 font-mono">
                  <span className="text-xs text-slate-500">=</span>
                  <span className="text-base font-bold text-emerald-400">
                    {stmt.result || '—'}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {stmt.result && (
                    <button
                      type="button"
                      onClick={() => handleCopy(stmt.id, stmt.result)}
                      className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                      title="Copy result"
                    >
                      {copiedId === stmt.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleRemoveLine(stmt.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-950/30 transition-colors"
                    title="Delete line"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Line Button */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={() => handleAddLine()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-medium transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Equation Line</span>
          </button>

          <span className="text-[11px] font-mono text-slate-500">
            Press <kbd className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded">Enter</kbd> to execute and jump to next line
          </span>
        </div>
      </div>
    </div>
  );
};
