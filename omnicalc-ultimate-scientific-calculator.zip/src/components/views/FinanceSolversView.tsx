import React, { useState } from 'react';
import {
  calculateSimpleInterest,
  calculateCompoundInterest,
  calculatePV,
  calculateFV,
  calculateAnnuity,
  calculateAmortizationSchedule,
  calculateDepreciation,
  calculateProfitLoss,
  calculatePercentageChange,
  calculateCAGR,
  calculateBreakEven,
  FINANCIAL_FORMULAS,
  CompoundingFrequency,
  DepreciationMethod
} from '../../utils/financialSolvers';
import { MathView } from '../MathView';
import {
  DollarSign,
  TrendingUp,
  Percent,
  Calendar,
  Layers,
  ArrowRightLeft,
  PieChart,
  BookOpen,
  Calculator,
  Download,
  Check,
  Building2,
  Receipt
} from 'lucide-react';

export type FinanceTab =
  | 'loans_emi'
  | 'interest'
  | 'tvm'
  | 'annuities'
  | 'depreciation'
  | 'profit_loss'
  | 'percent_cagr'
  | 'breakeven'
  | 'formulas';

export const FinanceSolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<FinanceTab>('loans_emi');

  // 1. Loans & EMI Amortization State
  const [loanP, setLoanP] = useState<number>(300000);
  const [loanRate, setLoanRate] = useState<number>(6.5);
  const [loanYears, setLoanYears] = useState<number>(30);
  const [extraPayment, setExtraPayment] = useState<number>(0);
  const [amortizationView, setAmortizationView] = useState<'yearly' | 'monthly'>('yearly');
  const [copiedSchedule, setCopiedSchedule] = useState<boolean>(false);

  const amortResult = calculateAmortizationSchedule(loanP, loanRate, loanYears * 12, extraPayment);

  // 2. Simple & Compound Interest State
  const [intMode, setIntMode] = useState<'compound' | 'simple'>('compound');
  const [intPrincipal, setIntPrincipal] = useState<number>(10000);
  const [intRate, setIntRate] = useState<number>(7.5);
  const [intYears, setIntYears] = useState<number>(10);
  const [intFreq, setIntFreq] = useState<CompoundingFrequency>(12);
  const [monthlyAddition, setMonthlyAddition] = useState<number>(250);

  const simpleResult = calculateSimpleInterest(intPrincipal, intRate, intYears);
  const compoundResult = calculateCompoundInterest(
    intPrincipal,
    intRate,
    intYears,
    intFreq,
    monthlyAddition
  );

  // 3. Present & Future Value State
  const [tvmMode, setTvmMode] = useState<'pv' | 'fv'>('pv');
  const [tvmAmount, setTvmAmount] = useState<number>(50000);
  const [tvmRate, setTvmRate] = useState<number>(6);
  const [tvmYears, setTvmYears] = useState<number>(5);
  const [tvmCompounding, setTvmCompounding] = useState<number>(1);

  const pvResult = calculatePV(tvmAmount, tvmRate, tvmYears, tvmCompounding);
  const fvResult = calculateFV(tvmAmount, tvmRate, tvmYears, tvmCompounding);

  // 4. Annuities State
  const [annPayment, setAnnPayment] = useState<number>(500);
  const [annRate, setAnnRate] = useState<number>(6.5);
  const [annPeriods, setAnnPeriods] = useState<number>(60);
  const [annFreq, setAnnFreq] = useState<number>(12);
  const [annIsDue, setAnnIsDue] = useState<boolean>(false);

  const annuityResult = calculateAnnuity(annPayment, annRate, annPeriods, annFreq, annIsDue);

  // 5. Depreciation State
  const [deprCost, setDeprCost] = useState<number>(50000);
  const [deprSalvage, setDeprSalvage] = useState<number>(5000);
  const [deprLife, setDeprLife] = useState<number>(5);
  const [deprMethod, setDeprMethod] = useState<DepreciationMethod>('straight_line');

  const deprResult = calculateDepreciation(deprCost, deprSalvage, deprLife, deprMethod);

  // 6. Profit / Loss & Margin / Markup State
  const [costPrice, setCostPrice] = useState<number>(120);
  const [sellingPrice, setSellingPrice] = useState<number>(165);
  const [plUnits, setPlUnits] = useState<number>(100);

  const plResult = calculateProfitLoss(costPrice, sellingPrice, plUnits);

  // 7. Percentage Change & CAGR State
  const [changeV1, setChangeV1] = useState<number>(2500);
  const [changeV2, setChangeV2] = useState<number>(3450);

  const [cagrV1, setCagrV1] = useState<number>(10000);
  const [cagrV2, setCagrV2] = useState<number>(26000);
  const [cagrYears, setCagrYears] = useState<number>(7);

  const pctChangeResult = calculatePercentageChange(changeV1, changeV2);
  const cagrResult = calculateCAGR(cagrV1, cagrV2, cagrYears);

  // 8. Break-Even Calculations State
  const [beFixedCost, setBeFixedCost] = useState<number>(45000);
  const [beVarCost, setBeVarCost] = useState<number>(22);
  const [bePrice, setBePrice] = useState<number>(55);
  const [beTargetProfit, setBeTargetProfit] = useState<number>(20000);

  const beResult = calculateBreakEven(beFixedCost, beVarCost, bePrice, beTargetProfit);

  // Export Amortization Table
  const handleExportAmortization = () => {
    let csv = 'Period,Starting Balance,Payment,Principal Paid,Interest Paid,Ending Balance,Total Interest\n';
    amortResult.schedule.forEach(r => {
      csv += `${r.period},${r.startingBalance},${r.payment},${r.principalPaid},${r.interestPaid},${r.endingBalance},${r.totalInterestPaid}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loan_amortization_schedule_${loanP}_${loanYears}yr.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setCopiedSchedule(true);
    setTimeout(() => setCopiedSchedule(false), 2000);
  };

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Financial Modules Navigation */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('loans_emi')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'loans_emi'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-indigo-300" />
          Loans, EMI & Amortization
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('interest')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'interest'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-emerald-300" />
          Simple & Compound Interest
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('tvm')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'tvm'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5 text-blue-300" />
          Present & Future Value (PV/FV)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('annuities')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'annuities'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 text-amber-300" />
          Annuities
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('depreciation')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'depreciation'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-cyan-300" />
          Depreciation (SL, DDB, SYD)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('profit_loss')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'profit_loss'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Receipt className="w-3.5 h-3.5 text-rose-300" />
          Profit / Loss, Margin & Markup
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('percent_cagr')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'percent_cagr'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Percent className="w-3.5 h-3.5 text-purple-300" />
          Percentage Change & CAGR
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('breakeven')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'breakeven'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <PieChart className="w-3.5 h-3.5 text-orange-300" />
          Break-Even Analysis
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('formulas')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'formulas'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-teal-300" />
          Financial Formulas Sheet
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: LOANS, EMI & AMORTIZATION
          ========================================================================= */}
      {activeTab === 'loans_emi' && (
        <div className="flex flex-col gap-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Input card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-semibold text-sm text-slate-200 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-indigo-400" />
                  Loan & Mortgage Parameters
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  Amortized EMI
                </span>
              </div>

              <div className="flex flex-col gap-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-400 mb-1 font-medium">
                    <span>Principal Amount ($)</span>
                    <span className="font-mono text-white">${loanP.toLocaleString()}</span>
                  </div>
                  <input
                    type="number"
                    value={loanP}
                    min="100"
                    step="1000"
                    onChange={e => setLoanP(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block mb-1 font-medium">Interest Rate (% p.a.)</span>
                    <input
                      type="number"
                      value={loanRate}
                      min="0"
                      max="100"
                      step="0.05"
                      onChange={e => setLoanRate(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1 font-medium">Loan Term (Years)</span>
                    <input
                      type="number"
                      value={loanYears}
                      min="1"
                      max="50"
                      onChange={e => setLoanYears(Math.max(1, parseInt(e.target.value, 10) || 1))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1 font-medium">
                    <span>Extra Monthly Payment (optional)</span>
                    <span className="font-mono text-emerald-400">+${extraPayment}</span>
                  </div>
                  <input
                    type="number"
                    value={extraPayment}
                    min="0"
                    step="50"
                    onChange={e => setExtraPayment(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                    placeholder="e.g. 100"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 flex flex-col gap-1">
                <span className="text-slate-300 font-semibold">Standard EMI Formula:</span>
                <MathView math="EMI = P \cdot i \cdot \frac{(1 + i)^n}{(1 + i)^n - 1}" block />
              </div>
            </div>

            {/* Metric Summary Cards */}
            <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Monthly Installment (EMI)</span>
                  <div className="text-3xl font-extrabold text-indigo-400 mt-1 font-mono">
                    ${amortResult.monthlyEMI.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Base monthly payment for {loanYears * 12} installments
                  </span>
                </div>

                {extraPayment > 0 && (
                  <div className="mt-4 p-2.5 bg-emerald-950/40 border border-emerald-800/40 rounded-xl text-xs text-emerald-300">
                    <span className="font-semibold">Early Payoff Impact:</span> Paid off in{' '}
                    <span className="font-bold font-mono">{amortResult.payoffMonths}</span> months (saved{' '}
                    <span className="font-bold font-mono">
                      {loanYears * 12 - amortResult.payoffMonths}
                    </span>{' '}
                    months & <span className="font-bold font-mono">${amortResult.interestSavings.toLocaleString()}</span> in interest)!
                  </div>
                )}
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Total Interest Payable</span>
                  <div className="text-3xl font-extrabold text-amber-400 mt-1 font-mono">
                    ${amortResult.totalInterest.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    {((amortResult.totalInterest / loanP) * 100).toFixed(1)}% of original principal balance
                  </span>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Total Out-of-Pocket:</span>
                  <span className="font-bold text-white">${amortResult.totalPayment.toLocaleString()}</span>
                </div>
              </div>

              {/* Progress bar visual: Principal vs Interest ratio */}
              <div className="sm:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-3">
                <span className="text-xs text-slate-400 font-medium flex items-center justify-between">
                  <span>Repayment Composition</span>
                  <span className="text-slate-500 font-mono">
                    Principal: {((loanP / amortResult.totalPayment) * 100).toFixed(1)}% | Interest:{' '}
                    {((amortResult.totalInterest / amortResult.totalPayment) * 100).toFixed(1)}%
                  </span>
                </span>
                <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
                  <div
                    style={{ width: `${(loanP / amortResult.totalPayment) * 100}%` }}
                    className="bg-indigo-600 h-full transition-all duration-500"
                    title="Principal"
                  />
                  <div
                    style={{ width: `${(amortResult.totalInterest / amortResult.totalPayment) * 100}%` }}
                    className="bg-amber-500 h-full transition-all duration-500"
                    title="Interest"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block" />
                    <span>Principal: ${loanP.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                    <span>Interest: ${amortResult.totalInterest.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Full Amortization Schedule Table */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="font-semibold text-sm text-slate-200">
                  Amortization Breakdown Schedule
                </span>
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setAmortizationView('yearly')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                      amortizationView === 'yearly'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Annual Summary
                  </button>
                  <button
                    type="button"
                    onClick={() => setAmortizationView('monthly')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                      amortizationView === 'monthly'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Monthly Schedule ({amortResult.schedule.length} mo)
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={handleExportAmortization}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white text-xs font-medium transition-colors border border-slate-700/60"
              >
                {copiedSchedule ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    CSV Exported!
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" />
                    Export CSV Schedule
                  </>
                )}
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto max-h-96 rounded-xl border border-slate-800/80">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-950 sticky top-0 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">{amortizationView === 'yearly' ? 'Year' : 'Month'}</th>
                    {amortizationView === 'monthly' && <th className="p-2.5">Start Balance</th>}
                    {amortizationView === 'monthly' && <th className="p-2.5">Payment</th>}
                    <th className="p-2.5 text-indigo-300">Principal Paid</th>
                    <th className="p-2.5 text-amber-300">Interest Paid</th>
                    <th className="p-2.5">Ending Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {amortizationView === 'yearly'
                    ? amortResult.yearlySummary.map(row => (
                        <tr key={row.year} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-2.5 font-bold text-white">Year {row.year}</td>
                          <td className="p-2.5 text-indigo-300">${row.principalPaid.toLocaleString()}</td>
                          <td className="p-2.5 text-amber-300">${row.interestPaid.toLocaleString()}</td>
                          <td className="p-2.5 font-semibold text-white">
                            ${row.endingBalance.toLocaleString()}
                          </td>
                        </tr>
                      ))
                    : amortResult.schedule.map(row => (
                        <tr key={row.period} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-2.5 font-semibold text-white">#{row.period}</td>
                          <td className="p-2.5">${row.startingBalance.toLocaleString()}</td>
                          <td className="p-2.5">${row.payment.toLocaleString()}</td>
                          <td className="p-2.5 text-indigo-300">${row.principalPaid.toLocaleString()}</td>
                          <td className="p-2.5 text-amber-300">${row.interestPaid.toLocaleString()}</td>
                          <td className="p-2.5 text-white font-semibold">
                            ${row.endingBalance.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: SIMPLE & COMPOUND INTEREST
          ========================================================================= */}
      {activeTab === 'interest' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Controls */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Interest Engine</span>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setIntMode('compound')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    intMode === 'compound'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Compound
                </button>
                <button
                  type="button"
                  onClick={() => setIntMode('simple')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    intMode === 'simple'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Simple
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Initial Principal ($)</span>
                <input
                  type="number"
                  value={intPrincipal}
                  min="0"
                  step="500"
                  onChange={e => setIntPrincipal(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Annual Rate (% p.a.)</span>
                  <input
                    type="number"
                    value={intRate}
                    min="0"
                    step="0.1"
                    onChange={e => setIntRate(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Duration (Years)</span>
                  <input
                    type="number"
                    value={intYears}
                    min="1"
                    max="100"
                    onChange={e => setIntYears(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {intMode === 'compound' && (
                <>
                  <div>
                    <span className="text-slate-400 block mb-1 font-medium">Compounding Frequency</span>
                    <select
                      value={intFreq}
                      onChange={e => setIntFreq(parseInt(e.target.value, 10) as CompoundingFrequency)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
                    >
                      <option value={1}>Annually (1x/yr)</option>
                      <option value={2}>Semi-Annually (2x/yr)</option>
                      <option value={4}>Quarterly (4x/yr)</option>
                      <option value={12}>Monthly (12x/yr)</option>
                      <option value={365}>Daily (365x/yr)</option>
                      <option value={0}>Continuously (e^rt)</option>
                    </select>
                  </div>

                  <div>
                    <span className="text-slate-400 block mb-1 font-medium">Monthly Contribution ($)</span>
                    <input
                      type="number"
                      value={monthlyAddition}
                      min="0"
                      step="50"
                      onChange={e => setMonthlyAddition(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                      placeholder="e.g. 200"
                    />
                  </div>
                </>
              )}
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Underlying Mathematical Model:</span>
              {intMode === 'compound' ? (
                <MathView math="A = P \left(1 + \frac{r}{n}\right)^{nt} + PMT \frac{(1 + r/n)^{nt} - 1}{r/n}" block />
              ) : (
                <MathView math="I = P \cdot r \cdot t, \quad A = P + I" block />
              )}
            </div>
          </div>

          {/* Results Summary */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Total Accumulated Balance</span>
                  <div className="text-3xl font-extrabold text-emerald-400 mt-1 font-mono">
                    $
                    {intMode === 'compound'
                      ? compoundResult.finalBalance.toLocaleString()
                      : simpleResult.totalAmount.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    After {intYears} years of interest accrual
                  </span>
                </div>
                {intMode === 'compound' && (
                  <div className="mt-3 text-xs text-slate-400 font-mono">
                    Effective APY:{' '}
                    <span className="text-indigo-400 font-bold">{compoundResult.effectiveAnnualRate}%</span>
                  </div>
                )}
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Total Interest Accrued</span>
                  <div className="text-3xl font-extrabold text-amber-400 mt-1 font-mono">
                    $
                    {intMode === 'compound'
                      ? compoundResult.totalInterest.toLocaleString()
                      : simpleResult.interest.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Total pure return over initial principal
                  </span>
                </div>
                <div className="mt-3 text-xs text-slate-400 font-mono">
                  Annual Simple Rate: <span className="text-white font-bold">{intRate}%</span>
                </div>
              </div>
            </div>

            {/* Growth Table */}
            {intMode === 'compound' && (
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-3">
                <span className="font-semibold text-sm text-slate-200">
                  Annual Growth Trajectory
                </span>
                <div className="overflow-x-auto max-h-72 rounded-xl border border-slate-800/80">
                  <table className="w-full text-left font-mono text-xs">
                    <thead className="bg-slate-950 sticky top-0 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2.5">Year</th>
                        <th className="p-2.5">Balance ($)</th>
                        <th className="p-2.5 text-amber-300">Cumulative Interest</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {compoundResult.breakdown.map(b => (
                        <tr key={b.year} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-2.5 font-bold text-white">Year {b.year}</td>
                          <td className="p-2.5 text-emerald-400 font-semibold">
                            ${b.balance.toLocaleString()}
                          </td>
                          <td className="p-2.5 text-amber-300">${b.interestEarned.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: PRESENT & FUTURE VALUE (TVM)
          ========================================================================= */}
      {activeTab === 'tvm' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Time Value of Money (TVM)</span>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setTvmMode('pv')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    tvmMode === 'pv'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Find PV
                </button>
                <button
                  type="button"
                  onClick={() => setTvmMode('fv')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    tvmMode === 'fv'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Find FV
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">
                  {tvmMode === 'pv' ? 'Future Target Value FV ($)' : 'Initial Present Value PV ($)'}
                </span>
                <input
                  type="number"
                  value={tvmAmount}
                  min="0"
                  step="1000"
                  onChange={e => setTvmAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Discount / Growth Rate (%)</span>
                  <input
                    type="number"
                    value={tvmRate}
                    min="0"
                    step="0.1"
                    onChange={e => setTvmRate(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Periods (Years)</span>
                  <input
                    type="number"
                    value={tvmYears}
                    min="1"
                    max="100"
                    onChange={e => setTvmYears(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Equation:</span>
              {tvmMode === 'pv' ? (
                <MathView math="PV = \frac{FV}{(1 + r)^t}" block />
              ) : (
                <MathView math="FV = PV (1 + r)^t" block />
              )}
            </div>
          </div>

          {/* Results card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              TVM Computation Result
            </span>

            <div className="my-auto py-6 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 font-medium">
                {tvmMode === 'pv' ? 'Calculated Present Value (PV)' : 'Calculated Future Value (FV)'}
              </span>
              <div className="text-4xl font-extrabold text-indigo-400 mt-2 font-mono">
                ${tvmMode === 'pv' ? pvResult.presentValue.toLocaleString() : fvResult.futureValue.toLocaleString()}
              </div>
              <span className="text-xs text-slate-500 mt-1">
                {tvmMode === 'pv'
                  ? `Required lump-sum today to reach $${tvmAmount.toLocaleString()} in ${tvmYears} years at ${tvmRate}%`
                  : `Future value of $${tvmAmount.toLocaleString()} invested today after ${tvmYears} years at ${tvmRate}%`}
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Multiplier / Factor:</span>
                <span className="text-white font-bold">
                  {tvmMode === 'pv' ? pvResult.discountFactor : fvResult.growthMultiplier}x
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Variance:</span>
                <span className="text-amber-400 font-bold">
                  ${tvmMode === 'pv' ? pvResult.totalDiscount.toLocaleString() : fvResult.totalGain.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: ANNUITIES
          ========================================================================= */}
      {activeTab === 'annuities' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Annuity Payouts & Streams</span>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setAnnIsDue(false)}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    !annIsDue ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Ordinary (End)
                </button>
                <button
                  type="button"
                  onClick={() => setAnnIsDue(true)}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    annIsDue ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Due (Beginning)
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Periodic Payment / Deposit ($)</span>
                <input
                  type="number"
                  value={annPayment}
                  min="0"
                  step="50"
                  onChange={e => setAnnPayment(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Interest Rate (% p.a.)</span>
                  <input
                    type="number"
                    value={annRate}
                    min="0"
                    step="0.1"
                    onChange={e => setAnnRate(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Total Periods (n)</span>
                  <input
                    type="number"
                    value={annPeriods}
                    min="1"
                    onChange={e => setAnnPeriods(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Frequency Per Year</span>
                <select
                  value={annFreq}
                  onChange={e => setAnnFreq(parseInt(e.target.value, 10) || 12)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
                >
                  <option value={12}>Monthly (12/year)</option>
                  <option value={4}>Quarterly (4/year)</option>
                  <option value={1}>Annual (1/year)</option>
                </select>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Annuity Formula:</span>
              <MathView math="FV = PMT \cdot \frac{(1 + r)^n - 1}{r} \cdot (1 + r)^{\text{due}}" block />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Annuity Valuation Summary
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-auto py-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs font-medium">Future Value (FV)</span>
                <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                  ${annuityResult.futureValue.toLocaleString()}
                </div>
                <span className="text-[11px] text-slate-500">Value of stream after all payments</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs font-medium">Present Value (PV)</span>
                <div className="text-2xl font-extrabold text-indigo-400 font-mono mt-1">
                  ${annuityResult.presentValue.toLocaleString()}
                </div>
                <span className="text-[11px] text-slate-500">Lump-sum needed today to fund stream</span>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Total Outlay (n × PMT):</span>
                <span className="text-white font-bold">${annuityResult.totalPayments.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Compound Interest:</span>
                <span className="text-amber-400 font-bold">
                  ${annuityResult.totalInterestFV.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: DEPRECIATION
          ========================================================================= */}
      {activeTab === 'depreciation' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Asset Depreciation Setup
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Asset Acquisition Cost ($)</span>
                <input
                  type="number"
                  value={deprCost}
                  min="0"
                  step="1000"
                  onChange={e => setDeprCost(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Salvage / Scrap Value ($)</span>
                  <input
                    type="number"
                    value={deprSalvage}
                    min="0"
                    step="500"
                    onChange={e => setDeprSalvage(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Useful Life (Years)</span>
                  <input
                    type="number"
                    value={deprLife}
                    min="1"
                    max="50"
                    onChange={e => setDeprLife(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Depreciation Method</span>
                <select
                  value={deprMethod}
                  onChange={e => setDeprMethod(e.target.value as DepreciationMethod)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
                >
                  <option value="straight_line">Straight-Line (Equal Annual Charge)</option>
                  <option value="double_declining">Double Declining Balance (DDB 200%)</option>
                  <option value="sum_of_years">Sum-of-Years' Digits (SYD)</option>
                </select>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Depreciable Base:</span>
              <div className="font-mono text-white text-xs">${deprResult.depreciableBase.toLocaleString()}</div>
            </div>
          </div>

          {/* Schedule Table */}
          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-3">
            <span className="font-semibold text-sm text-slate-200">
              Annual Depreciation Schedule
            </span>
            <div className="overflow-x-auto rounded-xl border border-slate-800/80">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Year</th>
                    <th className="p-2.5 text-amber-300">Annual Expense</th>
                    <th className="p-2.5 text-rose-300">Accumulated</th>
                    <th className="p-2.5 text-emerald-300">Ending Book Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {deprResult.schedule.map(row => (
                    <tr key={row.year} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-2.5 font-bold text-white">Year {row.year}</td>
                      <td className="p-2.5 text-amber-300">${row.depreciationExpense.toLocaleString()}</td>
                      <td className="p-2.5 text-rose-300">${row.accumulatedDepreciation.toLocaleString()}</td>
                      <td className="p-2.5 text-emerald-300 font-semibold">
                        ${row.endingBookValue.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 6: PROFIT / LOSS, MARGIN & MARKUP
          ========================================================================= */}
      {activeTab === 'profit_loss' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Profit, Margin & Markup Inputs
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Cost Price per Unit (CP) ($)</span>
                <input
                  type="number"
                  value={costPrice}
                  min="0"
                  step="1"
                  onChange={e => setCostPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Selling Price per Unit (SP) ($)</span>
                <input
                  type="number"
                  value={sellingPrice}
                  min="0"
                  step="1"
                  onChange={e => setSellingPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Quantity / Units Sold</span>
                <input
                  type="number"
                  value={plUnits}
                  min="1"
                  onChange={e => setPlUnits(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Formulas:</span>
              <div>• Margin = (Selling - Cost) / Selling × 100%</div>
              <div>• Markup = (Selling - Cost) / Cost × 100%</div>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Profitability Breakdown
            </span>

            <div className="my-auto py-4 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 font-medium">
                {plResult.isProfit ? 'Total Net Profit' : 'Total Net Loss'} ({plUnits} units)
              </span>
              <div
                className={`text-4xl font-extrabold mt-2 font-mono ${
                  plResult.isProfit ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {plResult.isProfit ? '+' : '-'}${plResult.totalDiff.toLocaleString()}
              </div>
              <span className="text-xs text-slate-500 mt-1">
                ${plResult.absoluteDiff} per unit ({plResult.percentageProfitLoss}%)
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Gross Profit Margin:</span>
                <span className="text-indigo-400 font-bold">{plResult.grossMarginPct}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">Cost Markup:</span>
                <span className="text-amber-400 font-bold">{plResult.markupPct}%</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Revenue:</span>
                <span className="text-white font-bold">${plResult.totalRevenue.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total COGS:</span>
                <span className="text-slate-400 font-bold">${plResult.totalCost.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 7: PERCENTAGE CHANGE & CAGR
          ========================================================================= */}
      {activeTab === 'percent_cagr' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Percentage Change Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Percent className="w-4 h-4 text-purple-400" />
              Percentage Change Calculator
            </span>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Initial Value (V1)</span>
                <input
                  type="number"
                  value={changeV1}
                  onChange={e => setChangeV1(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Final Value (V2)</span>
                <input
                  type="number"
                  value={changeV2}
                  onChange={e => setChangeV2(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400">Calculated Percentage Change</span>
              <div
                className={`text-3xl font-bold font-mono mt-1 ${
                  pctChangeResult.isIncrease ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {pctChangeResult.percentageChange > 0 ? '+' : ''}
                {pctChangeResult.percentageChange}%
              </div>
              <div className="flex gap-4 text-xs font-mono text-slate-400 mt-2">
                <span>Diff: {pctChangeResult.absoluteChange}</span>
                <span>Multiplier: {pctChangeResult.multiplier}x</span>
              </div>
            </div>
          </div>

          {/* CAGR Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              CAGR (Compound Annual Growth Rate)
            </span>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Start Value ($)</span>
                <input
                  type="number"
                  value={cagrV1}
                  min="1"
                  onChange={e => setCagrV1(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1 font-medium">End Value ($)</span>
                <input
                  type="number"
                  value={cagrV2}
                  min="1"
                  onChange={e => setCagrV2(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Years</span>
                <input
                  type="number"
                  value={cagrYears}
                  min="0.1"
                  step="0.5"
                  onChange={e => setCagrYears(Math.max(0.1, parseFloat(e.target.value) || 1))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400">Annualized Compound Return</span>
              <div className="text-3xl font-bold font-mono text-indigo-400 mt-1">
                {cagrResult.cagrPct}% / yr
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs font-mono text-slate-400 mt-2 w-full pt-2 border-t border-slate-800">
                <span>Total Return: {cagrResult.totalReturnPct}%</span>
                <span>Doubling Time: ~{cagrResult.doublingTimeYears} yrs</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 8: BREAK-EVEN ANALYSIS
          ========================================================================= */}
      {activeTab === 'breakeven' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Break-Even Cost & Revenue Structure
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1 font-medium">Total Fixed Costs (FC) ($)</span>
                <input
                  type="number"
                  value={beFixedCost}
                  min="0"
                  step="1000"
                  onChange={e => setBeFixedCost(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Variable Cost / Unit ($)</span>
                  <input
                    type="number"
                    value={beVarCost}
                    min="0"
                    step="1"
                    onChange={e => setBeVarCost(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1 font-medium">Sales Price / Unit ($)</span>
                  <input
                    type="number"
                    value={bePrice}
                    min="0"
                    step="1"
                    onChange={e => setBePrice(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Target Profit Goal (optional) ($)</span>
                <input
                  type="number"
                  value={beTargetProfit}
                  min="0"
                  step="1000"
                  onChange={e => setBeTargetProfit(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Formula:</span>
              <MathView math="Q_{\text{BE}} = \frac{FC}{P - VC}" block />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Break-Even Targets
            </span>

            {beResult.isViable ? (
              <div className="my-auto py-4 flex flex-col gap-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                  <span className="text-slate-400 text-xs font-medium">Break-Even Sales Volume</span>
                  <div className="text-3xl font-extrabold text-indigo-400 font-mono mt-1">
                    {beResult.breakEvenUnits.toLocaleString()} units
                  </div>
                  <span className="text-xs text-slate-500">
                    (${beResult.breakEvenRevenue.toLocaleString()} in gross revenue)
                  </span>
                </div>

                {beTargetProfit > 0 && (
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                    <span className="text-slate-400 text-xs font-medium">
                      Units to Reach Target Profit (${beTargetProfit.toLocaleString()})
                    </span>
                    <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">
                      {beResult.targetUnits.toLocaleString()} units
                    </div>
                    <span className="text-xs text-slate-500">
                      (${beResult.targetRevenue.toLocaleString()} in gross revenue)
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 bg-rose-950/40 border border-rose-800/40 rounded-xl text-rose-300 text-xs">
                Selling price must be higher than variable cost per unit to achieve positive contribution margin!
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Contribution Margin / Unit:</span>
                <span className="text-white font-bold">${beResult.contributionMarginUnit}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Contribution Margin Ratio:</span>
                <span className="text-indigo-400 font-bold">{beResult.contributionMarginRatioPct}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 9: FINANCIAL FORMULAS CHEAT SHEET
          ========================================================================= */}
      {activeTab === 'formulas' && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <span className="font-semibold text-base text-slate-100">
                Financial Mathematics Formula Reference
              </span>
              <p className="text-xs text-slate-400">
                Rigorous financial definitions rendered in dynamic LaTeX typesetting.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {FINANCIAL_FORMULAS.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between gap-3 hover:border-slate-700 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-white">{item.title}</span>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{item.description}</p>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 my-1 overflow-x-auto">
                  <MathView math={item.latex} block copyable />
                </div>

                <div className="text-[11px] font-mono text-slate-400 flex flex-col gap-0.5 pt-2 border-t border-slate-800/60">
                  {item.variables.map((v, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <span className="text-indigo-300 font-semibold">{v.name}:</span>
                      <span className="text-slate-400">{v.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
