import React, { useState, useRef, useEffect } from 'react';
import { AngleUnit, PrecisionMode, ResultDisplayFormat, HistoryItem } from '../../types/calc';
import { evaluateExpression, symbolicSimplify, symbolicDerivative, toExactFraction, toEngineering } from '../../utils/mathEngine';
import { isPrime, formatPrimeFactors } from '../../utils/discreteAndNumberTheory';
import { CalculatorKeypad } from '../CalculatorKeypad';
import { MathView } from '../MathView';
import { FunctionCatalogModal } from '../modals/FunctionCatalogModal';
import { FormulaSearchModal } from '../modals/FormulaSearchModal';
import { HelpModal } from '../modals/HelpModal';
import { StepByStepModal } from '../modals/StepByStepModal';
import { ShareModal } from '../modals/ShareModal';
import { ExportModal } from '../modals/ExportModal';
import { MultiLineNotebookView } from './MultiLineNotebookView';
import {
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Hash,
  ArrowRightLeft,
  BookOpen,
  Search,
  Layers,
  HelpCircle,
  Share2,
  Download,
  ClipboardPaste,
  Eye,
  AlignLeft,
  Calculator as CalcIcon,
  Trash2
} from 'lucide-react';

interface MainCalculatorViewProps {
  angleUnit: AngleUnit;
  precision: PrecisionMode;
  variables: Record<string, any>;
  onAddHistory: (item: HistoryItem) => void;
  recentHistory: HistoryItem[];
  ansValue: string;
  setAnsValue: (val: string) => void;
}

export const MainCalculatorView: React.FC<MainCalculatorViewProps> = ({
  angleUnit,
  precision,
  variables,
  onAddHistory,
  recentHistory,
  ansValue,
  setAnsValue
}) => {
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [exactFrac, setExactFrac] = useState<string | null>(null);
  const [engNotation, setEngNotation] = useState<string | null>(null);
  const [displayFormat, setDisplayFormat] = useState<ResultDisplayFormat>('auto');
  const [copied, setCopied] = useState(false);
  const [copiedLatex, setCopiedLatex] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [memoryValue, setMemoryValue] = useState<number>(0);
  const [stepExplanation, setStepExplanation] = useState<string | null>(null);
  const [activeLatex, setActiveLatex] = useState<string>('');
  const [showLatexDisplay, setShowLatexDisplay] = useState<boolean>(true);
  const [calcSubMode, setCalcSubMode] = useState<'classic' | 'notebook'>('classic');

  // History cycling index
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Modals
  const [isFunctionsOpen, setIsFunctionsOpen] = useState(false);
  const [isFormulasOpen, setIsFormulasOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isStepByStepOpen, setIsStepByStepOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  // Evaluate whenever expression is submitted
  const handleEvaluate = () => {
    if (!expression.trim()) return;

    setErrorMessage(null);
    setStepExplanation(null);

    const scope = {
      ...variables,
      Ans: parseFloat(ansValue) || 0,
      ans: parseFloat(ansValue) || 0
    };

    const res = evaluateExpression(expression, scope, angleUnit, precision, displayFormat);

    if (res.success) {
      setResult(res.resultString);
      setAnsValue(res.resultString);
      setExactFrac(res.exactFraction || null);
      setEngNotation(res.engineering || null);
      setActiveLatex(res.latex || expression);
      setHistoryIndex(-1);

      onAddHistory({
        id: Date.now().toString(),
        timestamp: Date.now(),
        expression,
        result: res.resultString,
        latex: res.latex,
        numericValue: res.numericValue,
        exactFraction: res.exactFraction,
        angleUnit
      });
    } else {
      setErrorMessage(res.error || 'Evaluation error');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleEvaluate();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (recentHistory.length > 0) {
        const nextIdx = Math.min(historyIndex + 1, recentHistory.length - 1);
        setHistoryIndex(nextIdx);
        const item = recentHistory[nextIdx];
        if (item) {
          setExpression(item.expression);
          setResult(item.result);
          if (item.latex) setActiveLatex(item.latex);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIdx = historyIndex - 1;
        setHistoryIndex(nextIdx);
        const item = recentHistory[nextIdx];
        if (item) {
          setExpression(item.expression);
          setResult(item.result);
          if (item.latex) setActiveLatex(item.latex);
        }
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setExpression('');
        setResult('0');
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      handleClear();
    }
  };

  const handleInsert = (text: string) => {
    setErrorMessage(null);
    if (inputRef.current) {
      const start = inputRef.current.selectionStart ?? expression.length;
      const end = inputRef.current.selectionEnd ?? expression.length;
      const newExpr = expression.substring(0, start) + text + expression.substring(end);
      setExpression(newExpr);

      // Re-focus and position cursor
      setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
          const nextPos = start + text.length;
          inputRef.current.setSelectionRange(nextPos, nextPos);
        }
      }, 10);
    } else {
      setExpression(prev => prev + text);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        handleInsert(text.trim());
      }
    } catch {
      // Fallback focus to input for standard Ctrl+V
      inputRef.current?.focus();
    }
  };

  const handleClear = () => {
    setExpression('');
    setResult('0');
    setExactFrac(null);
    setEngNotation(null);
    setErrorMessage(null);
    setStepExplanation(null);
    setActiveLatex('');
    setHistoryIndex(-1);
    inputRef.current?.focus();
  };

  const handleBackspace = () => {
    if (inputRef.current) {
      const start = inputRef.current.selectionStart ?? expression.length;
      const end = inputRef.current.selectionEnd ?? expression.length;
      if (start === end && start > 0) {
        const newExpr = expression.substring(0, start - 1) + expression.substring(end);
        setExpression(newExpr);
        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.focus();
            inputRef.current.setSelectionRange(start - 1, start - 1);
          }
        }, 10);
      } else if (start !== end) {
        const newExpr = expression.substring(0, start) + expression.substring(end);
        setExpression(newExpr);
        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.focus();
            inputRef.current.setSelectionRange(start, start);
          }
        }, 10);
      }
    } else {
      setExpression(prev => prev.slice(0, -1));
    }
  };

  // Smart parentheses balancing
  const handleSmartBrackets = () => {
    let openCount = 0;
    let closeCount = 0;
    for (const ch of expression) {
      if (ch === '(') openCount++;
      if (ch === ')') closeCount++;
    }

    if (openCount > closeCount) {
      const lastChar = expression.trim().slice(-1);
      if (['+', '-', '*', '/', '^', '('].includes(lastChar)) {
        handleInsert('(');
      } else {
        handleInsert(')');
      }
    } else {
      handleInsert('(');
    }
  };

  // Smart matrix brackets
  const handleSquareBrackets = (curly = false) => {
    if (curly) {
      handleInsert('{ }');
    } else {
      handleInsert('[ ]');
    }
  };

  // Quick CAS features
  const handleSimplify = () => {
    if (!expression.trim()) return;
    const res = symbolicSimplify(expression);
    if (!res.startsWith('Error:')) {
      setStepExplanation(`Simplified expression: ${res}`);
      setResult(res);
    } else {
      setErrorMessage(res.replace('Error: ', '') || 'Cannot simplify expression');
    }
  };

  const handleDerivative = () => {
    if (!expression.trim()) return;
    const res = symbolicDerivative(expression, 'x');
    if (!res.startsWith('Error:')) {
      setStepExplanation(`d/dx (${expression}) = ${res}`);
      setResult(res);
    } else {
      setErrorMessage(res.replace('Error: ', '') || 'Cannot compute derivative');
    }
  };

  const handlePrimeCheck = () => {
    const num = parseInt(result, 10);
    if (!isNaN(num) && num > 1) {
      if (isPrime(num)) {
        setStepExplanation(`${num} is a Prime Number!`);
      } else {
        const factors = formatPrimeFactors(num);
        setStepExplanation(`Prime factors of ${num}: ${factors}`);
      }
    } else {
      setStepExplanation('Calculate a positive integer > 1 to check primality.');
    }
  };

  const handleCopyResult = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleCopyLatex = () => {
    navigator.clipboard.writeText(activeLatex || expression);
    setCopiedLatex(true);
    setTimeout(() => setCopiedLatex(null), 1500);
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Top Application Toolbar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-2.5 sm:p-3 flex flex-wrap items-center justify-between gap-2.5 shadow-xl">
        {/* Left: Mode switcher (Classic Keypad vs Multi-line Notebook) */}
        <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-1 text-xs">
          <button
            type="button"
            onClick={() => setCalcSubMode('classic')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              calcSubMode === 'classic'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CalcIcon className="w-3.5 h-3.5" />
            <span>Classic Keypad</span>
          </button>

          <button
            type="button"
            onClick={() => setCalcSubMode('notebook')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              calcSubMode === 'notebook'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <AlignLeft className="w-3.5 h-3.5" />
            <span>Multi-Line Notebook</span>
          </button>
        </div>

        {/* Right: Feature Launchers */}
        <div className="flex items-center gap-1.5 flex-wrap text-xs">
          <button
            type="button"
            onClick={() => setIsFunctionsOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Searchable 100+ Functions Library"
          >
            <Search className="w-3.5 h-3.5 text-indigo-400" />
            <span>Functions</span>
          </button>

          <button
            type="button"
            onClick={() => setIsFormulasOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Searchable Formula Library"
          >
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span>Formulas</span>
          </button>

          <button
            type="button"
            onClick={() => setIsStepByStepOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Step-by-step Math Solver"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Step-by-Step</span>
          </button>

          <button
            type="button"
            onClick={() => setIsShareOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Share calculation results"
          >
            <Share2 className="w-3.5 h-3.5 text-blue-400" />
            <span>Share</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExportOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Export calculations & history"
          >
            <Download className="w-3.5 h-3.5 text-teal-400" />
            <span>Export</span>
          </button>

          <button
            type="button"
            onClick={() => setIsHelpOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors"
            title="Keyboard shortcuts & syntax help"
          >
            <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span>Help</span>
          </button>
        </div>
      </div>

      {/* Conditionally Render Multi-line Notebook View */}
      {calcSubMode === 'notebook' ? (
        <MultiLineNotebookView
          angleUnit={angleUnit}
          precision={precision}
          onInsertToMain={expr => {
            setExpression(expr);
            setCalcSubMode('classic');
          }}
        />
      ) : (
        /* Classic Keypad Mode */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full">
          {/* Left / Main Calculator Body */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            {/* Screen / Display Container */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xl relative overflow-hidden min-h-[220px]">
              {/* Status indicators */}
              <div className="flex items-center justify-between text-xs font-mono text-slate-400 pb-2 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-slate-800/80 text-indigo-300 font-semibold uppercase">
                    {angleUnit}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800/80 text-slate-300">
                    Fix {precision}
                  </span>
                  {memoryValue !== 0 && (
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold">
                      M: {memoryValue}
                    </span>
                  )}
                  {historyIndex >= 0 && (
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono text-[10px]">
                      Tape [{historyIndex + 1}/{recentHistory.length}]
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowLatexDisplay(!showLatexDisplay)}
                    className={`px-2 py-0.5 rounded transition-colors text-xs flex items-center gap-1 ${
                      showLatexDisplay
                        ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-700/50'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                    title="Toggle Natural Textbook Notation"
                  >
                    <Eye className="w-3 h-3" />
                    <span>Textbook Math</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setDisplayFormat(prev => (prev === 'fraction' ? 'auto' : 'fraction'))
                    }
                    className={`px-2 py-0.5 rounded transition-colors text-xs ${
                      displayFormat === 'fraction'
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                    title="Toggle Fraction/Decimal"
                  >
                    a/b ↔ dec
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setDisplayFormat(prev => (prev === 'engineering' ? 'auto' : 'engineering'))
                    }
                    className={`px-2 py-0.5 rounded transition-colors text-xs ${
                      displayFormat === 'engineering'
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                    title="Toggle Engineering Notation"
                  >
                    ENG
                  </button>
                </div>
              </div>

              {/* Formula input area */}
              <div className="my-3 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={expression}
                    onChange={e => setExpression(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter calculation or formula (e.g. 5*sin(pi/3) + 2^4)..."
                    className="w-full bg-transparent text-xl sm:text-2xl font-mono text-slate-100 placeholder-slate-600 focus:outline-none tracking-wide"
                    autoFocus
                  />

                  {/* Paste button */}
                  <button
                    type="button"
                    onClick={handlePaste}
                    className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors shrink-0"
                    title="Paste from clipboard"
                  >
                    <ClipboardPaste className="w-4 h-4" />
                  </button>
                </div>

                {/* Natural Textbook KaTeX Mathematical Notation Display */}
                {showLatexDisplay && expression.trim() && (
                  <div className="p-2 bg-slate-950/60 rounded-xl border border-slate-800/60 overflow-x-auto text-slate-300">
                    <MathView math={expression} rawText={expression} block />
                  </div>
                )}
              </div>

              {/* Error display */}
              {errorMessage && (
                <div className="text-rose-400 text-xs font-mono bg-rose-950/40 border border-rose-800/60 px-3 py-1.5 rounded-lg mb-2">
                  {errorMessage}
                </div>
              )}

              {/* Step explanation banner */}
              {stepExplanation && (
                <div className="text-indigo-200 text-xs font-mono bg-indigo-950/60 border border-indigo-800/60 px-3 py-1.5 rounded-lg mb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>{stepExplanation}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setStepExplanation(null)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    ✕
                  </button>
                </div>
              )}

              {/* Output / Result section */}
              <div className="pt-2 border-t border-slate-800/60 flex items-baseline justify-between gap-3">
                <div className="text-slate-500 text-xs font-mono">Result</div>
                <div className="flex items-center gap-2 overflow-x-auto justify-end">
                  {exactFrac && (
                    <button
                      type="button"
                      onClick={() => setResult(exactFrac)}
                      className="text-xs px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/60 transition-colors"
                      title="Exact Fraction"
                    >
                      = {exactFrac}
                    </button>
                  )}
                  <span className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-tight">
                    {result}
                  </span>

                  {/* Copy Result Button */}
                  <button
                    type="button"
                    onClick={handleCopyResult}
                    className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-colors"
                    title="Copy result to clipboard"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  {/* Share Result Button */}
                  <button
                    type="button"
                    onClick={() => setIsShareOpen(true)}
                    className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-colors"
                    title="Share calculation"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Quick CAS Actions */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <button
                type="button"
                onClick={handleSimplify}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 transition-colors shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                CAS Simplify
              </button>
              <button
                type="button"
                onClick={handleDerivative}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 transition-colors shrink-0"
              >
                <Hash className="w-3.5 h-3.5 text-amber-400" />
                Symbolic d/dx
              </button>
              <button
                type="button"
                onClick={handlePrimeCheck}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 transition-colors shrink-0"
              >
                <ArrowRightLeft className="w-3.5 h-3.5 text-cyan-400" />
                Prime / Factorization
              </button>
              <button
                type="button"
                onClick={() => {
                  const num = parseFloat(result);
                  if (!isNaN(num)) {
                    const frac = toExactFraction(num);
                    if (frac) setResult(frac);
                    else setStepExplanation('Could not find a simple rational fraction');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 transition-colors shrink-0"
              >
                Fraction ↔ Decimal
              </button>
            </div>

            {/* Tactile Keypad */}
            <CalculatorKeypad
              onInsert={handleInsert}
              onClear={handleClear}
              onBackspace={handleBackspace}
              onEvaluate={handleEvaluate}
              onAns={() => handleInsert('Ans')}
              onSmartBrackets={handleSmartBrackets}
              onSquareBrackets={handleSquareBrackets}
              onMemoryAdd={() => {
                const num = parseFloat(result) || 0;
                setMemoryValue(prev => prev + num);
                setStepExplanation(`M = ${memoryValue + num}`);
              }}
              onMemorySub={() => {
                const num = parseFloat(result) || 0;
                setMemoryValue(prev => prev - num);
                setStepExplanation(`M = ${memoryValue - num}`);
              }}
              onMemoryRecall={() => {
                handleInsert(memoryValue.toString());
              }}
              onMemoryClear={() => {
                setMemoryValue(0);
                setStepExplanation('Memory cleared (M = 0)');
              }}
            />
          </div>

          {/* Right Column: History & Memory Tape */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col h-[560px] shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                  Calculation Tape
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsExportOpen(true)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    title="Export tape"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs text-slate-500 font-mono">
                    {recentHistory.length} saved
                  </span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 py-3 pr-1">
                {recentHistory.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 text-xs px-4">
                    <span>No calculations yet. Enter equations or numbers to generate a paper tape history.</span>
                  </div>
                ) : (
                  recentHistory.map(item => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setExpression(item.expression);
                        setResult(item.result);
                        if (item.latex) setActiveLatex(item.latex);
                      }}
                      className="p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-850/90 border border-slate-800/80 hover:border-indigo-600/50 cursor-pointer transition-all group"
                    >
                      <div className="text-xs font-mono text-slate-400 truncate mb-1 group-hover:text-indigo-300">
                        {item.expression}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-mono font-bold text-white">
                          = {item.result}
                        </span>
                        <span className="text-[10px] text-slate-600 uppercase font-mono">
                          {item.angleUnit}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Pro tips reminder */}
              <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-500 leading-relaxed font-mono">
                <div className="text-slate-400 font-semibold mb-1">Keyboard Shortcuts:</div>
                Use <kbd className="text-indigo-300">↑ / ↓</kbd> for history, <kbd className="text-indigo-300">Enter</kbd> to solve, <kbd className="text-indigo-300">Esc</kbd> to clear.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <FunctionCatalogModal
        isOpen={isFunctionsOpen}
        onClose={() => setIsFunctionsOpen(false)}
        onInsertFunction={handleInsert}
      />

      <FormulaSearchModal
        isOpen={isFormulasOpen}
        onClose={() => setIsFormulasOpen(false)}
        onInsertFormula={handleInsert}
      />

      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onLoadExample={expr => {
          setExpression(expr);
          inputRef.current?.focus();
        }}
      />

      <StepByStepModal
        isOpen={isStepByStepOpen}
        onClose={() => setIsStepByStepOpen(false)}
        onInsertResult={res => {
          handleInsert(res);
        }}
      />

      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        expression={expression}
        result={result}
        latex={activeLatex}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        history={recentHistory}
      />
    </div>
  );
};
