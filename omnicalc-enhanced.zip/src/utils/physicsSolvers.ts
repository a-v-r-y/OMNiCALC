// Comprehensive Physics Solvers & Formula Library Engine

export interface PhysicsFormulaItem {
  id: string;
  name: string;
  category:
    | 'Kinematics'
    | "Newton's Laws"
    | 'Momentum'
    | 'Work & Energy'
    | 'Circular & Gravitation'
    | 'Fluids'
    | 'Waves & Sound'
    | 'Optics'
    | 'Electricity & Magnetism'
    | 'Thermodynamics'
    | 'Relativity'
    | 'Quantum Mechanics';
  latex: string;
  description: string;
  variables: { symbol: string; name: string; unit: string; defaultValue: number }[];
  solve: (target: string, vals: Record<string, number>) => number | null;
}

// 1. Universal Physics Constants
export interface PhysicsConstant {
  symbol: string;
  name: string;
  value: number;
  unit: string;
  category: string;
  description: string;
}

export const PHYSICS_CONSTANTS: PhysicsConstant[] = [
  { symbol: 'c', name: 'Speed of Light', value: 299792458, unit: 'm/s', category: 'Fundamental', description: 'Speed of light in vacuum' },
  { symbol: 'G', name: 'Gravitational Constant', value: 6.6743e-11, unit: 'N·m²/kg²', category: 'Gravitation', description: 'Universal Newtonian gravitation constant' },
  { symbol: 'g', name: 'Standard Earth Gravity', value: 9.80665, unit: 'm/s²', category: 'Gravitation', description: 'Standard gravitational acceleration on Earth' },
  { symbol: 'h', name: 'Planck Constant', value: 6.62607015e-34, unit: 'J·s', category: 'Quantum', description: 'Quantum of action' },
  { symbol: 'ℏ', name: 'Reduced Planck Constant', value: 1.054571817e-34, unit: 'J·s', category: 'Quantum', description: 'h / (2π)' },
  { symbol: 'e', name: 'Elementary Charge', value: 1.602176634e-19, unit: 'C', category: 'Electromagnetism', description: 'Electric charge on a proton' },
  { symbol: 'm_e', name: 'Electron Mass', value: 9.1093837e-31, unit: 'kg', category: 'Quantum', description: 'Rest mass of an electron' },
  { symbol: 'm_p', name: 'Proton Mass', value: 1.67262192e-27, unit: 'kg', category: 'Quantum', description: 'Rest mass of a proton' },
  { symbol: 'm_n', name: 'Neutron Mass', value: 1.6749275e-27, unit: 'kg', category: 'Quantum', description: 'Rest mass of a neutron' },
  { symbol: 'ε₀', name: 'Vacuum Permittivity', value: 8.8541878128e-12, unit: 'F/m', category: 'Electromagnetism', description: 'Permittivity of free space' },
  { symbol: 'μ₀', name: 'Vacuum Permeability', value: 1.25663706212e-6, unit: 'N/A²', category: 'Electromagnetism', description: 'Permeability of free space' },
  { symbol: 'k_e', name: "Coulomb's Constant", value: 8.9875517923e9, unit: 'N·m²/C²', category: 'Electromagnetism', description: '1 / (4πε₀)' },
  { symbol: 'k_B', name: 'Boltzmann Constant', value: 1.380649e-23, unit: 'J/K', category: 'Thermodynamics', description: 'Gas kinetic temperature factor' },
  { symbol: 'N_A', name: 'Avogadro Constant', value: 6.02214076e23, unit: 'mol⁻¹', category: 'Thermodynamics', description: 'Particles per mole' },
  { symbol: 'R', name: 'Universal Gas Constant', value: 8.314462618, unit: 'J/(mol·K)', category: 'Thermodynamics', description: 'Ideal gas molar constant' },
  { symbol: 'σ', name: 'Stefan-Boltzmann Constant', value: 5.670374419e-8, unit: 'W/(m²·K⁴)', category: 'Thermodynamics', description: 'Blackbody radiation constant' },
  { symbol: 'b', name: "Wien's Constant", value: 2.897771955e-3, unit: 'm·K', category: 'Thermodynamics', description: 'Blackbody peak wavelength constant' },
  { symbol: 'R_∞', name: 'Rydberg Constant', value: 10973731.568, unit: 'm⁻¹', category: 'Quantum', description: 'Atomic hydrogen spectrum constant' },
  { symbol: 'a₀', name: 'Bohr Radius', value: 5.291772109e-11, unit: 'm', category: 'Quantum', description: 'Ground state radius of hydrogen' },
  { symbol: 'u', name: 'Atomic Mass Unit', value: 1.6605390666e-27, unit: 'kg', category: 'Quantum', description: '1/12th the mass of Carbon-12' },
  { symbol: 'atm', name: 'Standard Atmosphere', value: 101325, unit: 'Pa', category: 'Fluids', description: 'Standard atmospheric pressure at sea level' },
  { symbol: 'M_earth', name: 'Earth Mass', value: 5.9722e24, unit: 'kg', category: 'Gravitation', description: 'Mass of Planet Earth' },
  { symbol: 'R_earth', name: 'Earth Mean Radius', value: 6.371e6, unit: 'm', category: 'Gravitation', description: 'Mean volumetric radius of Earth' }
];

// 2. Interactive Formula Solving Catalog
export const PHYSICS_FORMULAS: PhysicsFormulaItem[] = [
  // Kinematics
  {
    id: 'kin_v',
    name: 'Velocity-Time (v = u + at)',
    category: 'Kinematics',
    latex: 'v = u + a t',
    description: 'Relates final velocity, initial velocity, constant acceleration, and time.',
    variables: [
      { symbol: 'v', name: 'Final Velocity', unit: 'm/s', defaultValue: 25 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 5 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 4 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 5 }
    ],
    solve: (target, { v, u, a, t }) => {
      if (target === 'v') return u + a * t;
      if (target === 'u') return v - a * t;
      if (target === 'a') return (v - u) / t;
      if (target === 't') return (v - u) / a;
      return null;
    }
  },
  {
    id: 'kin_s',
    name: 'Displacement-Time (s = ut + ½at²)',
    category: 'Kinematics',
    latex: 's = u t + \\frac{1}{2} a t^2',
    description: 'Displacement traveled under uniform acceleration.',
    variables: [
      { symbol: 's', name: 'Displacement', unit: 'm', defaultValue: 75 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 5 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 4 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 5 }
    ],
    solve: (target, { s, u, a, t }) => {
      if (target === 's') return u * t + 0.5 * a * t * t;
      if (target === 'u') return (s - 0.5 * a * t * t) / t;
      if (target === 'a') return (2 * (s - u * t)) / (t * t);
      if (target === 't') {
        const A = 0.5 * a, B = u, C = -s;
        const disc = B * B - 4 * A * C;
        return disc >= 0 ? (-B + Math.sqrt(disc)) / (2 * A) : null;
      }
      return null;
    }
  },
  {
    id: 'kin_v2',
    name: 'Velocity-Displacement (v² = u² + 2as)',
    category: 'Kinematics',
    latex: 'v^2 = u^2 + 2 a s',
    description: 'Time-independent kinematic relation.',
    variables: [
      { symbol: 'v', name: 'Final Velocity', unit: 'm/s', defaultValue: 25 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 5 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 4 },
      { symbol: 's', name: 'Displacement', unit: 'm', defaultValue: 75 }
    ],
    solve: (target, { v, u, a, s }) => {
      if (target === 'v') return Math.sqrt(Math.max(0, u * u + 2 * a * s));
      if (target === 'u') return Math.sqrt(Math.max(0, v * v - 2 * a * s));
      if (target === 'a') return (v * v - u * u) / (2 * s);
      if (target === 's') return (v * v - u * u) / (2 * a);
      return null;
    }
  },

  // Newton's Laws
  {
    id: 'newton_fma',
    name: "Newton's Second Law (F = ma)",
    category: "Newton's Laws",
    latex: 'F = m \\cdot a',
    description: 'Net force equals mass times acceleration.',
    variables: [
      { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 50 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 5 }
    ],
    solve: (target, { F, m, a }) => {
      if (target === 'F') return m * a;
      if (target === 'm') return F / a;
      if (target === 'a') return F / m;
      return null;
    }
  },
  {
    id: 'friction_f',
    name: 'Friction Force (f = μN)',
    category: "Newton's Laws",
    latex: 'f = \\mu \\cdot N',
    description: 'Frictional resistance as coefficient times normal force.',
    variables: [
      { symbol: 'f', name: 'Friction Force', unit: 'N', defaultValue: 29.4 },
      { symbol: 'mu', name: 'Friction Coefficient μ', unit: '', defaultValue: 0.3 },
      { symbol: 'N', name: 'Normal Force', unit: 'N', defaultValue: 98 }
    ],
    solve: (target, { f, mu, N }) => {
      if (target === 'f') return mu * N;
      if (target === 'mu') return f / N;
      if (target === 'N') return f / mu;
      return null;
    }
  },

  // Momentum
  {
    id: 'mom_p',
    name: 'Linear Momentum (p = mv)',
    category: 'Momentum',
    latex: 'p = m \\cdot v',
    description: 'Product of mass and velocity of a body.',
    variables: [
      { symbol: 'p', name: 'Momentum', unit: 'kg·m/s', defaultValue: 50 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 5 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 10 }
    ],
    solve: (target, { p, m, v }) => {
      if (target === 'p') return m * v;
      if (target === 'm') return p / v;
      if (target === 'v') return p / m;
      return null;
    }
  },
  {
    id: 'mom_impulse',
    name: 'Impulse-Momentum (J = F Δt)',
    category: 'Momentum',
    latex: 'J = F \\cdot \\Delta t = \\Delta p',
    description: 'Impulse delivered by an applied average force over time duration.',
    variables: [
      { symbol: 'J', name: 'Impulse', unit: 'N·s', defaultValue: 100 },
      { symbol: 'F', name: 'Average Force', unit: 'N', defaultValue: 500 },
      { symbol: 't', name: 'Contact Time Δt', unit: 's', defaultValue: 0.2 }
    ],
    solve: (target, { J, F, t }) => {
      if (target === 'J') return F * t;
      if (target === 'F') return J / t;
      if (target === 't') return J / F;
      return null;
    }
  },

  // Work, Energy, Power
  {
    id: 'work_w',
    name: 'Work Done (W = F d cos θ)',
    category: 'Work & Energy',
    latex: 'W = F \\cdot d \\cdot \\cos(\\theta)',
    description: 'Energy transferred by a force acting through a displacement.',
    variables: [
      { symbol: 'W', name: 'Work Done', unit: 'J', defaultValue: 250 },
      { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 50 },
      { symbol: 'd', name: 'Displacement', unit: 'm', defaultValue: 5 },
      { symbol: 'theta', name: 'Angle θ', unit: 'deg', defaultValue: 0 }
    ],
    solve: (target, { W, F, d, theta }) => {
      const rad = (theta * Math.PI) / 180;
      if (target === 'W') return F * d * Math.cos(rad);
      if (target === 'F') return W / (d * Math.cos(rad));
      if (target === 'd') return W / (F * Math.cos(rad));
      if (target === 'theta') return (Math.acos(W / (F * d)) * 180) / Math.PI;
      return null;
    }
  },
  {
    id: 'energy_ke',
    name: 'Kinetic Energy (KE = ½mv²)',
    category: 'Work & Energy',
    latex: 'KE = \\frac{1}{2} m v^2',
    description: 'Translational kinetic energy of a moving particle.',
    variables: [
      { symbol: 'KE', name: 'Kinetic Energy', unit: 'J', defaultValue: 250 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 5 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 10 }
    ],
    solve: (target, { KE, m, v }) => {
      if (target === 'KE') return 0.5 * m * v * v;
      if (target === 'm') return (2 * KE) / (v * v);
      if (target === 'v') return Math.sqrt((2 * KE) / m);
      return null;
    }
  },
  {
    id: 'energy_pe',
    name: 'Gravitational Potential Energy (PE = mgh)',
    category: 'Work & Energy',
    latex: 'PE = m \\cdot g \\cdot h',
    description: 'Potential energy of a mass elevated to height h in a uniform gravitational field.',
    variables: [
      { symbol: 'PE', name: 'Potential Energy', unit: 'J', defaultValue: 490 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 5 },
      { symbol: 'g', name: 'Gravity', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 'h', name: 'Height', unit: 'm', defaultValue: 10 }
    ],
    solve: (target, { PE, m, g, h }) => {
      if (target === 'PE') return m * g * h;
      if (target === 'm') return PE / (g * h);
      if (target === 'g') return PE / (m * h);
      if (target === 'h') return PE / (m * g);
      return null;
    }
  },
  {
    id: 'power_p',
    name: 'Power (P = W / t = F v)',
    category: 'Work & Energy',
    latex: 'P = \\frac{W}{t}',
    description: 'Rate of doing work or transferring energy per unit time.',
    variables: [
      { symbol: 'P', name: 'Power', unit: 'W', defaultValue: 500 },
      { symbol: 'W', name: 'Work / Energy', unit: 'J', defaultValue: 2500 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 5 }
    ],
    solve: (target, { P, W, t }) => {
      if (target === 'P') return W / t;
      if (target === 'W') return P * t;
      if (target === 't') return W / P;
      return null;
    }
  },

  // Circular & Gravitation
  {
    id: 'circ_fc',
    name: 'Centripetal Force (Fc = mv²/r)',
    category: 'Circular & Gravitation',
    latex: 'F_c = \\frac{m v^2}{r} = m \\omega^2 r',
    description: 'Inward radial force required to maintain circular trajectory.',
    variables: [
      { symbol: 'Fc', name: 'Centripetal Force', unit: 'N', defaultValue: 200 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 2 },
      { symbol: 'v', name: 'Speed', unit: 'm/s', defaultValue: 10 },
      { symbol: 'r', name: 'Radius', unit: 'm', defaultValue: 1 }
    ],
    solve: (target, { Fc, m, v, r }) => {
      if (target === 'Fc') return (m * v * v) / r;
      if (target === 'm') return (Fc * r) / (v * v);
      if (target === 'v') return Math.sqrt((Fc * r) / m);
      if (target === 'r') return (m * v * v) / Fc;
      return null;
    }
  },
  {
    id: 'grav_f',
    name: "Newton's Law of Gravitation (F = G m₁m₂ / r²)",
    category: 'Circular & Gravitation',
    latex: 'F = G \\frac{m_1 m_2}{r^2}',
    description: 'Mutual gravitational attraction between two point masses.',
    variables: [
      { symbol: 'F', name: 'Gravitational Force', unit: 'N', defaultValue: 3.52e22 },
      { symbol: 'm1', name: 'Mass 1', unit: 'kg', defaultValue: 5.972e24 },
      { symbol: 'm2', name: 'Mass 2', unit: 'kg', defaultValue: 1.989e30 },
      { symbol: 'r', name: 'Separation Distance', unit: 'm', defaultValue: 1.496e11 }
    ],
    solve: (target, { F, m1, m2, r }) => {
      const G = 6.6743e-11;
      if (target === 'F') return (G * m1 * m2) / (r * r);
      if (target === 'm1') return (F * r * r) / (G * m2);
      if (target === 'm2') return (F * r * r) / (G * m1);
      if (target === 'r') return Math.sqrt((G * m1 * m2) / F);
      return null;
    }
  },

  // Fluid Mechanics
  {
    id: 'fluid_press',
    name: 'Hydrostatic Pressure (P = P₀ + ρgh)',
    category: 'Fluids',
    latex: 'P = P_0 + \\rho \\cdot g \\cdot h',
    description: 'Total pressure at depth h in an incompressible fluid.',
    variables: [
      { symbol: 'P', name: 'Total Pressure', unit: 'Pa', defaultValue: 199325 },
      { symbol: 'P0', name: 'Surface Pressure P₀', unit: 'Pa', defaultValue: 101325 },
      { symbol: 'rho', name: 'Fluid Density ρ', unit: 'kg/m³', defaultValue: 1000 },
      { symbol: 'h', name: 'Depth', unit: 'm', defaultValue: 10 }
    ],
    solve: (target, { P, P0, rho, h }) => {
      const g = 9.8;
      if (target === 'P') return P0 + rho * g * h;
      if (target === 'P0') return P - rho * g * h;
      if (target === 'rho') return (P - P0) / (g * h);
      if (target === 'h') return (P - P0) / (rho * g);
      return null;
    }
  },
  {
    id: 'fluid_buoy',
    name: "Archimedes' Buoyant Force (Fb = ρ V g)",
    category: 'Fluids',
    latex: 'F_b = \\rho_{\\text{fluid}} \\cdot V_{\\text{disp}} \\cdot g',
    description: 'Upward force exerted on a submerged body equal to displaced fluid weight.',
    variables: [
      { symbol: 'Fb', name: 'Buoyant Force', unit: 'N', defaultValue: 9800 },
      { symbol: 'rho', name: 'Fluid Density', unit: 'kg/m³', defaultValue: 1000 },
      { symbol: 'V', name: 'Displaced Volume', unit: 'm³', defaultValue: 1 }
    ],
    solve: (target, { Fb, rho, V }) => {
      const g = 9.8;
      if (target === 'Fb') return rho * V * g;
      if (target === 'rho') return Fb / (V * g);
      if (target === 'V') return Fb / (rho * g);
      return null;
    }
  },

  // Waves & Sound
  {
    id: 'wave_v',
    name: 'Wave Speed (v = f λ)',
    category: 'Waves & Sound',
    latex: 'v = f \\cdot \\lambda',
    description: 'Phase velocity of a periodic traveling wave.',
    variables: [
      { symbol: 'v', name: 'Wave Speed', unit: 'm/s', defaultValue: 343 },
      { symbol: 'f', name: 'Frequency', unit: 'Hz', defaultValue: 440 },
      { symbol: 'lambda', name: 'Wavelength λ', unit: 'm', defaultValue: 0.78 }
    ],
    solve: (target, { v, f, lambda }) => {
      if (target === 'v') return f * lambda;
      if (target === 'f') return v / lambda;
      if (target === 'lambda') return v / f;
      return null;
    }
  },
  {
    id: 'sound_db',
    name: 'Sound Intensity Level (β = 10 log₁₀(I / I₀))',
    category: 'Waves & Sound',
    latex: '\\beta = 10 \\log_{10}\\left(\\frac{I}{I_0}\\right)',
    description: 'Decibel scale relative to threshold of hearing I₀ = 10⁻¹² W/m².',
    variables: [
      { symbol: 'beta', name: 'Sound Level', unit: 'dB', defaultValue: 80 },
      { symbol: 'I', name: 'Intensity', unit: 'W/m²', defaultValue: 1e-4 }
    ],
    solve: (target, { beta, I }) => {
      const I0 = 1e-12;
      if (target === 'beta') return 10 * Math.log10(I / I0);
      if (target === 'I') return I0 * Math.pow(10, beta / 10);
      return null;
    }
  },

  // Optics
  {
    id: 'optics_snell',
    name: "Snell's Law of Refraction (n₁ sin θ₁ = n₂ sin θ₂)",
    category: 'Optics',
    latex: 'n_1 \\sin(\\theta_1) = n_2 \\sin(\\theta_2)',
    description: 'Wave propagation across the interface between two media.',
    variables: [
      { symbol: 'n1', name: 'Index of Medium 1', unit: '', defaultValue: 1 },
      { symbol: 'theta1', name: 'Incident Angle θ₁', unit: 'deg', defaultValue: 45 },
      { symbol: 'n2', name: 'Index of Medium 2', unit: '', defaultValue: 1.5 },
      { symbol: 'theta2', name: 'Refracted Angle θ₂', unit: 'deg', defaultValue: 28.13 }
    ],
    solve: (target, { n1, theta1, n2, theta2 }) => {
      const deg2rad = Math.PI / 180;
      const rad2deg = 180 / Math.PI;
      if (target === 'theta2') {
        const sin2 = (n1 * Math.sin(theta1 * deg2rad)) / n2;
        return sin2 <= 1 ? Math.asin(sin2) * rad2deg : null;
      }
      if (target === 'theta1') {
        const sin1 = (n2 * Math.sin(theta2 * deg2rad)) / n1;
        return sin1 <= 1 ? Math.asin(sin1) * rad2deg : null;
      }
      if (target === 'n2') return (n1 * Math.sin(theta1 * deg2rad)) / Math.sin(theta2 * deg2rad);
      if (target === 'n1') return (n2 * Math.sin(theta2 * deg2rad)) / Math.sin(theta1 * deg2rad);
      return null;
    }
  },
  {
    id: 'optics_lens',
    name: 'Thin Lens / Mirror Equation (1/f = 1/dₒ + 1/dᵢ)',
    category: 'Optics',
    latex: '\\frac{1}{f} = \\frac{1}{d_o} + \\frac{1}{d_i}',
    description: 'Gaussian form of image formation for lenses and spherical mirrors.',
    variables: [
      { symbol: 'f', name: 'Focal Length', unit: 'cm', defaultValue: 10 },
      { symbol: 'do', name: 'Object Distance dₒ', unit: 'cm', defaultValue: 30 },
      { symbol: 'di', name: 'Image Distance dᵢ', unit: 'cm', defaultValue: 15 }
    ],
    solve: (target, { f, do: d_o, di }) => {
      if (target === 'f') return (d_o * di) / (d_o + di);
      if (target === 'do') return (f * di) / (di - f);
      if (target === 'di') return (f * d_o) / (d_o - f);
      return null;
    }
  },

  // Electricity & Magnetism
  {
    id: 'coulomb_f',
    name: "Coulomb's Law (F = k q₁q₂ / r²)",
    category: 'Electricity & Magnetism',
    latex: 'F = k_e \\frac{|q_1 q_2|}{r^2}',
    description: 'Electrostatic force between two static charges in vacuum.',
    variables: [
      { symbol: 'F', name: 'Electrostatic Force', unit: 'N', defaultValue: 89.88 },
      { symbol: 'q1', name: 'Charge 1', unit: 'μC', defaultValue: 10 },
      { symbol: 'q2', name: 'Charge 2', unit: 'μC', defaultValue: 10 },
      { symbol: 'r', name: 'Distance', unit: 'm', defaultValue: 0.1 }
    ],
    solve: (target, { F, q1, q2, r }) => {
      const ke = 8.98755e9;
      const c1 = q1 * 1e-6;
      const c2 = q2 * 1e-6;
      if (target === 'F') return (ke * Math.abs(c1 * c2)) / (r * r);
      if (target === 'r') return Math.sqrt((ke * Math.abs(c1 * c2)) / F);
      if (target === 'q1') return ((F * r * r) / (ke * Math.abs(c2))) * 1e6;
      if (target === 'q2') return ((F * r * r) / (ke * Math.abs(c1))) * 1e6;
      return null;
    }
  },
  {
    id: 'mag_lorentz',
    name: 'Lorentz Magnetic Force (F = q v B sin θ)',
    category: 'Electricity & Magnetism',
    latex: 'F = |q| \\cdot v \\cdot B \\cdot \\sin(\\theta)',
    description: 'Deflecting force exerted on a charge moving through a magnetic field.',
    variables: [
      { symbol: 'F', name: 'Magnetic Force', unit: 'N', defaultValue: 0.048 },
      { symbol: 'q', name: 'Charge', unit: 'μC', defaultValue: 10 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 10000 },
      { symbol: 'B', name: 'Magnetic Flux Density', unit: 'T', defaultValue: 0.5 },
      { symbol: 'theta', name: 'Angle θ', unit: 'deg', defaultValue: 90 }
    ],
    solve: (target, { F, q, v, B, theta }) => {
      const rad = (theta * Math.PI) / 180;
      const qC = q * 1e-6;
      if (target === 'F') return qC * v * B * Math.sin(rad);
      if (target === 'B') return F / (qC * v * Math.sin(rad));
      if (target === 'v') return F / (qC * B * Math.sin(rad));
      if (target === 'q') return (F / (v * B * Math.sin(rad))) * 1e6;
      return null;
    }
  },
  {
    id: 'em_faraday',
    name: "Faraday's Induction Law (ε = -N ΔΦ / Δt)",
    category: 'Electricity & Magnetism',
    latex: '\\mathcal{E} = -N \\frac{\\Delta \\Phi_B}{\\Delta t}',
    description: 'Electromotive force induced by changing magnetic flux over time.',
    variables: [
      { symbol: 'emf', name: 'Induced EMF ε', unit: 'V', defaultValue: 25 },
      { symbol: 'N', name: 'Coil Turns', unit: '', defaultValue: 100 },
      { symbol: 'dPhi', name: 'Flux Change ΔΦ', unit: 'Wb', defaultValue: 0.05 },
      { symbol: 'dt', name: 'Time Δt', unit: 's', defaultValue: 0.2 }
    ],
    solve: (target, { emf, N, dPhi, dt }) => {
      if (target === 'emf') return (N * dPhi) / dt;
      if (target === 'N') return (emf * dt) / dPhi;
      if (target === 'dPhi') return (emf * dt) / N;
      if (target === 'dt') return (N * dPhi) / emf;
      return null;
    }
  },

  // Thermodynamics
  {
    id: 'thermo_heat',
    name: 'Specific Heat Capacity (Q = mc ΔT)',
    category: 'Thermodynamics',
    latex: 'Q = m \\cdot c \\cdot \\Delta T',
    description: 'Sensible heat required to raise temperature of mass m by ΔT.',
    variables: [
      { symbol: 'Q', name: 'Heat Energy', unit: 'J', defaultValue: 41840 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 2 },
      { symbol: 'c', name: 'Specific Heat c', unit: 'J/(kg·K)', defaultValue: 4184 },
      { symbol: 'dT', name: 'Temperature Change ΔT', unit: 'K', defaultValue: 5 }
    ],
    solve: (target, { Q, m, c, dT }) => {
      if (target === 'Q') return m * c * dT;
      if (target === 'm') return Q / (c * dT);
      if (target === 'c') return Q / (m * dT);
      if (target === 'dT') return Q / (m * c);
      return null;
    }
  },
  {
    id: 'thermo_carnot',
    name: 'Carnot Maximum Efficiency (η = 1 - T_C / T_H)',
    category: 'Thermodynamics',
    latex: '\\eta_{\\text{Carnot}} = 1 - \\frac{T_C}{T_H}',
    description: 'Theoretical upper limit on thermal heat engine conversion efficiency.',
    variables: [
      { symbol: 'eta', name: 'Efficiency η', unit: '%', defaultValue: 40 },
      { symbol: 'TC', name: 'Cold Reservoir T_C', unit: 'K', defaultValue: 300 },
      { symbol: 'TH', name: 'Hot Reservoir T_H', unit: 'K', defaultValue: 500 }
    ],
    solve: (target, { eta, TC, TH }) => {
      if (target === 'eta') return (1 - TC / TH) * 100;
      if (target === 'TC') return TH * (1 - eta / 100);
      if (target === 'TH') return TC / (1 - eta / 100);
      return null;
    }
  },

  // Relativity
  {
    id: 'rel_gamma',
    name: 'Lorentz Factor (γ = 1 / √(1 - v²/c²))',
    category: 'Relativity',
    latex: '\\gamma = \\frac{1}{\\sqrt{1 - \\frac{v^2}{c^2}}}',
    description: 'Relativistic factor governing time dilation and length contraction.',
    variables: [
      { symbol: 'gamma', name: 'Lorentz Factor γ', unit: '', defaultValue: 2.294 },
      { symbol: 'v_c', name: 'Speed Fraction (v / c)', unit: '', defaultValue: 0.9 }
    ],
    solve: (target, { gamma, v_c }) => {
      if (target === 'gamma') return 1 / Math.sqrt(Math.max(1e-10, 1 - v_c * v_c));
      if (target === 'v_c') return Math.sqrt(Math.max(0, 1 - 1 / (gamma * gamma)));
      return null;
    }
  },
  {
    id: 'rel_energy',
    name: 'Mass-Energy Equivalence (E = mc²)',
    category: 'Relativity',
    latex: 'E = m \\cdot c^2',
    description: 'Einstein rest energy relation.',
    variables: [
      { symbol: 'E', name: 'Rest Energy', unit: 'J', defaultValue: 8.9875e16 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1 }
    ],
    solve: (target, { E, m }) => {
      const c = 299792458;
      if (target === 'E') return m * c * c;
      if (target === 'm') return E / (c * c);
      return null;
    }
  },

  // Quantum Mechanics
  {
    id: 'quantum_photon',
    name: 'Photon Energy (E = h f = hc / λ)',
    category: 'Quantum Mechanics',
    latex: 'E = h \\cdot f = \\frac{h c}{\\lambda}',
    description: 'Planck-Einstein quantization of electromagnetic radiant energy.',
    variables: [
      { symbol: 'E', name: 'Photon Energy', unit: 'eV', defaultValue: 2.48 },
      { symbol: 'lambda', name: 'Wavelength λ', unit: 'nm', defaultValue: 500 }
    ],
    solve: (target, { E, lambda }) => {
      const hc_eV_nm = 1239.84193;
      if (target === 'E') return hc_eV_nm / lambda;
      if (target === 'lambda') return hc_eV_nm / E;
      return null;
    }
  },
  {
    id: 'quantum_debroglie',
    name: 'De Broglie Wavelength (λ = h / p)',
    category: 'Quantum Mechanics',
    latex: '\\lambda = \\frac{h}{p} = \\frac{h}{m \\cdot v}',
    description: 'Matter-wave wavelength associated with massive particles.',
    variables: [
      { symbol: 'lambda', name: 'Wavelength λ', unit: 'nm', defaultValue: 0.0388 },
      { symbol: 'm', name: 'Particle Mass', unit: 'kg', defaultValue: 9.109e-31 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 1e6 }
    ],
    solve: (target, { lambda, m, v }) => {
      const h = 6.62607e-34;
      if (target === 'lambda') return (h / (m * v)) * 1e9;
      if (target === 'v') return h / (m * (lambda * 1e-9));
      if (target === 'm') return h / (v * (lambda * 1e-9));
      return null;
    }
  }
];

// 3. Projectile Motion Trajectory Calculator
export function simulateProjectile(
  v0: number,
  angleDeg: number,
  initialHeight: number = 0,
  g: number = 9.80665
): {
  flightTime: number;
  maxHeight: number;
  horizontalRange: number;
  vImpact: number;
  trajectory: { x: number; y: number }[];
} {
  const rad = (angleDeg * Math.PI) / 180;
  const vx = v0 * Math.cos(rad);
  const vy0 = v0 * Math.sin(rad);

  // Time to apex
  const tApex = Math.max(0, vy0 / g);
  const maxHeight = initialHeight + (vy0 * vy0) / (2 * g);

  // Quadratic for flight time: -0.5*g*t^2 + vy0*t + h0 = 0
  const A = -0.5 * g;
  const B = vy0;
  const C = initialHeight;
  const disc = B * B - 4 * A * C;
  const flightTime = disc >= 0 ? (-B - Math.sqrt(disc)) / (2 * A) : 0;

  const horizontalRange = vx * flightTime;
  const vyImpact = vy0 - g * flightTime;
  const vImpact = Math.sqrt(vx * vx + vyImpact * vyImpact);

  // Trajectory sample points (25 points)
  const trajectory: { x: number; y: number }[] = [];
  const steps = 24;
  for (let i = 0; i <= steps; i++) {
    const t = (flightTime * i) / steps;
    const x = vx * t;
    const y = Math.max(0, initialHeight + vy0 * t - 0.5 * g * t * t);
    trajectory.push({
      x: parseFloat(x.toFixed(2)),
      y: parseFloat(y.toFixed(2))
    });
  }

  return {
    flightTime: parseFloat(flightTime.toFixed(3)),
    maxHeight: parseFloat(maxHeight.toFixed(2)),
    horizontalRange: parseFloat(horizontalRange.toFixed(2)),
    vImpact: parseFloat(vImpact.toFixed(2)),
    trajectory
  };
}

// 4. Elastic & Inelastic 1D Collisions
export function calculateCollision(
  m1: number,
  u1: number,
  m2: number,
  u2: number,
  type: 'elastic' | 'inelastic'
): {
  v1Final: number;
  v2Final: number;
  initialMomentum: number;
  finalMomentum: number;
  initialKE: number;
  finalKE: number;
  energyLoss: number;
} {
  const pInit = m1 * u1 + m2 * u2;
  const keInit = 0.5 * m1 * u1 * u1 + 0.5 * m2 * u2 * u2;

  let v1 = 0;
  let v2 = 0;

  if (type === 'elastic') {
    v1 = ((m1 - m2) / (m1 + m2)) * u1 + ((2 * m2) / (m1 + m2)) * u2;
    v2 = ((2 * m1) / (m1 + m2)) * u1 + ((m2 - m1) / (m1 + m2)) * u2;
  } else {
    // Completely inelastic (stick together)
    const vf = pInit / (m1 + m2);
    v1 = vf;
    v2 = vf;
  }

  const pFinal = m1 * v1 + m2 * v2;
  const keFinal = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2;
  const energyLoss = Math.max(0, keInit - keFinal);

  return {
    v1Final: parseFloat(v1.toFixed(3)),
    v2Final: parseFloat(v2.toFixed(3)),
    initialMomentum: parseFloat(pInit.toFixed(2)),
    finalMomentum: parseFloat(pFinal.toFixed(2)),
    initialKE: parseFloat(keInit.toFixed(2)),
    finalKE: parseFloat(keFinal.toFixed(2)),
    energyLoss: parseFloat(energyLoss.toFixed(2))
  };
}

// 5. Doppler Effect for Sound
export function calculateDoppler(
  sourceFreq: number,
  soundSpeed: number, // approx 343 m/s
  observerSpeed: number,
  observerTowards: boolean,
  sourceSpeed: number,
  sourceTowards: boolean
): {
  observedFrequency: number;
  freqShift: number;
} {
  // f' = f * (v ± vo) / (v ∓ vs)
  const vo = observerTowards ? observerSpeed : -observerSpeed;
  const vs = sourceTowards ? -sourceSpeed : sourceSpeed;

  const denom = soundSpeed + vs;
  if (denom <= 0) {
    return { observedFrequency: 0, freqShift: 0 };
  }

  const fPrime = sourceFreq * ((soundSpeed + vo) / denom);
  return {
    observedFrequency: parseFloat(fPrime.toFixed(2)),
    freqShift: parseFloat((fPrime - sourceFreq).toFixed(2))
  };
}
