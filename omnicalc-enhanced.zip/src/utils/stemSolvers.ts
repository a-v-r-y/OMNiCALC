// Atomic masses of common elements
export const ELEMENT_WEIGHTS: Record<string, number> = {
  H: 1.008, He: 4.0026, Li: 6.94, Be: 9.0122, B: 10.81, C: 12.011, N: 14.007,
  O: 15.999, F: 18.998, Ne: 20.180, Na: 22.990, Mg: 24.305, Al: 26.982, Si: 28.085,
  P: 30.974, S: 32.06, Cl: 35.45, Ar: 39.948, K: 39.098, Ca: 40.078, Sc: 44.956,
  Ti: 47.867, V: 50.942, Cr: 51.996, Mn: 54.938, Fe: 55.845, Co: 58.933, Ni: 58.693,
  Cu: 63.546, Zn: 65.38, Ga: 69.723, Ge: 72.630, As: 74.922, Se: 78.971, Br: 79.904,
  Kr: 83.798, Rb: 85.468, Sr: 87.62, Ag: 107.868, Sn: 118.71, I: 126.904, Ba: 137.327,
  Pt: 195.084, Au: 196.967, Hg: 200.592, Pb: 207.2, U: 238.029
};

// Chemical formula parser (e.g. "Ca(OH)2", "C6H12O6", "CuSO4*5H2O")
export function parseChemicalFormula(formula: string): { molarMass: number; breakdown: Record<string, number> } {
  // Clean formula
  const cleaned = formula.replace(/[*·]/g, '');
  const elementCounts: Record<string, number> = {};

  function parseSub(str: string, multiplier: number = 1) {
    const regex = /([A-Z][a-z]?|\((?:[^()]|\([^()]*\))*\))(\d*)/g;
    let match;
    while ((match = regex.exec(str)) !== null) {
      const part = match[1];
      const count = (match[2] ? parseInt(match[2], 10) : 1) * multiplier;

      if (part.startsWith('(') && part.endsWith(')')) {
        parseSub(part.slice(1, -1), count);
      } else {
        elementCounts[part] = (elementCounts[part] || 0) + count;
      }
    }
  }

  parseSub(cleaned);

  let totalMass = 0;
  for (const [elem, count] of Object.entries(elementCounts)) {
    const weight = ELEMENT_WEIGHTS[elem] || 0;
    totalMass += weight * count;
  }

  return {
    molarMass: parseFloat(totalMass.toFixed(4)),
    breakdown: elementCounts
  };
}

// Ideal Gas Law: P (atm), V (L), n (mol), T (K), R = 0.08206
export function solveIdealGas(
  knowns: { P?: number; V?: number; n?: number; T?: number }
): { solvedVar: string; value: number } | null {
  const R = 0.082057; // L·atm/(mol·K)
  const { P, V, n, T } = knowns;

  if (P === undefined && V && n && T) {
    return { solvedVar: 'P (atm)', value: parseFloat(((n * R * T) / V).toFixed(4)) };
  }
  if (V === undefined && P && n && T) {
    return { solvedVar: 'V (L)', value: parseFloat(((n * R * T) / P).toFixed(4)) };
  }
  if (n === undefined && P && V && T) {
    return { solvedVar: 'n (mol)', value: parseFloat(((P * V) / (R * T)).toFixed(4)) };
  }
  if (T === undefined && P && V && n) {
    return { solvedVar: 'T (K)', value: parseFloat(((P * V) / (n * R)).toFixed(4)) };
  }
  return null;
}

// pH and pOH calculations
export function calculatePH(type: 'pH' | 'pOH' | 'H+' | 'OH-', val: number): {
  pH: number;
  pOH: number;
  hConc: number;
  ohConc: number;
} {
  let pH = 7;
  if (type === 'pH') pH = val;
  else if (type === 'pOH') pH = 14 - val;
  else if (type === 'H+') pH = -Math.log10(val);
  else if (type === 'OH-') pH = 14 - -Math.log10(val);

  const pOH = 14 - pH;
  const hConc = Math.pow(10, -pH);
  const ohConc = Math.pow(10, -pOH);

  return {
    pH: parseFloat(pH.toFixed(4)),
    pOH: parseFloat(pOH.toFixed(4)),
    hConc: parseFloat(hConc.toExponential(4)),
    ohConc: parseFloat(ohConc.toExponential(4))
  };
}

// Projectile Motion
export function calculateProjectile(v0: number, angleDeg: number, g: number = 9.80665): {
  flightTime: number;
  maxHeight: number;
  range: number;
  vx: number;
  vy0: number;
} {
  const rad = (angleDeg * Math.PI) / 180;
  const vx = v0 * Math.cos(rad);
  const vy0 = v0 * Math.sin(rad);

  const flightTime = (2 * vy0) / g;
  const maxHeight = (vy0 * vy0) / (2 * g);
  const range = vx * flightTime;

  return {
    flightTime: parseFloat(flightTime.toFixed(4)),
    maxHeight: parseFloat(maxHeight.toFixed(4)),
    range: parseFloat(range.toFixed(4)),
    vx: parseFloat(vx.toFixed(4)),
    vy0: parseFloat(vy0.toFixed(4))
  };
}

// Electrical circuits
export function circuitResistors(type: 'series' | 'parallel', values: number[]): number {
  if (values.length === 0) return 0;
  if (type === 'series') {
    return parseFloat(values.reduce((acc, v) => acc + v, 0).toFixed(4));
  } else {
    const invSum = values.reduce((acc, v) => acc + (v > 0 ? 1 / v : 0), 0);
    return invSum > 0 ? parseFloat((1 / invSum).toFixed(4)) : 0;
  }
}

export function rlcResonance(L_henries: number, C_farads: number): number {
  if (L_henries <= 0 || C_farads <= 0) return 0;
  const f0 = 1 / (2 * Math.PI * Math.sqrt(L_henries * C_farads));
  return parseFloat(f0.toFixed(4));
}

// Financial: Loan EMI
export function calculateLoanEMI(principal: number, annualRatePct: number, tenureMonths: number): {
  emi: number;
  totalPayment: number;
  totalInterest: number;
} {
  const r = annualRatePct / (12 * 100);
  if (r === 0) {
    const emi = principal / tenureMonths;
    return { emi, totalPayment: principal, totalInterest: 0 };
  }
  const factor = Math.pow(1 + r, tenureMonths);
  const emi = (principal * r * factor) / (factor - 1);
  const totalPayment = emi * tenureMonths;
  const totalInterest = totalPayment - principal;

  return {
    emi: parseFloat(emi.toFixed(2)),
    totalPayment: parseFloat(totalPayment.toFixed(2)),
    totalInterest: parseFloat(totalInterest.toFixed(2))
  };
}

// Compound Interest
export function compoundInterest(
  p: number,
  rPct: number,
  tYears: number,
  nCompoundingPerYear: number = 12
): { finalAmount: number; interestEarned: number } {
  const r = rPct / 100;
  const a = p * Math.pow(1 + r / nCompoundingPerYear, nCompoundingPerYear * tYears);
  return {
    finalAmount: parseFloat(a.toFixed(2)),
    interestEarned: parseFloat((a - p).toFixed(2))
  };
}

// Date difference
export function calculateDateDiff(date1: string, date2: string): {
  days: number;
  weeks: number;
  months: number;
  years: number;
} {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  const diffMs = Math.abs(d2.getTime() - d1.getTime());
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const weeks = parseFloat((days / 7).toFixed(2));
  const months = parseFloat((days / 30.4375).toFixed(2));
  const years = parseFloat((days / 365.25).toFixed(2));

  return { days, weeks, months, years };
}
