import { StepSolution } from '../types/calc';
import { toExactFraction } from './mathEngine';

// Solve quadratic equation: a*x^2 + b*x + c = 0
export function solveQuadraticStepByStep(a: number, b: number, c: number): StepSolution {
  if (a === 0) {
    if (b === 0) {
      return {
        title: 'Degenerate Equation',
        problem: `${c} = 0`,
        category: 'Algebra',
        steps: [
          {
            label: 'Analysis',
            math: `${c} = 0`,
            explanation: c === 0 ? 'Identity: satisfied for all values of x.' : 'Contradiction: no solution exists.'
          }
        ],
        finalResult: c === 0 ? 'All real numbers' : 'No solution'
      };
    }
    // Linear
    const root = -c / b;
    return {
      title: 'Linear Equation Reduction (a = 0)',
      problem: `${b}x + ${c} = 0`,
      problemLatex: `${b}x + ${c} = 0`,
      category: 'Algebra',
      steps: [
        {
          label: 'Subtract constant from both sides',
          math: `${b}x = ${-c}`,
          explanation: `Subtract ${c} from both sides to isolate the linear term.`
        },
        {
          label: 'Divide by coefficient',
          math: `x = \\frac{${-c}}{${b}} = ${parseFloat(root.toFixed(6))}`,
          explanation: `Divide both sides by ${b}.`
        }
      ],
      finalResult: `x = ${parseFloat(root.toFixed(6))}`,
      finalMath: `x = ${parseFloat(root.toFixed(6))}`
    };
  }

  const D = b * b - 4 * a * c;
  const h = -b / (2 * a);
  const k = c - (b * b) / (4 * a);

  const steps = [
    {
      label: 'Identify Coefficients',
      math: `a = ${a}, \\quad b = ${b}, \\quad c = ${c}`,
      explanation: 'Standard form: ax^2 + bx + c = 0'
    },
    {
      label: 'Calculate the Discriminant (Δ)',
      math: `\\Delta = b^2 - 4ac = (${b})^2 - 4(${a})(${c}) = ${b * b} - ${4 * a * c} = ${D}`,
      explanation:
        D > 0
          ? 'Since Δ > 0, the equation has two distinct real roots.'
          : D === 0
          ? 'Since Δ = 0, the equation has one real repeated root.'
          : 'Since Δ < 0, the equation has two complex conjugate roots.'
    },
    {
      label: 'Apply the Quadratic Formula',
      math: `x = \\frac{-b \\pm \\sqrt{\\Delta}}{2a} = \\frac{-(${b}) \\pm \\sqrt{${D}}}{2(${a})}`,
      explanation: 'Substitute a, b, and Δ into the quadratic formula.'
    }
  ];

  let finalResult = '';
  let finalMath = '';

  if (D > 0) {
    const sqrtD = Math.sqrt(D);
    const x1 = (-b + sqrtD) / (2 * a);
    const x2 = (-b - sqrtD) / (2 * a);
    steps.push({
      label: 'Evaluate the two real roots',
      math: `x_1 = \\frac{${-b} + ${parseFloat(sqrtD.toFixed(6))}}{${2 * a}} = ${parseFloat(x1.toFixed(6))}, \\quad x_2 = \\frac{${-b} - ${parseFloat(sqrtD.toFixed(6))}}{${2 * a}} = ${parseFloat(x2.toFixed(6))}`,
      explanation: 'Split into plus and minus branches.'
    });
    steps.push({
      label: 'Parabola Vertex & Extrema',
      math: `\\text{Vertex } (h, k) = \\left(-\\frac{b}{2a}, c - \\frac{b^2}{4a}\\right) = (${parseFloat(h.toFixed(4))}, ${parseFloat(k.toFixed(4))})`,
      explanation: a > 0 ? 'Since a > 0, the parabola opens upwards (minimum vertex).' : 'Since a < 0, the parabola opens downwards (maximum vertex).'
    });
    finalResult = `x₁ = ${parseFloat(x1.toFixed(6))}, x₂ = ${parseFloat(x2.toFixed(6))}`;
    finalMath = `x_1 = ${parseFloat(x1.toFixed(6))}, \\quad x_2 = ${parseFloat(x2.toFixed(6))}`;
  } else if (D === 0) {
    const x = -b / (2 * a);
    steps.push({
      label: 'Evaluate the single repeated root',
      math: `x = \\frac{${-b}}{${2 * a}} = ${parseFloat(x.toFixed(6))}`,
      explanation: 'Both branches coincide.'
    });
    finalResult = `x = ${parseFloat(x.toFixed(6))} (multiplicity 2)`;
    finalMath = `x = ${parseFloat(x.toFixed(6))}`;
  } else {
    const realPart = -b / (2 * a);
    const imagPart = Math.sqrt(-D) / (2 * Math.abs(a));
    steps.push({
      label: 'Evaluate complex roots',
      math: `x = ${parseFloat(realPart.toFixed(6))} \\pm ${parseFloat(imagPart.toFixed(6))}i`,
      explanation: 'Use √(-1) = i to extract imaginary component.'
    });
    finalResult = `x = ${parseFloat(realPart.toFixed(6))} ± ${parseFloat(imagPart.toFixed(6))}i`;
    finalMath = `x = ${parseFloat(realPart.toFixed(6))} \\pm ${parseFloat(imagPart.toFixed(6))}i`;
  }

  return {
    title: 'Quadratic Equation Solution',
    problem: `${a}x² + ${b}x + ${c} = 0`,
    problemLatex: `${a}x^2 + ${b}x + ${c} = 0`,
    category: 'Polynomial Algebra',
    steps,
    finalResult,
    finalMath
  };
}

// Solve linear equation: a*x + b = c
export function solveLinearStepByStep(a: number, b: number, c: number): StepSolution {
  if (a === 0) {
    return {
      title: 'Degenerate Linear Equation',
      problem: `${b} = ${c}`,
      category: 'Algebra',
      steps: [
        {
          label: 'Comparison',
          math: `${b} = ${c}`,
          explanation: b === c ? 'Identity: valid for all x.' : 'Contradiction: no solution.'
        }
      ],
      finalResult: b === c ? 'All real numbers' : 'No solution'
    };
  }

  const rhs = c - b;
  const x = rhs / a;
  const xFrac = toExactFraction(x);

  return {
    title: 'Linear Equation Solution',
    problem: `${a}x + ${b} = ${c}`,
    problemLatex: `${a}x + ${b} = ${c}`,
    category: 'Linear Algebra',
    steps: [
      {
        label: 'Initial Equation',
        math: `${a}x + ${b} = ${c}`,
        explanation: 'Given linear equation in standard form.'
      },
      {
        label: 'Subtract constant term',
        math: `${a}x = ${c} - ${b} = ${rhs}`,
        explanation: `Subtract ${b} from both sides to isolate the variable term.`
      },
      {
        label: 'Divide by coefficient of x',
        math: `x = \\frac{${rhs}}{${a}} = ${parseFloat(x.toFixed(6))}${xFrac ? ` = ${xFrac}` : ''}`,
        explanation: `Divide both sides by ${a}.`
      }
    ],
    finalResult: `x = ${parseFloat(x.toFixed(6))}${xFrac ? ` (${xFrac})` : ''}`,
    finalMath: `x = ${xFrac || parseFloat(x.toFixed(6))}`
  };
}

// Prime Factorization step-by-step
export function solvePrimeFactorizationStepByStep(n: number): StepSolution {
  const original = Math.abs(Math.floor(n));
  if (original < 2) {
    return {
      title: 'Prime Factorization',
      problem: `Factorize ${n}`,
      category: 'Number Theory',
      steps: [
        {
          label: 'Special Case',
          math: `${n}`,
          explanation: `${n} does not possess a prime factorization by definition (primes are > 1).`
        }
      ],
      finalResult: `${n} is not a composite/prime integer.`
    };
  }

  let rem = original;
  const factors: number[] = [];
  const steps: { label: string; math: string; explanation?: string }[] = [];

  let d = 2;
  while (d * d <= rem) {
    if (rem % d === 0) {
      factors.push(d);
      const next = rem / d;
      steps.push({
        label: `Divide by prime factor ${d}`,
        math: `${rem} \\div ${d} = ${next}`,
        explanation: `${d} is the smallest prime dividing ${rem}.`
      });
      rem = next;
    } else {
      d = d === 2 ? 3 : d + 2;
    }
  }

  if (rem > 1) {
    factors.push(rem);
    steps.push({
      label: `Remaining prime quotient`,
      math: `${rem}`,
      explanation: `${rem} is prime, terminating factor division.`
    });
  }

  // Count exponents
  const counts: Record<number, number> = {};
  factors.forEach(f => {
    counts[f] = (counts[f] || 0) + 1;
  });

  const latexParts = Object.entries(counts).map(([prime, exp]) =>
    exp > 1 ? `${prime}^{${exp}}` : `${prime}`
  );
  const latexStr = latexParts.join(' \\times ');

  return {
    title: 'Prime Factorization Tree',
    problem: `Prime Factorization of ${original}`,
    problemLatex: `\\text{Factorize } ${original}`,
    category: 'Number Theory',
    steps,
    finalResult: factors.join(' × '),
    finalMath: `${original} = ${latexStr}`
  };
}

// Fraction addition/subtraction step-by-step
export function solveFractionArithmeticStepByStep(
  n1: number,
  d1: number,
  op: '+' | '-' | '*' | '/',
  n2: number,
  d2: number
): StepSolution {
  if (d1 === 0 || d2 === 0) {
    return {
      title: 'Fraction Arithmetic',
      problem: 'Division by zero',
      category: 'Arithmetic',
      steps: [
        {
          label: 'Error',
          math: `\\text{Denominator cannot be zero}`,
          explanation: 'Division by zero is undefined.'
        }
      ],
      finalResult: 'Undefined'
    };
  }

  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));

  if (op === '+' || op === '-') {
    const commonDenom = d1 === d2 ? d1 : Math.abs(d1 * d2) / gcd(d1, d2);
    const m1 = commonDenom / d1;
    const m2 = commonDenom / d2;
    const newN1 = n1 * m1;
    const newN2 = n2 * m2;
    const resNum = op === '+' ? newN1 + newN2 : newN1 - newN2;
    const commonFactor = Math.abs(gcd(resNum, commonDenom));
    const finalN = resNum / commonFactor;
    const finalD = commonDenom / commonFactor;

    return {
      title: `Fraction ${op === '+' ? 'Addition' : 'Subtraction'}`,
      problem: `${n1}/${d1} ${op} ${n2}/${d2}`,
      problemLatex: `\\frac{${n1}}{${d1}} ${op} \\frac{${n2}}{${d2}}`,
      category: 'Arithmetic',
      steps: [
        {
          label: 'Find Common Denominator',
          math: `\\text{LCM}(${d1}, ${d2}) = ${commonDenom}`,
          explanation: 'Convert both fractions to have an identical denominator.'
        },
        {
          label: 'Convert Numerators',
          math: `\\frac{${n1} \\times ${m1}}{${d1} \\times ${m1}} ${op} \\frac{${n2} \\times ${m2}}{${d2} \\times ${m2}} = \\frac{${newN1}}{${commonDenom}} ${op} \\frac{${newN2}}{${commonDenom}}`,
          explanation: 'Multiply numerator and denominator by scaling factors.'
        },
        {
          label: `${op === '+' ? 'Add' : 'Subtract'} Numerators`,
          math: `\\frac{${newN1} ${op} ${newN2}}{${commonDenom}} = \\frac{${resNum}}{${commonDenom}}`,
          explanation: 'Combine the numerators over the common denominator.'
        },
        {
          label: 'Reduce to Lowest Terms',
          math: `\\frac{${resNum} \\div ${commonFactor}}{${commonDenom} \\div ${commonFactor}} = \\frac{${finalN}}{${finalD}}`,
          explanation: `Divide numerator and denominator by their greatest common factor (${commonFactor}).`
        }
      ],
      finalResult: `${finalN}/${finalD}`,
      finalMath: `\\frac{${finalN}}{${finalD}}`
    };
  }

  // Multiplication
  if (op === '*') {
    const rawN = n1 * n2;
    const rawD = d1 * d2;
    const commonFactor = Math.abs(gcd(rawN, rawD));
    const finalN = rawN / commonFactor;
    const finalD = rawD / commonFactor;

    return {
      title: 'Fraction Multiplication',
      problem: `(${n1}/${d1}) * (${n2}/${d2})`,
      problemLatex: `\\frac{${n1}}{${d1}} \\times \\frac{${n2}}{${d2}}`,
      category: 'Arithmetic',
      steps: [
        {
          label: 'Multiply numerators and denominators directly',
          math: `\\frac{${n1} \\times ${n2}}{${d1} \\times ${d2}} = \\frac{${rawN}}{${rawD}}`,
          explanation: 'Multiply top numbers together and bottom numbers together.'
        },
        {
          label: 'Reduce to Lowest Terms',
          math: `\\frac{${rawN} \\div ${commonFactor}}{${rawD} \\div ${commonFactor}} = \\frac{${finalN}}{${finalD}}`,
          explanation: `Divide by greatest common divisor ${commonFactor}.`
        }
      ],
      finalResult: `${finalN}/${finalD}`,
      finalMath: `\\frac{${finalN}}{${finalD}}`
    };
  }

  // Division
  const rawN = n1 * d2;
  const rawD = d1 * n2;
  if (rawD === 0) {
    return {
      title: 'Fraction Division',
      problem: 'Division by zero',
      category: 'Arithmetic',
      steps: [{ label: 'Error', math: '\\text{Cannot divide by 0}', explanation: 'Divisor fraction evaluates to 0.' }],
      finalResult: 'Undefined'
    };
  }
  const commonFactor = Math.abs(gcd(rawN, rawD));
  const finalN = rawN / commonFactor;
  const finalD = rawD / commonFactor;

  return {
    title: 'Fraction Division',
    problem: `(${n1}/${d1}) ÷ (${n2}/${d2})`,
    problemLatex: `\\frac{${n1}}{${d1}} \\div \\frac{${n2}}{${d2}}`,
    category: 'Arithmetic',
    steps: [
      {
        label: 'Invert the second fraction and multiply',
        math: `\\frac{${n1}}{${d1}} \\times \\frac{${d2}}{${n2}}`,
        explanation: 'Dividing by a fraction is equivalent to multiplying by its reciprocal.'
      },
      {
        label: 'Perform Multiplication',
        math: `\\frac{${n1} \\times ${d2}}{${d1} \\times ${n2}} = \\frac{${rawN}}{${rawD}}`,
        explanation: 'Multiply numerators and denominators.'
      },
      {
        label: 'Simplify to Lowest Terms',
        math: `\\frac{${rawN} \\div ${commonFactor}}{${rawD} \\div ${commonFactor}} = \\frac{${finalN}}{${finalD}}`,
        explanation: `Divide by greatest common factor ${commonFactor}.`
      }
    ],
    finalResult: `${finalN}/${finalD}`,
    finalMath: `\\frac{${finalN}}{${finalD}}`
  };
}
