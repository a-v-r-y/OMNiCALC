import * as math from 'mathjs';

// High-precision 4th-order central difference for 1st derivative: f'(x)
export function numericalDerivative(fExpr: string, x: number, h: number = 1e-5): number {
  try {
    const f = math.compile(fExpr);
    const f1 = f.evaluate({ x: x + 2 * h });
    const f2 = f.evaluate({ x: x + h });
    const f3 = f.evaluate({ x: x - h });
    const f4 = f.evaluate({ x: x - 2 * h });
    return (-f1 + 8 * f2 - 8 * f3 + f4) / (12 * h);
  } catch {
    return NaN;
  }
}

// 2nd derivative: f''(x)
export function numericalSecondDerivative(fExpr: string, x: number, h: number = 1e-4): number {
  try {
    const f = math.compile(fExpr);
    const f1 = f.evaluate({ x: x + 2 * h });
    const f2 = f.evaluate({ x: x + h });
    const f0 = f.evaluate({ x });
    const f3 = f.evaluate({ x: x - h });
    const f4 = f.evaluate({ x: x - 2 * h });
    return (-f1 + 16 * f2 - 30 * f0 + 16 * f3 - f4) / (12 * h * h);
  } catch {
    return NaN;
  }
}

// Definite integral using Composite Simpson's 1/3 Rule (N must be even)
export function numericalIntegrate(fExpr: string, a: number, b: number, n: number = 1000): number {
  try {
    if (a === b) return 0;
    const f = math.compile(fExpr);
    if (n % 2 !== 0) n += 1;
    const h = (b - a) / n;

    let sum = f.evaluate({ x: a }) + f.evaluate({ x: b });

    for (let i = 1; i < n; i++) {
      const x = a + i * h;
      const val = f.evaluate({ x });
      if (isNaN(val) || !isFinite(val)) continue;
      sum += (i % 2 === 0 ? 2 : 4) * val;
    }

    return (h / 3) * sum;
  } catch {
    return NaN;
  }
}

// Double definite integral ∫[a,b] ∫[c,d] f(x, y) dy dx
export function numericalDoubleIntegral(
  fExpr: string,
  ax: number, bx: number,
  cy: number, dy: number,
  nx: number = 100, ny: number = 100
): number {
  try {
    const f = math.compile(fExpr);
    const hx = (bx - ax) / nx;
    const hy = (dy - cy) / ny;

    let total = 0;
    for (let i = 0; i < nx; i++) {
      const x = ax + (i + 0.5) * hx;
      for (let j = 0; j < ny; j++) {
        const y = cy + (j + 0.5) * hy;
        const val = f.evaluate({ x, y });
        if (!isNaN(val) && isFinite(val)) {
          total += val;
        }
      }
    }
    return total * hx * hy;
  } catch {
    return NaN;
  }
}

// Numerical limit calculation as x approaches c
export function numericalLimit(
  fExpr: string,
  c: number,
  direction: 'both' | 'left' | 'right' = 'both'
): { limit: number | string; left?: number; right?: number } {
  try {
    const f = math.compile(fExpr);
    const deltas = [1e-3, 1e-5, 1e-8, 1e-10];

    const leftVals = deltas.map(d => f.evaluate({ x: c - d })).filter(v => !isNaN(v) && isFinite(v));
    const rightVals = deltas.map(d => f.evaluate({ x: c + d })).filter(v => !isNaN(v) && isFinite(v));

    const left = leftVals.length > 0 ? leftVals[leftVals.length - 1] : NaN;
    const right = rightVals.length > 0 ? rightVals[rightVals.length - 1] : NaN;

    if (direction === 'left') {
      return { limit: isNaN(left) ? 'Undefined' : left, left };
    }
    if (direction === 'right') {
      return { limit: isNaN(right) ? 'Undefined' : right, right };
    }

    if (Math.abs(left - right) < 1e-4) {
      return { limit: (left + right) / 2, left, right };
    } else {
      return { limit: 'DNE (Left ≠ Right)', left, right };
    }
  } catch {
    return { limit: 'Undefined' };
  }
}

// Arc length of y = f(x) from a to b: L = ∫ sqrt(1 + (f'(x))^2) dx
export function arcLength(fExpr: string, a: number, b: number, n: number = 500): number {
  try {
    const f = math.compile(fExpr);
    const h = (b - a) / n;
    let length = 0;
    for (let i = 0; i < n; i++) {
      const x1 = a + i * h;
      const x2 = x1 + h;
      const y1 = f.evaluate({ x: x1 });
      const y2 = f.evaluate({ x: x2 });
      if (!isNaN(y1) && !isNaN(y2)) {
        length += Math.hypot(h, y2 - y1);
      }
    }
    return length;
  } catch {
    return NaN;
  }
}

// Taylor / Maclaurin Polynomial series coefficients at center x0 up to order n
export function taylorSeries(fExpr: string, x0: number = 0, order: number = 4): string {
  try {
    const terms: string[] = [];
    let currentExpr = fExpr;
    const f = math.compile(currentExpr);
    const f0 = f.evaluate({ x: x0 });

    if (Math.abs(f0) > 1e-9) {
      terms.push(parseFloat(f0.toFixed(4)).toString());
    }

    let fact = 1;
    let deriv = math.parse(fExpr);

    for (let k = 1; k <= order; k++) {
      fact *= k;
      deriv = math.derivative(deriv, 'x');
      const compiledDeriv = deriv.compile();
      const val = compiledDeriv.evaluate({ x: x0 });

      if (!isNaN(val) && Math.abs(val) > 1e-9) {
        const coeff = val / fact;
        const coeffStr = Math.abs(coeff - 1) < 1e-9 ? '' : parseFloat(coeff.toFixed(4)).toString();
        const termVar = x0 === 0 ? (k === 1 ? 'x' : `x^${k}`) : (k === 1 ? `(x - ${x0})` : `(x - ${x0})^${k}`);
        const sign = coeff > 0 && terms.length > 0 ? '+ ' : (coeff < 0 ? '- ' : '');
        terms.push(`${sign}${coeffStr ? Math.abs(coeff).toFixed(4) : ''}${termVar}`);
      }
    }

    return terms.length > 0 ? terms.join(' ') : '0';
  } catch (err: any) {
    return `Error: ${err.message}`;
  }
}

// Runge-Kutta 4th order (RK4) numerical ODE solver for dy/dx = f(x, y)
export interface ODESolutionPoint {
  x: number;
  y: number;
}

export function solveODE_RK4(
  dydxExpr: string,
  x0: number,
  y0: number,
  xEnd: number,
  steps: number = 100
): ODESolutionPoint[] {
  try {
    const f = math.compile(dydxExpr);
    const h = (xEnd - x0) / steps;
    const points: ODESolutionPoint[] = [{ x: x0, y: y0 }];

    let x = x0;
    let y = y0;

    for (let i = 0; i < steps; i++) {
      const k1 = f.evaluate({ x, y });
      const k2 = f.evaluate({ x: x + h / 2, y: y + (h * k1) / 2 });
      const k3 = f.evaluate({ x: x + h / 2, y: y + (h * k2) / 2 });
      const k4 = f.evaluate({ x: x + h, y: y + h * k3 });

      y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4);
      x = x + h;

      if (!isNaN(y) && isFinite(y)) {
        points.push({ x: parseFloat(x.toFixed(5)), y: parseFloat(y.toFixed(5)) });
      } else {
        break;
      }
    }
    return points;
  } catch {
    return [];
  }
}
