// Gamma function using Lanczos approximation (g=7, n=9)
export function gammaFunction(z: number): number {
  if (z < 0.5) {
    // Reflection formula: Gamma(1-z) * Gamma(z) = pi / sin(pi*z)
    return Math.PI / (Math.sin(Math.PI * z) * gammaFunction(1 - z));
  }
  z -= 1;
  const p = [
    0.99999999999980993,
    676.5209382780397,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.138571095836524,
    9.9843695780195716e-6,
    1.5056327351493116e-7
  ];
  let x = p[0];
  for (let i = 1; i < p.length; i++) {
    x += p[i] / (z + i);
  }
  const t = z + 7.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(t, z + 0.5) * Math.exp(-t) * x;
}

export const gamma = gammaFunction;

// Beta function: B(x, y) = (Gamma(x) * Gamma(y)) / Gamma(x + y)
export function betaFunction(x: number, y: number): number {
  return (gammaFunction(x) * gammaFunction(y)) / gammaFunction(x + y);
}

export const beta = betaFunction;

// Error function erf(x)
export function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  const a = Math.abs(x);
  const p = 0.3275911;
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const t = 1.0 / (1.0 + p * a);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-a * a);
  return sign * y;
}

export function erfc(x: number): number {
  return 1 - erf(x);
}

// Bessel function of first kind of order 0: J0(x)
export function besselJ0(x: number): number {
  const ax = Math.abs(x);
  if (ax < 3.75) {
    const y = (x / 3.75) * (x / 3.75);
    return (
      1.0 +
      y *
        (3.5156229 +
          y *
            (3.0899424 +
              y *
                (1.2067492 +
                  y * (0.2659732 + y * (0.360768e-1 + y * 0.45813e-2)))))
    );
  } else {
    const y = 3.75 / ax;
    const f0 =
      0.79788456 +
      y *
        (-0.00000077 +
          y *
            (-0.0055274 +
              y * (0.00009512 + y * (0.00137237 + y * -0.00072805))));
    const theta0 =
      ax -
      0.78539816 +
      y *
        (-0.04166397 +
          y *
            (-0.00003954 +
              y * (0.00262573 + y * (-0.00054125 + y * -0.00029333))));
    return (1.0 / Math.sqrt(ax)) * f0 * Math.cos(theta0);
  }
}

// Bessel function of first kind of order 1: J1(x)
export function besselJ1(x: number): number {
  const ax = Math.abs(x);
  let ans: number;
  if (ax < 3.75) {
    const y = (x / 3.75) * (x / 3.75);
    ans =
      x *
      (0.5 +
        y *
          (0.87890594 +
            y *
              (0.51498869 +
                y *
                  (0.15084934 +
                    y * (0.02658733 + y * (0.00301532 + y * 0.00032411))))));
  } else {
    const y = 3.75 / ax;
    const f1 =
      0.79788456 +
      y *
        (0.00000156 +
          y *
            (0.01659667 +
              y * (0.00017105 + y * (-0.00249511 + y * 0.00113653))));
    const theta1 =
      ax -
      2.35619449 +
      y *
        (0.04166397 +
          y *
            (-0.00003954 +
              y * (-0.00262573 + y * (-0.00054125 + y * 0.00029333))));
    ans = (1.0 / Math.sqrt(ax)) * f1 * Math.cos(theta1);
    if (x < 0) ans = -ans;
  }
  return ans;
}

// Riemann Zeta Function for real s > 1
export function riemannZeta(s: number): number {
  if (s <= 1) return Infinity;
  let sum = 0;
  for (let n = 1; n <= 10000; n++) {
    const term = Math.pow(n, -s);
    sum += term;
    if (term < 1e-12) break;
  }
  return sum;
}

// Lambert W function W0(x)
export function lambertW(x: number): number {
  if (x < -1 / Math.E) return NaN;
  let w = x > 0 ? Math.log(1 + x) : x;
  for (let i = 0; i < 50; i++) {
    const ew = Math.exp(w);
    const wew = w * ew;
    const f = wew - x;
    const fPrime = ew * (w + 1);
    const dw = f / fPrime;
    w -= dw;
    if (Math.abs(dw) < 1e-12) break;
  }
  return w;
}

// Discrete Fourier Transform (DFT)
export interface DFTPoint {
  k: number;
  freq: number;
  real: number;
  imag: number;
  magnitude: number;
  phase: number;
}

export function computeDFT(samples: number[], sampleRate: number = 100): DFTPoint[] {
  const N = samples.length;
  const result: DFTPoint[] = [];

  for (let k = 0; k < Math.floor(N / 2); k++) {
    let re = 0;
    let im = 0;
    for (let n = 0; n < N; n++) {
      const angle = (2 * Math.PI * k * n) / N;
      re += samples[n] * Math.cos(angle);
      im -= samples[n] * Math.sin(angle);
    }
    const mag = Math.sqrt(re * re + im * im) / N;
    const phase = Math.atan2(im, re);
    const freq = (k * sampleRate) / N;

    result.push({
      k,
      freq: parseFloat(freq.toFixed(2)),
      real: parseFloat(re.toFixed(4)),
      imag: parseFloat(im.toFixed(4)),
      magnitude: parseFloat(mag.toFixed(5)),
      phase: parseFloat(phase.toFixed(4))
    });
  }

  return result;
}

export const discreteFourierTransform = computeDFT;

// Discrete 1D Convolution: (f * g)[n]
export function discreteConvolution(f: number[], g: number[]): number[] {
  const nf = f.length;
  const ng = g.length;
  const resLen = nf + ng - 1;
  const res = new Array(resLen).fill(0);

  for (let i = 0; i < nf; i++) {
    for (let j = 0; j < ng; j++) {
      res[i + j] += f[i] * g[j];
    }
  }

  return res.map(v => parseFloat(v.toFixed(4)));
}
