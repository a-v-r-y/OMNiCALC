// Comprehensive Mechanical Engineering Solvers

// ==========================================
// 1. Force Calculations
// ==========================================

export function calculateForce(m: number, a: number): number {
  return parseFloat((m * a).toFixed(4));
}

export function calculateWeight(m: number, g: number = 9.80665): number {
  return parseFloat((m * g).toFixed(4));
}

export function calculateFriction(mu: number, normalForce: number): number {
  return parseFloat((mu * normalForce).toFixed(4));
}

export function calculateHookeSpring(k: number, x: number): { force: number; potentialEnergy: number } {
  const force = k * x;
  const pe = 0.5 * k * x * x;
  return {
    force: parseFloat(force.toFixed(4)),
    potentialEnergy: parseFloat(pe.toFixed(4))
  };
}

export function calculateCentripetalForce(m: number, v: number, r: number): { force: number; acceleration: number } {
  if (r <= 0) return { force: 0, acceleration: 0 };
  const a = (v * v) / r;
  const f = m * a;
  return {
    force: parseFloat(f.toFixed(4)),
    acceleration: parseFloat(a.toFixed(4))
  };
}

// ==========================================
// 2. Torque Calculations
// ==========================================

export function calculateTorque(r: number, f: number, angleDeg: number = 90): number {
  const thetaRad = (angleDeg * Math.PI) / 180;
  return parseFloat((r * f * Math.sin(thetaRad)).toFixed(4));
}

export function calculateTorqueFromPower(powerWatts: number, rpm: number): { torqueNm: number; omegaRadS: number } {
  if (rpm <= 0) return { torqueNm: 0, omegaRadS: 0 };
  const omega = (2 * Math.PI * rpm) / 60;
  const torque = powerWatts / omega;
  return {
    torqueNm: parseFloat(torque.toFixed(4)),
    omegaRadS: parseFloat(omega.toFixed(4))
  };
}

export function calculateRotationalDynamics(inertia: number, alpha: number): number {
  return parseFloat((inertia * alpha).toFixed(4));
}

// ==========================================
// 3. Work, Energy & Power
// ==========================================

export function calculateWork(force: number, distance: number, angleDeg: number = 0): number {
  const thetaRad = (angleDeg * Math.PI) / 180;
  return parseFloat((force * distance * Math.cos(thetaRad)).toFixed(4));
}

export function calculateKineticEnergy(mass: number, velocity: number): number {
  return parseFloat((0.5 * mass * velocity * velocity).toFixed(4));
}

export function calculateRotationalKineticEnergy(inertia: number, omegaRadS: number): number {
  return parseFloat((0.5 * inertia * omegaRadS * omegaRadS).toFixed(4));
}

export function calculatePotentialEnergy(mass: number, height: number, g: number = 9.80665): number {
  return parseFloat((mass * g * height).toFixed(4));
}

export function calculateMechanicalPower(work: number, timeSec: number): { watts: number; horsepower: number } {
  if (timeSec <= 0) return { watts: 0, horsepower: 0 };
  const watts = work / timeSec;
  const hp = watts / 745.699872;
  return {
    watts: parseFloat(watts.toFixed(4)),
    horsepower: parseFloat(hp.toFixed(4))
  };
}

export function calculateEfficiency(powerOut: number, powerIn: number): { efficiencyPercent: number; powerLoss: number } {
  if (powerIn <= 0) return { efficiencyPercent: 0, powerLoss: 0 };
  const eff = (powerOut / powerIn) * 100;
  const loss = Math.max(0, powerIn - powerOut);
  return {
    efficiencyPercent: parseFloat(eff.toFixed(2)),
    powerLoss: parseFloat(loss.toFixed(4))
  };
}

// ==========================================
// 4. Stress, Strain & Materials
// ==========================================

export function calculateStress(force: number, area: number): {
  stressPa: number;
  stressMPa: number;
  stressPsi: number;
} {
  if (area <= 0) return { stressPa: 0, stressMPa: 0, stressPsi: 0 };
  const pa = force / area;
  return {
    stressPa: parseFloat(pa.toFixed(2)),
    stressMPa: parseFloat((pa / 1e6).toFixed(4)),
    stressPsi: parseFloat((pa * 0.0001450377).toFixed(4))
  };
}

export function calculateStrain(deltaL: number, initialL: number): {
  strain: number;
  percent: number;
  microstrain: number;
} {
  if (initialL <= 0) return { strain: 0, percent: 0, microstrain: 0 };
  const strain = deltaL / initialL;
  return {
    strain: parseFloat(strain.toExponential(4)),
    percent: parseFloat((strain * 100).toFixed(4)),
    microstrain: parseFloat((strain * 1e6).toFixed(2))
  };
}

export function calculateYoungsModulus(stressPa: number, strain: number): {
  modulusPa: number;
  modulusGPa: number;
  modulusMsi: number;
} {
  if (strain === 0) return { modulusPa: 0, modulusGPa: 0, modulusMsi: 0 };
  const e = stressPa / strain;
  return {
    modulusPa: parseFloat(e.toExponential(4)),
    modulusGPa: parseFloat((e / 1e9).toFixed(3)),
    modulusMsi: parseFloat((e * 1.45038e-10).toFixed(3))
  };
}

export function calculateFactorOfSafety(yieldStrength: number, workingStress: number): {
  factorOfSafety: number;
  status: 'Safe' | 'Marginal' | 'Failure / Yielding';
} {
  if (workingStress <= 0) return { factorOfSafety: 0, status: 'Failure / Yielding' };
  const fos = yieldStrength / workingStress;
  let status: 'Safe' | 'Marginal' | 'Failure / Yielding' = 'Safe';
  if (fos < 1.0) status = 'Failure / Yielding';
  else if (fos < 1.5) status = 'Marginal';

  return {
    factorOfSafety: parseFloat(fos.toFixed(2)),
    status
  };
}

// ==========================================
// 5. Pressure & Hydraulics
// ==========================================

export function calculatePressure(force: number, area: number): {
  pascal: number;
  bar: number;
  psi: number;
  atm: number;
} {
  if (area <= 0) return { pascal: 0, bar: 0, psi: 0, atm: 0 };
  const p = force / area;
  return {
    pascal: parseFloat(p.toFixed(2)),
    bar: parseFloat((p / 100000).toFixed(4)),
    psi: parseFloat((p * 0.000145038).toFixed(4)),
    atm: parseFloat((p / 101325).toFixed(4))
  };
}

export function calculateHydrostaticPressure(
  density: number,
  depth: number,
  surfacePressure: number = 101325,
  g: number = 9.80665
): {
  gaugePressurePa: number;
  absolutePressurePa: number;
  depthMeters: number;
} {
  const gauge = density * g * depth;
  const abs = surfacePressure + gauge;
  return {
    gaugePressurePa: parseFloat(gauge.toFixed(2)),
    absolutePressurePa: parseFloat(abs.toFixed(2)),
    depthMeters: depth
  };
}

export function calculateHydraulicPress(
  f1: number,
  d1: number,
  d2: number
): {
  f2: number;
  mechanicalAdvantage: number;
  ratioAreas: number;
} {
  if (d1 <= 0 || d2 <= 0) return { f2: 0, mechanicalAdvantage: 0, ratioAreas: 0 };
  const areaRatio = (d2 * d2) / (d1 * d1);
  const f2 = f1 * areaRatio;
  return {
    f2: parseFloat(f2.toFixed(2)),
    mechanicalAdvantage: parseFloat(areaRatio.toFixed(2)),
    ratioAreas: parseFloat(areaRatio.toFixed(2))
  };
}

// ==========================================
// 6. Motion & Gear Trains
// ==========================================

export function calculateLinearKinematics(
  v0: number,
  a: number,
  t: number
): {
  finalVelocity: number;
  displacement: number;
  averageVelocity: number;
} {
  const v = v0 + a * t;
  const d = v0 * t + 0.5 * a * t * t;
  const vAvg = (v0 + v) / 2;
  return {
    finalVelocity: parseFloat(v.toFixed(4)),
    displacement: parseFloat(d.toFixed(4)),
    averageVelocity: parseFloat(vAvg.toFixed(4))
  };
}

export function calculateRotationalMotion(
  omega0Rpm: number,
  alphaRadS2: number,
  tSec: number
): {
  omegaFinalRpm: number;
  omegaFinalRadS: number;
  revolutions: number;
  radiansTotal: number;
} {
  const omega0RadS = (2 * Math.PI * omega0Rpm) / 60;
  const omegaFinalRadS = omega0RadS + alphaRadS2 * tSec;
  const thetaRad = omega0RadS * tSec + 0.5 * alphaRadS2 * tSec * tSec;
  const revs = thetaRad / (2 * Math.PI);
  const finalRpm = (omegaFinalRadS * 60) / (2 * Math.PI);

  return {
    omegaFinalRpm: parseFloat(finalRpm.toFixed(2)),
    omegaFinalRadS: parseFloat(omegaFinalRadS.toFixed(3)),
    revolutions: parseFloat(revs.toFixed(2)),
    radiansTotal: parseFloat(thetaRad.toFixed(2))
  };
}

export function calculateGearTrain(
  nDriver: number,
  nDriven: number,
  speedInRpm: number,
  torqueInNm: number
): {
  gearRatio: number;
  speedOutRpm: number;
  torqueOutNm: number;
  mechanicalAdvantage: number;
} {
  if (nDriver <= 0 || nDriven <= 0) return { gearRatio: 0, speedOutRpm: 0, torqueOutNm: 0, mechanicalAdvantage: 0 };
  const gr = nDriven / nDriver;
  const speedOut = speedInRpm / gr;
  const torqueOut = torqueInNm * gr;
  return {
    gearRatio: parseFloat(gr.toFixed(3)),
    speedOutRpm: parseFloat(speedOut.toFixed(2)),
    torqueOutNm: parseFloat(torqueOut.toFixed(2)),
    mechanicalAdvantage: parseFloat(gr.toFixed(3))
  };
}

// ==========================================
// 7. Fluid Calculations
// ==========================================

export function calculateFlowRate(diameterM: number, velocityMPerS: number): {
  areaM2: number;
  flowRateM3S: number;
  flowRateLPerMin: number;
  flowRateGPM: number;
} {
  if (diameterM <= 0) return { areaM2: 0, flowRateM3S: 0, flowRateLPerMin: 0, flowRateGPM: 0 };
  const area = (Math.PI * diameterM * diameterM) / 4;
  const q = area * velocityMPerS;
  const lpm = q * 1000 * 60;
  const gpm = q * 15850.323;

  return {
    areaM2: parseFloat(area.toExponential(4)),
    flowRateM3S: parseFloat(q.toFixed(6)),
    flowRateLPerMin: parseFloat(lpm.toFixed(2)),
    flowRateGPM: parseFloat(gpm.toFixed(2))
  };
}

export function calculateContinuity(
  d1M: number,
  v1MPerS: number,
  d2M: number
): {
  v2MPerS: number;
  areaRatio: number;
} {
  if (d1M <= 0 || d2M <= 0) return { v2MPerS: 0, areaRatio: 0 };
  const aRatio = (d1M * d1M) / (d2M * d2M);
  const v2 = v1MPerS * aRatio;
  return {
    v2MPerS: parseFloat(v2.toFixed(4)),
    areaRatio: parseFloat(aRatio.toFixed(3))
  };
}

export function calculateReynoldsNumber(
  densityKgM3: number,
  velocityMPerS: number,
  diameterM: number,
  viscosityPaS: number
): {
  reynoldsNumber: number;
  regime: 'Laminar (Re < 2,300)' | 'Transitional (2,300 ≤ Re ≤ 4,000)' | 'Turbulent (Re > 4,000)';
} {
  if (viscosityPaS <= 0 || diameterM <= 0) return { reynoldsNumber: 0, regime: 'Laminar (Re < 2,300)' };
  const re = (densityKgM3 * velocityMPerS * diameterM) / viscosityPaS;
  let regime: 'Laminar (Re < 2,300)' | 'Transitional (2,300 ≤ Re ≤ 4,000)' | 'Turbulent (Re > 4,000)' = 'Laminar (Re < 2,300)';
  if (re > 4000) regime = 'Turbulent (Re > 4,000)';
  else if (re >= 2300) regime = 'Transitional (2,300 ≤ Re ≤ 4,000)';

  return {
    reynoldsNumber: parseFloat(re.toFixed(1)),
    regime
  };
}

export function calculateDarcyWeisbach(
  frictionFactor: number,
  lengthM: number,
  diameterM: number,
  velocityMPerS: number,
  g: number = 9.80665
): {
  headLossM: number;
  pressureDropPa: number;
  densityWater: number;
} {
  if (diameterM <= 0) return { headLossM: 0, pressureDropPa: 0, densityWater: 1000 };
  const density = 1000; // default water kg/m3
  const hf = frictionFactor * (lengthM / diameterM) * ((velocityMPerS * velocityMPerS) / (2 * g));
  const deltaP = density * g * hf;

  return {
    headLossM: parseFloat(hf.toFixed(3)),
    pressureDropPa: parseFloat(deltaP.toFixed(2)),
    densityWater: density
  };
}

export function calculateBernoulli(
  p1Pa: number,
  v1MPerS: number,
  h1M: number,
  v2MPerS: number,
  h2M: number,
  densityKgM3: number = 1000,
  g: number = 9.80665
): {
  p2Pa: number;
  p2KPa: number;
  pressureDelta: number;
} {
  // P1 + 0.5*rho*v1^2 + rho*g*h1 = P2 + 0.5*rho*v2^2 + rho*g*h2
  const total1 = p1Pa + 0.5 * densityKgM3 * v1MPerS * v1MPerS + densityKgM3 * g * h1M;
  const p2 = total1 - 0.5 * densityKgM3 * v2MPerS * v2MPerS - densityKgM3 * g * h2M;
  return {
    p2Pa: parseFloat(p2.toFixed(2)),
    p2KPa: parseFloat((p2 / 1000).toFixed(3)),
    pressureDelta: parseFloat((p1Pa - p2).toFixed(2))
  };
}
