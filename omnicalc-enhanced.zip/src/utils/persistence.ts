/**
 * Versioned localStorage persistence for OmniCalc.
 * All keys live under `omnicalc:v1:*`. Corrupt or missing data falls back
 * to caller-supplied defaults — storage must never break the app.
 */

const KEY_PREFIX = 'omnicalc:v1:';

export function loadPersisted<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(KEY_PREFIX + key);
    if (raw === null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function savePersisted(key: string, value: unknown): void {
  try {
    window.localStorage.setItem(KEY_PREFIX + key, JSON.stringify(value));
  } catch {
    // Quota exceeded or storage unavailable — stay silent, app keeps working
  }
}

export function clearPersisted(key: string): void {
  try {
    window.localStorage.removeItem(KEY_PREFIX + key);
  } catch {
    // ignore
  }
}

// Per-key debounced saves so rapid state changes (typing, history) don't
// hammer localStorage on every keystroke.
const timers = new Map<string, ReturnType<typeof setTimeout>>();

export function savePersistedDebounced(key: string, value: unknown, delayMs = 400): void {
  const existing = timers.get(key);
  if (existing) clearTimeout(existing);
  timers.set(
    key,
    setTimeout(() => {
      timers.delete(key);
      savePersisted(key, value);
    }, delayMs)
  );
}

// Well-known keys
export const PersistKeys = {
  angleUnit: 'angleUnit',
  precision: 'precision',
  settings: 'settings',
  history: 'history',
  notebook: 'notebook',
} as const;
