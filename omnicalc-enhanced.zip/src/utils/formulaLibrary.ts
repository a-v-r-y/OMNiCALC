import { FormulaItem } from '../types/calc';

// ============================================================================
// 1. PHYSICS FORMULAS
// ============================================================================
export const PHYSICS_FORMULAS: FormulaItem[] = [
  // --- Kinematics & Dynamics ---
  {
    id: 'phys_kinematics_v',
    name: 'Velocity-Time (Kinematics)',
    category: 'Physics',
    subcategory: 'Kinematics',
    formula: 'v = u + a * t',
    latex: 'v = u + at',
    description: 'Final velocity under constant acceleration',
    variables: [
      { symbol: 'v', name: 'Final Velocity', unit: 'm/s', defaultValue: 20 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 0 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 2.04 }
    ],
    solveFor: (target, vals) => {
      const { v, u, a, t } = vals;
      if (target === 'v') return u + a * t;
      if (target === 'u') return v - a * t;
      if (target === 'a') return (v - u) / t;
      if (target === 't') return (v - u) / a;
      return null;
    }
  },
  {
    id: 'phys_kinematics_s',
    name: 'Displacement-Time (Kinematics)',
    category: 'Physics',
    subcategory: 'Kinematics',
    formula: 's = u * t + 0.5 * a * t^2',
    latex: 's = ut + \\frac{1}{2}at^2',
    description: 'Position / displacement under uniform acceleration',
    variables: [
      { symbol: 's', name: 'Displacement', unit: 'm', defaultValue: 20 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 0 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 2.02 }
    ],
    solveFor: (target, vals) => {
      const { s, u, a, t } = vals;
      if (target === 's') return u * t + 0.5 * a * t * t;
      if (target === 'u') return (s - 0.5 * a * t * t) / t;
      if (target === 'a') return (2 * (s - u * t)) / (t * t);
      if (target === 't') {
        const A = 0.5 * a, B = u, C = -s;
        const disc = B * B - 4 * A * C;
        return disc >= 0 ? (-B + Math.sqrt(disc)) / (2 * A) : null;
      }
      return null;
    }
  },
  {
    id: 'phys_torricelli',
    name: "Torricelli's Velocity-Displacement",
    category: 'Physics',
    subcategory: 'Kinematics',
    formula: 'v^2 = u^2 + 2 * a * s',
    latex: 'v^2 = u^2 + 2as',
    description: 'Relates velocities, constant acceleration, and distance',
    variables: [
      { symbol: 'v', name: 'Final Velocity', unit: 'm/s', defaultValue: 14 },
      { symbol: 'u', name: 'Initial Velocity', unit: 'm/s', defaultValue: 0 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 's', name: 'Displacement', unit: 'm', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { v, u, a, s } = vals;
      if (target === 'v') return Math.sqrt(Math.max(0, u * u + 2 * a * s));
      if (target === 'u') return Math.sqrt(Math.max(0, v * v - 2 * a * s));
      if (target === 'a') return (v * v - u * u) / (2 * s);
      if (target === 's') return (v * v - u * u) / (2 * a);
      return null;
    }
  },
  {
    id: 'phys_newton_second',
    name: "Newton's Second Law of Motion",
    category: 'Physics',
    subcategory: 'Dynamics',
    formula: 'F = m * a',
    latex: 'F = m \\cdot a',
    description: 'Net external force equals mass times acceleration',
    variables: [
      { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 50 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 5 }
    ],
    solveFor: (target, vals) => {
      const { F, m, a } = vals;
      if (target === 'F') return m * a;
      if (target === 'm') return F / a;
      if (target === 'a') return F / m;
      return null;
    }
  },
  {
    id: 'phys_momentum',
    name: 'Linear Momentum',
    category: 'Physics',
    subcategory: 'Dynamics',
    formula: 'p = m * v',
    latex: 'p = m \\cdot v',
    description: 'Product of an object’s mass and velocity',
    variables: [
      { symbol: 'p', name: 'Momentum', unit: 'kg·m/s', defaultValue: 1200 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 80 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 15 }
    ],
    solveFor: (target, vals) => {
      const { p, m, v } = vals;
      if (target === 'p') return m * v;
      if (target === 'm') return p / v;
      if (target === 'v') return p / m;
      return null;
    }
  },
  {
    id: 'phys_impulse',
    name: 'Impulse-Momentum Theorem',
    category: 'Physics',
    subcategory: 'Dynamics',
    formula: 'J = F * t',
    latex: 'J = F \\cdot \\Delta t',
    description: 'Impulse imparted by an average force over time duration',
    variables: [
      { symbol: 'J', name: 'Impulse', unit: 'N·s', defaultValue: 300 },
      { symbol: 'F', name: 'Average Force', unit: 'N', defaultValue: 150 },
      { symbol: 't', name: 'Time Interval', unit: 's', defaultValue: 2 }
    ],
    solveFor: (target, vals) => {
      const { J, F, t } = vals;
      if (target === 'J') return F * t;
      if (target === 'F') return J / t;
      if (target === 't') return J / F;
      return null;
    }
  },
  {
    id: 'phys_kinetic_energy',
    name: 'Translational Kinetic Energy',
    category: 'Physics',
    subcategory: 'Work & Energy',
    formula: 'KE = 0.5 * m * v^2',
    latex: 'KE = \\frac{1}{2}mv^2',
    description: 'Energy possessed by an object due to its linear motion',
    variables: [
      { symbol: 'KE', name: 'Kinetic Energy', unit: 'J', defaultValue: 45000 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1000 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 9.48 }
    ],
    solveFor: (target, vals) => {
      const { KE, m, v } = vals;
      if (target === 'KE') return 0.5 * m * v * v;
      if (target === 'm') return (2 * KE) / (v * v);
      if (target === 'v') return Math.sqrt((2 * KE) / m);
      return null;
    }
  },
  {
    id: 'phys_gravitational_pe',
    name: 'Gravitational Potential Energy',
    category: 'Physics',
    subcategory: 'Work & Energy',
    formula: 'PE = m * g * h',
    latex: 'PE = m \\cdot g \\cdot h',
    description: 'Potential energy stored in an elevated mass in a uniform gravity field',
    variables: [
      { symbol: 'PE', name: 'Potential Energy', unit: 'J', defaultValue: 4900 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 50 },
      { symbol: 'g', name: 'Gravity Accel', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 'h', name: 'Height', unit: 'm', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { PE, m, g, h } = vals;
      if (target === 'PE') return m * g * h;
      if (target === 'm') return PE / (g * h);
      if (target === 'g') return PE / (m * h);
      if (target === 'h') return PE / (m * g);
      return null;
    }
  },
  {
    id: 'phys_work',
    name: 'Mechanical Work',
    category: 'Physics',
    subcategory: 'Work & Energy',
    formula: 'W = F * d * cos(theta)',
    latex: 'W = F \\cdot d \\cos(\\theta)',
    description: 'Work done by a constant force over displacement',
    variables: [
      { symbol: 'W', name: 'Work', unit: 'J', defaultValue: 400 },
      { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 50 },
      { symbol: 'd', name: 'Displacement', unit: 'm', defaultValue: 8 },
      { symbol: 'theta', name: 'Angle', unit: 'deg', defaultValue: 0 }
    ],
    solveFor: (target, vals) => {
      const { W, F, d, theta } = vals;
      const rad = (theta * Math.PI) / 180;
      if (target === 'W') return F * d * Math.cos(rad);
      if (target === 'F') return W / (d * Math.cos(rad));
      if (target === 'd') return W / (F * Math.cos(rad));
      return null;
    }
  },
  {
    id: 'phys_power',
    name: 'Mechanical Power',
    category: 'Physics',
    subcategory: 'Work & Energy',
    formula: 'P = W / t',
    latex: 'P = \\frac{W}{t}',
    description: 'Rate of doing work or transferring energy',
    variables: [
      { symbol: 'P', name: 'Power', unit: 'W', defaultValue: 250 },
      { symbol: 'W', name: 'Work', unit: 'J', defaultValue: 1000 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 4 }
    ],
    solveFor: (target, vals) => {
      const { P, W, t } = vals;
      if (target === 'P') return W / t;
      if (target === 'W') return P * t;
      if (target === 't') return W / P;
      return null;
    }
  },
  {
    id: 'phys_hookes_law',
    name: "Hooke's Law (Elastic Spring)",
    category: 'Physics',
    subcategory: 'Harmonic Motion',
    formula: 'F = k * x',
    latex: 'F = k \\cdot x',
    description: 'Restoring force exerted by an ideal spring',
    variables: [
      { symbol: 'F', name: 'Restoring Force', unit: 'N', defaultValue: 60 },
      { symbol: 'k', name: 'Spring Constant', unit: 'N/m', defaultValue: 300 },
      { symbol: 'x', name: 'Extension / Compression', unit: 'm', defaultValue: 0.2 }
    ],
    solveFor: (target, vals) => {
      const { F, k, x } = vals;
      if (target === 'F') return k * x;
      if (target === 'k') return F / x;
      if (target === 'x') return F / k;
      return null;
    }
  },
  {
    id: 'phys_elastic_pe',
    name: 'Elastic Potential Energy',
    category: 'Physics',
    subcategory: 'Harmonic Motion',
    formula: 'U = 0.5 * k * x^2',
    latex: 'U = \\frac{1}{2}kx^2',
    description: 'Potential energy stored in a stretched or compressed spring',
    variables: [
      { symbol: 'U', name: 'Elastic Energy', unit: 'J', defaultValue: 6 },
      { symbol: 'k', name: 'Spring Constant', unit: 'N/m', defaultValue: 300 },
      { symbol: 'x', name: 'Displacement', unit: 'm', defaultValue: 0.2 }
    ],
    solveFor: (target, vals) => {
      const { U, k, x } = vals;
      if (target === 'U') return 0.5 * k * x * x;
      if (target === 'k') return (2 * U) / (x * x);
      if (target === 'x') return Math.sqrt((2 * U) / k);
      return null;
    }
  },
  {
    id: 'phys_centripetal_force',
    name: 'Centripetal Force',
    category: 'Physics',
    subcategory: 'Circular Motion',
    formula: 'Fc = m * v^2 / r',
    latex: 'F_c = \\frac{m v^2}{r}',
    description: 'Inward force required to maintain circular motion',
    variables: [
      { symbol: 'Fc', name: 'Centripetal Force', unit: 'N', defaultValue: 400 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 },
      { symbol: 'v', name: 'Tangential Velocity', unit: 'm/s', defaultValue: 20 },
      { symbol: 'r', name: 'Radius', unit: 'm', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { Fc, m, v, r } = vals;
      if (target === 'Fc') return (m * v * v) / r;
      if (target === 'm') return (Fc * r) / (v * v);
      if (target === 'v') return Math.sqrt((Fc * r) / m);
      if (target === 'r') return (m * v * v) / Fc;
      return null;
    }
  },
  {
    id: 'phys_gravitation',
    name: "Newton's Law of Universal Gravitation",
    category: 'Physics',
    subcategory: 'Gravitation',
    formula: 'F = G * m1 * m2 / r^2',
    latex: 'F = G \\frac{m_1 m_2}{r^2}',
    description: 'Mutual gravitational attractive force between two masses',
    variables: [
      { symbol: 'F', name: 'Gravitational Force', unit: 'N', defaultValue: 3.52e22 },
      { symbol: 'm1', name: 'Mass 1', unit: 'kg', defaultValue: 5.972e24 },
      { symbol: 'm2', name: 'Mass 2', unit: 'kg', defaultValue: 1.989e30 },
      { symbol: 'r', name: 'Separation Distance', unit: 'm', defaultValue: 1.496e11 }
    ],
    solveFor: (target, vals) => {
      const G = 6.6743e-11;
      const { F, m1, m2, r } = vals;
      if (target === 'F') return (G * m1 * m2) / (r * r);
      if (target === 'm1') return (F * r * r) / (G * m2);
      if (target === 'm2') return (F * r * r) / (G * m1);
      if (target === 'r') return Math.sqrt((G * m1 * m2) / F);
      return null;
    }
  },
  {
    id: 'phys_pendulum_period',
    name: 'Simple Pendulum Period',
    category: 'Physics',
    subcategory: 'Harmonic Motion',
    formula: 'T = 2 * pi * sqrt(L / g)',
    latex: 'T = 2\\pi \\sqrt{\\frac{L}{g}}',
    description: 'Period of oscillation of a simple pendulum for small angles',
    variables: [
      { symbol: 'T', name: 'Period', unit: 's', defaultValue: 2.006 },
      { symbol: 'L', name: 'Length', unit: 'm', defaultValue: 1.0 },
      { symbol: 'g', name: 'Gravity Accel', unit: 'm/s²', defaultValue: 9.8 }
    ],
    solveFor: (target, vals) => {
      const { T, L, g } = vals;
      if (target === 'T') return 2 * Math.PI * Math.sqrt(L / g);
      if (target === 'L') return g * Math.pow(T / (2 * Math.PI), 2);
      if (target === 'g') return L / Math.pow(T / (2 * Math.PI), 2);
      return null;
    }
  },

  // --- Thermodynamics ---
  {
    id: 'phys_heat_capacity',
    name: 'Sensible Heat Transfer',
    category: 'Physics',
    subcategory: 'Thermodynamics',
    formula: 'Q = m * c * deltaT',
    latex: 'Q = m \\cdot c \\cdot \\Delta T',
    description: 'Thermal energy required to change temperature of a mass',
    variables: [
      { symbol: 'Q', name: 'Heat Added', unit: 'J', defaultValue: 41840 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 2 },
      { symbol: 'c', name: 'Specific Heat Capacity', unit: 'J/(kg·K)', defaultValue: 4184 },
      { symbol: 'deltaT', name: 'Temperature Change', unit: 'K', defaultValue: 5 }
    ],
    solveFor: (target, vals) => {
      const { Q, m, c, deltaT } = vals;
      if (target === 'Q') return m * c * deltaT;
      if (target === 'm') return Q / (c * deltaT);
      if (target === 'c') return Q / (m * deltaT);
      if (target === 'deltaT') return Q / (m * c);
      return null;
    }
  },
  {
    id: 'phys_carnot_efficiency',
    name: 'Carnot Maximum Thermal Efficiency',
    category: 'Physics',
    subcategory: 'Thermodynamics',
    formula: 'eta = 1 - Tc / Th',
    latex: '\\eta = 1 - \\frac{T_C}{T_H}',
    description: 'Theoretical maximum thermodynamic efficiency of a heat engine',
    variables: [
      { symbol: 'eta', name: 'Efficiency (fraction)', unit: '', defaultValue: 0.5 },
      { symbol: 'Tc', name: 'Cold Reservoir Temp', unit: 'K', defaultValue: 300 },
      { symbol: 'Th', name: 'Hot Reservoir Temp', unit: 'K', defaultValue: 600 }
    ],
    solveFor: (target, vals) => {
      const { eta, Tc, Th } = vals;
      if (target === 'eta') return 1 - Tc / Th;
      if (target === 'Tc') return Th * (1 - eta);
      if (target === 'Th') return Tc / (1 - eta);
      return null;
    }
  },
  {
    id: 'phys_stefan_boltzmann',
    name: 'Stefan-Boltzmann Radiation Law',
    category: 'Physics',
    subcategory: 'Thermodynamics',
    formula: 'P = e * sigma * A * T^4',
    latex: 'P = \\varepsilon \\sigma A T^4',
    description: 'Thermal radiation power emitted by a blackbody / grey surface',
    variables: [
      { symbol: 'P', name: 'Radiated Power', unit: 'W', defaultValue: 459.3 },
      { symbol: 'e', name: 'Emissivity (0-1)', unit: '', defaultValue: 1 },
      { symbol: 'A', name: 'Surface Area', unit: 'm²', defaultValue: 1 },
      { symbol: 'T', name: 'Absolute Temp', unit: 'K', defaultValue: 300 }
    ],
    solveFor: (target, vals) => {
      const sigma = 5.670374e-8;
      const { P, e, A, T } = vals;
      if (target === 'P') return e * sigma * A * Math.pow(T, 4);
      if (target === 'e') return P / (sigma * A * Math.pow(T, 4));
      if (target === 'A') return P / (e * sigma * Math.pow(T, 4));
      if (target === 'T') return Math.pow(P / (e * sigma * A), 0.25);
      return null;
    }
  },

  // --- Electromagnetism & Circuits ---
  {
    id: 'phys_coulomb',
    name: "Coulomb's Electrostatic Law",
    category: 'Physics',
    subcategory: 'Electromagnetism',
    formula: 'F = ke * q1 * q2 / r^2',
    latex: 'F = k_e \\frac{q_1 q_2}{r^2}',
    description: 'Electric force between two stationary point charges',
    variables: [
      { symbol: 'F', name: 'Electrostatic Force', unit: 'N', defaultValue: 898.75 },
      { symbol: 'q1', name: 'Charge 1', unit: 'C', defaultValue: 1e-4 },
      { symbol: 'q2', name: 'Charge 2', unit: 'C', defaultValue: 1e-4 },
      { symbol: 'r', name: 'Distance', unit: 'm', defaultValue: 1 }
    ],
    solveFor: (target, vals) => {
      const ke = 8.98755e9;
      const { F, q1, q2, r } = vals;
      if (target === 'F') return (ke * q1 * q2) / (r * r);
      if (target === 'q1') return (F * r * r) / (ke * q2);
      if (target === 'q2') return (F * r * r) / (ke * q1);
      if (target === 'r') return Math.sqrt((ke * q1 * q2) / F);
      return null;
    }
  },
  {
    id: 'phys_ohms_law',
    name: "Ohm's Law",
    category: 'Physics',
    subcategory: 'Electromagnetism',
    formula: 'V = I * R',
    latex: 'V = I \\cdot R',
    description: 'Relationship between voltage, electric current, and resistance',
    variables: [
      { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 12 },
      { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 2 },
      { symbol: 'R', name: 'Resistance', unit: 'Ω', defaultValue: 6 }
    ],
    solveFor: (target, vals) => {
      const { V, I, R } = vals;
      if (target === 'V') return I * R;
      if (target === 'I') return V / R;
      if (target === 'R') return V / I;
      return null;
    }
  },
  {
    id: 'phys_electric_power',
    name: 'Joule Electrical Power',
    category: 'Physics',
    subcategory: 'Electromagnetism',
    formula: 'P = V * I',
    latex: 'P = V \\cdot I',
    description: 'Electric power dissipated or supplied in a circuit',
    variables: [
      { symbol: 'P', name: 'Power', unit: 'W', defaultValue: 24 },
      { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 12 },
      { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 2 }
    ],
    solveFor: (target, vals) => {
      const { P, V, I } = vals;
      if (target === 'P') return V * I;
      if (target === 'V') return P / I;
      if (target === 'I') return P / V;
      return null;
    }
  },
  {
    id: 'phys_lorentz_magnetic',
    name: 'Lorentz Magnetic Force on Moving Charge',
    category: 'Physics',
    subcategory: 'Electromagnetism',
    formula: 'F = q * v * B * sin(theta)',
    latex: 'F = q v B \\sin(\\theta)',
    description: 'Deflecting force exerted on a moving charge in a magnetic field',
    variables: [
      { symbol: 'F', name: 'Magnetic Force', unit: 'N', defaultValue: 1.6e-12 },
      { symbol: 'q', name: 'Charge', unit: 'C', defaultValue: 1.6e-19 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 1e7 },
      { symbol: 'B', name: 'Magnetic Field', unit: 'T', defaultValue: 1.0 },
      { symbol: 'theta', name: 'Angle', unit: 'deg', defaultValue: 90 }
    ],
    solveFor: (target, vals) => {
      const { F, q, v, B, theta } = vals;
      const rad = (theta * Math.PI) / 180;
      const s = Math.sin(rad);
      if (target === 'F') return q * v * B * s;
      if (target === 'q') return F / (v * B * s);
      if (target === 'v') return F / (q * B * s);
      if (target === 'B') return F / (q * v * s);
      return null;
    }
  },
  {
    id: 'phys_lc_resonance',
    name: 'LC Resonant Frequency',
    category: 'Physics',
    subcategory: 'Electromagnetism',
    formula: 'f0 = 1 / (2 * pi * sqrt(L * C))',
    latex: 'f_0 = \\frac{1}{2\\pi \\sqrt{L C}}',
    description: 'Natural resonant oscillation frequency of an LC tank circuit',
    variables: [
      { symbol: 'f0', name: 'Resonant Frequency', unit: 'Hz', defaultValue: 159155 },
      { symbol: 'L', name: 'Inductance', unit: 'H', defaultValue: 1e-3 },
      { symbol: 'C', name: 'Capacitance', unit: 'F', defaultValue: 1e-9 }
    ],
    solveFor: (target, vals) => {
      const { f0, L, C } = vals;
      if (target === 'f0') return 1 / (2 * Math.PI * Math.sqrt(L * C));
      if (target === 'L') return 1 / (4 * Math.PI * Math.PI * f0 * f0 * C);
      if (target === 'C') return 1 / (4 * Math.PI * Math.PI * f0 * f0 * L);
      return null;
    }
  },

  // --- Waves & Optics ---
  {
    id: 'phys_wave_speed',
    name: 'Wave Speed Equation',
    category: 'Physics',
    subcategory: 'Waves & Optics',
    formula: 'v = f * lambda',
    latex: 'v = f \\cdot \\lambda',
    description: 'Phase propagation velocity of a periodic wave',
    variables: [
      { symbol: 'v', name: 'Wave Speed', unit: 'm/s', defaultValue: 343 },
      { symbol: 'f', name: 'Frequency', unit: 'Hz', defaultValue: 440 },
      { symbol: 'lambda', name: 'Wavelength', unit: 'm', defaultValue: 0.7795 }
    ],
    solveFor: (target, vals) => {
      const { v, f, lambda } = vals;
      if (target === 'v') return f * lambda;
      if (target === 'f') return v / lambda;
      if (target === 'lambda') return v / f;
      return null;
    }
  },
  {
    id: 'phys_snells_law',
    name: "Snell's Law of Refraction",
    category: 'Physics',
    subcategory: 'Waves & Optics',
    formula: 'n1 * sin(theta1) = n2 * sin(theta2)',
    latex: 'n_1 \\sin(\\theta_1) = n_2 \\sin(\\theta_2)',
    description: 'Bending of light rays at interface between two optical media',
    variables: [
      { symbol: 'n1', name: 'Index 1 (Air)', unit: '', defaultValue: 1.0 },
      { symbol: 'theta1', name: 'Incident Angle', unit: 'deg', defaultValue: 30 },
      { symbol: 'n2', name: 'Index 2 (Glass)', unit: '', defaultValue: 1.5 },
      { symbol: 'theta2', name: 'Refracted Angle', unit: 'deg', defaultValue: 19.47 }
    ],
    solveFor: (target, vals) => {
      const { n1, theta1, n2, theta2 } = vals;
      const r1 = (theta1 * Math.PI) / 180;
      const r2 = (theta2 * Math.PI) / 180;
      if (target === 'theta2') {
        const val = (n1 * Math.sin(r1)) / n2;
        return val <= 1 && val >= -1 ? (Math.asin(val) * 180) / Math.PI : null;
      }
      if (target === 'theta1') {
        const val = (n2 * Math.sin(r2)) / n1;
        return val <= 1 && val >= -1 ? (Math.asin(val) * 180) / Math.PI : null;
      }
      if (target === 'n2') return (n1 * Math.sin(r1)) / Math.sin(r2);
      if (target === 'n1') return (n2 * Math.sin(r2)) / Math.sin(r1);
      return null;
    }
  },
  {
    id: 'phys_thin_lens',
    name: 'Thin Lens / Mirror Equation',
    category: 'Physics',
    subcategory: 'Waves & Optics',
    formula: '1 / f = 1 / do + 1 / di',
    latex: '\\frac{1}{f} = \\frac{1}{d_o} + \\frac{1}{d_i}',
    description: 'Relates focal length to object distance and image distance',
    variables: [
      { symbol: 'f', name: 'Focal Length', unit: 'cm', defaultValue: 10 },
      { symbol: 'do', name: 'Object Distance', unit: 'cm', defaultValue: 30 },
      { symbol: 'di', name: 'Image Distance', unit: 'cm', defaultValue: 15 }
    ],
    solveFor: (target, vals) => {
      const { f, do: objDist, di } = vals;
      if (target === 'f') return (objDist * di) / (objDist + di);
      if (target === 'do') return (f * di) / (di - f);
      if (target === 'di') return (f * objDist) / (objDist - f);
      return null;
    }
  },

  // --- Modern & Quantum Physics ---
  {
    id: 'phys_mass_energy',
    name: 'Einstein Mass-Energy Equivalence',
    category: 'Physics',
    subcategory: 'Modern Physics',
    formula: 'E = m * c^2',
    latex: 'E = m c^2',
    description: 'Equivalence of rest mass and relativistic energy',
    variables: [
      { symbol: 'E', name: 'Rest Energy', unit: 'J', defaultValue: 8.98755e16 },
      { symbol: 'm', name: 'Rest Mass', unit: 'kg', defaultValue: 1.0 }
    ],
    solveFor: (target, vals) => {
      const c = 299792458;
      const { E, m } = vals;
      if (target === 'E') return m * c * c;
      if (target === 'm') return E / (c * c);
      return null;
    }
  },
  {
    id: 'phys_photon_energy',
    name: 'Planck-Einstein Photon Energy',
    category: 'Physics',
    subcategory: 'Modern Physics',
    formula: 'E = h * f',
    latex: 'E = h \\cdot f',
    description: 'Quantum energy of an individual photon',
    variables: [
      { symbol: 'E', name: 'Energy', unit: 'J', defaultValue: 3.313e-19 },
      { symbol: 'f', name: 'Frequency', unit: 'Hz', defaultValue: 5e14 }
    ],
    solveFor: (target, vals) => {
      const h = 6.62607015e-34;
      const { E, f } = vals;
      if (target === 'E') return h * f;
      if (target === 'f') return E / h;
      return null;
    }
  },
  {
    id: 'phys_radioactive_decay',
    name: 'Radioactive Decay Law',
    category: 'Physics',
    subcategory: 'Modern Physics',
    formula: 'N = N0 * exp(-lambda * t)',
    latex: 'N(t) = N_0 e^{-\\lambda t}',
    description: 'Exponential decay of unstable radioactive atomic nuclei',
    variables: [
      { symbol: 'N', name: 'Remaining Quantity', unit: 'atoms', defaultValue: 500 },
      { symbol: 'N0', name: 'Initial Quantity', unit: 'atoms', defaultValue: 1000 },
      { symbol: 'lambda', name: 'Decay Constant', unit: '1/s', defaultValue: 0.00693 },
      { symbol: 't', name: 'Time', unit: 's', defaultValue: 100 }
    ],
    solveFor: (target, vals) => {
      const { N, N0, lambda, t } = vals;
      if (target === 'N') return N0 * Math.exp(-lambda * t);
      if (target === 'N0') return N * Math.exp(lambda * t);
      if (target === 'lambda') return -Math.log(N / N0) / t;
      if (target === 't') return -Math.log(N / N0) / lambda;
      return null;
    }
  },

  // --- Fluids ---
  {
    id: 'phys_hydrostatic_pressure',
    name: 'Hydrostatic Fluid Pressure',
    category: 'Physics',
    subcategory: 'Fluid Mechanics',
    formula: 'P = rho * g * h',
    latex: 'P = \\rho \\cdot g \\cdot h',
    description: 'Gauge pressure exerted by a fluid column of given depth',
    variables: [
      { symbol: 'P', name: 'Pressure', unit: 'Pa', defaultValue: 98000 },
      { symbol: 'rho', name: 'Fluid Density', unit: 'kg/m³', defaultValue: 1000 },
      { symbol: 'g', name: 'Gravity Accel', unit: 'm/s²', defaultValue: 9.8 },
      { symbol: 'h', name: 'Depth / Height', unit: 'm', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { P, rho, g, h } = vals;
      if (target === 'P') return rho * g * h;
      if (target === 'rho') return P / (g * h);
      if (target === 'g') return P / (rho * h);
      if (target === 'h') return P / (rho * g);
      return null;
    }
  }
];

// ============================================================================
// 2. CHEMISTRY FORMULAS
// ============================================================================
export const CHEMISTRY_FORMULAS: FormulaItem[] = [
  // --- Gas Laws ---
  {
    id: 'chem_ideal_gas',
    name: 'Ideal Gas Law',
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'P * V = n * R * T',
    latex: 'PV = nRT',
    description: 'State equation of a hypothetical ideal gas',
    variables: [
      { symbol: 'P', name: 'Pressure', unit: 'atm', defaultValue: 1 },
      { symbol: 'V', name: 'Volume', unit: 'L', defaultValue: 22.414 },
      { symbol: 'n', name: 'Amount of Substance', unit: 'mol', defaultValue: 1 },
      { symbol: 'T', name: 'Temperature', unit: 'K', defaultValue: 273.15 }
    ],
    solveFor: (target, vals) => {
      const R = 0.082057; // L·atm/(mol·K)
      const { P, V, n, T } = vals;
      if (target === 'P') return (n * R * T) / V;
      if (target === 'V') return (n * R * T) / P;
      if (target === 'n') return (P * V) / (R * T);
      if (target === 'T') return (P * V) / (n * R);
      return null;
    }
  },
  {
    id: 'chem_boyles_law',
    name: "Boyle's Isothermal Gas Law",
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'P1 * V1 = P2 * V2',
    latex: 'P_1 V_1 = P_2 V_2',
    description: 'Inverse relationship between pressure and volume at constant temperature',
    variables: [
      { symbol: 'P1', name: 'Initial Pressure', unit: 'atm', defaultValue: 1.0 },
      { symbol: 'V1', name: 'Initial Volume', unit: 'L', defaultValue: 10.0 },
      { symbol: 'P2', name: 'Final Pressure', unit: 'atm', defaultValue: 2.0 },
      { symbol: 'V2', name: 'Final Volume', unit: 'L', defaultValue: 5.0 }
    ],
    solveFor: (target, vals) => {
      const { P1, V1, P2, V2 } = vals;
      if (target === 'V2') return (P1 * V1) / P2;
      if (target === 'P2') return (P1 * V1) / V2;
      if (target === 'V1') return (P2 * V2) / P1;
      if (target === 'P1') return (P2 * V2) / V1;
      return null;
    }
  },
  {
    id: 'chem_charles_law',
    name: "Charles's Isobaric Gas Law",
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'V1 / T1 = V2 / T2',
    latex: '\\frac{V_1}{T_1} = \\frac{V_2}{T_2}',
    description: 'Direct proportionality between volume and absolute temperature',
    variables: [
      { symbol: 'V1', name: 'Initial Volume', unit: 'L', defaultValue: 2.0 },
      { symbol: 'T1', name: 'Initial Temperature', unit: 'K', defaultValue: 300 },
      { symbol: 'V2', name: 'Final Volume', unit: 'L', defaultValue: 4.0 },
      { symbol: 'T2', name: 'Final Temperature', unit: 'K', defaultValue: 600 }
    ],
    solveFor: (target, vals) => {
      const { V1, T1, V2, T2 } = vals;
      if (target === 'V2') return (V1 * T2) / T1;
      if (target === 'T2') return (V2 * T1) / V1;
      if (target === 'V1') return (V2 * T1) / T2;
      if (target === 'T1') return (V1 * T2) / V2;
      return null;
    }
  },
  {
    id: 'chem_combined_gas',
    name: 'Combined Gas Law',
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: '(P1 * V1) / T1 = (P2 * V2) / T2',
    latex: '\\frac{P_1 V_1}{T_1} = \\frac{P_2 V_2}{T_2}',
    description: 'Simultaneous variation of pressure, volume, and temperature',
    variables: [
      { symbol: 'P1', name: 'Initial Pressure', unit: 'atm', defaultValue: 1.0 },
      { symbol: 'V1', name: 'Initial Volume', unit: 'L', defaultValue: 2.0 },
      { symbol: 'T1', name: 'Initial Temp', unit: 'K', defaultValue: 300 },
      { symbol: 'P2', name: 'Final Pressure', unit: 'atm', defaultValue: 2.0 },
      { symbol: 'V2', name: 'Final Volume', unit: 'L', defaultValue: 1.5 },
      { symbol: 'T2', name: 'Final Temp', unit: 'K', defaultValue: 450 }
    ],
    solveFor: (target, vals) => {
      const { P1, V1, T1, P2, V2, T2 } = vals;
      if (target === 'P2') return (P1 * V1 * T2) / (T1 * V2);
      if (target === 'V2') return (P1 * V1 * T2) / (T1 * P2);
      if (target === 'T2') return (P2 * V2 * T1) / (P1 * V1);
      if (target === 'P1') return (P2 * V2 * T1) / (T2 * V1);
      if (target === 'V1') return (P2 * V2 * T1) / (T2 * P1);
      if (target === 'T1') return (P1 * V1 * T2) / (P2 * V2);
      return null;
    }
  },

  // --- Solutions & Concentration ---
  {
    id: 'chem_molarity',
    name: 'Solution Molarity',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'M = n / V',
    latex: 'M = \\frac{n}{V}',
    description: 'Molar concentration (moles of solute per liter of solution)',
    variables: [
      { symbol: 'M', name: 'Molarity', unit: 'mol/L', defaultValue: 0.5 },
      { symbol: 'n', name: 'Moles of Solute', unit: 'mol', defaultValue: 1.5 },
      { symbol: 'V', name: 'Solution Volume', unit: 'L', defaultValue: 3.0 }
    ],
    solveFor: (target, vals) => {
      const { M, n, V } = vals;
      if (target === 'M') return n / V;
      if (target === 'n') return M * V;
      if (target === 'V') return n / M;
      return null;
    }
  },
  {
    id: 'chem_dilution',
    name: 'Dilution Equation',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'M1 * V1 = M2 * V2',
    latex: 'M_1 V_1 = M_2 V_2',
    description: 'Conservation of moles during solution dilution',
    variables: [
      { symbol: 'M1', name: 'Initial Concentration', unit: 'M', defaultValue: 12.0 },
      { symbol: 'V1', name: 'Initial Volume', unit: 'L', defaultValue: 0.05 },
      { symbol: 'M2', name: 'Final Concentration', unit: 'M', defaultValue: 1.0 },
      { symbol: 'V2', name: 'Final Volume', unit: 'L', defaultValue: 0.6 }
    ],
    solveFor: (target, vals) => {
      const { M1, V1, M2, V2 } = vals;
      if (target === 'V1') return (M2 * V2) / M1;
      if (target === 'V2') return (M1 * V1) / M2;
      if (target === 'M1') return (M2 * V2) / V1;
      if (target === 'M2') return (M1 * V1) / V2;
      return null;
    }
  },
  {
    id: 'chem_osmotic_pressure',
    name: 'Osmotic Pressure (van ’t Hoff)',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'Pi = i * M * R * T',
    latex: '\\Pi = i M R T',
    description: 'Colligative pressure across a semipermeable membrane',
    variables: [
      { symbol: 'Pi', name: 'Osmotic Pressure', unit: 'atm', defaultValue: 24.6 },
      { symbol: 'i', name: 'van ’t Hoff factor', unit: '', defaultValue: 1.0 },
      { symbol: 'M', name: 'Molarity', unit: 'mol/L', defaultValue: 1.0 },
      { symbol: 'T', name: 'Temperature', unit: 'K', defaultValue: 300 }
    ],
    solveFor: (target, vals) => {
      const R = 0.082057;
      const { Pi, i, M, T } = vals;
      if (target === 'Pi') return i * M * R * T;
      if (target === 'M') return Pi / (i * R * T);
      if (target === 'T') return Pi / (i * M * R);
      if (target === 'i') return Pi / (M * R * T);
      return null;
    }
  },

  // --- Kinetics & Thermodynamics ---
  {
    id: 'chem_arrhenius',
    name: 'Arrhenius Reaction Rate Equation',
    category: 'Chemistry',
    subcategory: 'Kinetics',
    formula: 'k = A * exp(-Ea / (R * T))',
    latex: 'k = A \\cdot e^{-\\frac{E_a}{R T}}',
    description: 'Temperature dependence of chemical reaction rate constants',
    variables: [
      { symbol: 'k', name: 'Rate Constant', unit: '1/s', defaultValue: 0.042 },
      { symbol: 'A', name: 'Pre-exponential Factor', unit: '1/s', defaultValue: 1e11 },
      { symbol: 'Ea', name: 'Activation Energy', unit: 'J/mol', defaultValue: 70000 },
      { symbol: 'T', name: 'Temperature', unit: 'K', defaultValue: 300 }
    ],
    solveFor: (target, vals) => {
      const R = 8.31446;
      const { k, A, Ea, T } = vals;
      if (target === 'k') return A * Math.exp(-Ea / (R * T));
      if (target === 'A') return k / Math.exp(-Ea / (R * T));
      if (target === 'Ea') return -R * T * Math.log(k / A);
      if (target === 'T') return -Ea / (R * Math.log(k / A));
      return null;
    }
  },
  {
    id: 'chem_gibbs_free_energy',
    name: 'Gibbs Free Energy Equation',
    category: 'Chemistry',
    subcategory: 'Thermodynamics',
    formula: 'deltaG = deltaH - T * deltaS',
    latex: '\\Delta G = \\Delta H - T \\Delta S',
    description: 'Spontaneity criterion for chemical processes at constant T and P',
    variables: [
      { symbol: 'deltaG', name: 'Gibbs Free Energy', unit: 'kJ/mol', defaultValue: -30.0 },
      { symbol: 'deltaH', name: 'Enthalpy Change', unit: 'kJ/mol', defaultValue: -50.0 },
      { symbol: 'T', name: 'Temperature', unit: 'K', defaultValue: 298.15 },
      { symbol: 'deltaS', name: 'Entropy Change', unit: 'kJ/(mol·K)', defaultValue: -0.067 }
    ],
    solveFor: (target, vals) => {
      const { deltaG, deltaH, T, deltaS } = vals;
      if (target === 'deltaG') return deltaH - T * deltaS;
      if (target === 'deltaH') return deltaG + T * deltaS;
      if (target === 'T') return (deltaH - deltaG) / deltaS;
      if (target === 'deltaS') return (deltaH - deltaG) / T;
      return null;
    }
  },

  // --- Acids, Bases & Electrochemistry ---
  {
    id: 'chem_ph_definition',
    name: 'pH and Hydrogen Ion Concentration',
    category: 'Chemistry',
    subcategory: 'Acids & Bases',
    formula: 'pH = -log10([H+])',
    latex: '\\text{pH} = -\\log_{10}[\\text{H}^+]',
    description: 'Logarithmic scale of hydronium ion activity in aqueous solution',
    variables: [
      { symbol: 'pH', name: 'pH Value', unit: '', defaultValue: 7.0 },
      { symbol: 'H', name: '[H+] Concentration', unit: 'M', defaultValue: 1e-7 }
    ],
    solveFor: (target, vals) => {
      const { pH, H } = vals;
      if (target === 'pH') return -Math.log10(H);
      if (target === 'H') return Math.pow(10, -pH);
      return null;
    }
  },
  {
    id: 'chem_henderson_hasselbalch',
    name: 'Henderson-Hasselbalch Buffer Equation',
    category: 'Chemistry',
    subcategory: 'Acids & Bases',
    formula: 'pH = pKa + log10([A-] / [HA])',
    latex: '\\text{pH} = \\text{p}K_a + \\log_{10}\\left(\\frac{[\\text{A}^-]}{[\\text{HA}]}\\right)',
    description: 'Estimates pH of a conjugate acid-base buffer solution',
    variables: [
      { symbol: 'pH', name: 'Buffer pH', unit: '', defaultValue: 4.76 },
      { symbol: 'pKa', name: 'Acid pKa', unit: '', defaultValue: 4.76 },
      { symbol: 'A', name: 'Conjugate Base [A-]', unit: 'M', defaultValue: 0.1 },
      { symbol: 'HA', name: 'Weak Acid [HA]', unit: 'M', defaultValue: 0.1 }
    ],
    solveFor: (target, vals) => {
      const { pH, pKa, A, HA } = vals;
      if (target === 'pH') return pKa + Math.log10(A / HA);
      if (target === 'pKa') return pH - Math.log10(A / HA);
      return null;
    }
  },
  {
    id: 'chem_nernst_equation',
    name: 'Nernst Equation (at 298.15 K)',
    category: 'Chemistry',
    subcategory: 'Electrochemistry',
    formula: 'E = E0 - (0.0592 / n) * log10(Q)',
    latex: 'E = E^\\circ - \\frac{0.0592}{n} \\log_{10}(Q)',
    description: 'Electrode potential under non-standard electrochemical conditions',
    variables: [
      { symbol: 'E', name: 'Cell Potential', unit: 'V', defaultValue: 1.07 },
      { symbol: 'E0', name: 'Standard Potential', unit: 'V', defaultValue: 1.10 },
      { symbol: 'n', name: 'Moles of Electrons', unit: '', defaultValue: 2 },
      { symbol: 'Q', name: 'Reaction Quotient', unit: '', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { E, E0, n, Q } = vals;
      if (target === 'E') return E0 - (0.0592 / n) * Math.log10(Q);
      if (target === 'E0') return E + (0.0592 / n) * Math.log10(Q);
      if (target === 'Q') return Math.pow(10, ((E0 - E) * n) / 0.0592);
      return null;
    }
  }
];

// ============================================================================
// 3. MATHEMATICS FORMULAS
// ============================================================================
export const MATHEMATICS_FORMULAS: FormulaItem[] = [
  // --- Algebra & Polynomials ---
  {
    id: 'math_quadratic',
    name: 'Quadratic Formula Discriminant & Root',
    category: 'Mathematics',
    subcategory: 'Algebra',
    formula: 'x = (-b + sqrt(b^2 - 4*a*c)) / (2*a)',
    latex: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
    description: 'Analytic roots of second-order polynomial a·x² + b·x + c = 0',
    variables: [
      { symbol: 'x', name: 'Primary Real Root', unit: '', defaultValue: 2 },
      { symbol: 'a', name: 'Coefficient a', unit: '', defaultValue: 1 },
      { symbol: 'b', name: 'Coefficient b', unit: '', defaultValue: -5 },
      { symbol: 'c', name: 'Constant c', unit: '', defaultValue: 6 }
    ],
    solveFor: (target, vals) => {
      const { a, b, c } = vals;
      const disc = b * b - 4 * a * c;
      if (target === 'x') return disc >= 0 ? (-b + Math.sqrt(disc)) / (2 * a) : null;
      return null;
    }
  },
  {
    id: 'math_arithmetic_series',
    name: 'Arithmetic Series Sum',
    category: 'Mathematics',
    subcategory: 'Sequences & Series',
    formula: 'Sn = (n / 2) * (2 * a1 + (n - 1) * d)',
    latex: 'S_n = \\frac{n}{2}\\left(2a_1 + (n - 1)d\\right)',
    description: 'Sum of the first n terms of an arithmetic progression',
    variables: [
      { symbol: 'Sn', name: 'Sum of Series', unit: '', defaultValue: 5050 },
      { symbol: 'n', name: 'Number of Terms', unit: '', defaultValue: 100 },
      { symbol: 'a1', name: 'First Term', unit: '', defaultValue: 1 },
      { symbol: 'd', name: 'Common Difference', unit: '', defaultValue: 1 }
    ],
    solveFor: (target, vals) => {
      const { Sn, n, a1, d } = vals;
      if (target === 'Sn') return (n / 2) * (2 * a1 + (n - 1) * d);
      if (target === 'a1') return (2 * Sn) / n - (n - 1) * d / 2;
      if (target === 'd') return ((2 * Sn) / n - 2 * a1) / (n - 1);
      return null;
    }
  },
  {
    id: 'math_geometric_infinite',
    name: 'Infinite Geometric Series Sum',
    category: 'Mathematics',
    subcategory: 'Sequences & Series',
    formula: 'S_inf = a1 / (1 - r)',
    latex: 'S_\\infty = \\frac{a_1}{1 - r} \\quad (|r| < 1)',
    description: 'Convergent sum of an infinite geometric sequence',
    variables: [
      { symbol: 'S_inf', name: 'Infinite Sum', unit: '', defaultValue: 2 },
      { symbol: 'a1', name: 'First Term', unit: '', defaultValue: 1 },
      { symbol: 'r', name: 'Common Ratio', unit: '', defaultValue: 0.5 }
    ],
    solveFor: (target, vals) => {
      const { S_inf, a1, r } = vals;
      if (target === 'S_inf') return Math.abs(r) < 1 ? a1 / (1 - r) : null;
      if (target === 'a1') return S_inf * (1 - r);
      if (target === 'r') return 1 - a1 / S_inf;
      return null;
    }
  },

  // --- Geometry & Trigonometry ---
  {
    id: 'math_pythagorean',
    name: 'Pythagorean Theorem',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'c^2 = a^2 + b^2',
    latex: 'a^2 + b^2 = c^2',
    description: 'Fundamental relationship among the three sides of a right triangle',
    variables: [
      { symbol: 'c', name: 'Hypotenuse', unit: '', defaultValue: 5 },
      { symbol: 'a', name: 'Leg a', unit: '', defaultValue: 3 },
      { symbol: 'b', name: 'Leg b', unit: '', defaultValue: 4 }
    ],
    solveFor: (target, vals) => {
      const { c, a, b } = vals;
      if (target === 'c') return Math.sqrt(a * a + b * b);
      if (target === 'a') return Math.sqrt(Math.max(0, c * c - b * b));
      if (target === 'b') return Math.sqrt(Math.max(0, c * c - a * a));
      return null;
    }
  },
  {
    id: 'math_distance_2d',
    name: 'Euclidean Distance in 2D Space',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'd = sqrt((x2 - x1)^2 + (y2 - y1)^2)',
    latex: 'd = \\sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}',
    description: 'Straight line length between two points (x1, y1) and (x2, y2)',
    variables: [
      { symbol: 'd', name: 'Distance', unit: '', defaultValue: 5 },
      { symbol: 'x1', name: 'Point 1 X', unit: '', defaultValue: 0 },
      { symbol: 'y1', name: 'Point 1 Y', unit: '', defaultValue: 0 },
      { symbol: 'x2', name: 'Point 2 X', unit: '', defaultValue: 3 },
      { symbol: 'y2', name: 'Point 2 Y', unit: '', defaultValue: 4 }
    ],
    solveFor: (target, vals) => {
      const { x1, y1, x2, y2 } = vals;
      if (target === 'd') return Math.hypot(x2 - x1, y2 - y1);
      return null;
    }
  },
  {
    id: 'math_law_of_cosines',
    name: 'Law of Cosines (General Triangle)',
    category: 'Mathematics',
    subcategory: 'Trigonometry',
    formula: 'c = sqrt(a^2 + b^2 - 2 * a * b * cos(C))',
    latex: 'c^2 = a^2 + b^2 - 2ab \\cos(C)',
    description: 'Relates sides of any triangle to the cosine of one angle',
    variables: [
      { symbol: 'c', name: 'Side c', unit: '', defaultValue: 7 },
      { symbol: 'a', name: 'Side a', unit: '', defaultValue: 5 },
      { symbol: 'b', name: 'Side b', unit: '', defaultValue: 8 },
      { symbol: 'C', name: 'Angle C', unit: 'deg', defaultValue: 60 }
    ],
    solveFor: (target, vals) => {
      const { c, a, b, C } = vals;
      const rad = (C * Math.PI) / 180;
      if (target === 'c') return Math.sqrt(Math.max(0, a * a + b * b - 2 * a * b * Math.cos(rad)));
      return null;
    }
  },
  {
    id: 'math_heron_area',
    name: "Heron's Triangle Area Formula",
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'A = sqrt(s * (s - a) * (s - b) * (s - c))',
    latex: 'A = \\sqrt{s(s-a)(s-b)(s-c)} \\quad \\left(s = \\frac{a+b+c}{2}\\right)',
    description: 'Area of triangle from lengths of all three sides',
    variables: [
      { symbol: 'A', name: 'Area', unit: 'unit²', defaultValue: 6 },
      { symbol: 'a', name: 'Side a', unit: '', defaultValue: 3 },
      { symbol: 'b', name: 'Side b', unit: '', defaultValue: 4 },
      { symbol: 'c', name: 'Side c', unit: '', defaultValue: 5 }
    ],
    solveFor: (target, vals) => {
      const { a, b, c } = vals;
      const s = (a + b + c) / 2;
      if (target === 'A') return Math.sqrt(Math.max(0, s * (s - a) * (s - b) * (s - c)));
      return null;
    }
  },
  {
    id: 'math_sphere_volume',
    name: 'Sphere Volume and Surface Area',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'V = (4/3) * pi * r^3',
    latex: 'V = \\frac{4}{3}\\pi r^3, \\quad A = 4\\pi r^2',
    description: 'Geometric volume of a 3-dimensional solid sphere',
    variables: [
      { symbol: 'V', name: 'Volume', unit: 'unit³', defaultValue: 33.51 },
      { symbol: 'r', name: 'Radius', unit: 'unit', defaultValue: 2 }
    ],
    solveFor: (target, vals) => {
      const { V, r } = vals;
      if (target === 'V') return (4 / 3) * Math.PI * Math.pow(r, 3);
      if (target === 'r') return Math.cbrt((3 * V) / (4 * Math.PI));
      return null;
    }
  },

  // --- Probability & Statistics ---
  {
    id: 'math_z_score',
    name: 'Standard Normal Z-Score',
    category: 'Mathematics',
    subcategory: 'Statistics',
    formula: 'z = (x - mu) / sigma',
    latex: 'Z = \\frac{x - \\mu}{\\sigma}',
    description: 'Number of standard deviations a data point lies from the mean',
    variables: [
      { symbol: 'z', name: 'Z-Score', unit: '', defaultValue: 2 },
      { symbol: 'x', name: 'Raw Score', unit: '', defaultValue: 130 },
      { symbol: 'mu', name: 'Mean (μ)', unit: '', defaultValue: 100 },
      { symbol: 'sigma', name: 'Standard Deviation (σ)', unit: '', defaultValue: 15 }
    ],
    solveFor: (target, vals) => {
      const { z, x, mu, sigma } = vals;
      if (target === 'z') return (x - mu) / sigma;
      if (target === 'x') return mu + z * sigma;
      if (target === 'mu') return x - z * sigma;
      if (target === 'sigma') return (x - mu) / z;
      return null;
    }
  },
  {
    id: 'math_combinations',
    name: 'Combinations (n choose k)',
    category: 'Mathematics',
    subcategory: 'Combinatorics',
    formula: 'C(n, k) = n! / (k! * (n - k)!)',
    latex: '\\binom{n}{k} = \\frac{n!}{k!(n-k)!}',
    description: 'Number of ways to select k unordered items from n options',
    variables: [
      { symbol: 'C', name: 'Combinations', unit: '', defaultValue: 10 },
      { symbol: 'n', name: 'Total Set n', unit: '', defaultValue: 5 },
      { symbol: 'k', name: 'Chosen k', unit: '', defaultValue: 3 }
    ],
    solveFor: (target, vals) => {
      const fact = (num: number): number => (num <= 1 ? 1 : num * fact(num - 1));
      const { n, k } = vals;
      if (target === 'C') {
        const ni = Math.round(n);
        const ki = Math.round(k);
        if (ki < 0 || ki > ni) return 0;
        return fact(ni) / (fact(ki) * fact(ni - ki));
      }
      return null;
    }
  }
];

// ============================================================================
// 4. FINANCE FORMULAS
// ============================================================================
export const FINANCE_FORMULAS: FormulaItem[] = [
  // --- Interest & Time Value of Money ---
  {
    id: 'fin_simple_interest',
    name: 'Simple Interest',
    category: 'Finance',
    subcategory: 'Time Value of Money',
    formula: 'I = P * r * t',
    latex: 'I = P \\cdot r \\cdot t',
    description: 'Interest earned purely on the initial principal balance',
    variables: [
      { symbol: 'I', name: 'Total Interest', unit: '$', defaultValue: 150 },
      { symbol: 'P', name: 'Principal', unit: '$', defaultValue: 1000 },
      { symbol: 'r', name: 'Annual Rate (decimal)', unit: '', defaultValue: 0.05 },
      { symbol: 't', name: 'Time', unit: 'years', defaultValue: 3 }
    ],
    solveFor: (target, vals) => {
      const { I, P, r, t } = vals;
      if (target === 'I') return P * r * t;
      if (target === 'P') return I / (r * t);
      if (target === 'r') return I / (P * t);
      if (target === 't') return I / (P * r);
      return null;
    }
  },
  {
    id: 'fin_compound_interest',
    name: 'Periodic Compound Interest',
    category: 'Finance',
    subcategory: 'Time Value of Money',
    formula: 'A = P * (1 + r/n)^(n*t)',
    latex: 'A = P \\left(1 + \\frac{r}{n}\\right)^{nt}',
    description: 'Future value with interest compounding n times per year',
    variables: [
      { symbol: 'A', name: 'Future Value Amount', unit: '$', defaultValue: 1647.01 },
      { symbol: 'P', name: 'Principal Invested', unit: '$', defaultValue: 1000 },
      { symbol: 'r', name: 'Annual Nominal Rate', unit: '', defaultValue: 0.05 },
      { symbol: 'n', name: 'Compounding Frequency', unit: 'per year', defaultValue: 12 },
      { symbol: 't', name: 'Time', unit: 'years', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { A, P, r, n, t } = vals;
      if (target === 'A') return P * Math.pow(1 + r / n, n * t);
      if (target === 'P') return A / Math.pow(1 + r / n, n * t);
      if (target === 't') return Math.log(A / P) / (n * Math.log(1 + r / n));
      return null;
    }
  },
  {
    id: 'fin_continuous_compounding',
    name: 'Continuous Compounding Interest',
    category: 'Finance',
    subcategory: 'Time Value of Money',
    formula: 'A = P * exp(r * t)',
    latex: 'A = P e^{rt}',
    description: 'Limit of compound interest as compounding periods approach infinity',
    variables: [
      { symbol: 'A', name: 'Future Value', unit: '$', defaultValue: 1648.72 },
      { symbol: 'P', name: 'Principal', unit: '$', defaultValue: 1000 },
      { symbol: 'r', name: 'Annual Rate (decimal)', unit: '', defaultValue: 0.05 },
      { symbol: 't', name: 'Time', unit: 'years', defaultValue: 10 }
    ],
    solveFor: (target, vals) => {
      const { A, P, r, t } = vals;
      if (target === 'A') return P * Math.exp(r * t);
      if (target === 'P') return A / Math.exp(r * t);
      if (target === 't') return Math.log(A / P) / r;
      if (target === 'r') return Math.log(A / P) / t;
      return null;
    }
  },
  {
    id: 'fin_ear',
    name: 'Effective Annual Rate (EAR / APY)',
    category: 'Finance',
    subcategory: 'Time Value of Money',
    formula: 'EAR = (1 + r/n)^n - 1',
    latex: '\\text{EAR} = \\left(1 + \\frac{r}{n}\\right)^n - 1',
    description: 'Actual annualized interest rate taking compounding into account',
    variables: [
      { symbol: 'EAR', name: 'Effective Annual Rate', unit: '', defaultValue: 0.05116 },
      { symbol: 'r', name: 'Nominal Stated Rate', unit: '', defaultValue: 0.05 },
      { symbol: 'n', name: 'Periods per Year', unit: '', defaultValue: 12 }
    ],
    solveFor: (target, vals) => {
      const { EAR, r, n } = vals;
      if (target === 'EAR') return Math.pow(1 + r / n, n) - 1;
      if (target === 'r') return n * (Math.pow(EAR + 1, 1 / n) - 1);
      return null;
    }
  },
  {
    id: 'fin_rule_of_72',
    name: 'Rule of 72 (Doubling Time)',
    category: 'Finance',
    subcategory: 'Time Value of Money',
    formula: 't = 72 / r_pct',
    latex: 't \\approx \\frac{72}{r\\%}',
    description: 'Rule of thumb estimating years needed to double an investment',
    variables: [
      { symbol: 't', name: 'Doubling Time', unit: 'years', defaultValue: 10.28 },
      { symbol: 'r_pct', name: 'Annual Interest %', unit: '%', defaultValue: 7.0 }
    ],
    solveFor: (target, vals) => {
      const { t, r_pct } = vals;
      if (target === 't') return 72 / r_pct;
      if (target === 'r_pct') return 72 / t;
      return null;
    }
  },

  // --- Loans, Mortgages & Annuities ---
  {
    id: 'fin_loan_payment',
    name: 'Monthly Loan / Mortgage Amortization Payment',
    category: 'Finance',
    subcategory: 'Loans & Mortgages',
    formula: 'PMT = P * (r * (1 + r)^n) / ((1 + r)^n - 1)',
    latex: '\\text{PMT} = P \\frac{r(1 + r)^n}{(1 + r)^n - 1}',
    description: 'Fixed regular monthly payment for a fully amortizing loan',
    variables: [
      { symbol: 'PMT', name: 'Periodic Payment', unit: '$/mo', defaultValue: 1798.65 },
      { symbol: 'P', name: 'Principal Loan Amount', unit: '$', defaultValue: 300000 },
      { symbol: 'r', name: 'Periodic Monthly Rate', unit: '', defaultValue: 0.005 },
      { symbol: 'n', name: 'Total Monthly Payments', unit: 'months', defaultValue: 360 }
    ],
    solveFor: (target, vals) => {
      const { PMT, P, r, n } = vals;
      const factor = Math.pow(1 + r, n);
      if (target === 'PMT') return P * ((r * factor) / (factor - 1));
      if (target === 'P') return PMT / ((r * factor) / (factor - 1));
      return null;
    }
  },
  {
    id: 'fin_pv_annuity',
    name: 'Present Value of Ordinary Annuity',
    category: 'Finance',
    subcategory: 'Annuities & Perpetuities',
    formula: 'PV = PMT * (1 - (1 + r)^(-n)) / r',
    latex: 'PV = \\text{PMT} \\left[\\frac{1 - (1 + r)^{-n}}{r}\\right]',
    description: 'Lump-sum value today of a series of equal future cash flows',
    variables: [
      { symbol: 'PV', name: 'Present Value', unit: '$', defaultValue: 12462.21 },
      { symbol: 'PMT', name: 'Payment Amount', unit: '$', defaultValue: 1000 },
      { symbol: 'r', name: 'Discount Rate', unit: '', defaultValue: 0.05 },
      { symbol: 'n', name: 'Periods', unit: '', defaultValue: 20 }
    ],
    solveFor: (target, vals) => {
      const { PV, PMT, r, n } = vals;
      const bracket = (1 - Math.pow(1 + r, -n)) / r;
      if (target === 'PV') return PMT * bracket;
      if (target === 'PMT') return PV / bracket;
      return null;
    }
  },
  {
    id: 'fin_perpetuity',
    name: 'Constant Perpetuity Value',
    category: 'Finance',
    subcategory: 'Annuities & Perpetuities',
    formula: 'PV = C / r',
    latex: 'PV = \\frac{C}{r}',
    description: 'Present value of an infinite series of identical periodic payments',
    variables: [
      { symbol: 'PV', name: 'Present Value', unit: '$', defaultValue: 20000 },
      { symbol: 'C', name: 'Annual Cash Flow', unit: '$', defaultValue: 1000 },
      { symbol: 'r', name: 'Discount Rate', unit: '', defaultValue: 0.05 }
    ],
    solveFor: (target, vals) => {
      const { PV, C, r } = vals;
      if (target === 'PV') return C / r;
      if (target === 'C') return PV * r;
      if (target === 'r') return C / PV;
      return null;
    }
  },

  // --- Corporate Finance & Valuation ---
  {
    id: 'fin_capm',
    name: 'Capital Asset Pricing Model (CAPM)',
    category: 'Finance',
    subcategory: 'Corporate Finance',
    formula: 'ER = Rf + beta * (Rm - Rf)',
    latex: 'E[R_i] = R_f + \\beta_i (E[R_m] - R_f)',
    description: 'Expected return on an equity asset given its systematic market risk',
    variables: [
      { symbol: 'ER', name: 'Expected Return', unit: '', defaultValue: 0.106 },
      { symbol: 'Rf', name: 'Risk-Free Rate', unit: '', defaultValue: 0.03 },
      { symbol: 'beta', name: 'Beta Coefficient (β)', unit: '', defaultValue: 1.2 },
      { symbol: 'Rm', name: 'Expected Market Return', unit: '', defaultValue: 0.09 }
    ],
    solveFor: (target, vals) => {
      const { ER, Rf, beta, Rm } = vals;
      if (target === 'ER') return Rf + beta * (Rm - Rf);
      if (target === 'beta') return (ER - Rf) / (Rm - Rf);
      if (target === 'Rm') return Rf + (ER - Rf) / beta;
      return null;
    }
  },
  {
    id: 'fin_wacc',
    name: 'Weighted Average Cost of Capital (WACC)',
    category: 'Finance',
    subcategory: 'Corporate Finance',
    formula: 'WACC = (E/V)*Re + (D/V)*Rd*(1 - Tc)',
    latex: '\\text{WACC} = \\frac{E}{V}R_e + \\frac{D}{V}R_d(1 - T_c)',
    description: 'Firm’s average blended cost of capital across equity and debt',
    variables: [
      { symbol: 'WACC', name: 'WACC', unit: '', defaultValue: 0.076 },
      { symbol: 'E', name: 'Equity Value', unit: '$', defaultValue: 600000 },
      { symbol: 'D', name: 'Debt Value', unit: '$', defaultValue: 400000 },
      { symbol: 'Re', name: 'Cost of Equity', unit: '', defaultValue: 0.10 },
      { symbol: 'Rd', name: 'Cost of Debt', unit: '', defaultValue: 0.05 },
      { symbol: 'Tc', name: 'Corporate Tax Rate', unit: '', defaultValue: 0.20 }
    ],
    solveFor: (target, vals) => {
      const { E, D, Re, Rd, Tc } = vals;
      const V = E + D;
      if (target === 'WACC') return (E / V) * Re + (D / V) * Rd * (1 - Tc);
      return null;
    }
  },
  {
    id: 'fin_sharpe_ratio',
    name: 'Sharpe Ratio (Risk-Adjusted Return)',
    category: 'Finance',
    subcategory: 'Investment & Risk',
    formula: 'S = (Rp - Rf) / sigma_p',
    latex: 'S = \\frac{R_p - R_f}{\\sigma_p}',
    description: 'Excess portfolio return earned per unit of total risk (standard deviation)',
    variables: [
      { symbol: 'S', name: 'Sharpe Ratio', unit: '', defaultValue: 0.8 },
      { symbol: 'Rp', name: 'Portfolio Return', unit: '', defaultValue: 0.12 },
      { symbol: 'Rf', name: 'Risk-Free Rate', unit: '', defaultValue: 0.02 },
      { symbol: 'sigma_p', name: 'Portfolio Volatility', unit: '', defaultValue: 0.125 }
    ],
    solveFor: (target, vals) => {
      const { S, Rp, Rf, sigma_p } = vals;
      if (target === 'S') return (Rp - Rf) / sigma_p;
      if (target === 'Rp') return Rf + S * sigma_p;
      if (target === 'sigma_p') return (Rp - Rf) / S;
      return null;
    }
  },
  {
    id: 'fin_breakeven',
    name: 'Break-Even Sales Quantity',
    category: 'Finance',
    subcategory: 'Corporate Finance',
    formula: 'Q = FC / (P - VC)',
    latex: 'Q = \\frac{\\text{Fixed Costs}}{P - \\text{VC}}',
    description: 'Unit sales volume required for total revenue to equal total costs',
    variables: [
      { symbol: 'Q', name: 'Break-Even Units', unit: 'units', defaultValue: 5000 },
      { symbol: 'FC', name: 'Fixed Overhead Costs', unit: '$', defaultValue: 100000 },
      { symbol: 'P', name: 'Selling Price per Unit', unit: '$/unit', defaultValue: 50 },
      { symbol: 'VC', name: 'Variable Cost per Unit', unit: '$/unit', defaultValue: 30 }
    ],
    solveFor: (target, vals) => {
      const { Q, FC, P, VC } = vals;
      if (target === 'Q') return FC / (P - VC);
      if (target === 'FC') return Q * (P - VC);
      if (target === 'P') return FC / Q + VC;
      if (target === 'VC') return P - FC / Q;
      return null;
    }
  }
];

// ============================================================================
// COMBINED UNIFIED FORMULA LIBRARY
// ============================================================================
export const FORMULA_LIBRARY: FormulaItem[] = [
  ...PHYSICS_FORMULAS,
  ...CHEMISTRY_FORMULAS,
  ...MATHEMATICS_FORMULAS,
  ...FINANCE_FORMULAS
];
