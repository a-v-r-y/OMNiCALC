import * as math from 'mathjs';

export interface QuadraticResult {
  a: number;
  b: number;
  c: number;
  discriminant: number;
  vertex: { x: number; y: number };
  roots: {
    r1: string;
    r2: string;
    isComplex: boolean;
    realPart1?: number;
    imagPart1?: number;
    realPart2?: number;
    imagPart2?: number;
  };
  factorized: string;
}

export function solveQuadratic(a: number, b: number, c: number): QuadraticResult | null {
  if (a === 0) return null;
  const d = b * b - 4 * a * c;
  const vx = -b / (2 * a);
  const vy = c - (b * b) / (4 * a);

  if (d > 0) {
    const x1 = (-b + Math.sqrt(d)) / (2 * a);
    const x2 = (-b - Math.sqrt(d)) / (2 * a);
    return {
      a, b, c,
      discriminant: d,
      vertex: { x: vx, y: vy },
      roots: {
        r1: parseFloat(x1.toFixed(8)).toString(),
        r2: parseFloat(x2.toFixed(8)).toString(),
        isComplex: false
      },
      factorized: `${a !== 1 ? a : ''}(x - ${parseFloat(x1.toFixed(4))})(x - ${parseFloat(x2.toFixed(4))})`
    };
  } else if (d === 0) {
    const x = -b / (2 * a);
    return {
      a, b, c,
      discriminant: 0,
      vertex: { x: vx, y: vy },
      roots: {
        r1: parseFloat(x.toFixed(8)).toString(),
        r2: parseFloat(x.toFixed(8)).toString(),
        isComplex: false
      },
      factorized: `${a !== 1 ? a : ''}(x - ${parseFloat(x.toFixed(4))})²`
    };
  } else {
    const real = -b / (2 * a);
    const imag = Math.sqrt(-d) / (2 * a);
    const realStr = parseFloat(real.toFixed(6)).toString();
    const imagStr = parseFloat(Math.abs(imag).toFixed(6)).toString();
    return {
      a, b, c,
      discriminant: d,
      vertex: { x: vx, y: vy },
      roots: {
        r1: `${realStr} + ${imagStr}i`,
        r2: `${realStr} - ${imagStr}i`,
        isComplex: true,
        realPart1: real,
        imagPart1: imag,
        realPart2: real,
        imagPart2: -imag
      },
      factorized: `${a !== 1 ? a : ''}(x - (${realStr} + ${imagStr}i))(x - (${realStr} - ${imagStr}i))`
    };
  }
}

export function solveCubic(a: number, b: number, c: number, d: number): string[] {
  if (a === 0) {
    const q = solveQuadratic(b, c, d);
    return q ? [q.roots.r1, q.roots.r2] : [];
  }

  // Cardano's method for ax^3 + bx^2 + cx + d = 0
  const an = b / a;
  const bn = c / a;
  const cn = d / a;

  const p = bn - (an * an) / 3;
  const q = (2 * an * an * an) / 27 - (an * bn) / 3 + cn;
  const delta = (q * q) / 4 + (p * p * p) / 27;

  const shift = -an / 3;

  if (Math.abs(delta) < 1e-12) {
    // Roots are real and at least two are equal
    if (Math.abs(q) < 1e-12) {
      return [shift.toFixed(6)];
    }
    const u = Math.cbrt(-q / 2);
    const r1 = 2 * u + shift;
    const r2 = -u + shift;
    return [r1.toFixed(6), r2.toFixed(6)];
  } else if (delta > 0) {
    // One real root and two complex conjugate roots
    const u = Math.cbrt(-q / 2 + Math.sqrt(delta));
    const v = Math.cbrt(-q / 2 - Math.sqrt(delta));
    const realRoot = u + v + shift;
    const realPart = -(u + v) / 2 + shift;
    const imagPart = ((u - v) * Math.sqrt(3)) / 2;
    return [
      realRoot.toFixed(6),
      `${realPart.toFixed(6)} + ${Math.abs(imagPart).toFixed(6)}i`,
      `${realPart.toFixed(6)} - ${Math.abs(imagPart).toFixed(6)}i`
    ];
  } else {
    // Three real roots
    const r = Math.sqrt(-(p * p * p) / 27);
    const phi = Math.acos(-q / (2 * r));
    const m = 2 * Math.cbrt(r);
    const r1 = m * Math.cos(phi / 3) + shift;
    const r2 = m * Math.cos((phi + 2 * Math.PI) / 3) + shift;
    const r3 = m * Math.cos((phi + 4 * Math.PI) / 3) + shift;
    return [r1.toFixed(6), r2.toFixed(6), r3.toFixed(6)];
  }
}

// System of 2 linear equations:
// a1*x + b1*y = c1
// a2*x + b2*y = c2
export function solve2x2Linear(
  a1: number, b1: number, c1: number,
  a2: number, b2: number, c2: number
): { x: number; y: number; det: number } | null {
  const det = a1 * b2 - a2 * b1;
  if (Math.abs(det) < 1e-14) return null;
  const x = (c1 * b2 - c2 * b1) / det;
  const y = (a1 * c2 - a2 * c1) / det;
  return { x, y, det };
}

// System of 3 linear equations using Cramer's Rule
export function solve3x3Linear(
  m: number[][], // 3x3 matrix of coefficients
  b: number[]    // 3x1 constant vector
): { x: number; y: number; z: number } | null {
  try {
    const detA = (math.det(m) as any) as number;
    if (Math.abs(detA) < 1e-12) return null;

    const mx = m.map((row, i) => [b[i], row[1], row[2]]);
    const my = m.map((row, i) => [row[0], b[i], row[2]]);
    const mz = m.map((row, i) => [row[0], row[1], b[i]]);

    const x = ((math.det(mx) as any) as number) / detA;
    const y = ((math.det(my) as any) as number) / detA;
    const z = ((math.det(mz) as any) as number) / detA;

    return { x, y, z };
  } catch {
    return null;
  }
}

// Newton-Raphson numerical root solver for any f(x) = 0
export function solveNewtonRaphson(
  fExpr: string,
  initialGuess: number = 1.0,
  tolerance: number = 1e-10,
  maxIterations: number = 100
): { root: number; iterations: number; history: { iter: number; x: number; fx: number }[] } | null {
  try {
    const fCompiled = math.compile(fExpr);
    const dfNode = math.derivative(fExpr, 'x');
    const dfCompiled = dfNode.compile();

    let x = initialGuess;
    const history: { iter: number; x: number; fx: number }[] = [];

    for (let i = 0; i < maxIterations; i++) {
      const fx = fCompiled.evaluate({ x });
      const dfx = dfCompiled.evaluate({ x });

      history.push({ iter: i + 1, x, fx });

      if (Math.abs(fx) < tolerance) {
        return { root: x, iterations: i + 1, history };
      }
      if (Math.abs(dfx) < 1e-15) break; // Slope zero

      const nextX = x - fx / dfx;
      if (Math.abs(nextX - x) < tolerance) {
        return { root: nextX, iterations: i + 1, history };
      }
      x = nextX;
    }
    return null;
  } catch {
    return null;
  }
}

// Bisection method for f(x) = 0 in [a, b]
export function solveBisection(
  fExpr: string,
  a: number,
  b: number,
  tolerance: number = 1e-9,
  maxIter: number = 100
): { root: number; iterations: number } | null {
  try {
    const f = math.compile(fExpr);
    let fa = f.evaluate({ x: a });
    let fb = f.evaluate({ x: b });

    if (fa * fb > 0) return null; // Root not guaranteed bracketed

    let mid = a;
    for (let i = 0; i < maxIter; i++) {
      mid = (a + b) / 2;
      const fmid = f.evaluate({ x: mid });
      if (Math.abs(fmid) < tolerance || (b - a) / 2 < tolerance) {
        return { root: mid, iterations: i + 1 };
      }
      if (fa * fmid < 0) {
        b = mid;
        fb = fmid;
      } else {
        a = mid;
        fa = fmid;
      }
    }
    return { root: mid, iterations: maxIter };
  } catch {
    return null;
  }
}
