// Comprehensive Chemistry Engine & Solvers

export interface ElementData {
  number: number;
  symbol: string;
  name: string;
  mass: number;
  category: string;
  electronegativity?: number;
  group?: number;
  period: number;
}

export const PERIODIC_ELEMENTS: ElementData[] = [
  { number: 1, symbol: 'H', name: 'Hydrogen', mass: 1.008, category: 'Nonmetal', electronegativity: 2.20, period: 1, group: 1 },
  { number: 2, symbol: 'He', name: 'Helium', mass: 4.0026, category: 'Noble Gas', period: 1, group: 18 },
  { number: 3, symbol: 'Li', name: 'Lithium', mass: 6.94, category: 'Alkali Metal', electronegativity: 0.98, period: 2, group: 1 },
  { number: 4, symbol: 'Be', name: 'Beryllium', mass: 9.0122, category: 'Alkaline Earth', electronegativity: 1.57, period: 2, group: 2 },
  { number: 5, symbol: 'B', name: 'Boron', mass: 10.81, category: 'Metalloid', electronegativity: 2.04, period: 2, group: 13 },
  { number: 6, symbol: 'C', name: 'Carbon', mass: 12.011, category: 'Nonmetal', electronegativity: 2.55, period: 2, group: 14 },
  { number: 7, symbol: 'N', name: 'Nitrogen', mass: 14.007, category: 'Nonmetal', electronegativity: 3.04, period: 2, group: 15 },
  { number: 8, symbol: 'O', name: 'Oxygen', mass: 15.999, category: 'Nonmetal', electronegativity: 3.44, period: 2, group: 16 },
  { number: 9, symbol: 'F', name: 'Fluorine', mass: 18.998, category: 'Halogen', electronegativity: 3.98, period: 2, group: 17 },
  { number: 10, symbol: 'Ne', name: 'Neon', mass: 20.180, category: 'Noble Gas', period: 2, group: 18 },
  { number: 11, symbol: 'Na', name: 'Sodium', mass: 22.990, category: 'Alkali Metal', electronegativity: 0.93, period: 3, group: 1 },
  { number: 12, symbol: 'Mg', name: 'Magnesium', mass: 24.305, category: 'Alkaline Earth', electronegativity: 1.31, period: 3, group: 2 },
  { number: 13, symbol: 'Al', name: 'Aluminium', mass: 26.982, category: 'Post-transition Metal', electronegativity: 1.61, period: 3, group: 13 },
  { number: 14, symbol: 'Si', name: 'Silicon', mass: 28.085, category: 'Metalloid', electronegativity: 1.90, period: 3, group: 14 },
  { number: 15, symbol: 'P', name: 'Phosphorus', mass: 30.974, category: 'Nonmetal', electronegativity: 2.19, period: 3, group: 15 },
  { number: 16, symbol: 'S', name: 'Sulfur', mass: 32.06, category: 'Nonmetal', electronegativity: 2.58, period: 3, group: 16 },
  { number: 17, symbol: 'Cl', name: 'Chlorine', mass: 35.45, category: 'Halogen', electronegativity: 3.16, period: 3, group: 17 },
  { number: 18, symbol: 'Ar', name: 'Argon', mass: 39.948, category: 'Noble Gas', period: 3, group: 18 },
  { number: 19, symbol: 'K', name: 'Potassium', mass: 39.098, category: 'Alkali Metal', electronegativity: 0.82, period: 4, group: 1 },
  { number: 20, symbol: 'Ca', name: 'Calcium', mass: 40.078, category: 'Alkaline Earth', electronegativity: 1.00, period: 4, group: 2 },
  { number: 21, symbol: 'Sc', name: 'Scandium', mass: 44.956, category: 'Transition Metal', electronegativity: 1.36, period: 4, group: 3 },
  { number: 22, symbol: 'Ti', name: 'Titanium', mass: 47.867, category: 'Transition Metal', electronegativity: 1.54, period: 4, group: 4 },
  { number: 23, symbol: 'V', name: 'Vanadium', mass: 50.942, category: 'Transition Metal', electronegativity: 1.63, period: 4, group: 5 },
  { number: 24, symbol: 'Cr', name: 'Chromium', mass: 51.996, category: 'Transition Metal', electronegativity: 1.66, period: 4, group: 6 },
  { number: 25, symbol: 'Mn', name: 'Manganese', mass: 54.938, category: 'Transition Metal', electronegativity: 1.55, period: 4, group: 7 },
  { number: 26, symbol: 'Fe', name: 'Iron', mass: 55.845, category: 'Transition Metal', electronegativity: 1.83, period: 4, group: 8 },
  { number: 27, symbol: 'Co', name: 'Cobalt', mass: 58.933, category: 'Transition Metal', electronegativity: 1.88, period: 4, group: 9 },
  { number: 28, symbol: 'Ni', name: 'Nickel', mass: 58.693, category: 'Transition Metal', electronegativity: 1.91, period: 4, group: 10 },
  { number: 29, symbol: 'Cu', name: 'Copper', mass: 63.546, category: 'Transition Metal', electronegativity: 1.90, period: 4, group: 11 },
  { number: 30, symbol: 'Zn', name: 'Zinc', mass: 65.38, category: 'Transition Metal', electronegativity: 1.65, period: 4, group: 12 },
  { number: 31, symbol: 'Ga', name: 'Gallium', mass: 69.723, category: 'Post-transition Metal', electronegativity: 1.81, period: 4, group: 13 },
  { number: 32, symbol: 'Ge', name: 'Germanium', mass: 72.630, category: 'Metalloid', electronegativity: 2.01, period: 4, group: 14 },
  { number: 33, symbol: 'As', name: 'Arsenic', mass: 74.922, category: 'Metalloid', electronegativity: 2.18, period: 4, group: 15 },
  { number: 34, symbol: 'Se', name: 'Selenium', mass: 78.971, category: 'Nonmetal', electronegativity: 2.55, period: 4, group: 16 },
  { number: 35, symbol: 'Br', name: 'Bromine', mass: 79.904, category: 'Halogen', electronegativity: 2.96, period: 4, group: 17 },
  { number: 36, symbol: 'Kr', name: 'Krypton', mass: 83.798, category: 'Noble Gas', period: 4, group: 18 },
  { number: 47, symbol: 'Ag', name: 'Silver', mass: 107.868, category: 'Transition Metal', electronegativity: 1.93, period: 5, group: 11 },
  { number: 50, symbol: 'Sn', name: 'Tin', mass: 118.71, category: 'Post-transition Metal', electronegativity: 1.96, period: 5, group: 14 },
  { number: 53, symbol: 'I', name: 'Iodine', mass: 126.904, category: 'Halogen', electronegativity: 2.66, period: 5, group: 17 },
  { number: 56, symbol: 'Ba', name: 'Barium', mass: 137.327, category: 'Alkaline Earth', electronegativity: 0.89, period: 6, group: 2 },
  { number: 79, symbol: 'Au', name: 'Gold', mass: 196.967, category: 'Transition Metal', electronegativity: 2.54, period: 6, group: 11 },
  { number: 80, symbol: 'Hg', name: 'Mercury', mass: 200.592, category: 'Transition Metal', electronegativity: 2.00, period: 6, group: 12 },
  { number: 82, symbol: 'Pb', name: 'Lead', mass: 207.2, category: 'Post-transition Metal', electronegativity: 2.33, period: 6, group: 14 },
  { number: 92, symbol: 'U', name: 'Uranium', mass: 238.029, category: 'Actinide', electronegativity: 1.38, period: 7, group: 3 }
];

export const ELEMENT_MASS_MAP: Record<string, number> = {};
PERIODIC_ELEMENTS.forEach(el => {
  ELEMENT_MASS_MAP[el.symbol] = el.mass;
});

// 1. Formula Parser with Mass %
export interface FormulaBreakdown {
  molarMass: number;
  elements: { symbol: string; count: number; mass: number; percentage: number }[];
}

export function parseFormulaDetailed(formula: string): FormulaBreakdown {
  const cleaned = formula.replace(/\s+/g, '').replace(/·/g, '*');
  const counts: Record<string, number> = {};

  // Handle hydrates like CuSO4*5H2O
  const parts = cleaned.split('*');
  const mainPart = parts[0];
  const hydratePart = parts[1];

  function parseChunk(str: string, multiplier: number = 1) {
    const regex = /([A-Z][a-z]?|\((?:[^()]|\([^()]*\))*\))(\d*)/g;
    let match;
    while ((match = regex.exec(str)) !== null) {
      const part = match[1];
      const count = (match[2] ? parseInt(match[2], 10) : 1) * multiplier;

      if (part.startsWith('(') && part.endsWith(')')) {
        parseChunk(part.slice(1, -1), count);
      } else {
        counts[part] = (counts[part] || 0) + count;
      }
    }
  }

  parseChunk(mainPart);

  if (hydratePart) {
    const hydrateMatch = hydratePart.match(/^(\d*)(.*)$/);
    if (hydrateMatch) {
      const mult = hydrateMatch[1] ? parseInt(hydrateMatch[1], 10) : 1;
      parseChunk(hydrateMatch[2], mult);
    }
  }

  let totalMass = 0;
  const elements = Object.entries(counts).map(([symbol, count]) => {
    const elMass = ELEMENT_MASS_MAP[symbol] || 0;
    const massContrib = elMass * count;
    totalMass += massContrib;
    return { symbol, count, mass: massContrib, percentage: 0 };
  });

  elements.forEach(el => {
    el.percentage = totalMass > 0 ? parseFloat(((el.mass / totalMass) * 100).toFixed(2)) : 0;
  });

  return {
    molarMass: parseFloat(totalMass.toFixed(3)),
    elements
  };
}

// 2. Mole & Stoichiometry Engine
export function convertMoles(
  input: { mass?: number; moles?: number; particles?: number; volumeSTP?: number },
  molarMass: number
): {
  mass: number;
  moles: number;
  particles: number;
  volumeSTP: number;
} {
  const NA = 6.02214076e23;
  const V_MOL_STP = 22.414; // L/mol

  let moles = 0;
  if (input.moles !== undefined) {
    moles = input.moles;
  } else if (input.mass !== undefined && molarMass > 0) {
    moles = input.mass / molarMass;
  } else if (input.particles !== undefined) {
    moles = input.particles / NA;
  } else if (input.volumeSTP !== undefined) {
    moles = input.volumeSTP / V_MOL_STP;
  }

  const mass = moles * molarMass;
  const particles = moles * NA;
  const volumeSTP = moles * V_MOL_STP;

  return {
    mass: parseFloat(mass.toFixed(4)),
    moles: parseFloat(moles.toFixed(4)),
    particles,
    volumeSTP: parseFloat(volumeSTP.toFixed(4))
  };
}

// Stoichiometry 2 Reactants -> 1 Product
export function calculateStoichiometry(
  coeffA: number,
  massA: number,
  molarMassA: number,
  coeffB: number,
  massB: number,
  molarMassB: number,
  coeffProd: number,
  molarMassProd: number,
  actualYieldProd: number = 0
): {
  molesA: number;
  molesB: number;
  limitingReagent: 'A' | 'B' | 'Equimolar';
  theoreticalYieldMoles: number;
  theoreticalYieldMass: number;
  excessLeftoverMass: number;
  excessReagent: 'A' | 'B' | 'None';
  percentYield: number;
} {
  const molesA = molarMassA > 0 ? massA / molarMassA : 0;
  const molesB = molarMassB > 0 ? massB / molarMassB : 0;

  const ratioA = coeffA > 0 ? molesA / coeffA : 0;
  const ratioB = coeffB > 0 ? molesB / coeffB : 0;

  let limiting: 'A' | 'B' | 'Equimolar' = 'Equimolar';
  let limitingMolesPerCoeff = ratioA;
  let excessReagent: 'A' | 'B' | 'None' = 'None';
  let excessLeftoverMoles = 0;
  let excessMolarMass = 0;

  if (ratioA < ratioB) {
    limiting = 'A';
    limitingMolesPerCoeff = ratioA;
    excessReagent = 'B';
    excessLeftoverMoles = molesB - ratioA * coeffB;
    excessMolarMass = molarMassB;
  } else if (ratioB < ratioA) {
    limiting = 'B';
    limitingMolesPerCoeff = ratioB;
    excessReagent = 'A';
    excessLeftoverMoles = molesA - ratioB * coeffA;
    excessMolarMass = molarMassA;
  }

  const theoreticalMoles = limitingMolesPerCoeff * coeffProd;
  const theoreticalMass = theoreticalMoles * molarMassProd;
  const excessLeftoverMass = Math.max(0, excessLeftoverMoles * excessMolarMass);
  const percentYield = theoreticalMass > 0 ? (actualYieldProd / theoreticalMass) * 100 : 0;

  return {
    molesA: parseFloat(molesA.toFixed(4)),
    molesB: parseFloat(molesB.toFixed(4)),
    limitingReagent: limiting,
    theoreticalYieldMoles: parseFloat(theoreticalMoles.toFixed(4)),
    theoreticalYieldMass: parseFloat(theoreticalMass.toFixed(3)),
    excessLeftoverMass: parseFloat(excessLeftoverMass.toFixed(3)),
    excessReagent,
    percentYield: parseFloat(percentYield.toFixed(2))
  };
}

// 3. Solutions, Molarity, Molality & Dilution
export function calculateMolarity(moles: number, volumeL: number): number {
  return volumeL > 0 ? parseFloat((moles / volumeL).toFixed(4)) : 0;
}

export function calculateMolality(moles: number, massSolventKg: number): number {
  return massSolventKg > 0 ? parseFloat((moles / massSolventKg).toFixed(4)) : 0;
}

export function calculateDilution(
  m1?: number,
  v1?: number,
  m2?: number,
  v2?: number
): { solvedVar: string; value: number; solventToAdd: number } | null {
  if (m1 === undefined && v1 && m2 && v2) {
    const val = (m2 * v2) / v1;
    return { solvedVar: 'M₁ (Initial Molarity)', value: parseFloat(val.toFixed(4)), solventToAdd: Math.max(0, v2 - v1) };
  }
  if (v1 === undefined && m1 && m2 && v2) {
    const val = (m2 * v2) / m1;
    return { solvedVar: 'V₁ (Initial Volume)', value: parseFloat(val.toFixed(4)), solventToAdd: Math.max(0, v2 - val) };
  }
  if (m2 === undefined && m1 && v1 && v2) {
    const val = (m1 * v1) / v2;
    return { solvedVar: 'M₂ (Final Molarity)', value: parseFloat(val.toFixed(4)), solventToAdd: Math.max(0, v2 - v1) };
  }
  if (v2 === undefined && m1 && v1 && m2) {
    const val = (m1 * v1) / m2;
    return { solvedVar: 'V₂ (Final Volume)', value: parseFloat(val.toFixed(4)), solventToAdd: Math.max(0, val - v1) };
  }
  return null;
}

// 4. Acid / Base Equilibrium & Buffer Solutions
export function calculateWeakAcidPH(Ka: number, initialConc: number): {
  pH: number;
  hConc: number;
  percentIonization: number;
} {
  // Ka = x^2 / (C - x) -> x^2 + Ka*x - Ka*C = 0
  const A = 1;
  const B = Ka;
  const C = -Ka * initialConc;
  const disc = B * B - 4 * A * C;
  const x = disc >= 0 ? (-B + Math.sqrt(disc)) / (2 * A) : 0;

  const pH = x > 0 ? -Math.log10(x) : 7;
  const percentIon = initialConc > 0 ? (x / initialConc) * 100 : 0;

  return {
    pH: parseFloat(pH.toFixed(3)),
    hConc: parseFloat(x.toExponential(4)),
    percentIonization: parseFloat(percentIon.toFixed(2))
  };
}

export function calculateBufferPH(pKa: number, concBase: number, concAcid: number): number {
  if (concAcid <= 0 || concBase <= 0) return pKa;
  // Henderson-Hasselbalch: pH = pKa + log([Base] / [Acid])
  const pH = pKa + Math.log10(concBase / concAcid);
  return parseFloat(pH.toFixed(3));
}

// 5. Chemical Kinetics: Arrhenius Equation
export function calculateArrhenius(
  A_freq: number,
  Ea_kJ_mol: number,
  temperatureKelvin: number
): { rateConstant: number; factorExp: number } {
  const R = 8.314462618; // J/(mol·K)
  const Ea_J = Ea_kJ_mol * 1000;
  const exponent = -Ea_J / (R * temperatureKelvin);
  const k = A_freq * Math.exp(exponent);

  return {
    rateConstant: parseFloat(k.toExponential(4)),
    factorExp: parseFloat(Math.exp(exponent).toExponential(4))
  };
}

// 6. Radioactive Decay & Half-Life
export function calculateRadioactiveDecay(
  N0: number,
  halfLife: number,
  timeElapsed: number
): {
  remainingAmount: number;
  fractionRemaining: number;
  decayConstant: number;
  decayEvents: number;
} {
  const lambda = Math.LN2 / halfLife;
  const remaining = N0 * Math.pow(0.5, timeElapsed / halfLife);
  const fraction = N0 > 0 ? remaining / N0 : 0;

  return {
    remainingAmount: parseFloat(remaining.toFixed(4)),
    fractionRemaining: parseFloat((fraction * 100).toFixed(2)),
    decayConstant: parseFloat(lambda.toExponential(4)),
    decayEvents: parseFloat((N0 - remaining).toFixed(4))
  };
}

// 7. Chemical Constants Reference
export interface ChemicalConstant {
  symbol: string;
  name: string;
  value: string;
  unit: string;
  description: string;
}

export const CHEMICAL_CONSTANTS: ChemicalConstant[] = [
  { symbol: 'N_A', name: 'Avogadro Constant', value: '6.02214076 × 10²³', unit: 'mol⁻¹', description: 'Number of particles per mole' },
  { symbol: 'R', name: 'Gas Constant (SI)', value: '8.31446', unit: 'J/(mol·K)', description: 'Molar universal gas constant in metric units' },
  { symbol: 'R_atm', name: 'Gas Constant (L·atm)', value: '0.082057', unit: 'L·atm/(mol·K)', description: 'Gas constant for atmospheric pressure calculations' },
  { symbol: 'F', name: 'Faraday Constant', value: '96485.33', unit: 'C/mol', description: 'Electric charge per mole of electrons' },
  { symbol: 'K_w', name: 'Water Autoionization Product (25°C)', value: '1.00 × 10⁻¹⁴', unit: 'mol²/L²', description: 'Equilibrium constant for H₂O ⇌ H⁺ + OH⁻' },
  { symbol: 'V_m', name: 'Ideal Gas Molar Volume (STP)', value: '22.414', unit: 'L/mol', description: 'Volume occupied by one mole of gas at 0°C & 1 atm' },
  { symbol: 'k_B', name: 'Boltzmann Constant', value: '1.380649 × 10⁻²³', unit: 'J/K', description: 'Gas kinetic factor per molecule' },
  { symbol: 'u', name: 'Atomic Mass Unit', value: '1.660539 × 10⁻²⁷', unit: 'kg', description: 'Standard mass reference: 1/12th of carbon-12' }
];
