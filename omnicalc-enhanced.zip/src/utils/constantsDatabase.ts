import { PhysicalConstant } from '../types/calc';

export const CONSTANTS_DATABASE: PhysicalConstant[] = [
  // Mathematics
  { symbol: 'pi', name: 'Pi (π)', value: 3.141592653589793, unit: '', category: 'Mathematics', description: 'Ratio of a circle circumference to diameter' },
  { symbol: 'e', name: "Euler's Number (e)", value: 2.718281828459045, unit: '', category: 'Mathematics', description: 'Base of natural logarithms' },
  { symbol: 'phi', name: 'Golden Ratio (φ)', value: 1.618033988749895, unit: '', category: 'Mathematics', description: '(1 + √5) / 2' },
  { symbol: 'gamma', name: 'Euler-Mascheroni Constant (γ)', value: 0.577215664901532, unit: '', category: 'Mathematics', description: 'Lim (sum 1/k - ln(n))' },
  { symbol: 'sqrt2', name: 'Square Root of 2', value: 1.414213562373095, unit: '', category: 'Mathematics', description: 'Diagonal of unit square' },

  // Fundamental Physics
  { symbol: 'c', name: 'Speed of Light in Vacuum', value: 299792458, unit: 'm/s', category: 'Physics', description: 'Speed of electromagnetic waves in vacuum' },
  { symbol: 'G', name: 'Newtonian Constant of Gravitation', value: 6.67430e-11, unit: 'm³/(kg·s²)', category: 'Physics', description: 'Gravitational constant' },
  { symbol: 'g0', name: 'Standard Acceleration of Gravity', value: 9.80665, unit: 'm/s²', category: 'Physics', description: 'Standard Earth gravity' },
  { symbol: 'h', name: 'Planck Constant', value: 6.62607015e-34, unit: 'J·s', category: 'Quantum', description: 'Quantum of electromagnetic action' },
  { symbol: 'hbar', name: 'Reduced Planck Constant (ℏ)', value: 1.054571817e-34, unit: 'J·s', category: 'Quantum', description: 'h / (2π)' },

  // Electromagnetism
  { symbol: 'qe', name: 'Elementary Charge (e)', value: 1.602176634e-19, unit: 'C', category: 'Electromagnetism', description: 'Electric charge of proton/electron' },
  { symbol: 'eps0', name: 'Vacuum Electric Permittivity (ε₀)', value: 8.8541878128e-12, unit: 'F/m', category: 'Electromagnetism', description: 'Permittivity of free space' },
  { symbol: 'mu0', name: 'Vacuum Magnetic Permeability (μ₀)', value: 1.25663706212e-6, unit: 'N/A²', category: 'Electromagnetism', description: 'Permeability of free space' },
  { symbol: 'ke', name: "Coulomb's Constant", value: 8.9875517923e9, unit: 'N·m²/C²', category: 'Electromagnetism', description: '1 / (4πε₀)' },
  { symbol: 'Z0', name: 'Characteristic Impedance of Vacuum', value: 376.730313668, unit: 'Ω', category: 'Electromagnetism', description: 'Free space wave impedance' },

  // Thermodynamics & Chemistry
  { symbol: 'kB', name: 'Boltzmann Constant', value: 1.380649e-23, unit: 'J/K', category: 'Thermodynamics', description: 'Relates average kinetic energy with temperature' },
  { symbol: 'NA', name: 'Avogadro Constant', value: 6.02214076e23, unit: 'mol⁻¹', category: 'Thermodynamics', description: 'Number of constituent particles in one mole' },
  { symbol: 'R_gas', name: 'Molar Gas Constant (R)', value: 8.314462618, unit: 'J/(mol·K)', category: 'Thermodynamics', description: 'Universal gas constant' },
  { symbol: 'sigma_SB', name: 'Stefan-Boltzmann Constant (σ)', value: 5.670374419e-8, unit: 'W/(m²·K⁴)', category: 'Thermodynamics', description: 'Blackbody radiation constant' },
  { symbol: 'F_const', name: 'Faraday Constant (F)', value: 96485.33212, unit: 'C/mol', category: 'Thermodynamics', description: 'Electric charge per mole of electrons' },
  { symbol: 'b_wien', name: "Wien's Displacement Constant", value: 2.897771955e-3, unit: 'm·K', category: 'Thermodynamics', description: 'Peak wavelength of blackbody radiation' },

  // Quantum & Atomic
  { symbol: 'me', name: 'Electron Rest Mass', value: 9.1093837015e-31, unit: 'kg', category: 'Quantum', description: 'Mass of stationary electron' },
  { symbol: 'mp', name: 'Proton Rest Mass', value: 1.67262192369e-27, unit: 'kg', category: 'Quantum', description: 'Mass of stationary proton' },
  { symbol: 'mn', name: 'Neutron Rest Mass', value: 1.67492749804e-27, unit: 'kg', category: 'Quantum', description: 'Mass of stationary neutron' },
  { symbol: 'u_amu', name: 'Unified Atomic Mass Unit (u)', value: 1.66053906660e-27, unit: 'kg', category: 'Quantum', description: '1/12 the mass of carbon-12 atom' },
  { symbol: 'alpha_fs', name: 'Fine-Structure Constant (α)', value: 0.0072973525693, unit: '', category: 'Quantum', description: 'Electromagnetic interaction strength (~1/137)' },
  { symbol: 'R_inf', name: 'Rydberg Constant', value: 10973731.568160, unit: 'm⁻¹', category: 'Quantum', description: 'Atomic spectra constant' },
  { symbol: 'a0_bohr', name: 'Bohr Radius (a₀)', value: 5.29177210903e-11, unit: 'm', category: 'Quantum', description: 'Most probable distance of electron in hydrogen ground state' },

  // Astronomy
  { symbol: 'M_sun', name: 'Solar Mass (M☉)', value: 1.98847e30, unit: 'kg', category: 'Astronomy', description: 'Mass of the Sun' },
  { symbol: 'R_sun', name: 'Solar Radius (R☉)', value: 6.957e8, unit: 'm', category: 'Astronomy', description: 'Radius of the Sun' },
  { symbol: 'L_sun', name: 'Solar Luminosity (L☉)', value: 3.828e26, unit: 'W', category: 'Astronomy', description: 'Radiant flux of the Sun' },
  { symbol: 'M_earth', name: 'Earth Mass', value: 5.9722e24, unit: 'kg', category: 'Astronomy', description: 'Mass of Planet Earth' },
  { symbol: 'R_earth', name: 'Earth Mean Radius', value: 6.371e6, unit: 'm', category: 'Astronomy', description: 'Mean radius of Earth' },
  { symbol: 'au', name: 'Astronomical Unit (AU)', value: 149597870700, unit: 'm', category: 'Astronomy', description: 'Roughly distance from Earth to Sun' },
  { symbol: 'ly', name: 'Light Year', value: 9.4607304725808e15, unit: 'm', category: 'Astronomy', description: 'Distance light travels in 1 Julian year' },
  { symbol: 'pc', name: 'Parsec', value: 3.08567758149137e16, unit: 'm', category: 'Astronomy', description: 'Parallax of one arcsecond (~3.26 light years)' }
];
