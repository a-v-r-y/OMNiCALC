export interface UnitCategory {
  name: string;
  baseUnit: string;
  units: {
    name: string;
    symbol: string;
    toBase: (val: number) => number;
    fromBase: (baseVal: number) => number;
  }[];
}

export const UNIT_CATEGORIES: UnitCategory[] = [
  {
    name: 'Length',
    baseUnit: 'm',
    units: [
      { name: 'Meters', symbol: 'm', toBase: v => v, fromBase: v => v },
      { name: 'Kilometers', symbol: 'km', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Centimeters', symbol: 'cm', toBase: v => v / 100, fromBase: v => v * 100 },
      { name: 'Millimeters', symbol: 'mm', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Micrometers', symbol: 'µm', toBase: v => v * 1e-6, fromBase: v => v * 1e6 },
      { name: 'Nanometers', symbol: 'nm', toBase: v => v * 1e-9, fromBase: v => v * 1e9 },
      { name: 'Inches', symbol: 'in', toBase: v => v * 0.0254, fromBase: v => v / 0.0254 },
      { name: 'Feet', symbol: 'ft', toBase: v => v * 0.3048, fromBase: v => v / 0.3048 },
      { name: 'Yards', symbol: 'yd', toBase: v => v * 0.9144, fromBase: v => v / 0.9144 },
      { name: 'Miles', symbol: 'mi', toBase: v => v * 1609.344, fromBase: v => v / 1609.344 },
      { name: 'Nautical Miles', symbol: 'nmi', toBase: v => v * 1852, fromBase: v => v / 1852 },
      { name: 'Light Years', symbol: 'ly', toBase: v => v * 9.461e15, fromBase: v => v / 9.461e15 },
      { name: 'Astronomical Units', symbol: 'AU', toBase: v => v * 1.496e11, fromBase: v => v / 1.496e11 }
    ]
  },
  {
    name: 'Mass',
    baseUnit: 'kg',
    units: [
      { name: 'Kilograms', symbol: 'kg', toBase: v => v, fromBase: v => v },
      { name: 'Grams', symbol: 'g', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Milligrams', symbol: 'mg', toBase: v => v / 1e6, fromBase: v => v * 1e6 },
      { name: 'Micrograms', symbol: 'µg', toBase: v => v / 1e9, fromBase: v => v * 1e9 },
      { name: 'Metric Tonnes', symbol: 't', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Pounds', symbol: 'lb', toBase: v => v * 0.45359237, fromBase: v => v / 0.45359237 },
      { name: 'Ounces', symbol: 'oz', toBase: v => v * 0.028349523, fromBase: v => v / 0.028349523 },
      { name: 'Stones', symbol: 'st', toBase: v => v * 6.350293, fromBase: v => v / 6.350293 },
      { name: 'Atomic Mass Units', symbol: 'u', toBase: v => v * 1.660539e-27, fromBase: v => v / 1.660539e-27 }
    ]
  },
  {
    name: 'Temperature',
    baseUnit: 'K',
    units: [
      { name: 'Kelvin', symbol: 'K', toBase: v => v, fromBase: v => v },
      { name: 'Celsius', symbol: '°C', toBase: v => v + 273.15, fromBase: v => v - 273.15 },
      { name: 'Fahrenheit', symbol: '°F', toBase: v => ((v - 32) * 5) / 9 + 273.15, fromBase: v => ((v - 273.15) * 9) / 5 + 32 },
      { name: 'Rankine', symbol: '°R', toBase: v => (v * 5) / 9, fromBase: v => (v * 9) / 5 }
    ]
  },
  {
    name: 'Time',
    baseUnit: 's',
    units: [
      { name: 'Seconds', symbol: 's', toBase: v => v, fromBase: v => v },
      { name: 'Milliseconds', symbol: 'ms', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Microseconds', symbol: 'µs', toBase: v => v / 1e6, fromBase: v => v * 1e6 },
      { name: 'Nanoseconds', symbol: 'ns', toBase: v => v / 1e9, fromBase: v => v * 1e9 },
      { name: 'Minutes', symbol: 'min', toBase: v => v * 60, fromBase: v => v / 60 },
      { name: 'Hours', symbol: 'hr', toBase: v => v * 3600, fromBase: v => v / 3600 },
      { name: 'Days', symbol: 'day', toBase: v => v * 86400, fromBase: v => v / 86400 },
      { name: 'Weeks', symbol: 'wk', toBase: v => v * 604800, fromBase: v => v / 604800 },
      { name: 'Julian Years', symbol: 'yr', toBase: v => v * 31557600, fromBase: v => v / 31557600 }
    ]
  },
  {
    name: 'Speed',
    baseUnit: 'm/s',
    units: [
      { name: 'Meters per second', symbol: 'm/s', toBase: v => v, fromBase: v => v },
      { name: 'Kilometers per hour', symbol: 'km/h', toBase: v => v / 3.6, fromBase: v => v * 3.6 },
      { name: 'Miles per hour', symbol: 'mph', toBase: v => v * 0.44704, fromBase: v => v / 0.44704 },
      { name: 'Knots', symbol: 'kn', toBase: v => v * 0.514444, fromBase: v => v / 0.514444 },
      { name: 'Speed of Light', symbol: 'c', toBase: v => v * 299792458, fromBase: v => v / 299792458 },
      { name: 'Mach (at sea level)', symbol: 'Ma', toBase: v => v * 340.29, fromBase: v => v / 340.29 }
    ]
  },
  {
    name: 'Pressure',
    baseUnit: 'Pa',
    units: [
      { name: 'Pascals', symbol: 'Pa', toBase: v => v, fromBase: v => v },
      { name: 'Kilopascals', symbol: 'kPa', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Megapascals', symbol: 'MPa', toBase: v => v * 1e6, fromBase: v => v / 1e6 },
      { name: 'Bar', symbol: 'bar', toBase: v => v * 1e5, fromBase: v => v / 1e5 },
      { name: 'Standard Atmospheres', symbol: 'atm', toBase: v => v * 101325, fromBase: v => v / 101325 },
      { name: 'Torr / mmHg', symbol: 'Torr', toBase: v => v * 133.322368, fromBase: v => v / 133.322368 },
      { name: 'Pounds per sq inch', symbol: 'psi', toBase: v => v * 6894.757, fromBase: v => v / 6894.757 }
    ]
  },
  {
    name: 'Energy',
    baseUnit: 'J',
    units: [
      { name: 'Joules', symbol: 'J', toBase: v => v, fromBase: v => v },
      { name: 'Kilojoules', symbol: 'kJ', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Calories (thermochemical)', symbol: 'cal', toBase: v => v * 4.184, fromBase: v => v / 4.184 },
      { name: 'Kilocalories (food)', symbol: 'kcal', toBase: v => v * 4184, fromBase: v => v / 4184 },
      { name: 'Watt-hours', symbol: 'Wh', toBase: v => v * 3600, fromBase: v => v / 3600 },
      { name: 'Kilowatt-hours', symbol: 'kWh', toBase: v => v * 3.6e6, fromBase: v => v / 3.6e6 },
      { name: 'Electronvolts', symbol: 'eV', toBase: v => v * 1.602176634e-19, fromBase: v => v / 1.602176634e-19 },
      { name: 'British Thermal Units', symbol: 'BTU', toBase: v => v * 1055.06, fromBase: v => v / 1055.06 },
      { name: 'Foot-pounds', symbol: 'ft·lb', toBase: v => v * 1.355818, fromBase: v => v / 1.355818 }
    ]
  },
  {
    name: 'Power',
    baseUnit: 'W',
    units: [
      { name: 'Watts', symbol: 'W', toBase: v => v, fromBase: v => v },
      { name: 'Kilowatts', symbol: 'kW', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Megawatts', symbol: 'MW', toBase: v => v * 1e6, fromBase: v => v / 1e6 },
      { name: 'Horsepower (mechanical)', symbol: 'hp', toBase: v => v * 745.69987, fromBase: v => v / 745.69987 },
      { name: 'BTU per hour', symbol: 'BTU/h', toBase: v => v * 0.293071, fromBase: v => v / 0.293071 }
    ]
  },
  {
    name: 'Data Storage',
    baseUnit: 'B',
    units: [
      { name: 'Bytes', symbol: 'B', toBase: v => v, fromBase: v => v },
      { name: 'Kilobytes (decimal)', symbol: 'KB', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Kibibytes (binary)', symbol: 'KiB', toBase: v => v * 1024, fromBase: v => v / 1024 },
      { name: 'Megabytes (decimal)', symbol: 'MB', toBase: v => v * 1e6, fromBase: v => v / 1e6 },
      { name: 'Mebibytes (binary)', symbol: 'MiB', toBase: v => v * 1048576, fromBase: v => v / 1048576 },
      { name: 'Gigabytes (decimal)', symbol: 'GB', toBase: v => v * 1e9, fromBase: v => v / 1e9 },
      { name: 'Gibibytes (binary)', symbol: 'GiB', toBase: v => v * 1073741824, fromBase: v => v / 1073741824 },
      { name: 'Terabytes (decimal)', symbol: 'TB', toBase: v => v * 1e12, fromBase: v => v / 1e12 },
      { name: 'Tebibytes (binary)', symbol: 'TiB', toBase: v => v * 1099511627776, fromBase: v => v / 1099511627776 }
    ]
  },
  {
    name: 'Angle',
    baseUnit: 'rad',
    units: [
      { name: 'Radians', symbol: 'rad', toBase: v => v, fromBase: v => v },
      { name: 'Degrees', symbol: 'deg', toBase: v => (v * Math.PI) / 180, fromBase: v => (v * 180) / Math.PI },
      { name: 'Gradians', symbol: 'grad', toBase: v => (v * Math.PI) / 200, fromBase: v => (v * 200) / Math.PI },
      { name: 'Arcminutes', symbol: 'arcmin', toBase: v => (v * Math.PI) / (180 * 60), fromBase: v => (v * 180 * 60) / Math.PI },
      { name: 'Arcseconds', symbol: 'arcsec', toBase: v => (v * Math.PI) / (180 * 3600), fromBase: v => (v * 180 * 3600) / Math.PI },
      { name: 'Revolutions / Turns', symbol: 'rev', toBase: v => v * 2 * Math.PI, fromBase: v => v / (2 * Math.PI) }
    ]
  },
  {
    name: 'Area',
    baseUnit: 'm²',
    units: [
      { name: 'Square Meters', symbol: 'm²', toBase: v => v, fromBase: v => v },
      { name: 'Square Kilometers', symbol: 'km²', toBase: v => v * 1e6, fromBase: v => v / 1e6 },
      { name: 'Square Centimeters', symbol: 'cm²', toBase: v => v / 1e4, fromBase: v => v * 1e4 },
      { name: 'Hectares', symbol: 'ha', toBase: v => v * 10000, fromBase: v => v / 10000 },
      { name: 'Acres', symbol: 'ac', toBase: v => v * 4046.8564224, fromBase: v => v / 4046.8564224 },
      { name: 'Square Feet', symbol: 'ft²', toBase: v => v * 0.09290304, fromBase: v => v / 0.09290304 },
      { name: 'Square Inches', symbol: 'in²', toBase: v => v * 0.00064516, fromBase: v => v / 0.00064516 },
      { name: 'Square Yards', symbol: 'yd²', toBase: v => v * 0.83612736, fromBase: v => v / 0.83612736 },
      { name: 'Square Miles', symbol: 'mi²', toBase: v => v * 2589988.110336, fromBase: v => v / 2589988.110336 }
    ]
  },
  {
    name: 'Volume',
    baseUnit: 'L',
    units: [
      { name: 'Liters', symbol: 'L', toBase: v => v, fromBase: v => v },
      { name: 'Milliliters', symbol: 'mL', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Cubic Meters', symbol: 'm³', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { name: 'Cubic Centimeters', symbol: 'cm³', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { name: 'Cubic Feet', symbol: 'ft³', toBase: v => v * 28.316846592, fromBase: v => v / 28.316846592 },
      { name: 'Cubic Inches', symbol: 'in³', toBase: v => v * 0.016387064, fromBase: v => v / 0.016387064 },
      { name: 'US Gallons', symbol: 'gal', toBase: v => v * 3.785411784, fromBase: v => v / 3.785411784 },
      { name: 'US Fluid Ounces', symbol: 'fl oz', toBase: v => v * 0.0295735295625, fromBase: v => v / 0.0295735295625 },
      { name: 'US Pints', symbol: 'pt', toBase: v => v * 0.473176473, fromBase: v => v / 0.473176473 },
      { name: 'US Quarts', symbol: 'qt', toBase: v => v * 0.946352946, fromBase: v => v / 0.946352946 }
    ]
  },
  {
    // Fuel economy is inverse-proportional (consumption per distance):
    // converting goes through L/100km as the base via reciprocal relations.
    name: 'Fuel Economy',
    baseUnit: 'L/100km',
    units: [
      { name: 'Liters per 100 km', symbol: 'L/100km', toBase: v => v, fromBase: v => v },
      { name: 'Miles per US Gallon', symbol: 'mpg', toBase: v => 235.214583 / v, fromBase: v => 235.214583 / v },
      { name: 'Kilometers per Liter', symbol: 'km/L', toBase: v => 100 / v, fromBase: v => 100 / v },
      { name: 'Miles per Imperial Gallon', symbol: 'mpg imp', toBase: v => 282.480936 / v, fromBase: v => 282.480936 / v }
    ]
  }
];

export function convertUnits(
  categoryName: string,
  fromSymbol: string,
  toSymbol: string,
  value: number
): number | null {
  const category = UNIT_CATEGORIES.find(c => c.name.toLowerCase() === categoryName.toLowerCase());
  if (!category) return null;

  const fromUnit = category.units.find(u => u.symbol === fromSymbol);
  const toUnit = category.units.find(u => u.symbol === toSymbol);
  if (!fromUnit || !toUnit) return null;

  const baseVal = fromUnit.toBase(value);
  const converted = toUnit.fromBase(baseVal);
  return parseFloat(converted.toFixed(8));
}
