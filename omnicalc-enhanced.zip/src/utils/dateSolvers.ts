// Comprehensive Date & Time Solvers

// ==========================================
// 1. Date Differences & Date Calculations
// ==========================================

export interface DateDifferenceResult {
  totalDays: number;
  years: number;
  months: number;
  days: number;
  weeks: number;
  remainingDays: number;
  totalHours: number;
  totalMinutes: number;
  totalSeconds: number;
  weekdays: number;
  weekendDays: number;
}

export function calculateDateDifference(dateStartStr: string, dateEndStr: string): DateDifferenceResult {
  const d1 = new Date(dateStartStr + 'T00:00:00');
  const d2 = new Date(dateEndStr + 'T00:00:00');

  const isReversed = d1 > d2;
  const start = isReversed ? d2 : d1;
  const end = isReversed ? d1 : d2;

  const diffMs = Math.abs(end.getTime() - start.getTime());
  const totalDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
  const totalHours = totalDays * 24;
  const totalMinutes = totalHours * 60;
  const totalSeconds = totalMinutes * 60;

  const weeks = Math.floor(totalDays / 7);
  const remainingDays = totalDays % 7;

  // Exact years, months, days
  let y = end.getFullYear() - start.getFullYear();
  let m = end.getMonth() - start.getMonth();
  let d = end.getDate() - start.getDate();

  if (d < 0) {
    m -= 1;
    // Days in previous month
    const prevMonthDays = new Date(end.getFullYear(), end.getMonth(), 0).getDate();
    d += prevMonthDays;
  }
  if (m < 0) {
    y -= 1;
    m += 12;
  }

  // Workdays (Mon-Fri) vs Weekend (Sat-Sun)
  let weekdays = 0;
  let weekendDays = 0;
  const cur = new Date(start);
  while (cur < end) {
    const dayOfWeek = cur.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      weekendDays++;
    } else {
      weekdays++;
    }
    cur.setDate(cur.getDate() + 1);
  }

  return {
    totalDays,
    years: y,
    months: m,
    days: d,
    weeks,
    remainingDays,
    totalHours,
    totalMinutes,
    totalSeconds,
    weekdays,
    weekendDays
  };
}

// ==========================================
// 2. Add / Subtract Dates
// ==========================================

export interface DateArithmeticResult {
  resultDateStr: string;
  dayOfWeek: string;
  formattedDisplay: string;
}

export function calculateDateArithmetic(
  startDateStr: string,
  operation: 'add' | 'subtract',
  years: number = 0,
  months: number = 0,
  weeks: number = 0,
  days: number = 0
): DateArithmeticResult {
  const date = new Date(startDateStr + 'T00:00:00');
  const factor = operation === 'add' ? 1 : -1;

  // Add/sub years & months first
  const newYear = date.getFullYear() + factor * years;
  const newMonth = date.getMonth() + factor * months;
  date.setFullYear(newYear, newMonth, date.getDate());

  // Add/sub days & weeks
  const totalDays = factor * (days + weeks * 7);
  date.setDate(date.getDate() + totalDays);

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const monthsOfYear = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');

  return {
    resultDateStr: `${yyyy}-${mm}-${dd}`,
    dayOfWeek: daysOfWeek[date.getDay()],
    formattedDisplay: `${daysOfWeek[date.getDay()]}, ${monthsOfYear[date.getMonth()]} ${date.getDate()}, ${yyyy}`
  };
}

// ==========================================
// 3. Time Differences & Hours/Minutes/Seconds
// ==========================================

export interface TimeDifferenceResult {
  hours: number;
  minutes: number;
  seconds: number;
  totalHoursDecimal: number;
  totalMinutes: number;
  totalSeconds: number;
  formattedDuration: string;
}

export function calculateTimeDifference(
  timeStart: string, // "HH:MM" or "HH:MM:SS"
  timeEnd: string,   // "HH:MM" or "HH:MM:SS"
  crossesMidnight: boolean = false
): TimeDifferenceResult {
  const parseSeconds = (t: string) => {
    const parts = t.split(':').map(Number);
    const h = parts[0] || 0;
    const m = parts[1] || 0;
    const s = parts[2] || 0;
    return h * 3600 + m * 60 + s;
  };

  const s1 = parseSeconds(timeStart);
  let s2 = parseSeconds(timeEnd);

  if (s2 < s1 || crossesMidnight) {
    s2 += 24 * 3600; // Next day
  }

  const diffSec = Math.max(0, s2 - s1);
  const hours = Math.floor(diffSec / 3600);
  const minutes = Math.floor((diffSec % 3600) / 60);
  const seconds = diffSec % 60;

  const totalHoursDecimal = parseFloat((diffSec / 3600).toFixed(4));
  const totalMinutes = parseFloat((diffSec / 60).toFixed(2));

  return {
    hours,
    minutes,
    seconds,
    totalHoursDecimal,
    totalMinutes,
    totalSeconds: diffSec,
    formattedDuration: `${hours}h ${minutes}m ${seconds}s`
  };
}

export interface TimeUnitConversionResult {
  decimalHours: number;
  totalMinutes: number;
  totalSeconds: number;
  totalMilliseconds: number;
  standardHms: string;
}

export function convertTimeUnits(
  value: number,
  unit: 'hours' | 'minutes' | 'seconds'
): TimeUnitConversionResult {
  let sec = 0;
  if (unit === 'hours') sec = value * 3600;
  else if (unit === 'minutes') sec = value * 60;
  else sec = value;

  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.round(sec % 60);

  return {
    decimalHours: parseFloat((sec / 3600).toFixed(4)),
    totalMinutes: parseFloat((sec / 60).toFixed(3)),
    totalSeconds: parseFloat(sec.toFixed(2)),
    totalMilliseconds: parseFloat((sec * 1000).toFixed(0)),
    standardHms: `${h}h ${m}m ${s}s`
  };
}

// ==========================================
// 4. Age Calculation
// ==========================================

export interface AgeCalculationResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalWeeks: number;
  totalHours: number;
  nextBirthdayDays: number;
  dayOfWeekBorn: string;
  zodiacSign: string;
  nextBirthdayDayOfWeek: string;
}

export function calculateAge(birthDateStr: string, targetDateStr?: string): AgeCalculationResult {
  const birth = new Date(birthDateStr + 'T00:00:00');
  const target = targetDateStr ? new Date(targetDateStr + 'T00:00:00') : new Date();

  // Diff in time
  const diffTime = target.getTime() - birth.getTime();
  const totalDays = Math.max(0, Math.floor(diffTime / (1000 * 60 * 60 * 24)));
  const totalWeeks = Math.floor(totalDays / 7);
  const totalHours = totalDays * 24;

  let years = target.getFullYear() - birth.getFullYear();
  let months = target.getMonth() - birth.getMonth();
  let days = target.getDate() - birth.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonthDays = new Date(target.getFullYear(), target.getMonth(), 0).getDate();
    days += prevMonthDays;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  // Day of week born
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayOfWeekBorn = daysOfWeek[birth.getDay()];

  // Next birthday
  const nextBirthday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
  if (nextBirthday < target) {
    nextBirthday.setFullYear(target.getFullYear() + 1);
  }
  const nextDiff = Math.ceil((nextBirthday.getTime() - target.getTime()) / (1000 * 60 * 60 * 24));
  const nextBirthdayDayOfWeek = daysOfWeek[nextBirthday.getDay()];

  // Zodiac sign
  const m = birth.getMonth() + 1;
  const d = birth.getDate();
  let zodiac = 'Capricorn';
  if ((m === 1 && d >= 20) || (m === 2 && d <= 18)) zodiac = 'Aquarius ♒';
  else if ((m === 2 && d >= 19) || (m === 3 && d <= 20)) zodiac = 'Pisces ♓';
  else if ((m === 3 && d >= 21) || (m === 4 && d <= 19)) zodiac = 'Aries ♈';
  else if ((m === 4 && d >= 20) || (m === 5 && d <= 20)) zodiac = 'Taurus ♉';
  else if ((m === 5 && d >= 21) || (m === 6 && d <= 20)) zodiac = 'Gemini ♊';
  else if ((m === 6 && d >= 21) || (m === 7 && d <= 22)) zodiac = 'Cancer ♋';
  else if ((m === 7 && d >= 23) || (m === 8 && d <= 22)) zodiac = 'Leo ♌';
  else if ((m === 8 && d >= 23) || (m === 9 && d <= 22)) zodiac = 'Virgo ♍';
  else if ((m === 9 && d >= 23) || (m === 10 && d <= 22)) zodiac = 'Libra ♎';
  else if ((m === 10 && d >= 23) || (m === 11 && d <= 21)) zodiac = 'Scorpio ♏';
  else if ((m === 11 && d >= 22) || (m === 12 && d <= 21)) zodiac = 'Sagittarius ♐';
  else zodiac = 'Capricorn ♑';

  return {
    years: Math.max(0, years),
    months: Math.max(0, months),
    days: Math.max(0, days),
    totalDays,
    totalWeeks,
    totalHours,
    nextBirthdayDays: nextDiff === 0 ? 0 : nextDiff,
    dayOfWeekBorn,
    zodiacSign: zodiac,
    nextBirthdayDayOfWeek
  };
}

// ==========================================
// 5. Day-of-Week & Calendar Calculations
// ==========================================

export interface DayOfWeekResult {
  dayName: string;
  dayIndex: number; // 0=Sun, 6=Sat
  isWeekend: boolean;
  dayOfYear: number;
  isoWeekNumber: number;
  daysInMonth: number;
  isLeapYear: boolean;
  julianDayNumber: number;
}

export function calculateDayOfWeekAndCalendar(dateStr: string): DayOfWeekResult {
  const date = new Date(dateStr + 'T00:00:00');
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayIndex = date.getDay();
  const dayName = daysOfWeek[dayIndex];
  const isWeekend = dayIndex === 0 || dayIndex === 6;

  const year = date.getFullYear();
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;

  // Days in month
  const daysInMonth = new Date(year, date.getMonth() + 1, 0).getDate();

  // Day of the year
  const startOfYear = new Date(year, 0, 1);
  const diffDays = Math.floor((date.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  // ISO 8601 Week Number
  const target = new Date(date.valueOf());
  const dayNr = (date.getDay() + 6) % 7;
  target.setDate(target.getDate() - dayNr + 3);
  const firstThursday = target.valueOf();
  target.setMonth(0, 1);
  if (target.getDay() !== 4) {
    target.setMonth(0, 1 + ((4 - target.getDay() + 7) % 7));
  }
  const isoWeekNumber = 1 + Math.ceil((firstThursday - target.valueOf()) / 604800000);

  // Julian Day Number (astronomical calculation)
  const a = Math.floor((14 - (date.getMonth() + 1)) / 12);
  const y = year + 4800 - a;
  const m = date.getMonth() + 1 + 12 * a - 3;
  const jdn =
    date.getDate() +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045;

  return {
    dayName,
    dayIndex,
    isWeekend,
    dayOfYear: diffDays,
    isoWeekNumber,
    daysInMonth,
    isLeapYear,
    julianDayNumber: jdn
  };
}

export function checkLeapYear(year: number): { isLeap: boolean; reason: string; totalDays: number } {
  const isLeap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  let reason = '';
  if (year % 400 === 0) {
    reason = `${year} is divisible by 400, making it a leap year (366 days).`;
  } else if (year % 100 === 0) {
    reason = `${year} is divisible by 100 but not 400, so it is a common year (365 days).`;
  } else if (year % 4 === 0) {
    reason = `${year} is divisible by 4 and not 100, making it a leap year (366 days).`;
  } else {
    reason = `${year} is not divisible by 4, making it a regular common year (365 days).`;
  }
  return {
    isLeap,
    reason,
    totalDays: isLeap ? 366 : 365
  };
}
