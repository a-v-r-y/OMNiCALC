// Prime check
export function isPrime(n: number): boolean {
  if (n <= 1 || !Number.isInteger(n)) return false;
  if (n <= 3) return true;
  if (n % 2 === 0 || n % 3 === 0) return false;
  for (let i = 5; i * i <= n; i += 6) {
    if (n % i === 0 || n % (i + 2) === 0) return false;
  }
  return true;
}

// Prime factorization
export function primeFactorization(n: number): { factor: number; power: number }[] {
  if (n <= 1 || !Number.isInteger(n)) return [];
  const factors: { factor: number; power: number }[] = [];
  let d = 2;
  let temp = n;

  while (d * d <= temp) {
    if (temp % d === 0) {
      let count = 0;
      while (temp % d === 0) {
        count++;
        temp = Math.floor(temp / d);
      }
      factors.push({ factor: d, power: count });
    }
    d = d === 2 ? 3 : d + 2;
  }
  if (temp > 1) {
    factors.push({ factor: temp, power: 1 });
  }
  return factors;
}

export const primeFactors = primeFactorization;

export function formatPrimeFactors(n: number): string {
  const factors = primeFactorization(n);
  if (factors.length === 0) return `${n}`;
  return factors
    .map(f => (f.power > 1 ? `${f.factor}^${f.power}` : `${f.factor}`))
    .join(' × ');
}

// GCD & LCM
export function gcd(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b !== 0) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

export function lcm(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return Math.abs(Math.round((a * b) / gcd(a, b)));
}

export function gcdEuclidean(a: number, b: number): { gcd: number; steps: string[] } {
  let x = Math.abs(Math.round(a));
  let y = Math.abs(Math.round(b));
  const steps: string[] = [];

  while (y !== 0) {
    const q = Math.floor(x / y);
    const r = x % y;
    steps.push(`${x} = ${y} × ${q} + ${r}`);
    x = y;
    y = r;
  }
  return { gcd: x, steps };
}

// Extended Euclidean Algorithm
export function extendedGCD(a: number, b: number): { gcd: number; x: number; y: number } {
  if (b === 0) return { gcd: a, x: 1, y: 0 };
  const res = extendedGCD(b, a % b);
  return {
    gcd: res.gcd,
    x: res.y,
    y: res.x - Math.floor(a / b) * res.y
  };
}

// Modular inverse
export function modInverse(a: number, m: number): number | null {
  const res = extendedGCD(a, m);
  if (res.gcd !== 1) return null;
  return ((res.x % m) + m) % m;
}

// Modular exponentiation (b^e mod m)
export function modPow(base: number, exp: number, mod: number): number {
  if (mod === 1) return 0;
  let res = 1;
  let b = base % mod;
  let e = exp;
  while (e > 0) {
    if (e % 2 === 1) res = (res * b) % mod;
    e = Math.floor(e / 2);
    b = (b * b) % mod;
  }
  return res;
}

// Euler's Totient Function phi(n)
export function eulerTotient(n: number): number {
  if (n <= 0) return 0;
  let result = n;
  let p = 2;
  let temp = n;

  while (p * p <= temp) {
    if (temp % p === 0) {
      while (temp % p === 0) temp = Math.floor(temp / p);
      result -= Math.floor(result / p);
    }
    p = p === 2 ? 3 : p + 2;
  }
  if (temp > 1) {
    result -= Math.floor(result / temp);
  }
  return result;
}

// Divisors of n
export function getDivisors(n: number): number[] {
  if (n <= 0 || !Number.isInteger(n)) return [];
  const divisors: number[] = [];
  for (let i = 1; i * i <= n; i++) {
    if (n % i === 0) {
      divisors.push(i);
      if (i * i !== n) divisors.push(n / i);
    }
  }
  return divisors.sort((a, b) => a - b);
}

export const divisors = getDivisors;

export interface TruthTableRow {
  inputs: Record<string, boolean>;
  output: boolean;
}

// Only these tokens may appear in a boolean expression AFTER variable and
// keyword substitution. Anything else (semicolons, dots, quotes, letters…)
// is rejected before evaluation. `!==` must precede `!` in the alternation
// so it is matched as a unit.
const SAFE_BOOLEAN_PATTERN = /^(?:\s|true|false|!==|&&|\|\||!|\(|\))*$/;

type BoolToken =
  | { kind: 'true' } | { kind: 'false' }
  | { kind: 'and' } | { kind: 'or' } | { kind: 'not' } | { kind: 'neq' }
  | { kind: 'lparen' } | { kind: 'rparen' };

function tokenizeBoolean(code: string): BoolToken[] | null {
  const tokens: BoolToken[] = [];
  let i = 0;
  while (i < code.length) {
    const ch = code[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (code.startsWith('true', i)) { tokens.push({ kind: 'true' }); i += 4; continue; }
    if (code.startsWith('false', i)) { tokens.push({ kind: 'false' }); i += 5; continue; }
    if (code.startsWith('!==', i)) { tokens.push({ kind: 'neq' }); i += 3; continue; }
    if (code.startsWith('&&', i)) { tokens.push({ kind: 'and' }); i += 2; continue; }
    if (code.startsWith('||', i)) { tokens.push({ kind: 'or' }); i += 2; continue; }
    if (ch === '!') { tokens.push({ kind: 'not' }); i++; continue; }
    if (ch === '(') { tokens.push({ kind: 'lparen' }); i++; continue; }
    if (ch === ')') { tokens.push({ kind: 'rparen' }); i++; continue; }
    return null; // unreachable after validation, but stay safe
  }
  return tokens;
}

// Recursive-descent parser mirroring JS operator precedence for these ops:
// !  >  !==  >  &&  >  ||
class BooleanParser {
  private pos = 0;
  constructor(private tokens: BoolToken[]) {}

  parse(): boolean | null {
    const val = this.parseOr();
    return val !== null && this.pos === this.tokens.length ? val : null;
  }

  private peek(): BoolToken | undefined {
    return this.tokens[this.pos];
  }

  private parseOr(): boolean | null {
    let left = this.parseAnd();
    if (left === null) return null;
    while (this.peek()?.kind === 'or') {
      this.pos++;
      const right = this.parseAnd();
      if (right === null) return null;
      left = left || right;
    }
    return left;
  }

  private parseAnd(): boolean | null {
    let left = this.parseNeq();
    if (left === null) return null;
    while (this.peek()?.kind === 'and') {
      this.pos++;
      const right = this.parseNeq();
      if (right === null) return null;
      left = left && right;
    }
    return left;
  }

  private parseNeq(): boolean | null {
    let left = this.parseUnary();
    if (left === null) return null;
    while (this.peek()?.kind === 'neq') {
      this.pos++;
      const right = this.parseUnary();
      if (right === null) return null;
      left = left !== right;
    }
    return left;
  }

  private parseUnary(): boolean | null {
    if (this.peek()?.kind === 'not') {
      this.pos++;
      const val = this.parseUnary();
      return val === null ? null : !val;
    }
    return this.parsePrimary();
  }

  private parsePrimary(): boolean | null {
    const tok = this.peek();
    if (!tok) return null;
    if (tok.kind === 'true') { this.pos++; return true; }
    if (tok.kind === 'false') { this.pos++; return false; }
    if (tok.kind === 'lparen') {
      this.pos++;
      const val = this.parseOr();
      if (val === null || this.peek()?.kind !== 'rparen') return null;
      this.pos++;
      return val;
    }
    return null;
  }
}

/**
 * Safely evaluate a substituted boolean expression.
 * Returns null when the expression is invalid — never evaluates arbitrary code.
 */
export function evaluateBooleanExpression(code: string): boolean | null {
  if (!SAFE_BOOLEAN_PATTERN.test(code)) return null;
  const tokens = tokenizeBoolean(code);
  if (!tokens) return null;
  try {
    return new BooleanParser(tokens).parse();
  } catch {
    return null;
  }
}

// Truth Table Generator
// Returns [] when the expression is syntactically invalid or unsafe —
// callers render nothing in that case (never evaluates arbitrary code).
export function generateTruthTable(expr: string, vars: string[] = ['A', 'B', 'C']): TruthTableRow[] {
  // Extract variable tokens if possible or default to A, B, C
  const foundVars = Array.from(new Set(expr.match(/\b[A-Za-z]\b/g) || vars));
  const activeVars = foundVars.length > 0 ? foundVars.slice(0, 4) : ['A', 'B'];

  const substitute = (template: string, inputs: Record<string, boolean>): string => {
    let evalCode = template;
    for (const v of activeVars) {
      const regex = new RegExp(`\\b${v}\\b`, 'g');
      evalCode = evalCode.replace(regex, inputs[v] ? 'true' : 'false');
    }
    return evalCode
      .replace(/\band\b/gi, '&&')
      .replace(/\bor\b/gi, '||')
      .replace(/\bnot\b/gi, '!')
      .replace(/\bxor\b/gi, '!==');
  };

  // Validate once with a dummy assignment: if the expression shape is
  // invalid/unsafe, bail out before generating any rows.
  const dummyInputs: Record<string, boolean> = {};
  for (const v of activeVars) dummyInputs[v] = false;
  if (evaluateBooleanExpression(substitute(expr, dummyInputs)) === null) {
    return [];
  }

  const numVars = activeVars.length;
  const numRows = 1 << numVars;
  const rows: TruthTableRow[] = [];

  for (let i = 0; i < numRows; i++) {
    const inputs: Record<string, boolean> = {};
    for (let j = 0; j < numVars; j++) {
      inputs[activeVars[j]] = Boolean((i >> (numVars - 1 - j)) & 1);
    }

    // Safe evaluation: strict whitelist validation + hand-written parser.
    const result = evaluateBooleanExpression(substitute(expr, inputs));
    rows.push({ inputs, output: result === true });
  }

  return rows;
}
