import { describe, it, expect } from 'vitest';
import { evaluateExpression, getMathInstance } from '../mathEngine';

describe('trig overrides — plain numbers', () => {
  it('sin(30) in deg mode is 0.5', () => {
    const r = evaluateExpression('sin(30)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });

  it('sin(pi/2) in rad mode is 1', () => {
    const r = evaluateExpression('sin(pi/2)', {}, 'rad');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(1, 10);
  });

  it('sin(100) in grad mode is 1', () => {
    const r = evaluateExpression('sin(100)', {}, 'grad');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(1, 10);
  });

  it('cos(60) in deg mode is 0.5', () => {
    const r = evaluateExpression('cos(60)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });

  it('tan(45) in deg mode is 1', () => {
    const r = evaluateExpression('tan(45)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(1, 10);
  });

  it('asin(0.5) in deg mode is 30', () => {
    const r = evaluateExpression('asin(0.5)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(30, 10);
  });

  it('acos(0.5) in rad mode is pi/3', () => {
    const r = evaluateExpression('acos(0.5)', {}, 'rad');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(Math.PI / 3, 10);
  });
});

describe('C2 regression — trig with unit inputs must not recurse', () => {
  it('sin(30 deg) works in deg mode', () => {
    const r = evaluateExpression('sin(30 deg)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });

  it('sin(30 deg) works in rad mode (explicit unit wins)', () => {
    const r = evaluateExpression('sin(30 deg)', {}, 'rad');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });

  it('cos(60 deg) is 0.5', () => {
    const r = evaluateExpression('cos(60 deg)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });

  it('tan(45 deg) is 1', () => {
    const r = evaluateExpression('tan(45 deg)', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(1, 10);
  });

  it('completes quickly (no stack overflow / hang)', () => {
    const start = Date.now();
    const r = evaluateExpression('sin(30 deg) + cos(60 deg)', {}, 'deg');
    expect(Date.now() - start).toBeLessThan(2000);
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(1, 10);
  });
});

describe('BigNumber precision path', () => {
  it('sin(30) in deg mode at precision 32', () => {
    const r = evaluateExpression('sin(30)', {}, 'deg', 32);
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(0.5, 10);
  });
});

describe('nested roots (I8)', () => {
  it('sqrt(sqrt(16)) is 2', () => {
    const r = evaluateExpression('√(√(16))', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(2, 10);
  });

  it('triple-nested roots work', () => {
    const r = evaluateExpression('√(√(√(256)))', {}, 'deg');
    expect(r.success).toBe(true);
    expect(r.numericValue).toBeCloseTo(2, 10);
  });
});

describe('getMathInstance does not leak overrides between calls', () => {
  it('two instances behave independently', () => {
    const deg = getMathInstance('deg');
    const rad = getMathInstance('rad');
    expect((deg.evaluate('sin(30)') as number)).toBeCloseTo(0.5, 10);
    expect((rad.evaluate('sin(30)') as number)).toBeCloseTo(Math.sin(30), 10);
  });
});
