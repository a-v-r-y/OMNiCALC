import { describe, it, expect } from 'vitest';
import { convertUnits, UNIT_CATEGORIES } from '../unitConverterData';

describe('new categories are registered', () => {
  it('Area, Volume, Fuel Economy exist', () => {
    const names = UNIT_CATEGORIES.map(c => c.name);
    expect(names).toContain('Area');
    expect(names).toContain('Volume');
    expect(names).toContain('Fuel Economy');
  });
});

describe('Area — hand-computed', () => {
  it('1 acre = 4046.8564224 m²', () => {
    expect(convertUnits('Area', 'ac', 'm²', 1)).toBeCloseTo(4046.8564224, 4);
  });

  it('1 mi² = 640 acres', () => {
    expect(convertUnits('Area', 'mi²', 'ac', 1)).toBeCloseTo(640, 4);
  });

  it('1 ha = 10000 m²', () => {
    expect(convertUnits('Area', 'ha', 'm²', 1)).toBe(10000);
  });

  it('round-trips', () => {
    const there = convertUnits('Area', 'ft²', 'm²', 1500)!;
    expect(convertUnits('Area', 'm²', 'ft²', there)).toBeCloseTo(1500, 4);
  });
});

describe('Volume — hand-computed', () => {
  it('1 US gallon = 3.785411784 L', () => {
    expect(convertUnits('Volume', 'gal', 'L', 1)).toBeCloseTo(3.785411784, 6);
  });

  it('1 m³ = 1000 L', () => {
    expect(convertUnits('Volume', 'm³', 'L', 1)).toBe(1000);
  });

  it('1 ft³ = 7.48052 US gallons', () => {
    expect(convertUnits('Volume', 'ft³', 'gal', 1)).toBeCloseTo(7.48052, 4);
  });
});

describe('Fuel Economy — inverse-proportional', () => {
  it('30 mpg = 7.8404861 L/100km', () => {
    // 235.214583 / 30
    expect(convertUnits('Fuel Economy', 'mpg', 'L/100km', 30)).toBeCloseTo(7.8404861, 4);
  });

  it('better mpg means lower L/100km (inverse relationship)', () => {
    const low = convertUnits('Fuel Economy', 'mpg', 'L/100km', 20)!;
    const high = convertUnits('Fuel Economy', 'mpg', 'L/100km', 40)!;
    expect(low).toBeGreaterThan(high);
  });

  it('round-trips through the base unit', () => {
    const l100 = convertUnits('Fuel Economy', 'mpg', 'L/100km', 25)!;
    expect(convertUnits('Fuel Economy', 'L/100km', 'mpg', l100)).toBeCloseTo(25, 4);
  });

  it('km/L converts consistently', () => {
    // 20 km/L = 5 L/100km
    expect(convertUnits('Fuel Economy', 'km/L', 'L/100km', 20)).toBeCloseTo(5, 6);
  });
});
