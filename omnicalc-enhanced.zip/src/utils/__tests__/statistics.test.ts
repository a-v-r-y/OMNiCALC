import { describe, it, expect } from 'vitest';
import { binomialPMF } from '../statisticsEngine';

describe('binomialPMF — standard cases', () => {
  it('Bin(10, 5, 0.5) = 0.24609375', () => {
    // C(10,5) * 0.5^10 = 252 / 1024
    expect(binomialPMF(10, 5, 0.5)).toBeCloseTo(0.24609375, 10);
  });

  it('Bin(5, 0, 0.3) = 0.7^5', () => {
    expect(binomialPMF(5, 0, 0.3)).toBeCloseTo(Math.pow(0.7, 5), 10);
  });

  it('probabilities sum to ~1', () => {
    let total = 0;
    for (let k = 0; k <= 20; k++) total += binomialPMF(20, k, 0.35);
    expect(total).toBeCloseTo(1, 8);
  });
});

describe('binomialPMF — degenerate edges (I6)', () => {
  it('p=0, k=0 → 1 (was NaN)', () => {
    expect(binomialPMF(10, 0, 0)).toBe(1);
  });

  it('p=0, k>0 → 0', () => {
    expect(binomialPMF(10, 3, 0)).toBe(0);
  });

  it('p=1, k=n → 1 (was NaN)', () => {
    expect(binomialPMF(10, 10, 1)).toBe(1);
  });

  it('p=1, k<n → 0', () => {
    expect(binomialPMF(10, 7, 1)).toBe(0);
  });

  it('p outside [0,1] → NaN', () => {
    expect(binomialPMF(10, 5, 1.5)).toBeNaN();
    expect(binomialPMF(10, 5, -0.2)).toBeNaN();
  });

  it('k out of range → 0', () => {
    expect(binomialPMF(10, 11, 0.5)).toBe(0);
    expect(binomialPMF(10, -1, 0.5)).toBe(0);
  });
});
