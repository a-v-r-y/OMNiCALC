import { describe, it, expect } from 'vitest';
import { generateTruthTable, evaluateBooleanExpression } from '../discreteAndNumberTheory';

describe('C1 — safe boolean parser: valid expressions', () => {
  it('evaluates AND correctly', () => {
    expect(evaluateBooleanExpression('true && false')).toBe(false);
    expect(evaluateBooleanExpression('true && true')).toBe(true);
  });

  it('evaluates OR correctly', () => {
    expect(evaluateBooleanExpression('false || true')).toBe(true);
    expect(evaluateBooleanExpression('false || false')).toBe(false);
  });

  it('evaluates NOT correctly', () => {
    expect(evaluateBooleanExpression('!false')).toBe(true);
    expect(evaluateBooleanExpression('!!true')).toBe(true);
  });

  it('evaluates !== (xor) correctly', () => {
    expect(evaluateBooleanExpression('true !== false')).toBe(true);
    expect(evaluateBooleanExpression('true !== true')).toBe(false);
  });

  it('respects precedence: ! > !== > && > ||', () => {
    // || lowest: true || (false && false) = true
    expect(evaluateBooleanExpression('true || false && false')).toBe(true);
    // && binds tighter than ||: (true && false) || true = true
    expect(evaluateBooleanExpression('true && false || true')).toBe(true);
    // !== binds tighter than &&: (true !== true) && true = false
    expect(evaluateBooleanExpression('true !== true && true')).toBe(false);
    // ! binds tightest: (!true) !== false → false !== false → false
    expect(evaluateBooleanExpression('!true !== false')).toBe(false);
  });

  it('handles parentheses', () => {
    expect(evaluateBooleanExpression('(true || false) && !false')).toBe(true);
    expect(evaluateBooleanExpression('!(true && true)')).toBe(false);
  });

  it('handles whitespace variants', () => {
    expect(evaluateBooleanExpression('  true\t&&\nfalse ')).toBe(false);
  });
});

describe('C1 — safe boolean parser: malicious input is rejected, never executed', () => {
  const attacks = [
    'true; alert(1)',
    'true.constructor',
    'fetch("http://evil.com")',
    '(()=>{})()',
    'true`',
    '${process.env}',
    'true + 1',
    'true == true',
    'true != false', // != (without third =) is not in the whitelist
    'a ? b : c',
  ];

  for (const attack of attacks) {
    it(`rejects ${JSON.stringify(attack)}`, () => {
      // The sentinel: if code executed, this would throw or have side effects.
      // We assert the parser returns null (rejected).
      expect(evaluateBooleanExpression(attack)).toBeNull();
    });
  }

  it('does not execute code smuggled through variable positions', () => {
    // generateTruthTable only treats single letters as variables;
    // everything else must fail validation → empty table, no execution.
    const rows = generateTruthTable('A; alert(document.domain)');
    expect(rows).toEqual([]);
  });

  it('never touches the Function constructor', () => {
    const seen: string[] = [];
    const origFunction = globalThis.Function;
    // If any code path calls Function(), record it
    (globalThis as any).Function = new Proxy(origFunction, {
      construct(t, args) {
        seen.push(String(args[0]).slice(0, 40));
        return Reflect.construct(t, args);
      },
      apply(t, thisArg, args) {
        seen.push(String(args[0]).slice(0, 40));
        return Reflect.apply(t, thisArg, args as any);
      },
    });
    try {
      generateTruthTable('A and B or not C');
      evaluateBooleanExpression('true && (false || true)');
      generateTruthTable('A; alert(1)');
    } finally {
      (globalThis as any).Function = origFunction;
    }
    expect(seen).toEqual([]);
  });
});

describe('generateTruthTable — correctness', () => {
  it('A and B has 4 rows with the right outputs', () => {
    const rows = generateTruthTable('A and B');
    expect(rows).toHaveLength(4);
    const outputs = rows.map(r => r.output);
    expect(outputs).toEqual([false, false, false, true]);
  });

  it('A xor B matches !== semantics', () => {
    const rows = generateTruthTable('A xor B');
    expect(rows.map(r => r.output)).toEqual([false, true, true, false]);
  });

  it('not A or B', () => {
    const rows = generateTruthTable('not A or B');
    // !A || B : rows are (F,F),(F,T),(T,F),(T,T)
    expect(rows.map(r => r.output)).toEqual([true, true, false, true]);
  });

  it('returns [] for garbage input', () => {
    expect(generateTruthTable('hello world')).toEqual([]);
    expect(generateTruthTable('')).toEqual([]);
    expect(generateTruthTable('A &&& B')).toEqual([]);
  });
});
