import { describe, it, expect } from 'vitest';
import {
  calculateNPV,
  calculateIRR,
  calculateXIRR,
  calculateAmortizationSchedule,
} from '../financialSolvers';

describe('NPV — hand-computed', () => {
  it('NPV(10%, [-10000, 3000, 4200, 6800]) = 1307.29', () => {
    // -10000 + 3000/1.1 + 4200/1.21 + 6800/1.331
    // = -10000 + 2727.2727 + 3471.0744 + 5108.9414 = 1307.2885
    expect(calculateNPV(10, [-10000, 3000, 4200, 6800])).toBeCloseTo(1307.29, 2);
  });

  it('NPV at 0% is the plain sum', () => {
    expect(calculateNPV(0, [-100, 40, 40, 40])).toBe(20);
  });

  it('NPV is negative when the rate exceeds the return', () => {
    expect(calculateNPV(50, [-10000, 3000, 4200, 6800])).toBeLessThan(0);
  });

  it('empty / invalid input → NaN', () => {
    expect(calculateNPV(10, [])).toBeNaN();
  });
});

describe('IRR — Newton-Raphson with bisection fallback', () => {
  it('IRR([-100, 110]) is exactly 10%', () => {
    const r = calculateIRR([-100, 110]);
    expect(r.converged).toBe(true);
    expect(r.irrPct).toBeCloseTo(10, 6);
  });

  it('IRR zeroes the NPV', () => {
    const flows = [-10000, 3000, 4200, 6800];
    const r = calculateIRR(flows);
    expect(r.converged).toBe(true);
    expect(r.irrPct).not.toBeNull();
    // Cross-check: NPV at the found IRR must be ~0
    expect(Math.abs(calculateNPV(r.irrPct!, flows))).toBeLessThan(0.05);
    // Sanity range for this cash-flow shape
    expect(r.irrPct!).toBeGreaterThan(15);
    expect(r.irrPct!).toBeLessThan(18);
  });

  it('all-positive cash flows → no solution, not a crash', () => {
    const r = calculateIRR([100, 200, 300]);
    expect(r.converged).toBe(false);
    expect(r.irrPct).toBeNull();
    expect(r.message).toMatch(/positive and one negative/i);
  });

  it('single cash flow → no solution', () => {
    const r = calculateIRR([-100]);
    expect(r.converged).toBe(false);
    expect(r.irrPct).toBeNull();
  });
});

describe('XIRR — irregular dates (actual/365)', () => {
  it('10000 → 11000 over a non-leap year ≈ 10%', () => {
    const r = calculateXIRR([
      { date: '2023-01-01', amount: -10000 },
      { date: '2024-01-01', amount: 11000 },
    ]);
    expect(r.converged).toBe(true);
    expect(r.irrPct).toBeCloseTo(10, 2);
  });

  it('handles irregular spacing', () => {
    const r = calculateXIRR([
      { date: '2024-01-01', amount: -10000 },
      { date: '2024-07-01', amount: 2500 },
      { date: '2025-01-01', amount: 4000 },
      { date: '2025-07-01', amount: 5000 },
    ]);
    expect(r.converged).toBe(true);
    expect(r.irrPct).not.toBeNull();
    expect(r.irrPct!).toBeGreaterThan(0);
  });

  it('invalid dates → graceful failure', () => {
    const r = calculateXIRR([
      { date: 'not-a-date', amount: -100 },
      { date: '2024-01-01', amount: 110 },
    ]);
    expect(r.converged).toBe(false);
    expect(r.irrPct).toBeNull();
  });
});

describe('EMI / amortization — hand-computed', () => {
  it('EMI for P=100000, 12% annual, 12 months', () => {
    // EMI = P·r·(1+r)^n / ((1+r)^n − 1), r = 0.01, n = 12 → 8884.8789…
    const s = calculateAmortizationSchedule(100000, 12, 12);
    expect(s.monthlyEMI).toBeCloseTo(8884.88, 2);
  });

  it('schedule principal sums back to the loan amount', () => {
    const s = calculateAmortizationSchedule(100000, 12, 12);
    const principalSum = s.schedule.reduce((a, r) => a + r.principalPaid, 0);
    expect(principalSum).toBeCloseTo(100000, 0);
    expect(s.schedule).toHaveLength(12);
  });

  it('total interest = total payments − principal', () => {
    const s = calculateAmortizationSchedule(100000, 12, 12);
    expect(s.totalPayment - 100000).toBeCloseTo(s.totalInterest, 0);
  });
});
