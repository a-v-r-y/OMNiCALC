// Comprehensive Geometry Solvers: 2D, 3D, Coordinate, Intersections & Spherical Geometry

// ==========================================
// 1. 2D Shapes (Areas & Perimeters)
// ==========================================

export interface CircleMetrics {
  radius: number;
  diameter: number;
  circumference: number;
  area: number;
  sectorArea: number;
  arcLength: number;
}

export function calculateCircle(radius: number, sectorAngleDeg: number = 360): CircleMetrics {
  const r = Math.max(0, radius);
  const thetaRad = (sectorAngleDeg * Math.PI) / 180;
  const diameter = 2 * r;
  const circumference = 2 * Math.PI * r;
  const area = Math.PI * r * r;
  const sectorArea = 0.5 * r * r * thetaRad;
  const arcLength = r * thetaRad;

  return {
    radius: r,
    diameter: parseFloat(diameter.toFixed(4)),
    circumference: parseFloat(circumference.toFixed(4)),
    area: parseFloat(area.toFixed(4)),
    sectorArea: parseFloat(sectorArea.toFixed(4)),
    arcLength: parseFloat(arcLength.toFixed(4))
  };
}

export interface TriangleMetrics {
  a: number;
  b: number;
  c: number;
  perimeter: number;
  area: number;
  inradius: number;
  circumradius: number;
  angleA: number;
  angleB: number;
  angleC: number;
  type: string;
}

export function calculateTriangle(a: number, b: number, c: number): TriangleMetrics | null {
  if (a <= 0 || b <= 0 || c <= 0) return null;
  if (a + b <= c || a + c <= b || b + c <= a) return null; // Triangle inequality

  const perimeter = a + b + c;
  const s = perimeter / 2;
  const area = Math.sqrt(Math.max(0, s * (s - a) * (s - b) * (s - c)));
  const inradius = s > 0 ? area / s : 0;
  const circumradius = area > 0 ? (a * b * c) / (4 * area) : 0;

  // Angles via law of cosines
  const radToDeg = 180 / Math.PI;
  const cosA = (b * b + c * c - a * a) / (2 * b * c);
  const cosB = (a * a + c * c - b * b) / (2 * a * c);
  const cosC = (a * a + b * b - c * c) / (2 * a * b);

  const angleA = Math.acos(Math.max(-1, Math.min(1, cosA))) * radToDeg;
  const angleB = Math.acos(Math.max(-1, Math.min(1, cosB))) * radToDeg;
  const angleC = Math.acos(Math.max(-1, Math.min(1, cosC))) * radToDeg;

  let type = 'Scalene';
  if (Math.abs(a - b) < 1e-5 && Math.abs(b - c) < 1e-5) {
    type = 'Equilateral';
  } else if (
    Math.abs(a - b) < 1e-5 ||
    Math.abs(a - c) < 1e-5 ||
    Math.abs(b - c) < 1e-5
  ) {
    type = 'Isosceles';
  }
  if (
    Math.abs(angleA - 90) < 0.05 ||
    Math.abs(angleB - 90) < 0.05 ||
    Math.abs(angleC - 90) < 0.05
  ) {
    type += ' Right';
  }

  return {
    a,
    b,
    c,
    perimeter: parseFloat(perimeter.toFixed(4)),
    area: parseFloat(area.toFixed(4)),
    inradius: parseFloat(inradius.toFixed(4)),
    circumradius: parseFloat(circumradius.toFixed(4)),
    angleA: parseFloat(angleA.toFixed(2)),
    angleB: parseFloat(angleB.toFixed(2)),
    angleC: parseFloat(angleC.toFixed(2)),
    type
  };
}

export interface RegularPolygonMetrics {
  sides: number;
  sideLength: number;
  perimeter: number;
  area: number;
  apothem: number;
  interiorAngle: number;
  exteriorAngle: number;
}

export function calculateRegularPolygon(n: number, side: number): RegularPolygonMetrics {
  const sides = Math.max(3, Math.round(n));
  const s = Math.max(0, side);
  const perimeter = sides * s;
  const apothem = s / (2 * Math.tan(Math.PI / sides));
  const area = 0.5 * perimeter * apothem;
  const interiorAngle = ((sides - 2) * 180) / sides;
  const exteriorAngle = 360 / sides;

  return {
    sides,
    sideLength: s,
    perimeter: parseFloat(perimeter.toFixed(4)),
    area: parseFloat(area.toFixed(4)),
    apothem: parseFloat(apothem.toFixed(4)),
    interiorAngle: parseFloat(interiorAngle.toFixed(2)),
    exteriorAngle: parseFloat(exteriorAngle.toFixed(2))
  };
}

export function calculateTrapezoid(
  base1: number,
  base2: number,
  height: number
): { area: number; median: number } {
  const area = 0.5 * (base1 + base2) * height;
  const median = 0.5 * (base1 + base2);
  return {
    area: parseFloat(area.toFixed(4)),
    median: parseFloat(median.toFixed(4))
  };
}

export function calculateEllipse(
  a: number,
  b: number
): { area: number; perimeterApprox: number; eccentricity: number } {
  const semiMajor = Math.max(a, b);
  const semiMinor = Math.min(a, b);
  const area = Math.PI * semiMajor * semiMinor;

  // Ramanujan approximation for perimeter of ellipse
  const h = Math.pow(semiMajor - semiMinor, 2) / Math.pow(semiMajor + semiMinor, 2);
  const perimeter = Math.PI * (semiMajor + semiMinor) * (1 + (3 * h) / (10 + Math.sqrt(4 - 3 * h)));
  const eccentricity = semiMajor > 0 ? Math.sqrt(1 - (semiMinor * semiMinor) / (semiMajor * semiMajor)) : 0;

  return {
    area: parseFloat(area.toFixed(4)),
    perimeterApprox: parseFloat(perimeter.toFixed(4)),
    eccentricity: parseFloat(eccentricity.toFixed(4))
  };
}

// ==========================================
// 2. 3D Solids (Volumes & Surface Areas)
// ==========================================

export function calculateSphere(radius: number): {
  volume: number;
  surfaceArea: number;
  hemisphereVolume: number;
} {
  const r = Math.max(0, radius);
  const volume = (4 / 3) * Math.PI * Math.pow(r, 3);
  const surfaceArea = 4 * Math.PI * Math.pow(r, 2);
  return {
    volume: parseFloat(volume.toFixed(4)),
    surfaceArea: parseFloat(surfaceArea.toFixed(4)),
    hemisphereVolume: parseFloat((volume / 2).toFixed(4))
  };
}

export function calculateCylinder(radius: number, height: number): {
  volume: number;
  lateralArea: number;
  totalSurfaceArea: number;
} {
  const r = Math.max(0, radius);
  const h = Math.max(0, height);
  const volume = Math.PI * r * r * h;
  const lateralArea = 2 * Math.PI * r * h;
  const totalSurfaceArea = 2 * Math.PI * r * (r + h);

  return {
    volume: parseFloat(volume.toFixed(4)),
    lateralArea: parseFloat(lateralArea.toFixed(4)),
    totalSurfaceArea: parseFloat(totalSurfaceArea.toFixed(4))
  };
}

export function calculateCone(radius: number, height: number): {
  volume: number;
  slantHeight: number;
  lateralArea: number;
  totalSurfaceArea: number;
} {
  const r = Math.max(0, radius);
  const h = Math.max(0, height);
  const slantHeight = Math.sqrt(r * r + h * h);
  const volume = (1 / 3) * Math.PI * r * r * h;
  const lateralArea = Math.PI * r * slantHeight;
  const totalSurfaceArea = Math.PI * r * (r + slantHeight);

  return {
    volume: parseFloat(volume.toFixed(4)),
    slantHeight: parseFloat(slantHeight.toFixed(4)),
    lateralArea: parseFloat(lateralArea.toFixed(4)),
    totalSurfaceArea: parseFloat(totalSurfaceArea.toFixed(4))
  };
}

export function calculateCuboid(l: number, w: number, h: number): {
  volume: number;
  surfaceArea: number;
  spaceDiagonal: number;
} {
  const volume = l * w * h;
  const surfaceArea = 2 * (l * w + l * h + w * h);
  const spaceDiagonal = Math.sqrt(l * l + w * w + h * h);

  return {
    volume: parseFloat(volume.toFixed(4)),
    surfaceArea: parseFloat(surfaceArea.toFixed(4)),
    spaceDiagonal: parseFloat(spaceDiagonal.toFixed(4))
  };
}

export function calculateTorus(majorR: number, minorR: number): {
  volume: number;
  surfaceArea: number;
} {
  const R = Math.max(0, majorR);
  const r = Math.max(0, minorR);
  const volume = 2 * Math.PI * Math.PI * R * r * r;
  const surfaceArea = 4 * Math.PI * Math.PI * R * r;

  return {
    volume: parseFloat(volume.toFixed(4)),
    surfaceArea: parseFloat(surfaceArea.toFixed(4))
  };
}

// ==========================================
// 3. Coordinate Geometry (2D & 3D)
// ==========================================

export interface Coord2DMetrics {
  distance: number;
  midpoint: { x: number; y: number };
  slope: number | null; // null if vertical
  angleDeg: number;
  equation: string; // y = mx + b
  perpendicularSlope: number | null;
}

export function calculate2DCoordinates(
  x1: number,
  y1: number,
  x2: number,
  y2: number
): Coord2DMetrics {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const distance = Math.sqrt(dx * dx + dy * dy);
  const midpoint = {
    x: parseFloat(((x1 + x2) / 2).toFixed(4)),
    y: parseFloat(((y1 + y2) / 2).toFixed(4))
  };

  if (Math.abs(dx) < 1e-10) {
    return {
      distance: parseFloat(distance.toFixed(4)),
      midpoint,
      slope: null,
      angleDeg: 90,
      equation: `x = ${x1}`,
      perpendicularSlope: 0
    };
  }

  const slope = dy / dx;
  const intercept = y1 - slope * x1;
  const angleDeg = (Math.atan2(dy, dx) * 180) / Math.PI;
  const perpSlope = Math.abs(slope) > 1e-10 ? -1 / slope : null;

  const sign = intercept >= 0 ? '+' : '-';
  const eq = `y = ${slope.toFixed(4)}x ${sign} ${Math.abs(intercept).toFixed(4)}`;

  return {
    distance: parseFloat(distance.toFixed(4)),
    midpoint,
    slope: parseFloat(slope.toFixed(4)),
    angleDeg: parseFloat(angleDeg.toFixed(2)),
    equation: eq,
    perpendicularSlope: perpSlope !== null ? parseFloat(perpSlope.toFixed(4)) : null
  };
}

export interface Coord3DMetrics {
  distance: number;
  midpoint: { x: number; y: number; z: number };
  vector: { x: number; y: number; z: number };
  unitVector: { x: number; y: number; z: number };
}

export function calculate3DCoordinates(
  x1: number,
  y1: number,
  z1: number,
  x2: number,
  y2: number,
  z2: number
): Coord3DMetrics {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dz = z2 - z1;
  const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

  const midpoint = {
    x: parseFloat(((x1 + x2) / 2).toFixed(4)),
    y: parseFloat(((y1 + y2) / 2).toFixed(4)),
    z: parseFloat(((z1 + z2) / 2).toFixed(4))
  };

  const unitVector = dist > 0
    ? {
        x: parseFloat((dx / dist).toFixed(4)),
        y: parseFloat((dy / dist).toFixed(4)),
        z: parseFloat((dz / dist).toFixed(4))
      }
    : { x: 0, y: 0, z: 0 };

  return {
    distance: parseFloat(dist.toFixed(4)),
    midpoint,
    vector: { x: dx, y: dy, z: dz },
    unitVector
  };
}

// Distance from 3D point (x0, y0, z0) to plane Ax + By + Cz + D = 0
export function pointToPlaneDistance(
  x0: number,
  y0: number,
  z0: number,
  A: number,
  B: number,
  C: number,
  D: number
): { distance: number; projection: { x: number; y: number; z: number } } {
  const denom = Math.sqrt(A * A + B * B + C * C);
  if (denom === 0) return { distance: 0, projection: { x: x0, y: y0, z: z0 } };

  const dist = Math.abs(A * x0 + B * y0 + C * z0 + D) / denom;
  const k = -(A * x0 + B * y0 + C * z0 + D) / (A * A + B * B + C * C);

  return {
    distance: parseFloat(dist.toFixed(4)),
    projection: {
      x: parseFloat((x0 + k * A).toFixed(4)),
      y: parseFloat((y0 + k * B).toFixed(4)),
      z: parseFloat((z0 + k * C).toFixed(4))
    }
  };
}

// ==========================================
// 4. Lines & Planes Intersections
// ==========================================

export function calculateLineIntersection2D(
  A1: number,
  B1: number,
  C1: number, // A1*x + B1*y = C1
  A2: number,
  B2: number,
  C2: number  // A2*x + B2*y = C2
): {
  status: 'intersecting' | 'parallel' | 'coincident';
  point: { x: number; y: number } | null;
  angleBetweenDeg: number;
} {
  const det = A1 * B2 - A2 * B1;

  if (Math.abs(det) < 1e-10) {
    const isCoincident = Math.abs(A1 * C2 - A2 * C1) < 1e-10 && Math.abs(B1 * C2 - B2 * C1) < 1e-10;
    return {
      status: isCoincident ? 'coincident' : 'parallel',
      point: null,
      angleBetweenDeg: 0
    };
  }

  const x = (C1 * B2 - C2 * B1) / det;
  const y = (A1 * C2 - A2 * C1) / det;

  // Angle between normal vectors
  const dot = A1 * A2 + B1 * B2;
  const mag1 = Math.sqrt(A1 * A1 + B1 * B1);
  const mag2 = Math.sqrt(A2 * A2 + B2 * B2);
  const cosTheta = Math.abs(dot) / (mag1 * mag2);
  const angleDeg = (Math.acos(Math.max(-1, Math.min(1, cosTheta))) * 180) / Math.PI;

  return {
    status: 'intersecting',
    point: { x: parseFloat(x.toFixed(4)), y: parseFloat(y.toFixed(4)) },
    angleBetweenDeg: parseFloat(angleDeg.toFixed(2))
  };
}

// ==========================================
// 5. Spherical Geometry (Haversine & Excess)
// ==========================================

export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  radiusKm: number = 6371 // Earth mean radius km
): {
  distanceKm: number;
  distanceMiles: number;
  initialBearingDeg: number;
} {
  const toRad = Math.PI / 180;
  const dLat = (lat2 - lat1) * toRad;
  const dLon = (lon2 - lon1) * toRad;

  const phi1 = lat1 * toRad;
  const phi2 = lat2 * toRad;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = radiusKm * c;
  const distanceMiles = distanceKm * 0.621371;

  // Initial bearing
  const y = Math.sin(dLon) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLon);
  let bearingDeg = (Math.atan2(y, x) * 180) / Math.PI;
  bearingDeg = (bearingDeg + 360) % 360;

  return {
    distanceKm: parseFloat(distanceKm.toFixed(2)),
    distanceMiles: parseFloat(distanceMiles.toFixed(2)),
    initialBearingDeg: parseFloat(bearingDeg.toFixed(1))
  };
}

// Spherical Triangle Area via Girard's theorem
export function calculateSphericalTriangle(
  alphaDeg: number,
  betaDeg: number,
  gammaDeg: number,
  radius: number = 6371
): { excessRad: number; area: number } {
  const toRad = Math.PI / 180;
  const sumRad = (alphaDeg + betaDeg + gammaDeg) * toRad;
  const excessRad = Math.max(0, sumRad - Math.PI);
  const area = excessRad * radius * radius;

  return {
    excessRad: parseFloat(excessRad.toFixed(4)),
    area: parseFloat(area.toFixed(2))
  };
}
