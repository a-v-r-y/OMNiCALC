// Comprehensive Electronics & Circuit Analysis Solvers

// ==========================================
// 1. Ohm's Law & DC / AC Power
// ==========================================

export interface OhmsLawResult {
  V: number;
  I: number;
  R: number;
  P: number;
}

export function solveOhmsLaw(knowns: {
  V?: number;
  I?: number;
  R?: number;
  P?: number;
}): OhmsLawResult | null {
  let { V, I, R, P } = knowns;

  // Case 1: V and I
  if (V !== undefined && I !== undefined && I !== 0) {
    R = V / I;
    P = V * I;
  }
  // Case 2: V and R
  else if (V !== undefined && R !== undefined && R !== 0) {
    I = V / R;
    P = (V * V) / R;
  }
  // Case 3: V and P
  else if (V !== undefined && P !== undefined && V !== 0) {
    I = P / V;
    R = (V * V) / P;
  }
  // Case 4: I and R
  else if (I !== undefined && R !== undefined) {
    V = I * R;
    P = I * I * R;
  }
  // Case 5: I and P
  else if (I !== undefined && P !== undefined && I !== 0) {
    V = P / I;
    R = P / (I * I);
  }
  // Case 6: R and P
  else if (R !== undefined && P !== undefined && R > 0 && P >= 0) {
    V = Math.sqrt(P * R);
    I = Math.sqrt(P / R);
  } else {
    return null;
  }

  return {
    V: parseFloat(V.toFixed(4)),
    I: parseFloat(I.toFixed(4)),
    R: parseFloat(R.toFixed(4)),
    P: parseFloat(P.toFixed(4))
  };
}

export interface ACPowerResult {
  realPowerWatts: number;       // P = V * I * cos(theta)
  apparentPowerVA: number;      // S = V * I
  reactivePowerVAR: number;     // Q = V * I * sin(theta)
  powerFactor: number;          // PF = cos(theta)
  phaseAngleDeg: number;
}

export function calculateACPower(
  vRms: number,
  iRms: number,
  phaseAngleDeg: number
): ACPowerResult {
  const thetaRad = (phaseAngleDeg * Math.PI) / 180;
  const apparent = vRms * iRms;
  const pf = Math.cos(thetaRad);
  const real = apparent * pf;
  const reactive = apparent * Math.sin(thetaRad);

  return {
    realPowerWatts: parseFloat(real.toFixed(3)),
    apparentPowerVA: parseFloat(apparent.toFixed(3)),
    reactivePowerVAR: parseFloat(reactive.toFixed(3)),
    powerFactor: parseFloat(pf.toFixed(4)),
    phaseAngleDeg
  };
}

export function convertACWaveform(
  type: 'peak' | 'rms' | 'peakToPeak' | 'avg',
  value: number
): {
  peak: number;
  rms: number;
  peakToPeak: number;
  average: number;
} {
  let peak = 0;
  if (type === 'peak') peak = value;
  else if (type === 'rms') peak = value * Math.SQRT2;
  else if (type === 'peakToPeak') peak = value / 2;
  else if (type === 'avg') peak = (value * Math.PI) / 2;

  const rms = peak / Math.SQRT2;
  const peakToPeak = 2 * peak;
  const average = (2 * peak) / Math.PI;

  return {
    peak: parseFloat(peak.toFixed(4)),
    rms: parseFloat(rms.toFixed(4)),
    peakToPeak: parseFloat(peakToPeak.toFixed(4)),
    average: parseFloat(average.toFixed(4))
  };
}

// ==========================================
// 2. Kirchhoff's Laws & Divider Circuits
// ==========================================

export function calculateVoltageDivider(
  vIn: number,
  r1: number,
  r2: number
): { vOut: number; current: number; ratio: number } {
  const totalR = r1 + r2;
  if (totalR <= 0) return { vOut: 0, current: 0, ratio: 0 };

  const current = vIn / totalR;
  const vOut = vIn * (r2 / totalR);
  const ratio = r2 / totalR;

  return {
    vOut: parseFloat(vOut.toFixed(4)),
    current: parseFloat(current.toFixed(4)),
    ratio: parseFloat(ratio.toFixed(4))
  };
}

export function calculateCurrentDivider(
  iTotal: number,
  r1: number,
  r2: number
): { i1: number; i2: number } {
  const totalR = r1 + r2;
  if (totalR <= 0) return { i1: 0, i2: 0 };

  const i1 = iTotal * (r2 / totalR);
  const i2 = iTotal * (r1 / totalR);

  return {
    i1: parseFloat(i1.toFixed(4)),
    i2: parseFloat(i2.toFixed(4))
  };
}

// ==========================================
// 3. Components: R, L, C Combinations & Time Constants
// ==========================================

export function combineComponents(
  type: 'series' | 'parallel',
  component: 'resistor' | 'capacitor' | 'inductor',
  values: number[]
): number {
  const valid = values.filter(v => v > 0);
  if (valid.length === 0) return 0;

  // Resistors and Inductors follow standard: Series = sum, Parallel = 1 / sum(1/v)
  if (component === 'resistor' || component === 'inductor') {
    if (type === 'series') {
      return parseFloat(valid.reduce((a, b) => a + b, 0).toFixed(4));
    }
    const invSum = valid.reduce((acc, val) => acc + 1 / val, 0);
    return parseFloat((1 / invSum).toFixed(4));
  }

  // Capacitors follow inverted rule: Parallel = sum, Series = 1 / sum(1/v)
  if (type === 'parallel') {
    return parseFloat(valid.reduce((a, b) => a + b, 0).toFixed(4));
  }
  const invSum = valid.reduce((acc, val) => acc + 1 / val, 0);
  return parseFloat((1 / invSum).toFixed(4));
}

// Delta-to-Wye (Δ-Y) & Wye-to-Delta (Y-Δ) conversion
export function deltaToWye(
  Ra: number,
  Rb: number,
  Rc: number
): { R1: number; R2: number; R3: number } {
  const denom = Ra + Rb + Rc;
  if (denom <= 0) return { R1: 0, R2: 0, R3: 0 };

  const R1 = (Rb * Rc) / denom;
  const R2 = (Ra * Rc) / denom;
  const R3 = (Ra * Rb) / denom;

  return {
    R1: parseFloat(R1.toFixed(4)),
    R2: parseFloat(R2.toFixed(4)),
    R3: parseFloat(R3.toFixed(4))
  };
}

export function wyeToDelta(
  R1: number,
  R2: number,
  R3: number
): { Ra: number; Rb: number; Rc: number } {
  const num = R1 * R2 + R2 * R3 + R3 * R1;
  return {
    Ra: R1 > 0 ? parseFloat((num / R1).toFixed(4)) : 0,
    Rb: R2 > 0 ? parseFloat((num / R2).toFixed(4)) : 0,
    Rc: R3 > 0 ? parseFloat((num / R3).toFixed(4)) : 0
  };
}

// RC & RL Time Constants
export function calculateTimeConstant(
  circuit: 'RC' | 'RL',
  R: number,
  C_or_L: number,
  voltageSource: number = 5,
  timeT?: number
): {
  tau: number;
  freqCutoff: number;
  voltageAtTau: number;
  voltageAtTime: number | null;
} {
  const tau = circuit === 'RC' ? R * C_or_L : C_or_L / (R || 1);
  const freqCutoff = 1 / (2 * Math.PI * tau);
  // Charging: v(tau) = V0 * (1 - e^-1) ≈ 63.2%
  const voltageAtTau = voltageSource * (1 - Math.exp(-1));

  let voltageAtTime: number | null = null;
  if (timeT !== undefined && timeT >= 0) {
    voltageAtTime = voltageSource * (1 - Math.exp(-timeT / (tau || 1)));
  }

  return {
    tau: parseFloat(tau.toExponential(4)),
    freqCutoff: parseFloat(freqCutoff.toFixed(2)),
    voltageAtTau: parseFloat(voltageAtTau.toFixed(3)),
    voltageAtTime: voltageAtTime !== null ? parseFloat(voltageAtTime.toFixed(3)) : null
  };
}

// ==========================================
// 4. Impedance & RLC Resonance
// ==========================================

export interface RLCResult {
  resonantFrequencyHz: number;
  resonantOmegaRadS: number;
  impedanceMag: number;
  phaseAngleDeg: number;
  reactanceCapacitive: number;
  reactanceInductive: number;
  netReactance: number;
  qualityFactor: number;
  bandwidthHz: number;
  cutoffLowHz: number;
  cutoffHighHz: number;
}

export function calculateRLCCircuit(
  R: number,
  L_Henry: number,
  C_Farad: number,
  freqHz: number,
  type: 'series' | 'parallel' = 'series'
): RLCResult {
  const omega = 2 * Math.PI * freqHz;
  const XL = omega * L_Henry;
  const XC = omega * C_Farad > 0 ? 1 / (omega * C_Farad) : 0;
  const X_net = XL - XC;

  // Resonance
  const f0 = L_Henry > 0 && C_Farad > 0 ? 1 / (2 * Math.PI * Math.sqrt(L_Henry * C_Farad)) : 0;
  const omega0 = 2 * Math.PI * f0;

  let Z_mag = 0;
  let phaseDeg = 0;
  let Q = 0;

  if (type === 'series') {
    Z_mag = Math.sqrt(R * R + X_net * X_net);
    phaseDeg = (Math.atan2(X_net, R) * 180) / Math.PI;
    Q = R > 0 && C_Farad > 0 ? (1 / R) * Math.sqrt(L_Henry / C_Farad) : 0;
  } else {
    // Parallel RLC: 1/Z = 1/R + j(1/XC - 1/XL) = 1/R + j(omega*C - 1/(omega*L))
    const BL = XL > 0 ? 1 / XL : 0;
    const BC = XC > 0 ? 1 / XC : 0;
    const B_net = BC - BL;
    const Y_mag = Math.sqrt((1 / (R || 1)) ** 2 + B_net * B_net);
    Z_mag = Y_mag > 0 ? 1 / Y_mag : 0;
    phaseDeg = (-Math.atan2(B_net, 1 / (R || 1)) * 180) / Math.PI;
    Q = L_Henry > 0 ? R * Math.sqrt(C_Farad / L_Henry) : 0;
  }

  const bw = Q > 0 ? f0 / Q : 0;
  const f1 = Math.max(0, f0 - bw / 2);
  const f2 = f0 + bw / 2;

  return {
    resonantFrequencyHz: parseFloat(f0.toFixed(2)),
    resonantOmegaRadS: parseFloat(omega0.toFixed(2)),
    impedanceMag: parseFloat(Z_mag.toFixed(3)),
    phaseAngleDeg: parseFloat(phaseDeg.toFixed(2)),
    reactanceCapacitive: parseFloat(XC.toFixed(3)),
    reactanceInductive: parseFloat(XL.toFixed(3)),
    netReactance: parseFloat(X_net.toFixed(3)),
    qualityFactor: parseFloat(Q.toFixed(3)),
    bandwidthHz: parseFloat(bw.toFixed(2)),
    cutoffLowHz: parseFloat(f1.toFixed(2)),
    cutoffHighHz: parseFloat(f2.toFixed(2))
  };
}

// ==========================================
// 5. Transfer Functions & Control Systems
// ==========================================

export interface FirstOrderFilterResult {
  cutoffFreqHz: number;
  gainMagnitude: number;
  gainDb: number;
  phaseShiftDeg: number;
}

export function calculateFirstOrderFilter(
  type: 'lowpass' | 'highpass',
  R: number,
  C: number,
  freqHz: number
): FirstOrderFilterResult {
  const fc = 1 / (2 * Math.PI * R * C);
  const ratio = freqHz / fc;

  let gainMag = 0;
  let phaseDeg = 0;

  if (type === 'lowpass') {
    // H(f) = 1 / sqrt(1 + (f/fc)^2)
    gainMag = 1 / Math.sqrt(1 + ratio * ratio);
    phaseDeg = -Math.atan(ratio) * (180 / Math.PI);
  } else {
    // H(f) = (f/fc) / sqrt(1 + (f/fc)^2)
    gainMag = ratio / Math.sqrt(1 + ratio * ratio);
    phaseDeg = (Math.PI / 2 - Math.atan(ratio)) * (180 / Math.PI);
  }

  const gainDb = 20 * Math.log10(Math.max(1e-12, gainMag));

  return {
    cutoffFreqHz: parseFloat(fc.toFixed(2)),
    gainMagnitude: parseFloat(gainMag.toFixed(4)),
    gainDb: parseFloat(gainDb.toFixed(2)),
    phaseShiftDeg: parseFloat(phaseDeg.toFixed(1))
  };
}

// Second-order control system standard prototype: T(s) = omega_n^2 / (s^2 + 2*zeta*omega_n*s + omega_n^2)
export interface SecondOrderControlResult {
  regime: 'Underdamped' | 'Critically Damped' | 'Overdamped' | 'Undamped';
  dampingRatio: number;
  naturalFreqRadS: number;
  percentOvershoot: number;
  settlingTimeSec: number; // 2% criterion: 4 / (zeta * wn)
  peakTimeSec: number | null;
  riseTimeSec: number;
  poles: { real: number; imag: number }[];
}

export function calculateSecondOrderSystem(
  omega_n: number,
  zeta: number
): SecondOrderControlResult {
  const wn = Math.max(0.001, omega_n);
  let regime: 'Underdamped' | 'Critically Damped' | 'Overdamped' | 'Undamped' = 'Underdamped';
  let percentOvershoot = 0;
  let peakTimeSec: number | null = null;
  let settlingTimeSec = 0;
  let riseTimeSec = 0;
  const poles: { real: number; imag: number }[] = [];

  if (Math.abs(zeta) < 1e-5) {
    regime = 'Undamped';
    percentOvershoot = 100;
    settlingTimeSec = Infinity;
    poles.push({ real: 0, imag: wn }, { real: 0, imag: -wn });
  } else if (zeta > 0 && zeta < 1) {
    regime = 'Underdamped';
    const wd = wn * Math.sqrt(1 - zeta * zeta);
    percentOvershoot = 100 * Math.exp((-zeta * Math.PI) / Math.sqrt(1 - zeta * zeta));
    settlingTimeSec = 4 / (zeta * wn);
    peakTimeSec = Math.PI / wd;
    riseTimeSec = (1.76 - 0.417 * zeta) / wn;
    poles.push(
      { real: parseFloat((-zeta * wn).toFixed(3)), imag: parseFloat(wd.toFixed(3)) },
      { real: parseFloat((-zeta * wn).toFixed(3)), imag: parseFloat((-wd).toFixed(3)) }
    );
  } else if (Math.abs(zeta - 1) < 1e-4) {
    regime = 'Critically Damped';
    percentOvershoot = 0;
    settlingTimeSec = 5.83 / wn;
    riseTimeSec = 2.16 / wn;
    poles.push(
      { real: parseFloat((-wn).toFixed(3)), imag: 0 },
      { real: parseFloat((-wn).toFixed(3)), imag: 0 }
    );
  } else {
    regime = 'Overdamped';
    percentOvershoot = 0;
    const s1 = -zeta * wn + wn * Math.sqrt(zeta * zeta - 1);
    const s2 = -zeta * wn - wn * Math.sqrt(zeta * zeta - 1);
    settlingTimeSec = 4 / Math.abs(s1);
    riseTimeSec = (1.1 + 1.4 * zeta) / wn;
    poles.push(
      { real: parseFloat(s1.toFixed(3)), imag: 0 },
      { real: parseFloat(s2.toFixed(3)), imag: 0 }
    );
  }

  return {
    regime,
    dampingRatio: parseFloat(zeta.toFixed(3)),
    naturalFreqRadS: parseFloat(wn.toFixed(3)),
    percentOvershoot: parseFloat(percentOvershoot.toFixed(2)),
    settlingTimeSec: isFinite(settlingTimeSec) ? parseFloat(settlingTimeSec.toFixed(3)) : 9999,
    peakTimeSec: peakTimeSec !== null ? parseFloat(peakTimeSec.toFixed(3)) : null,
    riseTimeSec: parseFloat(riseTimeSec.toFixed(3)),
    poles
  };
}
