import * as math from 'mathjs';

// Reduced Row Echelon Form (RREF)
export function computeRREF(matrix: number[][]): { rref: number[][]; rank: number } {
  // Clone matrix
  const A = matrix.map(row => [...row]);
  const rows = A.length;
  if (rows === 0) return { rref: [], rank: 0 };
  const cols = A[0].length;

  let lead = 0;
  let rank = 0;

  for (let r = 0; r < rows; r++) {
    if (cols <= lead) break;
    let i = r;

    while (Math.abs(A[i][lead]) < 1e-10) {
      i++;
      if (rows === i) {
        i = r;
        lead++;
        if (cols === lead) return { rref: A, rank };
      }
    }

    // Swap rows i and r
    const temp = A[i];
    A[i] = A[r];
    A[r] = temp;

    // Scale row r
    const lv = A[r][lead];
    for (let j = 0; j < cols; j++) {
      A[r][j] = A[r][j] / lv;
    }

    // Eliminate other rows
    for (let i2 = 0; i2 < rows; i2++) {
      if (i2 !== r) {
        const factor = A[i2][lead];
        for (let j = 0; j < cols; j++) {
          A[i2][j] = A[i2][j] - factor * A[r][j];
        }
      }
    }
    lead++;
    rank++;
  }

  // Round near zeros
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      if (Math.abs(A[i][j]) < 1e-10) A[i][j] = 0;
      else A[i][j] = parseFloat(A[i][j].toFixed(6));
    }
  }

  return { rref: A, rank };
}

// Matrix determinant
export function matrixDeterminant(A: number[][]): number | null {
  try {
    if (A.length !== A[0].length) return null;
    return (math.det(A) as any) as number;
  } catch {
    return null;
  }
}

// Matrix Inverse
export function matrixInverse(A: number[][]): number[][] | null {
  try {
    if (A.length !== A[0].length) return null;
    const inv = math.inv(A) as any;
    return (inv as number[][]).map(row => row.map(v => parseFloat(v.toFixed(6))));
  } catch {
    return null;
  }
}

// Matrix Transpose
export function matrixTranspose(A: number[][]): number[][] {
  const rows = A.length;
  const cols = A[0].length;
  const result: number[][] = [];
  for (let j = 0; j < cols; j++) {
    const row: number[] = [];
    for (let i = 0; i < rows; i++) {
      row.push(A[i][j]);
    }
    result.push(row);
  }
  return result;
}

// Matrix multiplication
export function matrixMultiply(A: number[][], B: number[][]): number[][] | null {
  try {
    const res = math.multiply(A, B) as any;
    return res as number[][];
  } catch {
    return null;
  }
}

// Matrix Trace
export function matrixTrace(A: number[][]): number | null {
  try {
    return (math.trace(A) as any) as number;
  } catch {
    return null;
  }
}

// 2x2 Eigenvalues and Eigenvectors
export function eigen2x2(A: number[][]): {
  lambda1: string;
  lambda2: string;
  trace: number;
  det: number;
} | null {
  if (A.length !== 2 || A[0].length !== 2) return null;
  const tr = A[0][0] + A[1][1];
  const det = A[0][0] * A[1][1] - A[0][1] * A[1][0];
  const disc = tr * tr - 4 * det;

  if (disc >= 0) {
    const l1 = (tr + Math.sqrt(disc)) / 2;
    const l2 = (tr - Math.sqrt(disc)) / 2;
    return {
      lambda1: parseFloat(l1.toFixed(6)).toString(),
      lambda2: parseFloat(l2.toFixed(6)).toString(),
      trace: tr,
      det
    };
  } else {
    const real = tr / 2;
    const imag = Math.sqrt(-disc) / 2;
    return {
      lambda1: `${parseFloat(real.toFixed(4))} + ${parseFloat(imag.toFixed(4))}i`,
      lambda2: `${parseFloat(real.toFixed(4))} - ${parseFloat(imag.toFixed(4))}i`,
      trace: tr,
      det
    };
  }
}

// Vector operations (2D or 3D)
export function vectorDot(u: number[], v: number[]): number {
  return u.reduce((sum, val, i) => sum + val * (v[i] || 0), 0);
}

export function vectorCross3D(u: number[], v: number[]): number[] {
  const u1 = u[0] || 0, u2 = u[1] || 0, u3 = u[2] || 0;
  const v1 = v[0] || 0, v2 = v[1] || 0, v3 = v[2] || 0;
  return [
    u2 * v3 - u3 * v2,
    u3 * v1 - u1 * v3,
    u1 * v2 - u2 * v1
  ];
}

export function vectorMagnitude(v: number[]): number {
  return Math.sqrt(v.reduce((sum, val) => sum + val * val, 0));
}

export function vectorUnit(v: number[]): number[] {
  const mag = vectorMagnitude(v);
  if (mag === 0) return v.map(() => 0);
  return v.map(val => parseFloat((val / mag).toFixed(6)));
}

export function vectorAngle(u: number[], v: number[]): { radians: number; degrees: number } {
  const dot = vectorDot(u, v);
  const magU = vectorMagnitude(u);
  const magV = vectorMagnitude(v);
  if (magU === 0 || magV === 0) return { radians: 0, degrees: 0 };
  const cosTheta = Math.max(-1, Math.min(1, dot / (magU * magV)));
  const rad = Math.acos(cosTheta);
  return {
    radians: parseFloat(rad.toFixed(6)),
    degrees: parseFloat(((rad * 180) / Math.PI).toFixed(4))
  };
}

export function vectorProjection(u: number[], v: number[]): number[] {
  const magV2 = vectorDot(v, v);
  if (magV2 === 0) return v.map(() => 0);
  const scale = vectorDot(u, v) / magV2;
  return v.map(val => parseFloat((scale * val).toFixed(6)));
}
