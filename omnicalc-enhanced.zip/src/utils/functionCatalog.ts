import { FunctionDef } from '../types/calc';

export const FUNCTION_CATALOG: FunctionDef[] = [
  // --- Arithmetic & Basic ---
  {
    name: 'abs',
    syntax: 'abs(x)',
    category: 'Arithmetic & Basic',
    description: 'Calculates the absolute value of a real number or magnitude of a complex number.',
    example: 'abs(-14.2)',
    tags: ['modulus', 'magnitude', 'absolute', 'positive', 'distance']
  },
  {
    name: 'mod',
    syntax: 'mod(x, y)',
    category: 'Arithmetic & Basic',
    description: 'Modulo operation returning the remainder of integer or real division x / y.',
    example: 'mod(17, 5)',
    tags: ['remainder', 'modulo', 'division']
  },
  {
    name: 'round',
    syntax: 'round(x, [decimals])',
    category: 'Arithmetic & Basic',
    description: 'Rounds a number to the nearest integer or specified number of decimal digits.',
    example: 'round(3.14159, 2)',
    tags: ['round', 'approximate', 'nearest']
  },
  {
    name: 'ceil',
    syntax: 'ceil(x)',
    category: 'Arithmetic & Basic',
    description: 'Rounds a number up to the nearest integer (ceiling function).',
    example: 'ceil(4.1)',
    tags: ['ceiling', 'round up', 'integer']
  },
  {
    name: 'floor',
    syntax: 'floor(x)',
    category: 'Arithmetic & Basic',
    description: 'Rounds a number down to the nearest integer (floor function).',
    example: 'floor(4.9)',
    tags: ['floor', 'round down', 'integer']
  },
  {
    name: 'sign',
    syntax: 'sign(x)',
    category: 'Arithmetic & Basic',
    description: 'Signum function returning -1 for negative, 0 for zero, and 1 for positive.',
    example: 'sign(-25)',
    tags: ['signum', 'direction', 'polarity']
  },
  {
    name: 'gcd',
    syntax: 'gcd(a, b, ...)',
    category: 'Arithmetic & Basic',
    description: 'Greatest common divisor of two or more integers.',
    example: 'gcd(54, 24)',
    tags: ['divisor', 'factor', 'hcf']
  },
  {
    name: 'lcm',
    syntax: 'lcm(a, b, ...)',
    category: 'Arithmetic & Basic',
    description: 'Least common multiple of two or more integers.',
    example: 'lcm(12, 18)',
    tags: ['multiple', 'common', 'lcm']
  },
  {
    name: 'sqrt',
    syntax: 'sqrt(x)',
    category: 'Arithmetic & Basic',
    description: 'Square root of a number (supports real and complex values).',
    example: 'sqrt(144)',
    tags: ['radical', 'square root', 'root']
  },
  {
    name: 'cbrt',
    syntax: 'cbrt(x)',
    category: 'Arithmetic & Basic',
    description: 'Cube root of a number.',
    example: 'cbrt(125)',
    tags: ['cube root', 'radical']
  },
  {
    name: 'nthRoot',
    syntax: 'nthRoot(x, n)',
    category: 'Arithmetic & Basic',
    description: 'Calculates the n-th root of a number x.',
    example: 'nthRoot(81, 4)',
    tags: ['root', 'radical', 'power']
  },

  // --- Trigonometry ---
  {
    name: 'sin',
    syntax: 'sin(x)',
    category: 'Trigonometry',
    description: 'Sine of an angle (adheres to Deg/Rad/Grad setting).',
    example: 'sin(pi / 6)',
    tags: ['trig', 'sine', 'wave']
  },
  {
    name: 'cos',
    syntax: 'cos(x)',
    category: 'Trigonometry',
    description: 'Cosine of an angle (adheres to Deg/Rad/Grad setting).',
    example: 'cos(pi / 3)',
    tags: ['trig', 'cosine', 'wave']
  },
  {
    name: 'tan',
    syntax: 'tan(x)',
    category: 'Trigonometry',
    description: 'Tangent of an angle (adheres to Deg/Rad/Grad setting).',
    example: 'tan(pi / 4)',
    tags: ['trig', 'tangent', 'slope']
  },
  {
    name: 'asin',
    syntax: 'asin(x)',
    category: 'Trigonometry',
    description: 'Inverse sine (arcsine), returns angle in current angle unit.',
    example: 'asin(0.5)',
    tags: ['arcsin', 'inverse sine', 'angle']
  },
  {
    name: 'acos',
    syntax: 'acos(x)',
    category: 'Trigonometry',
    description: 'Inverse cosine (arccosine), returns angle in current angle unit.',
    example: 'acos(0.5)',
    tags: ['arccos', 'inverse cosine', 'angle']
  },
  {
    name: 'atan',
    syntax: 'atan(x)',
    category: 'Trigonometry',
    description: 'Inverse tangent (arctangent), returns angle in current angle unit.',
    example: 'atan(1)',
    tags: ['arctan', 'inverse tangent', 'angle']
  },
  {
    name: 'atan2',
    syntax: 'atan2(y, x)',
    category: 'Trigonometry',
    description: 'Four-quadrant inverse tangent of y and x coordinates.',
    example: 'atan2(3, -3)',
    tags: ['arctan', 'polar angle', 'quadrant']
  },
  {
    name: 'sec',
    syntax: 'sec(x)',
    category: 'Trigonometry',
    description: 'Secant function: 1 / cos(x).',
    example: 'sec(pi / 3)',
    tags: ['secant', 'reciprocal trig']
  },
  {
    name: 'csc',
    syntax: 'csc(x)',
    category: 'Trigonometry',
    description: 'Cosecant function: 1 / sin(x).',
    example: 'csc(pi / 6)',
    tags: ['cosecant', 'reciprocal trig']
  },
  {
    name: 'cot',
    syntax: 'cot(x)',
    category: 'Trigonometry',
    description: 'Cotangent function: 1 / tan(x).',
    example: 'cot(pi / 4)',
    tags: ['cotangent', 'reciprocal trig']
  },
  {
    name: 'sinc',
    syntax: 'sinc(x)',
    category: 'Trigonometry',
    description: 'Normalized or unnormalized cardinal sine function sin(pi*x)/(pi*x).',
    example: 'sin(1) / 1',
    tags: ['sinc', 'dsp', 'filter']
  },

  // --- Hyperbolic ---
  {
    name: 'sinh',
    syntax: 'sinh(x)',
    category: 'Hyperbolic',
    description: 'Hyperbolic sine: (e^x - e^(-x)) / 2.',
    example: 'sinh(1.5)',
    tags: ['hyperbolic', 'sinh', 'catenary']
  },
  {
    name: 'cosh',
    syntax: 'cosh(x)',
    category: 'Hyperbolic',
    description: 'Hyperbolic cosine: (e^x + e^(-x)) / 2.',
    example: 'cosh(1.5)',
    tags: ['hyperbolic', 'cosh', 'catenary']
  },
  {
    name: 'tanh',
    syntax: 'tanh(x)',
    category: 'Hyperbolic',
    description: 'Hyperbolic tangent: sinh(x) / cosh(x).',
    example: 'tanh(0.75)',
    tags: ['hyperbolic', 'tanh', 'activation']
  },
  {
    name: 'asinh',
    syntax: 'asinh(x)',
    category: 'Hyperbolic',
    description: 'Inverse hyperbolic sine (area hyperbolic sine).',
    example: 'asinh(2.5)',
    tags: ['hyperbolic', 'inverse sinh']
  },
  {
    name: 'acosh',
    syntax: 'acosh(x)',
    category: 'Hyperbolic',
    description: 'Inverse hyperbolic cosine (area hyperbolic cosine) for x >= 1.',
    example: 'acosh(2.5)',
    tags: ['hyperbolic', 'inverse cosh']
  },
  {
    name: 'atanh',
    syntax: 'atanh(x)',
    category: 'Hyperbolic',
    description: 'Inverse hyperbolic tangent for |x| < 1.',
    example: 'atanh(0.5)',
    tags: ['hyperbolic', 'inverse tanh']
  },

  // --- Exponential & Log ---
  {
    name: 'exp',
    syntax: 'exp(x)',
    category: 'Exponential & Log',
    description: 'Natural exponential function e^x.',
    example: 'exp(2)',
    tags: ['exponential', 'euler', 'power']
  },
  {
    name: 'log',
    syntax: 'log(x, [base])',
    category: 'Exponential & Log',
    description: 'Logarithm of x to a specified base (defaults to natural log base e).',
    example: 'log(100, 10)',
    tags: ['logarithm', 'base', 'exponent']
  },
  {
    name: 'ln',
    syntax: 'ln(x)',
    category: 'Exponential & Log',
    description: 'Natural logarithm of x (base e).',
    example: 'ln(e^3)',
    tags: ['natural log', 'ln', 'euler']
  },
  {
    name: 'log10',
    syntax: 'log10(x)',
    category: 'Exponential & Log',
    description: 'Common base-10 logarithm.',
    example: 'log10(1000)',
    tags: ['decadic', 'base 10', 'decibel']
  },
  {
    name: 'log2',
    syntax: 'log2(x)',
    category: 'Exponential & Log',
    description: 'Binary logarithm (base 2), common in computer science and information theory.',
    example: 'log2(256)',
    tags: ['binary log', 'bits', 'information']
  },

  // --- Calculus & Analysis ---
  {
    name: 'derivative',
    syntax: 'derivative(expr, variable)',
    category: 'Calculus & Analysis',
    description: 'Computes the symbolic derivative of an expression with respect to a variable.',
    example: 'derivative("x^3 + 2*x", "x")',
    tags: ['calculus', 'differentiation', 'slope', 'rate']
  },
  {
    name: 'simplify',
    syntax: 'simplify(expr)',
    category: 'Calculus & Analysis',
    description: 'Symbolically simplifies an algebraic or trigonometric mathematical expression.',
    example: 'simplify("2x + 3x + (x^2)/x")',
    tags: ['cas', 'algebra', 'reduce', 'combine']
  },

  // --- Probability & Statistics ---
  {
    name: 'mean',
    syntax: 'mean([a, b, c, ...])',
    category: 'Probability & Statistics',
    description: 'Arithmetic mean of an array or matrix of numbers.',
    example: 'mean([12, 15, 18, 22, 30])',
    tags: ['average', 'expected value', 'stats']
  },
  {
    name: 'median',
    syntax: 'median([a, b, c, ...])',
    category: 'Probability & Statistics',
    description: 'Middle value separating the higher half from the lower half of a data sample.',
    example: 'median([3, 13, 7, 5, 21, 23, 39])',
    tags: ['middle', 'statistics', 'percentile']
  },
  {
    name: 'mode',
    syntax: 'mode([a, b, c, ...])',
    category: 'Probability & Statistics',
    description: 'Most frequently occurring value(s) in a dataset.',
    example: 'mode([1, 2, 2, 3, 4, 4, 4, 5])',
    tags: ['frequency', 'statistics']
  },
  {
    name: 'std',
    syntax: 'std([a, b, c, ...])',
    category: 'Probability & Statistics',
    description: 'Standard deviation measuring the dispersion of values.',
    example: 'std([2, 4, 4, 4, 5, 5, 7, 9])',
    tags: ['variance', 'dispersion', 'sigma']
  },
  {
    name: 'variance',
    syntax: 'variance([a, b, c, ...])',
    category: 'Probability & Statistics',
    description: 'Variance (square of standard deviation).',
    example: 'variance([2, 4, 4, 4, 5, 5, 7, 9])',
    tags: ['dispersion', 'spread']
  },
  {
    name: 'factorial',
    syntax: 'factorial(n) or n!',
    category: 'Probability & Statistics',
    description: 'Product of all positive integers less than or equal to n.',
    example: 'factorial(6)',
    tags: ['combinatorics', 'permutation', 'gamma']
  },
  {
    name: 'combinations',
    syntax: 'combinations(n, k)',
    category: 'Probability & Statistics',
    description: 'Binomial coefficient "n choose k": n! / (k! * (n - k)!).',
    example: 'combinations(10, 3)',
    tags: ['nCr', 'choose', 'combinations']
  },
  {
    name: 'permutations',
    syntax: 'permutations(n, [k])',
    category: 'Probability & Statistics',
    description: 'Permutations of n items taken k at a time: n! / (n - k)!.',
    example: 'permutations(8, 3)',
    tags: ['nPr', 'arrangements', 'permutations']
  },
  {
    name: 'gamma',
    syntax: 'gamma(x)',
    category: 'Probability & Statistics',
    description: 'Euler Gamma function generalizing factorial to complex and real numbers.',
    example: 'gamma(5.5)',
    tags: ['gamma', 'special', 'factorial extension']
  },
  {
    name: 'erf',
    syntax: 'erf(x)',
    category: 'Probability & Statistics',
    description: 'Gauss error function widely used in probability, statistics, and PDEs.',
    example: 'erf(0.85)',
    tags: ['error function', 'normal distribution', 'integral']
  },

  // --- Linear Algebra & Matrices ---
  {
    name: 'det',
    syntax: 'det(M)',
    category: 'Linear Algebra & Matrices',
    description: 'Determinant of a square matrix.',
    example: 'det([[1, 2], [3, 4]])',
    tags: ['determinant', 'matrix', 'linear algebra']
  },
  {
    name: 'inv',
    syntax: 'inv(M)',
    category: 'Linear Algebra & Matrices',
    description: 'Multiplicative inverse of a square non-singular matrix.',
    example: 'inv([[4, 7], [2, 6]])',
    tags: ['inverse', 'matrix', 'solve']
  },
  {
    name: 'transpose',
    syntax: 'transpose(M)',
    category: 'Linear Algebra & Matrices',
    description: 'Flips a matrix over its diagonal, swapping row and column indices.',
    example: 'transpose([[1, 2, 3], [4, 5, 6]])',
    tags: ['transpose', 'matrix', 'flip']
  },
  {
    name: 'trace',
    syntax: 'trace(M)',
    category: 'Linear Algebra & Matrices',
    description: 'Sum of elements on the main diagonal of a square matrix.',
    example: 'trace([[2, 0], [1, 5]])',
    tags: ['trace', 'diagonal sum', 'eigenvalues']
  },
  {
    name: 'dot',
    syntax: 'dot(v1, v2)',
    category: 'Linear Algebra & Matrices',
    description: 'Scalar dot product of two vectors.',
    example: 'dot([1, 2, 3], [4, -5, 6])',
    tags: ['dot product', 'inner product', 'scalar']
  },
  {
    name: 'cross',
    syntax: 'cross(v1, v2)',
    category: 'Linear Algebra & Matrices',
    description: 'Vector cross product of two 3-dimensional vectors.',
    example: 'cross([1, 0, 0], [0, 1, 0])',
    tags: ['cross product', 'vector product', 'torque']
  },
  {
    name: 'identity',
    syntax: 'identity(n)',
    category: 'Linear Algebra & Matrices',
    description: 'Constructs an n x n identity matrix.',
    example: 'identity(3)',
    tags: ['identity', 'matrix', 'ones']
  },

  // --- Complex Numbers ---
  {
    name: 're',
    syntax: 're(z)',
    category: 'Complex Numbers',
    description: 'Extracts the real component of a complex number.',
    example: 're(3 + 4i)',
    tags: ['real', 'complex']
  },
  {
    name: 'im',
    syntax: 'im(z)',
    category: 'Complex Numbers',
    description: 'Extracts the imaginary component of a complex number.',
    example: 'im(3 + 4i)',
    tags: ['imaginary', 'complex']
  },
  {
    name: 'conj',
    syntax: 'conj(z)',
    category: 'Complex Numbers',
    description: 'Calculates the complex conjugate: conj(a + bi) = a - bi.',
    example: 'conj(5 - 2i)',
    tags: ['conjugate', 'complex']
  },
  {
    name: 'arg',
    syntax: 'arg(z)',
    category: 'Complex Numbers',
    description: 'Computes the argument (phase angle) of a complex number.',
    example: 'arg(1 + 1i)',
    tags: ['phase', 'angle', 'polar']
  },

  // --- Discrete & Bitwise ---
  {
    name: 'bitAnd',
    syntax: 'bitAnd(a, b)',
    category: 'Discrete & Bitwise',
    description: 'Bitwise AND of two integer operands.',
    example: 'bitAnd(12, 10)',
    tags: ['bitwise', 'and', 'binary']
  },
  {
    name: 'bitOr',
    syntax: 'bitOr(a, b)',
    category: 'Discrete & Bitwise',
    description: 'Bitwise OR of two integer operands.',
    example: 'bitOr(12, 10)',
    tags: ['bitwise', 'or', 'binary']
  },
  {
    name: 'bitXor',
    syntax: 'bitXor(a, b)',
    category: 'Discrete & Bitwise',
    description: 'Bitwise XOR of two integer operands.',
    example: 'bitXor(12, 10)',
    tags: ['bitwise', 'xor', 'binary']
  },
  {
    name: 'bitNot',
    syntax: 'bitNot(a)',
    category: 'Discrete & Bitwise',
    description: 'Bitwise NOT (one\'s complement) of an integer.',
    example: 'bitNot(5)',
    tags: ['bitwise', 'not', 'invert']
  },

  // --- Constants ---
  {
    name: 'pi',
    syntax: 'pi',
    category: 'Constants',
    description: 'Archimedes constant pi (ratio of circumference to diameter) ~ 3.14159265...',
    example: '2 * pi * 10',
    tags: ['pi', 'circle', 'constant']
  },
  {
    name: 'e',
    syntax: 'e',
    category: 'Constants',
    description: 'Euler’s number, base of the natural logarithm ~ 2.71828182...',
    example: 'e^2',
    tags: ['euler', 'natural log', 'constant']
  },
  {
    name: 'i',
    syntax: 'i',
    category: 'Constants',
    description: 'Imaginary unit defined such that i^2 = -1.',
    example: 'i^2',
    tags: ['imaginary', 'complex unit']
  },
  {
    name: 'tau',
    syntax: 'tau',
    category: 'Constants',
    description: 'Circle constant tau = 2 * pi ~ 6.2831853...',
    example: 'tau / 4',
    tags: ['tau', 'circle', 'turn']
  },
  {
    name: 'phi',
    syntax: 'phi',
    category: 'Constants',
    description: 'Golden ratio (1 + sqrt(5)) / 2 ~ 1.6180339...',
    example: 'phi',
    tags: ['golden ratio', 'divine proportion']
  }
];
