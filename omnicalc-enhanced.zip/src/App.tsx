import React, { useState, useEffect } from 'react';
import { AngleUnit, PrecisionMode, HistoryItem, AppSettings, AppTheme } from './types/calc';
import { setSoundMuted } from './utils/audioFeedback';
import { MainCalculatorView } from './components/views/MainCalculatorView';
import { MultiLineNotebookView } from './components/views/MultiLineNotebookView';
import { GraphingView } from './components/views/GraphingView';
import { CalculusLinearAlgebraView } from './components/views/CalculusLinearAlgebraView';
import { StatisticsProbabilityView } from './components/views/StatisticsProbabilityView';
import { StemSolversView } from './components/views/StemSolversView';
import { UnitConverterConstantsView } from './components/views/UnitConverterConstantsView';
import { ProgrammerBaseNView } from './components/views/ProgrammerBaseNView';
import { ProgrammerScriptingView } from './components/views/ProgrammerScriptingView';
import { DiscreteNumberTheoryView } from './components/views/DiscreteNumberTheoryView';
import { SpecialFunctionsTransformsView } from './components/views/SpecialFunctionsTransformsView';
import { HelpModal } from './components/modals/HelpModal';
import { FunctionCatalogModal } from './components/modals/FunctionCatalogModal';
import { FormulaSearchModal } from './components/modals/FormulaSearchModal';
import { DigitalClock } from './components/DigitalClock';
import {
  Calculator,
  LineChart,
  Grid,
  BarChart3,
  FlaskConical,
  ArrowRightLeft,
  Binary,
  Code2,
  Sparkles,
  Waves,
  Settings,
  Trash2,
  Download,
  AlignLeft,
  HelpCircle,
  Search,
  Layers,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Monitor
} from 'lucide-react';

export type AppMode =
  | 'calc'
  | 'notebook'
  | 'graphing'
  | 'calculus_linear_algebra'
  | 'statistics'
  | 'stem_solvers'
  | 'units_constants'
  | 'discrete'
  | 'special_transforms'
  | 'programmer'
  | 'scripting';

import { loadPersisted, savePersistedDebounced, PersistKeys } from './utils/persistence';

const ANGLE_UNITS: AngleUnit[] = ['deg', 'rad', 'grad'];
const PRECISIONS: PrecisionMode[] = [6, 10, 14, 16, 18, 32, 64, 128];

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  soundEnabled: true,
  fontSize: 'normal',
  keypadStyle: 'glass',
  hapticFeedback: true
};

export default function App() {
  const [mode, setMode] = useState<AppMode>('calc');
  const [angleUnit, setAngleUnit] = useState<AngleUnit>(() => {
    const saved = loadPersisted<unknown>(PersistKeys.angleUnit, 'deg');
    return ANGLE_UNITS.includes(saved as AngleUnit) ? (saved as AngleUnit) : 'deg';
  });
  const [precision, setPrecision] = useState<PrecisionMode>(() => {
    const saved = loadPersisted<unknown>(PersistKeys.precision, 10);
    return PRECISIONS.includes(saved as PrecisionMode) ? (saved as PrecisionMode) : 10;
  });
  const [history, setHistory] = useState<HistoryItem[]>(() =>
    loadPersisted<HistoryItem[]>(PersistKeys.history, [])
  );
  const [ansValue, setAnsValue] = useState<string>('0');
  const [variables, setVariables] = useState<Record<string, any>>({});
  const [showSettings, setShowSettings] = useState<boolean>(false);

  // Global modals
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [showFunctionsModal, setShowFunctionsModal] = useState<boolean>(false);
  const [showFormulasModal, setShowFormulasModal] = useState<boolean>(false);

  // App Settings for customizable interface & themes
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = loadPersisted<Partial<AppSettings>>(PersistKeys.settings, {});
    return { ...DEFAULT_SETTINGS, ...saved };
  });

  // Persist user preferences (debounced so rapid changes don't hammer storage)
  useEffect(() => {
    savePersistedDebounced(PersistKeys.angleUnit, angleUnit);
  }, [angleUnit]);
  useEffect(() => {
    savePersistedDebounced(PersistKeys.precision, precision);
  }, [precision]);
  useEffect(() => {
    savePersistedDebounced(PersistKeys.settings, settings);
  }, [settings]);
  useEffect(() => {
    savePersistedDebounced(PersistKeys.history, history.slice(0, 100));
  }, [history]);

  // Keep audioFeedback utility in sync with user's sound preference
  useEffect(() => {
    setSoundMuted(!settings.soundEnabled);
  }, [settings.soundEnabled]);

  // Global keyboard listener for '?' to open help modal
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // If typing in input or textarea, ignore
      if (
        ['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)
      ) {
        return;
      }
      if (e.key === '?') {
        setShowHelpModal(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  const handleAddHistory = (item: HistoryItem) => {
    setHistory(prev => [item, ...prev].slice(0, 100));
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleExportHistory = () => {
    const text = history.map(h => `${new Date(h.timestamp).toLocaleTimeString()}: ${h.expression} = ${h.result}`).join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `omnicalc_tape_${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Dynamic theme wrapper styles
  const getThemeClass = (theme: AppTheme) => {
    switch (theme) {
      case 'light':
        return 'bg-slate-50 text-slate-900 selection:bg-indigo-200 selection:text-indigo-900';
      case 'oled':
        return 'bg-black text-slate-100 selection:bg-indigo-900 selection:text-indigo-200';
      case 'solarized':
        return 'bg-[#002b36] text-[#93a1a1] selection:bg-[#073642] selection:text-[#2aa198]';
      case 'dark':
      default:
        return 'bg-slate-950 text-slate-100 selection:bg-indigo-500/30 selection:text-indigo-200';
    }
  };

  const getFontSizeClass = () => {
    switch (settings.fontSize) {
      case 'compact':
        return 'text-xs';
      case 'large':
        return 'text-base';
      case 'normal':
      default:
        return 'text-sm';
    }
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-200 ${getThemeClass(settings.theme)} ${getFontSizeClass()}`}>
      {/* Top Application Header */}
      <header className="sticky top-0 z-30 bg-slate-950/85 backdrop-blur-md border-b border-slate-800 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Calculator className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white">OmniCalc</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-semibold">
                  Ultimate
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans hidden sm:block">
                Advanced Scientific & Mathematical Computing System
              </p>
            </div>
          </div>

          {/* Live Digital Clock & Date */}
          <div className="flex items-center order-3 md:order-2 mx-auto md:mx-0">
            <DigitalClock />
          </div>

          {/* Quick Engine Controls */}
          <div className="flex items-center gap-2 text-xs">
            {/* Angle Unit Switcher */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 font-mono">
              {(['deg', 'rad', 'grad'] as AngleUnit[]).map(u => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setAngleUnit(u)}
                  className={`px-2 py-1 rounded font-semibold uppercase transition-colors ${
                    angleUnit === u
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {u}
                </button>
              ))}
            </div>

            {/* Precision Selector */}
            <select
              value={precision}
              onChange={e => setPrecision(parseInt(e.target.value, 10) as PrecisionMode)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-slate-300 font-mono text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
              title="Significant decimal precision"
            >
              <option value={6}>Fix 6</option>
              <option value={10}>Fix 10</option>
              <option value={14}>Fix 14</option>
              <option value={18}>Fix 18</option>
            </select>

            {/* Sound Toggle Shortcut */}
            <button
              type="button"
              onClick={() => setSettings(s => ({ ...s, soundEnabled: !s.soundEnabled }))}
              className={`p-1.5 rounded-lg border transition-colors ${
                settings.soundEnabled
                  ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40'
                  : 'bg-slate-900 text-slate-500 border-slate-800'
              }`}
              title={settings.soundEnabled ? 'Keypad Audio Feedback: ON' : 'Keypad Audio Feedback: MUTED'}
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Quick Functions Catalog */}
            <button
              type="button"
              onClick={() => setShowFunctionsModal(true)}
              className="p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
              title="Search Functions Catalog"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Quick Help Modal */}
            <button
              type="button"
              onClick={() => setShowHelpModal(true)}
              className="p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
              title="Built-in Help & Keyboard Shortcuts (?)"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Settings toggle */}
            <button
              type="button"
              onClick={() => setShowSettings(!showSettings)}
              className="p-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
              title="Customizable Interface & Themes"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Navigation Mode Bar */}
      <nav className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            type="button"
            onClick={() => setMode('calc')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'calc'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            Main Calculator
          </button>

          <button
            type="button"
            onClick={() => setMode('notebook')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'notebook'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <AlignLeft className="w-3.5 h-3.5" />
            Multi-Line Notebook
          </button>

          <button
            type="button"
            onClick={() => setMode('graphing')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'graphing'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <LineChart className="w-3.5 h-3.5" />
            Graphing (2D & 3D)
          </button>

          <button
            type="button"
            onClick={() => setMode('calculus_linear_algebra')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'calculus_linear_algebra'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            Calculus & Linear Algebra
          </button>

          <button
            type="button"
            onClick={() => setMode('statistics')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'statistics'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Statistics & Probability
          </button>

          <button
            type="button"
            onClick={() => setMode('discrete')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'discrete'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Discrete & Number Theory
          </button>

          <button
            type="button"
            onClick={() => setMode('special_transforms')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'special_transforms'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Waves className="w-3.5 h-3.5" />
            Special Functions & Transforms
          </button>

          <button
            type="button"
            onClick={() => setMode('stem_solvers')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'stem_solvers'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5" />
            STEM Solvers
          </button>

          <button
            type="button"
            onClick={() => setMode('units_constants')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'units_constants'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            Converter & Constants
          </button>

          <button
            type="button"
            onClick={() => setMode('programmer')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'programmer'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Binary className="w-3.5 h-3.5" />
            Programmer Base-N
          </button>

          <button
            type="button"
            onClick={() => setMode('scripting')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
              mode === 'scripting'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 border border-slate-850 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            Scripting & Algorithms
          </button>
        </div>
      </nav>

      {/* Customizable Interface & Theme Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl flex flex-col gap-4 text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="font-semibold text-base text-white">Customizable Interface Options</span>
              <button
                type="button"
                onClick={() => setShowSettings(false)}
                className="text-slate-400 hover:text-white text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              {/* Theme Selector */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <div className="font-semibold text-white flex items-center justify-between">
                  <span>Visual Theme</span>
                  <span className="text-slate-400 font-mono capitalize">{settings.theme}</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {(['dark', 'light', 'oled', 'solarized'] as AppTheme[]).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setSettings(s => ({ ...s, theme: t }))}
                      className={`py-1.5 px-2 rounded-lg text-xs font-semibold capitalize transition-all ${
                        settings.theme === t
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sound Feedback Toggle */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">Keypad Audio Click</div>
                  <div className="text-slate-500 text-[11px]">Synthesized tactile click sounds</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSettings(s => ({ ...s, soundEnabled: !s.soundEnabled }))}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                    settings.soundEnabled
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {settings.soundEnabled ? 'Enabled' : 'Muted'}
                </button>
              </div>

              {/* Font Sizing */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">Interface Scale</div>
                  <div className="text-slate-500 text-[11px]">Display sizing density</div>
                </div>
                <div className="flex gap-1">
                  {(['compact', 'normal', 'large'] as const).map(size => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSettings(s => ({ ...s, fontSize: size }))}
                      className={`px-2 py-1 rounded capitalize text-xs font-medium ${
                        settings.fontSize === size
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* History Tape Management */}
              <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div>
                  <div className="font-semibold text-white">Calculation Tape</div>
                  <div className="text-slate-500 text-[11px]">{history.length} operations stored</div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportHistory}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export
                  </button>
                  <button
                    type="button"
                    onClick={handleClearHistory}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear
                  </button>
                </div>
              </div>

              {/* Engine Spec */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-1 font-mono text-[11px] text-slate-400">
                <div className="text-slate-200 font-bold">Computing Core:</div>
                <div>• Math.js v14 + Custom Arbitrary-Precision Engine</div>
                <div>• KaTeX Dynamic Typesetting & Natural Textbook Preview</div>
                <div>• Step-by-Step Mathematical Solvers</div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowSettings(false)}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold mt-1"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-5">
        {mode === 'calc' && (
          <MainCalculatorView
            angleUnit={angleUnit}
            precision={precision}
            variables={variables}
            onAddHistory={handleAddHistory}
            recentHistory={history}
            ansValue={ansValue}
            setAnsValue={setAnsValue}
          />
        )}

        {mode === 'notebook' && (
          <MultiLineNotebookView
            angleUnit={angleUnit}
            precision={precision}
            onInsertToMain={val => {
              setAnsValue(val);
              setMode('calc');
            }}
          />
        )}

        {mode === 'graphing' && <GraphingView angleUnit={angleUnit} />}

        {mode === 'calculus_linear_algebra' && (
          <CalculusLinearAlgebraView angleUnit={angleUnit} />
        )}

        {mode === 'statistics' && <StatisticsProbabilityView />}

        {mode === 'discrete' && <DiscreteNumberTheoryView />}

        {mode === 'special_transforms' && <SpecialFunctionsTransformsView />}

        {mode === 'stem_solvers' && <StemSolversView />}

        {mode === 'units_constants' && (
          <UnitConverterConstantsView
            onInsertExpression={val => {
              setAnsValue(val);
              setMode('calc');
            }}
          />
        )}

        {mode === 'programmer' && <ProgrammerBaseNView />}

        {mode === 'scripting' && <ProgrammerScriptingView />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-3 px-4 text-center text-xs text-slate-600 font-mono">
        OmniCalc Ultimate • Complete University & Professional Scientific Computing System
      </footer>

      {/* Global Modals */}
      <HelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        onLoadExample={expr => {
          setAnsValue(expr);
          setMode('calc');
        }}
      />

      <FunctionCatalogModal
        isOpen={showFunctionsModal}
        onClose={() => setShowFunctionsModal(false)}
        onInsertFunction={syntax => {
          setAnsValue(syntax);
          setMode('calc');
        }}
      />

      <FormulaSearchModal
        isOpen={showFormulasModal}
        onClose={() => setShowFormulasModal(false)}
        onInsertFormula={formula => {
          setAnsValue(formula);
          setMode('calc');
        }}
      />
    </div>
  );
}
