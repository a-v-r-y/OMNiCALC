import React, { useState } from 'react';
import { FORMULA_LIBRARY } from '../../utils/formulaLibrary';
import { FormulaItem } from '../../types/calc';
import { MathView } from '../MathView';
import { Search, X, Calculator, ArrowRight, BookOpen, Layers } from 'lucide-react';

interface FormulaSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertFormula: (formula: string) => void;
}

export const FormulaSearchModal: React.FC<FormulaSearchModalProps> = ({
  isOpen,
  onClose,
  onInsertFormula
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [solvingId, setSolvingId] = useState<string | null>(null);
  const [targetVar, setTargetVar] = useState<string>('');
  const [varValues, setVarValues] = useState<Record<string, number>>({});

  if (!isOpen) return null;

  const categories = ['all', 'Physics', 'Chemistry', 'Mathematics', 'Finance'];

  const filtered = FORMULA_LIBRARY.filter(f => {
    const matchCat = selectedCategory === 'all' || f.category.toLowerCase() === selectedCategory.toLowerCase();
    const q = searchQuery.toLowerCase().trim();
    if (!q) return matchCat;

    const matchName = f.name.toLowerCase().includes(q);
    const matchFormula = f.formula.toLowerCase().includes(q);
    const matchDesc = f.description.toLowerCase().includes(q);
    const matchSub = (f.subcategory || '').toLowerCase().includes(q);

    return matchCat && (matchName || matchFormula || matchDesc || matchSub);
  });

  const handleToggleSolver = (f: FormulaItem) => {
    if (solvingId === f.id) {
      setSolvingId(null);
    } else {
      setSolvingId(f.id);
      const first = f.variables[0]?.symbol || '';
      setTargetVar(first);
      const defaults: Record<string, number> = {};
      f.variables.forEach(v => {
        defaults[v.symbol] = v.defaultValue ?? 0;
      });
      setVarValues(defaults);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Formula Finder & Equation Solver
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Search standard formulas across Physics, Chemistry, Mathematics, and Finance
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Categories */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-900/90 flex flex-col gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search formulas by name, concept, or symbols (e.g. 'kinetic energy', 'ideal gas', 'quadratic', 'compound interest')..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-sans"
              autoFocus
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg capitalize font-medium transition-colors ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Grid of Formulas */}
        <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filtered.length === 0 ? (
            <div className="col-span-full py-12 flex flex-col items-center justify-center text-center text-slate-500">
              <Search className="w-8 h-8 mb-2 opacity-40" />
              <p className="text-sm font-medium">No formulas found matching "{searchQuery}"</p>
              <p className="text-xs text-slate-600 mt-1">Try another keyword or select "All" categories</p>
            </div>
          ) : (
            filtered.map(f => {
              const isSolving = solvingId === f.id;
              const solvedVal = isSolving ? f.solveFor(targetVar, varValues) : null;
              const targetVarObj = f.variables.find(v => v.symbol === targetVar);

              return (
                <div
                  key={f.id}
                  className={`p-4 bg-slate-950 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                    isSolving
                      ? 'border-indigo-500/80 shadow-lg shadow-indigo-950/30'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-semibold text-slate-200 text-sm">{f.name}</span>
                      <span className="text-[10px] uppercase font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40 shrink-0">
                        {f.category}
                      </span>
                    </div>

                    <div className="my-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800/80 overflow-x-auto">
                      <MathView math={f.latex} rawText={f.formula} />
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">{f.description}</p>
                  </div>

                  {/* Inline Variable Solver */}
                  {isSolving && (
                    <div className="p-3 bg-slate-900/90 rounded-xl border border-indigo-800/50 flex flex-col gap-2.5 text-xs font-mono">
                      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                        <span className="text-slate-400 font-sans font-medium text-[11px]">Solve for Variable:</span>
                        <div className="flex gap-1">
                          {f.variables.map(v => (
                            <button
                              key={v.symbol}
                              type="button"
                              onClick={() => setTargetVar(v.symbol)}
                              className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                                targetVar === v.symbol
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                              }`}
                            >
                              {v.symbol}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {f.variables
                          .filter(v => v.symbol !== targetVar)
                          .map(v => (
                            <div key={v.symbol} className="flex flex-col gap-0.5">
                              <span className="text-slate-400 text-[10px] truncate">
                                {v.name} ({v.symbol}){v.unit ? ` [${v.unit}]` : ''}:
                              </span>
                              <input
                                type="number"
                                step="any"
                                value={varValues[v.symbol] ?? v.defaultValue ?? 0}
                                onChange={e => {
                                  const val = parseFloat(e.target.value) || 0;
                                  setVarValues(prev => ({ ...prev, [v.symbol]: val }));
                                }}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1 text-white text-xs font-mono"
                              />
                            </div>
                          ))}
                      </div>

                      <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between mt-1">
                        <span className="text-slate-400 text-[11px]">
                          Calculated <strong className="text-white">{targetVar}</strong>:
                        </span>
                        <span className="text-sm font-bold text-emerald-400">
                          {solvedVal !== null && !isNaN(solvedVal)
                            ? `${parseFloat(solvedVal.toFixed(6))} ${targetVarObj?.unit || ''}`
                            : 'Undefined / Out of Range'}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 gap-2">
                    <span className="text-[11px] font-mono text-indigo-400 truncate">{f.formula}</span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleSolver(f)}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                          isSolving
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800'
                        }`}
                      >
                        <Calculator className="w-3 h-3" />
                        {isSolving ? 'Close' : 'Solve'}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onInsertFormula(f.formula);
                          onClose();
                        }}
                        className="px-2.5 py-1 rounded bg-indigo-600/30 hover:bg-indigo-600/60 text-indigo-300 hover:text-white text-xs font-medium flex items-center gap-1"
                      >
                        <span>Use</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
