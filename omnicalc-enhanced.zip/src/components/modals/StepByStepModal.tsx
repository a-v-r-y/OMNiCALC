import React, { useState } from 'react';
import { MathView } from '../MathView';
import {
  solveQuadraticStepByStep,
  solveLinearStepByStep,
  solvePrimeFactorizationStepByStep,
  solveFractionArithmeticStepByStep
} from '../../utils/stepByStepSolvers';
import { StepSolution } from '../../types/calc';
import { Sparkles, X, Calculator, Copy, Check, ArrowRight, Layers } from 'lucide-react';

interface StepByStepModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertResult?: (expr: string) => void;
}

export const StepByStepModal: React.FC<StepByStepModalProps> = ({
  isOpen,
  onClose,
  onInsertResult
}) => {
  const [problemType, setProblemType] = useState<'quadratic' | 'linear' | 'factors' | 'fractions'>('quadratic');

  // Quadratic inputs: ax^2 + bx + c = 0
  const [quadA, setQuadA] = useState<number>(1);
  const [quadB, setQuadB] = useState<number>(-5);
  const [quadC, setQuadC] = useState<number>(6);

  // Linear inputs: ax + b = c
  const [linA, setLinA] = useState<number>(3);
  const [linB, setLinB] = useState<number>(7);
  const [linC, setLinC] = useState<number>(22);

  // Prime factorization input
  const [factorN, setFactorN] = useState<number>(360);

  // Fraction inputs
  const [fracN1, setFracN1] = useState<number>(3);
  const [fracD1, setFracD1] = useState<number>(4);
  const [fracOp, setFracOp] = useState<'+' | '-' | '*' | '/'>('+');
  const [fracN2, setFracN2] = useState<number>(2);
  const [fracD2, setFracD2] = useState<number>(5);

  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  let solution: StepSolution;
  if (problemType === 'quadratic') {
    solution = solveQuadraticStepByStep(quadA, quadB, quadC);
  } else if (problemType === 'linear') {
    solution = solveLinearStepByStep(linA, linB, linC);
  } else if (problemType === 'factors') {
    solution = solvePrimeFactorizationStepByStep(factorN);
  } else {
    solution = solveFractionArithmeticStepByStep(fracN1, fracD1, fracOp, fracN2, fracD2);
  }

  const handleCopy = () => {
    const text = `${solution.title}\nProblem: ${solution.problem}\n\nSteps:\n${solution.steps
      .map((s, i) => `${i + 1}. ${s.label}: ${s.explanation || ''} [${s.math}]`)
      .join('\n')}\n\nResult: ${solution.finalResult}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Step-by-Step Mathematical Solver
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Detailed derivations with natural textbook typesetting and intermediate rules
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Problem Type Tabs */}
        <div className="flex items-center gap-1.5 px-5 py-2.5 border-b border-slate-800/80 bg-slate-900 text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setProblemType('quadratic')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              problemType === 'quadratic' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Quadratic (ax² + bx + c = 0)
          </button>
          <button
            type="button"
            onClick={() => setProblemType('linear')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              problemType === 'linear' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Linear (ax + b = c)
          </button>
          <button
            type="button"
            onClick={() => setProblemType('factors')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              problemType === 'factors' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Prime Factor Tree
          </button>
          <button
            type="button"
            onClick={() => setProblemType('fractions')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              problemType === 'fractions' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Fraction Arithmetic
          </button>
        </div>

        {/* Dynamic Parameter Controls */}
        <div className="p-4 bg-slate-950/70 border-b border-slate-800 flex flex-wrap items-center gap-3 text-xs font-mono">
          {problemType === 'quadratic' && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-400 font-sans">Equation:</span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={quadA}
                  onChange={e => setQuadA(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
                <span className="text-slate-300">x² +</span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={quadB}
                  onChange={e => setQuadB(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
                <span className="text-slate-300">x +</span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={quadC}
                  onChange={e => setQuadC(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
                <span className="text-slate-300">= 0</span>
              </div>
            </div>
          )}

          {problemType === 'linear' && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-400 font-sans">Equation:</span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={linA}
                  onChange={e => setLinA(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
                <span className="text-slate-300">x +</span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={linB}
                  onChange={e => setLinB(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
                <span className="text-slate-300">=</span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={linC}
                  onChange={e => setLinC(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                />
              </div>
            </div>
          )}

          {problemType === 'factors' && (
            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-sans">Integer to factorize:</span>
              <input
                type="number"
                min="2"
                max="10000000"
                value={factorN}
                onChange={e => setFactorN(parseInt(e.target.value, 10) || 2)}
                className="w-28 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
              />
            </div>
          )}

          {problemType === 'fractions' && (
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={fracN1}
                  onChange={e => setFracN1(parseFloat(e.target.value) || 0)}
                  className="w-14 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-white text-center"
                />
                <span>/</span>
                <input
                  type="number"
                  value={fracD1}
                  onChange={e => setFracD1(parseFloat(e.target.value) || 1)}
                  className="w-14 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-white text-center"
                />
              </div>

              <select
                value={fracOp}
                onChange={e => setFracOp(e.target.value as any)}
                className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
              >
                <option value="+">+</option>
                <option value="-">−</option>
                <option value="*">×</option>
                <option value="/">÷</option>
              </select>

              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={fracN2}
                  onChange={e => setFracN2(parseFloat(e.target.value) || 0)}
                  className="w-14 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-white text-center"
                />
                <span>/</span>
                <input
                  type="number"
                  value={fracD2}
                  onChange={e => setFracD2(parseFloat(e.target.value) || 1)}
                  className="w-14 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-white text-center"
                />
              </div>
            </div>
          )}
        </div>

        {/* Steps Content Area */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
          {/* Problem Banner */}
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider font-mono">
                {solution.category} Problem
              </div>
              <div className="text-sm font-semibold text-white mt-0.5">
                {solution.problemLatex ? (
                  <MathView math={solution.problemLatex} rawText={solution.problem} block />
                ) : (
                  solution.problem
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Solution'}</span>
            </button>
          </div>

          {/* Derivation Steps List */}
          <div className="space-y-3">
            {solution.steps.map((step, idx) => (
              <div
                key={idx}
                className="p-4 bg-slate-950/80 border border-slate-800/80 rounded-xl flex flex-col gap-2"
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-300 flex items-center justify-center font-mono text-[11px] font-bold">
                    {idx + 1}
                  </span>
                  <span className="text-xs font-semibold text-slate-200">{step.label}</span>
                </div>

                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800/80 overflow-x-auto my-1">
                  <MathView math={step.math} block />
                </div>

                {step.explanation && (
                  <p className="text-xs text-slate-400 leading-relaxed font-sans">{step.explanation}</p>
                )}
              </div>
            ))}
          </div>

          {/* Final Answer Highlight */}
          <div className="p-4 bg-emerald-950/40 border border-emerald-800/60 rounded-xl flex items-center justify-between">
            <div>
              <div className="text-xs font-mono uppercase text-emerald-400 font-semibold">
                Final Result
              </div>
              <div className="text-base font-bold text-white mt-1">
                {solution.finalMath ? (
                  <MathView math={solution.finalMath} rawText={solution.finalResult} block />
                ) : (
                  solution.finalResult
                )}
              </div>
            </div>

            {onInsertResult && (
              <button
                type="button"
                onClick={() => {
                  onInsertResult(solution.finalResult);
                  onClose();
                }}
                className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow transition-colors"
              >
                <span>Use Result</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
