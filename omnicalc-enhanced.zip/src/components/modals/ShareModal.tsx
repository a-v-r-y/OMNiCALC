import React, { useState } from 'react';
import { Share2, X, Copy, Check, ExternalLink, MessageSquare, FileCode } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  expression: string;
  result: string;
  latex?: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  expression,
  result,
  latex
}) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const shareableUrl = `${currentOrigin}?expr=${encodeURIComponent(expression)}`;

  const markdownSnippet = `\`\`\`math\n${expression} = ${result}\n\`\`\``;
  const latexSnippet = `\\begin{equation}\n${latex || expression} = ${result}\n\\end{equation}`;

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 1500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'OmniCalc Calculation Result',
          text: `${expression} = ${result}`,
          url: shareableUrl
        });
      } catch {
        // User cancelled or share failed
      }
    } else {
      copyToClipboard(shareableUrl, 'link');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Share Calculation & Results
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Export shareable link, Markdown, or academic LaTeX
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col gap-4 text-xs">
          {/* Active Result Preview */}
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span className="text-[11px] font-mono text-slate-400 truncate">{expression}</span>
            <span className="text-lg font-bold font-mono text-white">= {result}</span>
          </div>

          {/* Shareable Link */}
          <div className="flex flex-col gap-1.5">
            <label className="font-semibold text-slate-300">Shareable Calculation URL</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareableUrl}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 font-mono text-xs focus:outline-none"
              />
              <button
                type="button"
                onClick={() => copyToClipboard(shareableUrl, 'url')}
                className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium flex items-center gap-1.5 shrink-0 transition-colors"
              >
                {copiedType === 'url' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedType === 'url' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Web Share Native Button (if available) */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              type="button"
              onClick={handleNativeShare}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span>Share via Device Menu...</span>
            </button>
          )}

          {/* Formatted Markdown */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300 flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                Markdown Format (Discord / GitHub / Slack)
              </span>
              <button
                type="button"
                onClick={() => copyToClipboard(markdownSnippet, 'markdown')}
                className="text-indigo-400 hover:text-indigo-300 font-medium"
              >
                {copiedType === 'markdown' ? 'Copied!' : 'Copy Markdown'}
              </button>
            </div>
            <pre className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-mono text-slate-400 overflow-x-auto">
              {markdownSnippet}
            </pre>
          </div>

          {/* Academic LaTeX */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300 flex items-center gap-1">
                <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                LaTeX Equation (Overleaf / Papers)
              </span>
              <button
                type="button"
                onClick={() => copyToClipboard(latexSnippet, 'latex')}
                className="text-emerald-400 hover:text-emerald-300 font-medium"
              >
                {copiedType === 'latex' ? 'Copied!' : 'Copy LaTeX'}
              </button>
            </div>
            <pre className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-mono text-slate-400 overflow-x-auto">
              {latexSnippet}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
