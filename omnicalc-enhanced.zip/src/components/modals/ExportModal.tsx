import React, { useState } from 'react';
import { HistoryItem } from '../../types/calc';
import { Download, X, Copy, Check, FileText, Table, Code, FileSpreadsheet } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  history
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  // 1. Text Tape format
  const exportTxt = () => {
    const lines = [
      '========================================',
      '        OMNICALC CALCULATION TAPE       ',
      `        Exported: ${new Date().toLocaleString()}`,
      `        Total Operations: ${history.length}`,
      '========================================\n'
    ];
    history.forEach((h, idx) => {
      const time = new Date(h.timestamp).toLocaleTimeString();
      lines.push(`[${time}] #${idx + 1}`);
      lines.push(`  Expr:   ${h.expression}`);
      lines.push(`  Result: = ${h.result} (${h.angleUnit.toUpperCase()})`);
      if (h.exactFraction) lines.push(`  Frac:   = ${h.exactFraction}`);
      lines.push('----------------------------------------');
    });
    downloadFile(lines.join('\n'), `omnicalc_tape_${Date.now()}.txt`, 'text/plain;charset=utf-8');
  };

  // 2. CSV format
  const exportCsv = () => {
    const rows = [['Timestamp', 'Time', 'Expression', 'Result', 'ExactFraction', 'AngleUnit']];
    history.forEach(h => {
      rows.push([
        h.timestamp.toString(),
        new Date(h.timestamp).toISOString(),
        `"${h.expression.replace(/"/g, '""')}"`,
        `"${h.result.replace(/"/g, '""')}"`,
        `"${(h.exactFraction || '').replace(/"/g, '""')}"`,
        h.angleUnit
      ]);
    });
    const csvContent = rows.map(r => r.join(',')).join('\n');
    downloadFile(csvContent, `omnicalc_data_${Date.now()}.csv`, 'text/csv;charset=utf-8');
  };

  // 3. JSON format
  const exportJson = () => {
    const jsonStr = JSON.stringify(history, null, 2);
    downloadFile(jsonStr, `omnicalc_history_${Date.now()}.json`, 'application/json');
  };

  // 4. LaTeX Document format
  const exportLatex = () => {
    const lines = [
      '\\documentclass{article}',
      '\\usepackage{amsmath}',
      '\\usepackage{geometry}',
      '\\geometry{margin=1in}',
      '\\title{OmniCalc Calculation Report}',
      `\\date{${new Date().toLocaleDateString()}}`,
      '\\begin{document}',
      '\\maketitle',
      '\\section*{Calculations Tape}',
      '\\begin{align*}'
    ];

    history.forEach(h => {
      const texExpr = h.latex || h.expression;
      lines.push(`  ${texExpr} &= ${h.result} \\\\`);
    });

    lines.push('\\end{align*}');
    lines.push('\\end{document}');
    downloadFile(lines.join('\n'), `omnicalc_report_${Date.now()}.tex`, 'text/x-tex');
  };

  const copyAllToClipboard = () => {
    const text = history
      .map(h => `${new Date(h.timestamp).toLocaleTimeString()}: ${h.expression} = ${h.result}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Export Calculations & History
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                {history.length} operations stored in session
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Options */}
        <div className="p-5 flex flex-col gap-3 text-xs">
          {history.length === 0 ? (
            <div className="py-6 text-center text-slate-500">
              No calculations recorded yet to export. Evaluate some expressions first!
            </div>
          ) : (
            <>
              {/* Text File */}
              <button
                type="button"
                onClick={exportTxt}
                className="p-3.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl flex items-center justify-between transition-colors group text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 text-slate-300 group-hover:text-white border border-slate-800">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200">Text Tape (.txt)</div>
                    <div className="text-slate-500 text-[11px]">Formatted printable paper tape</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-white" />
              </button>

              {/* CSV Spreadsheet */}
              <button
                type="button"
                onClick={exportCsv}
                className="p-3.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl flex items-center justify-between transition-colors group text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 text-slate-300 group-hover:text-white border border-slate-800">
                    <Table className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200">Spreadsheet CSV (.csv)</div>
                    <div className="text-slate-500 text-[11px]">Excel / Google Sheets tabular data</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-white" />
              </button>

              {/* JSON */}
              <button
                type="button"
                onClick={exportJson}
                className="p-3.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl flex items-center justify-between transition-colors group text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 text-slate-300 group-hover:text-white border border-slate-800">
                    <Code className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200">JSON Data (.json)</div>
                    <div className="text-slate-500 text-[11px]">Structured dataset for developers</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-white" />
              </button>

              {/* LaTeX */}
              <button
                type="button"
                onClick={exportLatex}
                className="p-3.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl flex items-center justify-between transition-colors group text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 text-slate-300 group-hover:text-white border border-slate-800">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200">LaTeX Document (.tex)</div>
                    <div className="text-slate-500 text-[11px]">Typeset academic align report</div>
                  </div>
                </div>
                <Download className="w-4 h-4 text-slate-400 group-hover:text-white" />
              </button>

              {/* Copy all to clipboard */}
              <button
                type="button"
                onClick={copyAllToClipboard}
                className="mt-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy Entire Tape to Clipboard'}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
