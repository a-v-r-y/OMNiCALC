import React, { useState } from 'react';
import { MathView } from '../MathView';
import {
  HelpCircle,
  X,
  Keyboard,
  BookOpen,
  Sparkles,
  Layers,
  Code,
  Smartphone,
  Check,
  Copy
} from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadExample?: (expr: string) => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  onLoadExample
}) => {
  const [activeTab, setActiveTab] = useState<'shortcuts' | 'syntax' | 'examples' | 'gestures'>('shortcuts');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 1500);
  };

  const KEYBOARD_SHORTCUTS = [
    { key: 'Enter or =', description: 'Evaluate current expression or statement' },
    { key: 'Escape', description: 'Clear expression input or dismiss active modal' },
    { key: 'Backspace', description: 'Delete previous character or selection' },
    { key: 'ArrowUp / ArrowDown', description: 'Recall previous / next calculation from history tape' },
    { key: 'Ctrl + C / Cmd + C', description: 'Copy evaluated result or LaTeX to clipboard' },
    { key: 'Ctrl + V / Cmd + V', description: 'Paste equation or data into calculator' },
    { key: 's, c, t', description: 'Quick insert sin(), cos(), tan()' },
    { key: 'l', description: 'Quick insert ln()' },
    { key: 'r', description: 'Quick insert sqrt()' },
    { key: 'p', description: 'Insert constant pi (π)' },
    { key: 'e', description: 'Insert Euler number (e)' },
    { key: 'a', description: 'Insert previous answer variable (Ans)' },
    { key: '( ) [ ] { }', description: 'Smart nested bracket handling & wrapping' }
  ];

  const SYNTAX_RULES = [
    {
      title: 'Implicit Multiplication',
      syntax: '2x, 4pi, 3(4 + 5), 2sin(x)',
      explanation: 'Multiplication operators can be omitted between numbers, variables, and bracket groups.'
    },
    {
      title: 'Exponents & Powers',
      syntax: 'x^2, 2^8, (a + b)^3',
      explanation: 'Use the caret symbol (^) for powers and exponentiation.'
    },
    {
      title: 'Variable Assignment',
      syntax: 'radius = 15, area = pi * radius^2',
      explanation: 'Store numbers and expressions in variables to reuse in subsequent calculations.'
    },
    {
      title: 'Complex Numbers',
      syntax: '3 + 4i, (2 - i) * (1 + 2i)',
      explanation: 'Use i for the imaginary unit. Full polar and rectangular arithmetic supported.'
    },
    {
      title: 'Matrices & Vectors',
      syntax: '[[1, 2], [3, 4]], det([[2, 0], [1, 5]])',
      explanation: 'Define nested square brackets for 2D matrices. Use det(), inv(), transpose().'
    },
    {
      title: 'Calculus & CAS',
      syntax: 'derivative("x^3 + 4*x", "x"), simplify("2x + 3x")',
      explanation: 'Symbolic differentiation and algebraic expression simplification.'
    }
  ];

  const EXAMPLES = [
    { label: 'Basic Trig & Constants', expr: 'sin(pi / 4) + cos(pi / 4)' },
    { label: 'Exact Radicals & Powers', expr: 'sqrt(18) + sqrt(50)' },
    { label: 'Scientific Engineering', expr: '6.626e-34 * 3e8 / 500e-9' },
    { label: 'Matrix Determinant', expr: 'det([[4, 7], [2, 6]])' },
    { label: 'Combinatorics & Factorial', expr: 'combinations(12, 4) * 4!' },
    { label: 'Complex Number Euler', expr: 'exp(i * pi) + 1' },
    { label: 'Polynomial CAS Simplify', expr: 'simplify("2x + 5x + x^2 - x")' },
    { label: 'Symbolic Derivative', expr: 'derivative("x^3 * sin(x)", "x")' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                OmniCalc System Help & User Guide
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Keyboard shortcuts, natural mathematical syntax, and touch controls
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-5 py-2.5 border-b border-slate-800/80 bg-slate-900 text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('shortcuts')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'shortcuts'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5" />
            Keyboard Shortcuts
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('syntax')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'syntax'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Math Notation & Syntax
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('examples')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'examples'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Interactive Examples
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('gestures')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'gestures'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Touch & Gestures
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* Shortcuts Tab */}
          {activeTab === 'shortcuts' && (
            <div className="flex flex-col gap-3">
              <p className="text-xs text-slate-400">
                OmniCalc is optimized for high-speed scientific and engineering workflow using standard physical keyboards:
              </p>
              <div className="divide-y divide-slate-800/80 border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
                {KEYBOARD_SHORTCUTS.map(sc => (
                  <div key={sc.key} className="flex items-center justify-between p-3 text-xs">
                    <kbd className="px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded font-mono text-indigo-300 font-semibold shadow-sm">
                      {sc.key}
                    </kbd>
                    <span className="text-slate-300 text-right">{sc.description}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Syntax Tab */}
          {activeTab === 'syntax' && (
            <div className="grid grid-cols-1 gap-3.5">
              {SYNTAX_RULES.map(rule => (
                <div key={rule.title} className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-white">{rule.title}</span>
                    <code className="text-xs font-mono text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
                      {rule.syntax}
                    </code>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{rule.explanation}</p>
                </div>
              ))}
            </div>
          )}

          {/* Examples Tab */}
          {activeTab === 'examples' && (
            <div className="flex flex-col gap-3">
              <p className="text-xs text-slate-400">
                Click any calculation below to immediately load it into your calculator:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {EXAMPLES.map(ex => (
                  <div
                    key={ex.label}
                    className="p-3 bg-slate-950 border border-slate-800 hover:border-indigo-600/50 rounded-xl flex flex-col justify-between gap-2 group transition-all"
                  >
                    <div>
                      <span className="text-xs font-semibold text-slate-300">{ex.label}</span>
                      <div className="text-xs font-mono text-indigo-400 bg-slate-900 p-1.5 rounded mt-1 border border-slate-800">
                        {ex.expr}
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-800/60">
                      <button
                        type="button"
                        onClick={() => handleCopy(ex.expr)}
                        className="p-1 text-slate-400 hover:text-white rounded"
                        title="Copy text"
                      >
                        {copiedText === ex.expr ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      {onLoadExample && (
                        <button
                          type="button"
                          onClick={() => {
                            onLoadExample(ex.expr);
                            onClose();
                          }}
                          className="px-2.5 py-1 rounded bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-medium transition-colors"
                        >
                          Try It
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Touch & Gestures Tab */}
          {activeTab === 'gestures' && (
            <div className="flex flex-col gap-3.5">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col gap-2">
                <span className="text-sm font-semibold text-white">Interactive Graph Gestures</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  • <strong>Pan / Drag:</strong> Touch or click-and-drag across the canvas to shift coordinate centers in real time.
                  <br />
                  • <strong>Zoom:</strong> Pinch with two fingers or use the mouse scroll wheel over the canvas to zoom in and out smoothly.
                  <br />
                  • <strong>Trace Inspection:</strong> Hover or touch on any curve to display instantaneous coordinates (x, y) and tangent slope dy/dx.
                  <br />
                  • <strong>3D Surface Rotation:</strong> Drag on 3D graphs to rotate spherical azimuth and elevation angles.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col gap-2">
                <span className="text-sm font-semibold text-white">Tactile Keypad Design</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Every button meets mobile touch targets (&gt;= 44px) with active spring physics and optional audio synthesizer click feedback.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-500">
          <span>OmniCalc Help System</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
