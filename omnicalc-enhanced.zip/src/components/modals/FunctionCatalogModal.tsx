import React, { useState } from 'react';
import { FUNCTION_CATALOG } from '../../utils/functionCatalog';
import { FunctionDef } from '../../types/calc';
import { Search, Sparkles, X, ArrowRight, BookOpen, Tag } from 'lucide-react';

interface FunctionCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertFunction: (syntax: string) => void;
}

const CATEGORIES = [
  'All',
  'Arithmetic & Basic',
  'Algebra & Polynomials',
  'Trigonometry',
  'Hyperbolic',
  'Exponential & Log',
  'Calculus & Analysis',
  'Probability & Statistics',
  'Linear Algebra & Matrices',
  'Complex Numbers',
  'Discrete & Bitwise',
  'Constants'
];

export const FunctionCatalogModal: React.FC<FunctionCatalogModalProps> = ({
  isOpen,
  onClose,
  onInsertFunction
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  if (!isOpen) return null;

  const filteredFunctions = FUNCTION_CATALOG.filter(fn => {
    const matchesCategory = selectedCategory === 'All' || fn.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    if (!q) return matchesCategory;

    const matchesName = fn.name.toLowerCase().includes(q);
    const matchesSyntax = fn.syntax.toLowerCase().includes(q);
    const matchesDesc = fn.description.toLowerCase().includes(q);
    const matchesTags = fn.tags.some(t => t.toLowerCase().includes(q));

    return matchesCategory && (matchesName || matchesSyntax || matchesDesc || matchesTags);
  });

  const handleInsert = (fn: FunctionDef) => {
    // If syntax has parameters like sin(x), insert sin(
    let toInsert = fn.syntax;
    if (fn.syntax.includes('(')) {
      toInsert = fn.syntax.substring(0, fn.syntax.indexOf('(') + 1);
    }
    onInsertFunction(toInsert);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Searchable Function Library
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Over 100+ mathematical, scientific, statistical, and algebraic functions
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-900/90 flex flex-col gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search functions by name, keyword, or math operation (e.g. 'sine', 'matrix', 'integral', 'gcd')..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-sans"
              autoFocus
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Categories Pill Scroller */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Functions Grid */}
        <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredFunctions.length === 0 ? (
            <div className="col-span-full py-12 flex flex-col items-center justify-center text-center text-slate-500">
              <Search className="w-8 h-8 mb-2 opacity-40" />
              <p className="text-sm font-medium">No functions found matching "{searchQuery}"</p>
              <p className="text-xs text-slate-600 mt-1">Try searching for broader keywords like "trig", "log", or "matrix"</p>
            </div>
          ) : (
            filteredFunctions.map(fn => (
              <div
                key={fn.name}
                className="bg-slate-950/80 border border-slate-800 hover:border-indigo-600/50 rounded-xl p-3.5 flex flex-col justify-between gap-2.5 transition-all group hover:bg-slate-950"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono font-bold text-sm text-indigo-300">
                      {fn.syntax}
                    </span>
                    <span className="text-[10px] font-sans px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 shrink-0">
                      {fn.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-sans mt-1.5 leading-relaxed">
                    {fn.description}
                  </p>

                  <div className="mt-2 text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-sans">Example:</span>
                    <code className="text-emerald-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800/80">
                      {fn.example}
                    </code>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 mt-1">
                  <div className="flex items-center gap-1 overflow-hidden">
                    {fn.tags.slice(0, 2).map(tag => (
                      <span key={tag} className="text-[10px] text-slate-500 truncate">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleInsert(fn)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-medium transition-all"
                  >
                    <span>Insert</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-500">
          <span>Showing {filteredFunctions.length} of {FUNCTION_CATALOG.length} functions</span>
          <span className="font-mono">Tip: Click "Insert" to add function to expression</span>
        </div>
      </div>
    </div>
  );
};
