import React, { useState, useEffect } from 'react';
import { Clock, Calendar } from 'lucide-react';

interface DigitalClockProps {
  className?: string;
}

export const DigitalClock: React.FC<DigitalClockProps> = ({ className = '' }) => {
  const [time, setTime] = useState<Date>(new Date());
  const [use24Hour, setUse24Hour] = useState<boolean>(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format time
  const hoursRaw = time.getHours();
  const minutes = String(time.getMinutes()).padStart(2, '0');
  const seconds = String(time.getSeconds()).padStart(2, '0');
  const ampm = hoursRaw >= 12 ? 'PM' : 'AM';

  let displayHours = hoursRaw;
  if (!use24Hour) {
    displayHours = hoursRaw % 12 || 12;
  }
  const hoursStr = String(displayHours).padStart(2, '0');

  // Format date
  const dayName = time.toLocaleDateString(undefined, { weekday: 'short' });
  const monthName = time.toLocaleDateString(undefined, { month: 'short' });
  const dayNumber = time.getDate();
  const year = time.getFullYear();

  return (
    <div
      id="live-digital-clock"
      onClick={() => setUse24Hour(prev => !prev)}
      title="Click to toggle 12h / 24h format"
      className={`group cursor-pointer select-none flex items-center gap-2.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl transition-all shadow-sm ${className}`}
    >
      {/* Date badge */}
      <div className="flex items-center gap-1.5 text-slate-400 group-hover:text-slate-300 text-xs font-medium border-r border-slate-800/80 pr-2.5">
        <Calendar className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
        <span className="whitespace-nowrap font-sans text-[11px] sm:text-xs">
          <span className="hidden sm:inline">{dayName}, </span>
          {monthName} {dayNumber}, {year}
        </span>
      </div>

      {/* Digital Clock digits */}
      <div className="flex items-center gap-1 font-mono tracking-wider text-xs sm:text-sm">
        <Clock className="w-3.5 h-3.5 text-indigo-400 shrink-0 mr-0.5 hidden xs:inline-block" />
        <span className="font-bold text-white bg-slate-950 px-1 py-0.5 rounded border border-slate-800/60">
          {hoursStr}
        </span>
        <span className="text-indigo-400 animate-pulse font-bold">:</span>
        <span className="font-bold text-white bg-slate-950 px-1 py-0.5 rounded border border-slate-800/60">
          {minutes}
        </span>
        <span className="text-indigo-400 animate-pulse font-bold">:</span>
        <span className="font-semibold text-indigo-300 bg-slate-950 px-1 py-0.5 rounded border border-slate-800/60 text-xs">
          {seconds}
        </span>

        {!use24Hour && (
          <span className="text-[10px] font-bold text-indigo-400 uppercase ml-1 px-1 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20">
            {ampm}
          </span>
        )}
      </div>
    </div>
  );
};
