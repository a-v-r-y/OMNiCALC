import React, { useState } from 'react';
import { FlaskConical, Zap, DollarSign, Shapes, Calendar, Rocket, Wrench } from 'lucide-react';
import { FinanceSolversView } from './FinanceSolversView';
import { PhysicsSolversView } from './PhysicsSolversView';
import { ChemistrySolversView } from './ChemistrySolversView';
import { GeometrySolversView } from './GeometrySolversView';
import { ElectronicsSolversView } from './ElectronicsSolversView';
import { MechanicalSolversView } from './MechanicalSolversView';
import { DateSolversView } from './DateSolversView';

export const StemSolversView: React.FC = () => {
  const [subTab, setSubTab] = useState<'chemistry' | 'physics' | 'mechanical' | 'electronics' | 'finance' | 'geometry' | 'datetime'>('chemistry');

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Sub tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setSubTab('chemistry')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'chemistry' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5" />
          Chemistry
        </button>
        <button
          type="button"
          onClick={() => setSubTab('physics')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'physics' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Rocket className="w-3.5 h-3.5" />
          Physics
        </button>
        <button
          type="button"
          onClick={() => setSubTab('mechanical')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'mechanical' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          Mechanical
        </button>
        <button
          type="button"
          onClick={() => setSubTab('electronics')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'electronics' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          Electronics
        </button>
        <button
          type="button"
          onClick={() => setSubTab('finance')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'finance' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          Finance & Loans
        </button>
        <button
          type="button"
          onClick={() => setSubTab('geometry')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'geometry' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shapes className="w-3.5 h-3.5" />
          Geometry (2D/3D)
        </button>
        <button
          type="button"
          onClick={() => setSubTab('datetime')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'datetime' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          Date & Time
        </button>
      </div>

      {/* 1. Chemistry */}
      {subTab === 'chemistry' && <ChemistrySolversView />}

      {/* 2. Physics */}
      {subTab === 'physics' && <PhysicsSolversView />}

      {/* 3. Mechanical */}
      {subTab === 'mechanical' && <MechanicalSolversView />}

      {/* 4. Electronics */}
      {subTab === 'electronics' && <ElectronicsSolversView />}

      {/* 4. Finance */}
      {subTab === 'finance' && <FinanceSolversView />}

      {/* 5. Geometry */}
      {subTab === 'geometry' && <GeometrySolversView />}

      {/* 6. Date & Time */}
      {subTab === 'datetime' && <DateSolversView />}
    </div>
  );
};
