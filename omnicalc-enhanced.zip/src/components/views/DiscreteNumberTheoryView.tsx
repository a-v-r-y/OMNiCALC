import React, { useState } from 'react';
import {
  isPrime,
  primeFactors,
  formatPrimeFactors,
  gcdEuclidean,
  lcm,
  modInverse,
  modPow,
  eulerTotient,
  divisors,
  generateTruthTable,
  TruthTableRow
} from '../../utils/discreteAndNumberTheory';
import { Binary, Sparkles, Table2, Calculator } from 'lucide-react';

export const DiscreteNumberTheoryView: React.FC = () => {
  const [subTab, setSubTab] = useState<'primes' | 'modular' | 'combinatorics' | 'logic'>('primes');

  // Primes & Divisors
  const [primeInput, setPrimeInput] = useState<number>(360);
  const [primeResult, setPrimeResult] = useState<any | null>(null);

  // GCD & LCM
  const [gcdA, setGcdA] = useState<number>(48);
  const [gcdB, setGcdB] = useState<number>(180);
  const [gcdResult, setGcdResult] = useState<any | null>(null);

  // Modular Math
  const [modBase, setModBase] = useState<number>(7);
  const [modExp, setModExp] = useState<number>(256);
  const [modM, setModM] = useState<number>(13);
  const [modResult, setModResult] = useState<any | null>(null);

  // Logic Truth Table
  const [logicExpr, setLogicExpr] = useState<string>('(A and B) or (not C)');
  const [truthTable, setTruthTable] = useState<TruthTableRow[] | null>(null);

  const handleComputePrime = () => {
    const p = isPrime(primeInput);
    const factors = formatPrimeFactors(primeInput);
    const divs = divisors(primeInput);
    const phi = eulerTotient(primeInput);
    setPrimeResult({
      isPrime: p,
      factors,
      divisors: divs,
      eulerTotient: phi
    });
  };

  const handleComputeGCD = () => {
    const { gcd, steps } = gcdEuclidean(gcdA, gcdB);
    const l = lcm(gcdA, gcdB);
    setGcdResult({ gcd, lcm: l, steps });
  };

  const handleComputeMod = () => {
    const pow = modPow(modBase, modExp, modM);
    const inv = modInverse(modBase, modM);
    setModResult({
      modPow: pow,
      modInverse: inv !== null ? inv : 'Does not exist (gcd(a,m) ≠ 1)'
    });
  };

  const handleGenerateTruthTable = () => {
    const table = generateTruthTable(logicExpr);
    setTruthTable(table);
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Sub tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setSubTab('primes')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'primes' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Primes & Divisors
        </button>
        <button
          type="button"
          onClick={() => setSubTab('modular')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'modular' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          GCD, LCM & Modular Math
        </button>
        <button
          type="button"
          onClick={() => setSubTab('logic')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'logic' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Logic & Truth Tables
        </button>
      </div>

      {/* 1. Primes & Divisors */}
      {subTab === 'primes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Integer Number Theory Analyzer
            </div>
            <p className="text-xs text-slate-400">
              Enter any integer to test primality, prime factors, and Euler's totient:
            </p>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={primeInput}
                onChange={e => setPrimeInput(parseInt(e.target.value, 10) || 1)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm font-mono text-white"
              />
              <button
                type="button"
                onClick={handleComputePrime}
                className="py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
              >
                Factorize
              </button>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Factorization Breakdown
            </div>
            {primeResult ? (
              <div className="w-full flex flex-col gap-2.5 font-mono text-xs">
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">Primality:</span>
                  <span
                    className={`font-bold ${
                      primeResult.isPrime ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {primeResult.isPrime ? 'PRIME NUMBER' : 'COMPOSITE'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400">Prime Factorization:</span>
                  <div className="text-sm font-bold text-indigo-300 mt-0.5">
                    {primeInput} = {primeResult.factors}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-slate-400">Euler's Totient φ({primeInput}):</span>
                  <span className="text-sm font-bold text-white ml-2">
                    {primeResult.eulerTotient}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 max-h-24 overflow-y-auto">
                  <span className="text-slate-400">
                    Divisors ({primeResult.divisors.length}):
                  </span>
                  <div className="text-slate-300 text-[11px] mt-0.5">
                    {primeResult.divisors.join(', ')}
                  </div>
                </div>
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Enter an integer to view prime factorization.
              </span>
            )}
          </div>
        </div>
      )}

      {/* 2. Modular & GCD */}
      {subTab === 'modular' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Euclidean GCD */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              Euclidean Algorithm: GCD & LCM
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400">Number A:</span>
                <input
                  type="number"
                  value={gcdA}
                  onChange={e => setGcdA(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Number B:</span>
                <input
                  type="number"
                  value={gcdB}
                  onChange={e => setGcdB(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
            </div>
            <button
              type="button"
              onClick={handleComputeGCD}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Compute GCD & LCM
            </button>

            {gcdResult && (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs flex flex-col gap-1.5">
                <div>
                  GCD({gcdA}, {gcdB}) = <strong className="text-emerald-300">{gcdResult.gcd}</strong>
                </div>
                <div>
                  LCM({gcdA}, {gcdB}) = <strong className="text-indigo-300">{gcdResult.lcm}</strong>
                </div>
                <div className="text-slate-500 text-[11px] mt-1 border-t border-slate-800 pt-1">
                  Steps:
                  {gcdResult.steps.map((s: string, idx: number) => (
                    <div key={idx}>{s}</div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Modular Exponentiation & Inverse */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              Modular Power & Inverse
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-slate-400">Base b:</span>
                <input
                  type="number"
                  value={modBase}
                  onChange={e => setModBase(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Exponent e:</span>
                <input
                  type="number"
                  value={modExp}
                  onChange={e => setModExp(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Modulus m:</span>
                <input
                  type="number"
                  value={modM}
                  onChange={e => setModM(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
            </div>
            <button
              type="button"
              onClick={handleComputeMod}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Compute Modular Math
            </button>

            {modResult && (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs flex flex-col gap-1.5">
                <div>
                  {modBase}^{modExp} mod {modM} = <strong className="text-emerald-300">{modResult.modPow}</strong>
                </div>
                <div>
                  {modBase}⁻¹ mod {modM} = <strong className="text-indigo-300">{modResult.modInverse}</strong>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. Logic & Truth Tables */}
      {subTab === 'logic' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
          <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
            <Table2 className="w-4 h-4 text-indigo-400" />
            Propositional Logic Truth Table Generator
          </div>
          <p className="text-xs text-slate-400">
            Enter any boolean expression using <code className="text-indigo-300">and</code>, <code className="text-indigo-300">or</code>, <code className="text-indigo-300">not</code>, <code className="text-indigo-300">xor</code>, with variables (e.g. A, B, C):
          </p>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={logicExpr}
              onChange={e => setLogicExpr(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm font-mono text-white"
            />
            <button
              type="button"
              onClick={handleGenerateTruthTable}
              className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Generate Table
            </button>
          </div>

          {truthTable && truthTable.length > 0 && (
            <div className="overflow-x-auto max-h-72 border border-slate-800 rounded-xl font-mono text-xs">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-950 text-slate-400 sticky top-0 border-b border-slate-800">
                  <tr>
                    {Object.keys(truthTable[0].inputs).map(v => (
                      <th key={v} className="p-2.5 text-center">
                        {v}
                      </th>
                    ))}
                    <th className="p-2.5 text-indigo-300 text-center">Output</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 bg-slate-900/60">
                  {truthTable.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      {Object.values(row.inputs).map((val, i) => (
                        <td key={i} className="p-2.5 text-center text-slate-300">
                          {val ? 'T (1)' : 'F (0)'}
                        </td>
                      ))}
                      <td className="p-2.5 text-center font-bold">
                        <span
                          className={`px-2 py-0.5 rounded text-xs ${
                            row.output
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {row.output ? 'TRUE' : 'FALSE'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
