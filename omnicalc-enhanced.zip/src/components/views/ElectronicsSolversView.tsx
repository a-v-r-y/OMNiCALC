import React, { useState } from 'react';
import {
  solveOhmsLaw,
  calculateACPower,
  convertACWaveform,
  calculateVoltageDivider,
  calculateCurrentDivider,
  combineComponents,
  deltaToWye,
  wyeToDelta,
  calculateTimeConstant,
  calculateRLCCircuit,
  calculateFirstOrderFilter,
  calculateSecondOrderSystem
} from '../../utils/electronicsSolvers';
import {
  Zap,
  Activity,
  Cpu,
  Radio,
  Sliders,
  Split,
  Layers,
  ArrowRightLeft,
  Gauge
} from 'lucide-react';

export type ElectronicsTab =
  | 'ohms_power'
  | 'kirchhoff_dividers'
  | 'rlc_components'
  | 'impedance_resonance'
  | 'control_systems';

export const ElectronicsSolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ElectronicsTab>('ohms_power');

  // ==========================================
  // 1. Ohm's Law & Power State
  // ==========================================
  const [ohmVar1, setOhmVar1] = useState<'V' | 'I' | 'R' | 'P'>('V');
  const [ohmVal1, setOhmVal1] = useState<number>(12);
  const [ohmVar2, setOhmVar2] = useState<'V' | 'I' | 'R' | 'P'>('R');
  const [ohmVal2, setOhmVal2] = useState<number>(4);

  const ohmsObj: { V?: number; I?: number; R?: number; P?: number } = {};
  ohmsObj[ohmVar1] = ohmVal1;
  ohmsObj[ohmVar2] = ohmVal2;
  const ohmsResult = solveOhmsLaw(ohmsObj);

  // AC Waveform Conversion
  const [acWaveType, setAcWaveType] = useState<'peak' | 'rms' | 'peakToPeak' | 'avg'>('rms');
  const [acWaveVal, setAcWaveVal] = useState<number>(120);
  const waveConversions = convertACWaveform(acWaveType, acWaveVal);

  // AC Power
  const [acVRms, setAcVRms] = useState<number>(120);
  const [acIRms, setAcIRms] = useState<number>(5);
  const [acPhaseAngle, setAcPhaseAngle] = useState<number>(30); // 30 degrees lagging
  const acPower = calculateACPower(acVRms, acIRms, acPhaseAngle);

  // ==========================================
  // 2. Kirchhoff & Dividers State
  // ==========================================
  // Voltage divider
  const [vIn, setVIn] = useState<number>(12);
  const [vR1, setVR1] = useState<number>(1000);
  const [vR2, setVR2] = useState<number>(2000);
  const voltDiv = calculateVoltageDivider(vIn, vR1, vR2);

  // Current divider
  const [iTotal, setITotal] = useState<number>(3);
  const [iR1, setIR1] = useState<number>(100);
  const [iR2, setIR2] = useState<number>(200);
  const currDiv = calculateCurrentDivider(iTotal, iR1, iR2);

  // KCL Quick Verifier
  const [kclIn, setKclIn] = useState<string>('2.5, 1.8');
  const [kclOut, setKclOut] = useState<string>('4.3');
  const kclInSum = kclIn.split(/[\s,]+/).map(v => parseFloat(v) || 0).reduce((a, b) => a + b, 0);
  const kclOutSum = kclOut.split(/[\s,]+/).map(v => parseFloat(v) || 0).reduce((a, b) => a + b, 0);
  const kclBalanced = Math.abs(kclInSum - kclOutSum) < 1e-4;

  // ==========================================
  // 3. Components R, L, C State
  // ==========================================
  const [compType, setCompType] = useState<'resistor' | 'capacitor' | 'inductor'>('resistor');
  const [compConfig, setCompConfig] = useState<'series' | 'parallel'>('parallel');
  const [compInput, setCompInput] = useState<string>('100, 220, 470');
  const compValues = compInput.split(/[\s,]+/).map(v => parseFloat(v)).filter(v => !isNaN(v) && v > 0);
  const compEq = combineComponents(compConfig, compType, compValues);

  // Delta - Wye
  const [deltaRa, setDeltaRa] = useState<number>(10);
  const [deltaRb, setDeltaRb] = useState<number>(20);
  const [deltaRc, setDeltaRc] = useState<number>(30);
  const wyeRes = deltaToWye(deltaRa, deltaRb, deltaRc);

  // RC / RL Time Constant
  const [transientCircuit, setTransientCircuit] = useState<'RC' | 'RL'>('RC');
  const [transientR, setTransientR] = useState<number>(10000); // 10k ohm
  const [transientCL, setTransientCL] = useState<number>(0.0001); // 100uF = 0.0001F
  const [transientV0, setTransientV0] = useState<number>(5);
  const [transientT, setTransientT] = useState<number>(1.5);
  const timeConst = calculateTimeConstant(transientCircuit, transientR, transientCL, transientV0, transientT);

  // ==========================================
  // 4. Impedance & RLC Resonance State
  // ==========================================
  const [rlcType, setRlcType] = useState<'series' | 'parallel'>('series');
  const [rlcR, setRlcR] = useState<number>(50); // 50 ohm
  const [rlcL, setRlcL] = useState<number>(0.05); // 50 mH = 0.05 H
  const [rlcC, setRlcC] = useState<number>(0.000001); // 1 uF = 1e-6 F
  const [rlcFreq, setRlcFreq] = useState<number>(1000); // 1000 Hz
  const rlcMetrics = calculateRLCCircuit(rlcR, rlcL, rlcC, rlcFreq, rlcType);

  // ==========================================
  // 5. Transfer Functions & Control Systems State
  // ==========================================
  // Filter
  const [filterType, setFilterType] = useState<'lowpass' | 'highpass'>('lowpass');
  const [filtR, setFiltR] = useState<number>(1000); // 1k
  const [filtC, setFiltC] = useState<number>(0.000001); // 1 uF
  const [filtFreq, setFiltFreq] = useState<number>(159.15); // near cutoff
  const filterMetrics = calculateFirstOrderFilter(filterType, filtR, filtC, filtFreq);

  // 2nd-Order Control System
  const [wn, setWn] = useState<number>(10); // rad/s
  const [zeta, setZeta] = useState<number>(0.5); // underdamped
  const controlMetrics = calculateSecondOrderSystem(wn, zeta);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Module Subtabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('ohms_power')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'ohms_power'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-300" />
          Ohm's Law, Power & AC Waveforms
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('kirchhoff_dividers')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'kirchhoff_dividers'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Split className="w-3.5 h-3.5 text-indigo-300" />
          Kirchhoff's Laws & Dividers
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('rlc_components')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'rlc_components'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-emerald-300" />
          R, L, C & Time Constants (τ)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('impedance_resonance')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'impedance_resonance'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-cyan-300" />
          Impedance & RLC Resonance
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('control_systems')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'control_systems'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-purple-300" />
          Transfer Functions & Control Systems
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: OHM'S LAW, POWER & AC WAVEFORMS
          ========================================================================= */}
      {activeTab === 'ohms_power' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Ohm's Law Solver (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Ohm's Law Matrix (V, I, R, P)</span>
              <span className="text-[11px] font-mono text-slate-400">Select any 2 knowns</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex flex-col gap-1.5">
                <span className="text-slate-400 font-medium">Variable 1:</span>
                <select
                  value={ohmVar1}
                  onChange={e => setOhmVar1(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                >
                  <option value="V">Voltage V (Volts)</option>
                  <option value="I">Current I (Amperes)</option>
                  <option value="R">Resistance R (Ohms)</option>
                  <option value="P">Power P (Watts)</option>
                </select>
                <input
                  type="number"
                  value={ohmVal1}
                  onChange={e => setOhmVal1(parseFloat(e.target.value) || 0)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <span className="text-slate-400 font-medium">Variable 2:</span>
                <select
                  value={ohmVar2}
                  onChange={e => setOhmVar2(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                >
                  <option value="V" disabled={ohmVar1 === 'V'}>Voltage V (Volts)</option>
                  <option value="I" disabled={ohmVar1 === 'I'}>Current I (Amperes)</option>
                  <option value="R" disabled={ohmVar1 === 'R'}>Resistance R (Ohms)</option>
                  <option value="P" disabled={ohmVar1 === 'P'}>Power P (Watts)</option>
                </select>
                <input
                  type="number"
                  value={ohmVal2}
                  onChange={e => setOhmVal2(parseFloat(e.target.value) || 0)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                />
              </div>
            </div>

            {/* Results Grid */}
            {ohmsResult ? (
              <div className="grid grid-cols-2 gap-3 pt-2 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Voltage V:</span>
                  <div className="text-xl font-bold text-amber-400 mt-0.5">{ohmsResult.V} V</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Current I:</span>
                  <div className="text-xl font-bold text-sky-400 mt-0.5">{ohmsResult.I} A</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Resistance R:</span>
                  <div className="text-xl font-bold text-indigo-400 mt-0.5">{ohmsResult.R} Ω</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Power P:</span>
                  <div className="text-xl font-bold text-emerald-400 mt-0.5">{ohmsResult.P} W</div>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-slate-500 text-xs">
                Please specify two distinct valid variables.
              </div>
            )}
          </div>

          {/* AC Power & Waveform Calculations (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">AC Power & Waveform Converter</span>
              <span className="text-[11px] font-mono text-slate-400">RMS / Peak / Power Factor</span>
            </div>

            {/* AC Power Input */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">V_rms (V):</span>
                <input
                  type="number"
                  value={acVRms}
                  onChange={e => setAcVRms(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1">I_rms (A):</span>
                <input
                  type="number"
                  value={acIRms}
                  onChange={e => setAcIRms(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1">Phase Angle θ (°):</span>
                <input
                  type="number"
                  value={acPhaseAngle}
                  onChange={e => setAcPhaseAngle(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                />
              </div>
            </div>

            {/* AC Power Metrics */}
            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Real Power P:</span>
                <div className="text-lg font-bold text-emerald-400 mt-0.5">{acPower.realPowerWatts} W</div>
                <span className="text-[10px] text-slate-500">P = V·I·cos(θ)</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Apparent Power S:</span>
                <div className="text-lg font-bold text-indigo-400 mt-0.5">{acPower.apparentPowerVA} VA</div>
                <span className="text-[10px] text-slate-500">S = V_rms · I_rms</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Reactive Power Q:</span>
                <div className="text-lg font-bold text-amber-400 mt-0.5">{acPower.reactivePowerVAR} VAR</div>
                <span className="text-[10px] text-slate-500">Q = V·I·sin(θ)</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Power Factor PF:</span>
                <div className="text-lg font-bold text-sky-400 mt-0.5">{acPower.powerFactor}</div>
                <span className="text-[10px] text-slate-500">cos(θ)</span>
              </div>
            </div>

            {/* AC Waveform Table */}
            <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Convert Waveform:</span>
                <div className="flex items-center gap-2">
                  <select
                    value={acWaveType}
                    onChange={e => setAcWaveType(e.target.value as any)}
                    className="bg-slate-950 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  >
                    <option value="rms">RMS Value</option>
                    <option value="peak">Peak Value (Vp)</option>
                    <option value="peakToPeak">Peak-to-Peak (Vpp)</option>
                    <option value="avg">Average (Vavg)</option>
                  </select>
                  <input
                    type="number"
                    value={acWaveVal}
                    onChange={e => setAcWaveVal(parseFloat(e.target.value) || 0)}
                    className="w-20 bg-slate-950 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 text-[11px] font-mono p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <div>
                  <span className="text-slate-500 block">V_rms</span>
                  <span className="text-white font-bold">{waveConversions.rms}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">V_peak</span>
                  <span className="text-sky-300 font-bold">{waveConversions.peak}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">V_pp</span>
                  <span className="text-indigo-300 font-bold">{waveConversions.peakToPeak}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">V_avg</span>
                  <span className="text-amber-300 font-bold">{waveConversions.average}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: KIRCHHOFF'S LAWS & DIVIDERS
          ========================================================================= */}
      {activeTab === 'kirchhoff_dividers' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Voltage & Current Dividers */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Voltage & Current Dividers
            </span>

            {/* Voltage Divider */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5 text-xs">
              <span className="font-bold text-indigo-400">Voltage Divider: V_out = V_in · [R₂ / (R₁ + R₂)]</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">V_in (V):</span>
                  <input
                    type="number"
                    value={vIn}
                    onChange={e => setVIn(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">R₁ (Ω):</span>
                  <input
                    type="number"
                    value={vR1}
                    onChange={e => setVR1(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">R₂ (Ω):</span>
                  <input
                    type="number"
                    value={vR2}
                    onChange={e => setVR2(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">V_out across R₂</span>
                  <div className="text-base font-bold text-emerald-400">{voltDiv.vOut} V</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Branch Current</span>
                  <div className="text-base font-bold text-sky-400">{voltDiv.current} A</div>
                </div>
              </div>
            </div>

            {/* Current Divider */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5 text-xs">
              <span className="font-bold text-emerald-400">Current Divider: I₁ = I_tot · [R₂ / (R₁ + R₂)]</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">I_total (A):</span>
                  <input
                    type="number"
                    value={iTotal}
                    onChange={e => setITotal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">R₁ (Ω):</span>
                  <input
                    type="number"
                    value={iR1}
                    onChange={e => setIR1(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">R₂ (Ω):</span>
                  <input
                    type="number"
                    value={iR2}
                    onChange={e => setIR2(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Branch I₁ (through R₁)</span>
                  <div className="text-base font-bold text-indigo-400">{currDiv.i1} A</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Branch I₂ (through R₂)</span>
                  <div className="text-base font-bold text-amber-400">{currDiv.i2} A</div>
                </div>
              </div>
            </div>
          </div>

          {/* Kirchhoff's Laws Verifier */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-4">
                Kirchhoff's Laws (KCL & KVL) Validation
              </span>

              {/* KCL */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3 text-xs">
                <span className="font-bold text-sky-400">Kirchhoff's Current Law (KCL): ∑ I_in = ∑ I_out</span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-400 block mb-1">Currents Entering Node (A):</span>
                    <input
                      type="text"
                      value={kclIn}
                      onChange={e => setKclIn(e.target.value)}
                      placeholder="e.g. 2.5, 1.8"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <span className="text-[10px] text-slate-500 mt-1 block">Sum: {kclInSum.toFixed(3)} A</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Currents Leaving Node (A):</span>
                    <input
                      type="text"
                      value={kclOut}
                      onChange={e => setKclOut(e.target.value)}
                      placeholder="e.g. 4.3"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <span className="text-[10px] text-slate-500 mt-1 block">Sum: {kclOutSum.toFixed(3)} A</span>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center font-mono">
                  <span className="text-slate-400">Node Balance (∑ I = 0):</span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded text-xs ${
                      kclBalanced
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    {kclBalanced ? 'Balanced (Δ = 0 A)' : `Unbalanced (Δ = ${(kclInSum - kclOutSum).toFixed(3)} A)`}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-400">
              <span className="font-semibold text-slate-200 block mb-1">Kirchhoff's Voltage Law (KVL):</span>
              The directed sum of potential differences around any closed circuit loop equals zero:
              <span className="block font-mono text-amber-300 mt-1">∑ V_sources = ∑ (I · R_drops)</span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: R, L, C COMPONENTS & TRANSIENT RESPONSE
          ========================================================================= */}
      {activeTab === 'rlc_components' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Equivalent Combinations & Delta-Wye (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Series & Parallel Combinations
            </span>

            <div className="flex gap-2 text-xs font-mono">
              {(['resistor', 'capacitor', 'inductor'] as const).map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCompType(c)}
                  className={`px-3 py-1.5 rounded-xl capitalize font-medium transition-all ${
                    compType === c
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 border border-slate-800'
                  }`}
                >
                  {c}s
                </button>
              ))}
            </div>

            <div className="flex gap-2 text-xs">
              <button
                type="button"
                onClick={() => setCompConfig('series')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  compConfig === 'series'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Series
              </button>
              <button
                type="button"
                onClick={() => setCompConfig('parallel')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  compConfig === 'parallel'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Parallel
              </button>
            </div>

            <div>
              <span className="text-slate-400 text-xs block mb-1">
                Enter values (comma or space separated):
              </span>
              <input
                type="text"
                value={compInput}
                onChange={e => setCompInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-sm"
              />
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center font-mono">
              <span className="text-slate-400 text-xs uppercase tracking-wider">Equivalent Result</span>
              <div className="text-3xl font-extrabold text-emerald-400 mt-1">
                {compEq}{' '}
                {compType === 'resistor' ? 'Ω' : compType === 'capacitor' ? 'F' : 'H'}
              </div>
            </div>

            {/* Delta-Wye Transformation */}
            <div className="pt-3 border-t border-slate-800 flex flex-col gap-2.5 text-xs">
              <span className="font-bold text-amber-400">Delta-to-Wye (Δ → Y) Conversion</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Ra (Ω):</span>
                  <input
                    type="number"
                    value={deltaRa}
                    onChange={e => setDeltaRa(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Rb (Ω):</span>
                  <input
                    type="number"
                    value={deltaRb}
                    onChange={e => setDeltaRb(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Rc (Ω):</span>
                  <input
                    type="number"
                    value={deltaRc}
                    onChange={e => setDeltaRc(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 font-mono text-center pt-1">
                <div className="p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">R₁</span>
                  <div className="text-sky-400 font-bold">{wyeRes.R1} Ω</div>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">R₂</span>
                  <div className="text-sky-400 font-bold">{wyeRes.R2} Ω</div>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">R₃</span>
                  <div className="text-sky-400 font-bold">{wyeRes.R3} Ω</div>
                </div>
              </div>
            </div>
          </div>

          {/* RC / RL Transient Time Constant (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-4">
                RC & RL Transient Response & Time Constant (τ)
              </span>

              <div className="flex gap-2 text-xs mb-3">
                <button
                  type="button"
                  onClick={() => setTransientCircuit('RC')}
                  className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                    transientCircuit === 'RC'
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  RC Circuit (τ = R·C)
                </button>
                <button
                  type="button"
                  onClick={() => setTransientCircuit('RL')}
                  className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                    transientCircuit === 'RL'
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  RL Circuit (τ = L/R)
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs mb-3">
                <div>
                  <span className="text-slate-400 block mb-1">Resistance R (Ω):</span>
                  <input
                    type="number"
                    value={transientR}
                    onChange={e => setTransientR(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">
                    {transientCircuit === 'RC' ? 'Capacitance C (F):' : 'Inductance L (H):'}
                  </span>
                  <input
                    type="number"
                    value={transientCL}
                    step="0.0001"
                    onChange={e => setTransientCL(parseFloat(e.target.value) || 0.0001)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Source Voltage V₀ (V):</span>
                  <input
                    type="number"
                    value={transientV0}
                    onChange={e => setTransientV0(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Target Time t (sec):</span>
                  <input
                    type="number"
                    value={transientT}
                    onChange={e => setTransientT(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Time Constant τ:</span>
                <div className="text-xl font-bold text-amber-400 mt-1">{timeConst.tau} s</div>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Cutoff Frequency f_c:</span>
                <div className="text-xl font-bold text-sky-400 mt-1">{timeConst.freqCutoff} Hz</div>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Value at 1τ (63.2%):</span>
                <div className="text-base font-bold text-white mt-1">{timeConst.voltageAtTau} V</div>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Value at t = {transientT}s:</span>
                <div className="text-base font-bold text-emerald-400 mt-1">{timeConst.voltageAtTime} V</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: IMPEDANCE & RLC RESONANCE
          ========================================================================= */}
      {activeTab === 'impedance_resonance' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Inputs (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              RLC Circuit Parameters
            </span>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setRlcType('series')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  rlcType === 'series'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Series RLC
              </button>
              <button
                type="button"
                onClick={() => setRlcType('parallel')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  rlcType === 'parallel'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Parallel RLC
              </button>
            </div>

            <div>
              <span className="text-slate-400 block mb-1">Resistance R (Ω):</span>
              <input
                type="number"
                value={rlcR}
                onChange={e => setRlcR(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
              />
            </div>

            <div>
              <span className="text-slate-400 block mb-1">Inductance L (Henries):</span>
              <input
                type="number"
                value={rlcL}
                step="0.001"
                onChange={e => setRlcL(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500">{(rlcL * 1000).toFixed(1)} mH</span>
            </div>

            <div>
              <span className="text-slate-400 block mb-1">Capacitance C (Farads):</span>
              <input
                type="number"
                value={rlcC}
                step="0.000001"
                onChange={e => setRlcC(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500">{(rlcC * 1e6).toFixed(1)} µF</span>
            </div>

            <div>
              <span className="text-slate-400 block mb-1">Operating Frequency f (Hz):</span>
              <input
                type="number"
                value={rlcFreq}
                onChange={e => setRlcFreq(parseFloat(e.target.value) || 1)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
              />
            </div>
          </div>

          {/* Results Display (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 font-mono text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Impedance, Reactance & Resonance Analysis
            </span>

            {/* Resonance Highlight */}
            <div className="p-4 bg-slate-950 rounded-xl border border-indigo-900/40 grid grid-cols-2 gap-3">
              <div>
                <span className="text-slate-400 text-xs">Resonant Frequency f₀:</span>
                <div className="text-2xl font-extrabold text-amber-400 mt-1">
                  {rlcMetrics.resonantFrequencyHz} Hz
                </div>
                <span className="text-[10px] text-slate-500">ω₀ = {rlcMetrics.resonantOmegaRadS} rad/s</span>
              </div>
              <div>
                <span className="text-slate-400 text-xs">Quality Factor Q:</span>
                <div className="text-2xl font-extrabold text-indigo-300 mt-1">
                  {rlcMetrics.qualityFactor}
                </div>
                <span className="text-[10px] text-slate-500">Bandwidth = {rlcMetrics.bandwidthHz} Hz</span>
              </div>
            </div>

            {/* Impedance at operating frequency */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Total Impedance |Z|:</span>
                <div className="text-xl font-bold text-emerald-400 mt-1">
                  {rlcMetrics.impedanceMag} Ω
                </div>
                <span className="text-[10px] text-slate-500">at {rlcFreq} Hz</span>
              </div>
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Phase Angle θ:</span>
                <div className="text-xl font-bold text-sky-400 mt-1">
                  {rlcMetrics.phaseAngleDeg}°
                </div>
                <span className="text-[10px] text-slate-500">
                  {rlcMetrics.phaseAngleDeg > 0 ? 'Inductive' : rlcMetrics.phaseAngleDeg < 0 ? 'Capacitive' : 'Resistive'}
                </span>
              </div>
            </div>

            {/* Reactance Breakdown */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">X_L (Inductive)</span>
                <div className="text-indigo-400 font-bold">{rlcMetrics.reactanceInductive} Ω</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">X_C (Capacitive)</span>
                <div className="text-sky-400 font-bold">{rlcMetrics.reactanceCapacitive} Ω</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Net Reactance</span>
                <div className="text-white font-bold">{rlcMetrics.netReactance} Ω</div>
              </div>
            </div>

            {/* Half-Power Cutoff frequencies */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-slate-400">
              <span>Half-Power Bandwidth Limits:</span>
              <span className="text-white font-bold">
                f₁ = {rlcMetrics.cutoffLowHz} Hz — f₂ = {rlcMetrics.cutoffHighHz} Hz
              </span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: TRANSFER FUNCTIONS & CONTROL SYSTEMS
          ========================================================================= */}
      {activeTab === 'control_systems' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* 1st-Order Filter Transfer Function */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              1st-Order RC Filter Transfer Function H(s)
            </span>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setFilterType('lowpass')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  filterType === 'lowpass'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Low-Pass: H(s) = 1/(1 + τs)
              </button>
              <button
                type="button"
                onClick={() => setFilterType('highpass')}
                className={`flex-1 py-1.5 rounded-xl font-medium border transition-colors ${
                  filterType === 'highpass'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                High-Pass: H(s) = τs/(1 + τs)
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <span className="text-slate-400 block mb-1">R (Ω):</span>
                <input
                  type="number"
                  value={filtR}
                  onChange={e => setFiltR(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1">C (F):</span>
                <input
                  type="number"
                  value={filtC}
                  step="0.000001"
                  onChange={e => setFiltC(parseFloat(e.target.value) || 0.000001)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400 block mb-1">Test f (Hz):</span>
                <input
                  type="number"
                  value={filtFreq}
                  onChange={e => setFiltFreq(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono pt-1">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Cutoff Frequency f_c:</span>
                <div className="text-xl font-bold text-amber-400 mt-1">{filterMetrics.cutoffFreqHz} Hz</div>
                <span className="text-[10px] text-slate-500">(-3 dB point)</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-400">Gain in dB:</span>
                <div className="text-xl font-bold text-emerald-400 mt-1">{filterMetrics.gainDb} dB</div>
                <span className="text-[10px] text-slate-500">|H| = {filterMetrics.gainMagnitude}</span>
              </div>
              <div className="col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Phase Shift at {filtFreq} Hz:</span>
                <span className="text-sky-400 font-bold text-base">{filterMetrics.phaseShiftDeg}°</span>
              </div>
            </div>
          </div>

          {/* 2nd-Order Control System */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-3">
                Standard 2nd-Order Control System
              </span>
              <div className="text-[11px] font-mono text-slate-400 mb-3">
                T(s) = ω_n² / (s² + 2ζω_n s + ω_n²)
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <span className="text-slate-400 block mb-1">Natural Frequency ω_n (rad/s):</span>
                  <input
                    type="number"
                    value={wn}
                    min="0.1"
                    onChange={e => setWn(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Damping Ratio ζ (zeta):</span>
                  <input
                    type="number"
                    value={zeta}
                    step="0.05"
                    min="0"
                    onChange={e => setZeta(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-indigo-900/40 flex justify-between items-center mb-3">
                <span className="text-slate-400">Damping Regime:</span>
                <span className="font-bold px-2.5 py-0.5 rounded text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {controlMetrics.regime}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 font-mono">
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px]">Percentage Overshoot (%OS)</span>
                <div className="text-base font-bold text-emerald-400">{controlMetrics.percentOvershoot}%</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px]">Settling Time T_s (2%)</span>
                <div className="text-base font-bold text-sky-400">{controlMetrics.settlingTimeSec} s</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px]">Peak Time T_p</span>
                <div className="text-base font-bold text-amber-400">
                  {controlMetrics.peakTimeSec !== null ? `${controlMetrics.peakTimeSec} s` : 'N/A'}
                </div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px]">Rise Time T_r</span>
                <div className="text-base font-bold text-white">{controlMetrics.riseTimeSec} s</div>
              </div>
            </div>

            {/* Poles */}
            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-400 flex justify-between items-center">
              <span>Characteristic Poles:</span>
              <span className="text-purple-300 font-bold">
                {controlMetrics.poles.map(p => `${p.real} ${p.imag !== 0 ? `± j${Math.abs(p.imag)}` : ''}`).join(', ')}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
