import React, { useState } from 'react';
import { Binary, Cpu, RotateCcw, ArrowLeftRight } from 'lucide-react';

type WordSize = 8 | 16 | 32 | 64;

export const ProgrammerBaseNView: React.FC = () => {
  const [value, setValue] = useState<bigint>(42n);
  const [wordSize, setWordSize] = useState<WordSize>(64);
  const [isSigned, setIsSigned] = useState<boolean>(true);
  const [activeRadix, setActiveRadix] = useState<'hex' | 'dec' | 'oct' | 'bin'>('dec');
  const [inputStr, setInputStr] = useState<string>('42');

  // Word mask
  const getMask = (bits: WordSize): bigint => {
    return (1n << BigInt(bits)) - 1n;
  };

  const mask = getMask(wordSize);
  const maskedVal = value & mask;

  // Format strings
  const hexStr = maskedVal.toString(16).toUpperCase();
  const decStr = maskedVal.toString(10);
  const octStr = maskedVal.toString(8);
  const binStr = maskedVal.toString(2).padStart(wordSize, '0');

  // Group binary string into 4-bit nibbles
  const binNibbles = binStr.match(/.{1,4}/g) || [];

  const handleUpdateValue = (newVal: bigint) => {
    const clamped = newVal & mask;
    setValue(clamped);
    if (activeRadix === 'hex') setInputStr(clamped.toString(16).toUpperCase());
    else if (activeRadix === 'oct') setInputStr(clamped.toString(8));
    else if (activeRadix === 'bin') setInputStr(clamped.toString(2));
    else setInputStr(clamped.toString(10));
  };

  const handleInputChange = (str: string) => {
    setInputStr(str);
    try {
      let parsed = 0n;
      if (activeRadix === 'hex') parsed = BigInt(`0x${str || '0'}`);
      else if (activeRadix === 'oct') parsed = BigInt(`0o${str || '0'}`);
      else if (activeRadix === 'bin') parsed = BigInt(`0b${str || '0'}`);
      else parsed = BigInt(str || '0');
      setValue(parsed & mask);
    } catch {
      // invalid partial input ignored
    }
  };

  // Toggle individual bit
  const handleToggleBit = (bitIndex: number) => {
    const bitMask = 1n << BigInt(bitIndex);
    const updated = value ^ bitMask;
    handleUpdateValue(updated);
  };

  // Bitwise actions
  const handleNot = () => handleUpdateValue(value ^ mask);
  const handleShiftLeft = () => handleUpdateValue(value << 1n);
  const handleShiftRight = () => handleUpdateValue(value >> 1n);
  const handleByteSwap = () => {
    let v = maskedVal;
    let swapped = 0n;
    const bytes = wordSize / 8;
    for (let i = 0; i < bytes; i++) {
      swapped = (swapped << 8n) | (v & 0xffn);
      v >>= 8n;
    }
    handleUpdateValue(swapped);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full">
      {/* Left panel: Radix Display & Keypad */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {/* Radix Synchronization Cards */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-2.5">
          {/* Settings bar */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Word Size:</span>
              {([64, 32, 16, 8] as WordSize[]).map(sz => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setWordSize(sz)}
                  className={`px-2 py-0.5 rounded font-mono ${
                    wordSize === sz
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {sz === 64 ? 'QWORD' : sz === 32 ? 'DWORD' : sz === 16 ? 'WORD' : 'BYTE'} ({sz})
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleByteSwap}
                className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                title="Swap byte endianness"
              >
                <ArrowLeftRight className="w-3 h-3" />
                Endian Swap
              </button>
            </div>
          </div>

          {/* Radix Rows */}
          <div className="space-y-1.5 font-mono">
            {/* HEX */}
            <div
              onClick={() => {
                setActiveRadix('hex');
                setInputStr(hexStr);
              }}
              className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                activeRadix === 'hex'
                  ? 'bg-indigo-950/60 border-indigo-500/60 text-indigo-200'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-xs font-bold text-indigo-400 w-12">HEX</span>
              <span className="text-sm font-bold truncate">0x{hexStr}</span>
            </div>

            {/* DEC */}
            <div
              onClick={() => {
                setActiveRadix('dec');
                setInputStr(decStr);
              }}
              className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                activeRadix === 'dec'
                  ? 'bg-indigo-950/60 border-indigo-500/60 text-indigo-200'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-xs font-bold text-indigo-400 w-12">DEC</span>
              <span className="text-sm font-bold truncate">{decStr}</span>
            </div>

            {/* OCT */}
            <div
              onClick={() => {
                setActiveRadix('oct');
                setInputStr(octStr);
              }}
              className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                activeRadix === 'oct'
                  ? 'bg-indigo-950/60 border-indigo-500/60 text-indigo-200'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-xs font-bold text-indigo-400 w-12">OCT</span>
              <span className="text-sm font-bold truncate">0o{octStr}</span>
            </div>

            {/* BIN */}
            <div
              onClick={() => {
                setActiveRadix('bin');
                setInputStr(binStr);
              }}
              className={`p-2 rounded-xl flex items-center justify-between cursor-pointer border transition-colors ${
                activeRadix === 'bin'
                  ? 'bg-indigo-950/60 border-indigo-500/60 text-indigo-200'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-xs font-bold text-indigo-400 w-12">BIN</span>
              <span className="text-xs font-bold truncate">{binNibbles.join(' ')}</span>
            </div>
          </div>

          {/* Active input field */}
          <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-indigo-400">
              {activeRadix} Input:
            </span>
            <input
              type="text"
              value={inputStr}
              onChange={e => handleInputChange(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-base font-mono text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Bitwise operations bar */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          <button
            type="button"
            onClick={handleNot}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-mono text-white"
          >
            NOT (~)
          </button>
          <button
            type="button"
            onClick={handleShiftLeft}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-mono text-white"
          >
            LSH (&lt;&lt;)
          </button>
          <button
            type="button"
            onClick={handleShiftRight}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-mono text-white"
          >
            RSH (&gt;&gt;)
          </button>
          <button
            type="button"
            onClick={() => handleUpdateValue(value & 0xffn)}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-mono text-white"
          >
            AND 0xFF
          </button>
          <button
            type="button"
            onClick={() => handleUpdateValue(value ^ mask)}
            className="py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-mono text-white"
          >
            FLIP ALL
          </button>
          <button
            type="button"
            onClick={() => handleUpdateValue(0n)}
            className="py-2 px-3 bg-rose-950/60 hover:bg-rose-900/70 border border-rose-800/60 rounded-lg text-xs font-mono text-rose-300"
          >
            CLEAR
          </button>
        </div>
      </div>

      {/* Right panel: Interactive 64-bit Bit Matrix */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Binary className="w-4 h-4 text-indigo-400" />
              Interactive Bit Toggles
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Click bit to flip</span>
          </div>

          <div className="grid grid-cols-8 gap-1.5 font-mono text-xs max-h-[380px] overflow-y-auto pr-1">
            {Array.from({ length: wordSize }).map((_, i) => {
              const bitIndex = wordSize - 1 - i;
              const isSet = (maskedVal & (1n << BigInt(bitIndex))) !== 0n;
              return (
                <button
                  key={bitIndex}
                  type="button"
                  onClick={() => handleToggleBit(bitIndex)}
                  className={`p-2 rounded-lg border text-center font-bold transition-all ${
                    isSet
                      ? 'bg-indigo-600 text-white border-indigo-400 shadow-sm'
                      : 'bg-slate-950 text-slate-600 border-slate-800 hover:text-slate-400'
                  }`}
                  title={`Bit ${bitIndex}`}
                >
                  <div className="text-[9px] text-slate-400 mb-0.5">{bitIndex}</div>
                  <div>{isSet ? '1' : '0'}</div>
                </button>
              );
            })}
          </div>

          {/* ASCII interpretation */}
          <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between font-mono">
            <span>ASCII Representation:</span>
            <span className="text-white font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              {Number(maskedVal) >= 32 && Number(maskedVal) <= 126
                ? `'${String.fromCharCode(Number(maskedVal))}'`
                : 'Non-printable'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
