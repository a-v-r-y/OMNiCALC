import React, { useState } from 'react';
import {
  PERIODIC_ELEMENTS,
  CHEMICAL_CONSTANTS,
  parseFormulaDetailed,
  convertMoles,
  calculateStoichiometry,
  calculateMolarity,
  calculateMolality,
  calculateDilution,
  calculateWeakAcidPH,
  calculateBufferPH,
  calculateArrhenius,
  calculateRadioactiveDecay
} from '../../utils/chemistrySolvers';
import { MathView } from '../MathView';
import {
  FlaskConical,
  Flame,
  Search,
  Check,
  Copy,
  Layers,
  Wind,
  Gauge,
  Activity,
  Atom,
  Radiation,
  Sparkles,
  ChevronRight,
  TrendingUp,
  Database
} from 'lucide-react';

export type ChemTab =
  | 'molar_mass'
  | 'stoichiometry'
  | 'solutions'
  | 'gas_laws'
  | 'acid_base'
  | 'kinetics_nuclear'
  | 'periodic_table';

export const ChemistrySolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ChemTab>('molar_mass');

  // 1. Molar Mass & Mole Converter State
  const [formulaInput, setFormulaInput] = useState<string>('CuSO4*5H2O');
  const formulaBreakdown = parseFormulaDetailed(formulaInput);

  const [moleInputType, setMoleInputType] = useState<'mass' | 'moles' | 'particles' | 'volumeSTP'>('mass');
  const [moleInputValue, setMoleInputValue] = useState<number>(50);
  const moleConversion = convertMoles(
    { [moleInputType]: moleInputValue },
    formulaBreakdown.molarMass
  );

  // 2. Stoichiometry State: aA + bB -> cC
  const [coeffA, setCoeffA] = useState<number>(2);
  const [massA, setMassA] = useState<number>(10);
  const [formulaA, setFormulaA] = useState<string>('H2');

  const [coeffB, setCoeffB] = useState<number>(1);
  const [massB, setMassB] = useState<number>(64);
  const [formulaB, setFormulaB] = useState<string>('O2');

  const [coeffProd, setCoeffProd] = useState<number>(2);
  const [formulaProd, setFormulaProd] = useState<string>('H2O');
  const [actualYield, setActualYield] = useState<number>(70);

  const molarA = parseFormulaDetailed(formulaA).molarMass;
  const molarB = parseFormulaDetailed(formulaB).molarMass;
  const molarProd = parseFormulaDetailed(formulaProd).molarMass;

  const stoichResult = calculateStoichiometry(
    coeffA,
    massA,
    molarA,
    coeffB,
    massB,
    molarB,
    coeffProd,
    molarProd,
    actualYield
  );

  // 3. Solutions State
  const [soluteMoles, setSoluteMoles] = useState<number>(0.5);
  const [solVolumeL, setSolVolumeL] = useState<number>(0.25);
  const [solventMassKg, setSolventMassKg] = useState<number>(0.25);

  const molarityResult = calculateMolarity(soluteMoles, solVolumeL);
  const molalityResult = calculateMolality(soluteMoles, solventMassKg);

  // Dilution M1 V1 = M2 V2
  const [dilM1, setDilM1] = useState<number | ''>(6);
  const [dilV1, setDilV1] = useState<number | ''>(0.05);
  const [dilM2, setDilM2] = useState<number | ''>(1.5);
  const [dilV2, setDilV2] = useState<number | ''>('');

  const dilutionResult = calculateDilution(
    dilM1 === '' ? undefined : Number(dilM1),
    dilV1 === '' ? undefined : Number(dilV1),
    dilM2 === '' ? undefined : Number(dilM2),
    dilV2 === '' ? undefined : Number(dilV2)
  );

  // 4. Gas Laws: Ideal Gas PV = nRT
  const [gasTarget, setGasTarget] = useState<'P' | 'V' | 'n' | 'T'>('P');
  const [gasP, setGasP] = useState<number>(1);
  const [gasV, setGasV] = useState<number>(22.4);
  const [gasN, setGasN] = useState<number>(1);
  const [gasT, setGasT] = useState<number>(273.15);
  const R_GAS = 0.082057; // L·atm/(mol·K)

  const computeGas = () => {
    if (gasTarget === 'P') return (gasN * R_GAS * gasT) / (gasV || 1);
    if (gasTarget === 'V') return (gasN * R_GAS * gasT) / (gasP || 1);
    if (gasTarget === 'n') return (gasP * gasV) / (R_GAS * gasT || 1);
    if (gasTarget === 'T') return (gasP * gasV) / (gasN * R_GAS || 1);
    return 0;
  };
  const gasResult = computeGas();

  // 5. Acid / Base & Equilibrium
  const [phInput, setPhInput] = useState<number>(3.5);
  const [phType, setPhType] = useState<'pH' | 'pOH' | 'H+' | 'OH-'>('pH');

  const computePH = () => {
    let pH = 7;
    if (phType === 'pH') pH = phInput;
    else if (phType === 'pOH') pH = 14 - phInput;
    else if (phType === 'H+') pH = phInput > 0 ? -Math.log10(phInput) : 7;
    else if (phType === 'OH-') pH = phInput > 0 ? 14 - -Math.log10(phInput) : 7;

    const pOH = 14 - pH;
    const hConc = Math.pow(10, -pH);
    const ohConc = Math.pow(10, -pOH);
    return {
      pH: parseFloat(pH.toFixed(3)),
      pOH: parseFloat(pOH.toFixed(3)),
      hConc: hConc.toExponential(3),
      ohConc: ohConc.toExponential(3)
    };
  };
  const phResult = computePH();

  // Weak acid Ka solver
  const [weakKa, setWeakKa] = useState<number>(1.8e-5); // acetic acid
  const [weakConc, setWeakConc] = useState<number>(0.1);
  const weakAcidResult = calculateWeakAcidPH(weakKa, weakConc);

  // Buffer Henderson-Hasselbalch
  const [bufPka, setBufPka] = useState<number>(4.76);
  const [bufBase, setBufBase] = useState<number>(0.2);
  const [bufAcid, setBufAcid] = useState<number>(0.1);
  const bufferPH = calculateBufferPH(bufPka, bufBase, bufAcid);

  // 6. Kinetics & Nuclear
  const [arrA, setArrA] = useState<number>(1e11);
  const [arrEa, setArrEa] = useState<number>(75); // kJ/mol
  const [arrT, setArrT] = useState<number>(298.15); // K
  const arrResult = calculateArrhenius(arrA, arrEa, arrT);

  // Half-life
  const [decayN0, setDecayN0] = useState<number>(100);
  const [decayHalfLife, setDecayHalfLife] = useState<number>(5730); // Carbon-14
  const [decayTime, setDecayTime] = useState<number>(11460);
  const decayResult = calculateRadioactiveDecay(decayN0, decayHalfLife, decayTime);

  // 7. Periodic Table & Constants
  const [elementSearch, setElementSearch] = useState<string>('');
  const [elementCategory, setElementCategory] = useState<string>('All');
  const [copiedConst, setCopiedConst] = useState<string | null>(null);

  const filteredElements = PERIODIC_ELEMENTS.filter(el => {
    const matchesSearch =
      el.name.toLowerCase().includes(elementSearch.toLowerCase()) ||
      el.symbol.toLowerCase().includes(elementSearch.toLowerCase()) ||
      el.number.toString() === elementSearch.trim();
    const matchesCat = elementCategory === 'All' || el.category === elementCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Module Subtabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('molar_mass')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'molar_mass'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5 text-indigo-300" />
          Molar Mass & Mole Converter
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('stoichiometry')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'stoichiometry'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-emerald-300" />
          Reaction Stoichiometry & Yield
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('solutions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'solutions'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Gauge className="w-3.5 h-3.5 text-cyan-300" />
          Molarity, Molality & Dilution
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('gas_laws')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'gas_laws'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Wind className="w-3.5 h-3.5 text-sky-300" />
          Gas Laws (PV = nRT)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('acid_base')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'acid_base'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-amber-300" />
          pH, Acid-Base & Buffers
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('kinetics_nuclear')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'kinetics_nuclear'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Radiation className="w-3.5 h-3.5 text-rose-300" />
          Arrhenius & Half-Life Decay
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('periodic_table')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'periodic_table'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Atom className="w-3.5 h-3.5 text-purple-300" />
          Periodic Table & Constants
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: MOLAR MASS & MOLE CONVERTER
          ========================================================================= */}
      {activeTab === 'molar_mass' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Formula Parser & Breakdown (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Chemical Formula Analyzer</span>
              <span className="text-[11px] font-mono text-slate-400">Hydrates & Parentheses Supported</span>
            </div>

            <div>
              <span className="text-xs text-slate-400 block mb-1">Enter Formula (e.g., C6H12O6, Ca(NO3)2, CuSO4*5H2O):</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={formulaInput}
                  onChange={e => setFormulaInput(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-base focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Total Molar Mass Banner */}
            <div className="p-4 bg-slate-950 rounded-xl border border-indigo-900/40 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 font-medium">Molecular Weight / Molar Mass</span>
                <div className="text-3xl font-extrabold text-emerald-400 font-mono mt-0.5">
                  {formulaBreakdown.molarMass} <span className="text-base font-normal text-slate-400">g/mol</span>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
                {formulaBreakdown.elements.length} unique elements
              </span>
            </div>

            {/* Mass Percentage Breakdown Table */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-slate-300">Elemental Composition (% by Mass):</span>
              <div className="overflow-x-auto border border-slate-800 rounded-xl">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-950 text-slate-400 font-mono border-b border-slate-800">
                    <tr>
                      <th className="py-2 px-3">Element</th>
                      <th className="py-2 px-3">Atoms</th>
                      <th className="py-2 px-3">Total Mass</th>
                      <th className="py-2 px-3">Mass %</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {formulaBreakdown.elements.map(el => (
                      <tr key={el.symbol} className="hover:bg-slate-850/50">
                        <td className="py-2 px-3 font-bold text-white">{el.symbol}</td>
                        <td className="py-2 px-3 text-slate-300">{el.count}</td>
                        <td className="py-2 px-3 text-slate-400">{el.mass.toFixed(2)} g/mol</td>
                        <td className="py-2 px-3 text-indigo-400 font-bold">{el.percentage}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Mole Conversions (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Mole Conversion Bridge (Avogadro & STP)
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Convert From:</span>
                  <select
                    value={moleInputType}
                    onChange={e => setMoleInputType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="mass">Mass (grams)</option>
                    <option value="moles">Moles (mol)</option>
                    <option value="particles">Molecules / Particles</option>
                    <option value="volumeSTP">Gas Volume at STP (L)</option>
                  </select>
                </div>

                <div>
                  <span className="text-slate-400 block mb-1">Input Value:</span>
                  <input
                    type="number"
                    value={moleInputValue}
                    step="any"
                    onChange={e => setMoleInputValue(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Conversion Outputs */}
              <div className="grid grid-cols-1 gap-2.5 pt-2">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Total Mass</span>
                  <span className="font-mono text-base font-bold text-white">{moleConversion.mass} g</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Amount of Substance</span>
                  <span className="font-mono text-base font-bold text-emerald-400">{moleConversion.moles} mol</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Number of Particles</span>
                  <span className="font-mono text-base font-bold text-indigo-400">
                    {moleConversion.particles.toExponential(4)}
                  </span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Ideal Gas Vol. (STP, 22.4 L)</span>
                  <span className="font-mono text-base font-bold text-amber-400">{moleConversion.volumeSTP} L</span>
                </div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-0.5">Relations:</span>
              <span>n = m / M = N / N_A = V / 22.414 L</span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: STOICHIOMETRY & REACTION YIELD
          ========================================================================= */}
      {activeTab === 'stoichiometry' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Reaction Inputs */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Chemical Reaction Setup: aA + bB → cC
            </span>

            {/* Reactant A */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <span className="font-bold text-indigo-400">Reactant A</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Coeff a</span>
                  <input
                    type="number"
                    value={coeffA}
                    min="1"
                    onChange={e => setCoeffA(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Formula A</span>
                  <input
                    type="text"
                    value={formulaA}
                    onChange={e => setFormulaA(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Mass (g)</span>
                  <input
                    type="number"
                    value={massA}
                    onChange={e => setMassA(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">Molar Mass: {molarA} g/mol</span>
            </div>

            {/* Reactant B */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <span className="font-bold text-amber-400">Reactant B</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Coeff b</span>
                  <input
                    type="number"
                    value={coeffB}
                    min="1"
                    onChange={e => setCoeffB(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Formula B</span>
                  <input
                    type="text"
                    value={formulaB}
                    onChange={e => setFormulaB(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Mass (g)</span>
                  <input
                    type="number"
                    value={massB}
                    onChange={e => setMassB(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">Molar Mass: {molarB} g/mol</span>
            </div>

            {/* Product C & Actual Yield */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <span className="font-bold text-emerald-400">Product C</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Coeff c</span>
                  <input
                    type="number"
                    value={coeffProd}
                    min="1"
                    onChange={e => setCoeffProd(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Formula C</span>
                  <input
                    type="text"
                    value={formulaProd}
                    onChange={e => setFormulaProd(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Actual Yield (g)</span>
                  <input
                    type="number"
                    value={actualYield}
                    onChange={e => setActualYield(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">Molar Mass: {molarProd} g/mol</span>
            </div>
          </div>

          {/* Stoichiometric Results */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Yield & Limiting Reagent Analysis
            </span>

            {/* Limiting Reagent Spotlight */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">Limiting Reagent</span>
                <div className="text-2xl font-extrabold text-rose-400 font-mono mt-0.5">
                  {stoichResult.limitingReagent === 'A'
                    ? `Reactant A (${formulaA})`
                    : stoichResult.limitingReagent === 'B'
                    ? `Reactant B (${formulaB})`
                    : 'Equimolar Proportions'}
                </div>
              </div>
              <span className="text-xs font-mono px-2 py-1 rounded bg-slate-900 text-slate-400 border border-slate-800">
                Dictates max yield
              </span>
            </div>

            {/* Yield Metric Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Theoretical Yield (Mass)</span>
                <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                  {stoichResult.theoreticalYieldMass} g
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  {stoichResult.theoreticalYieldMoles} moles
                </span>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Reaction Percent Yield</span>
                <div className="text-xl font-bold font-mono text-indigo-400 mt-1">
                  {stoichResult.percentYield}%
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  (Actual / Theoretical) × 100
                </span>
              </div>
            </div>

            {/* Excess Reagent Leftover */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono flex justify-between items-center">
              <span className="text-slate-400">
                Excess Leftover ({stoichResult.excessReagent === 'A' ? formulaA : formulaB}):
              </span>
              <span className="text-amber-400 font-bold">{stoichResult.excessLeftoverMass} g</span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: SOLUTIONS, MOLARITY & DILUTION
          ========================================================================= */}
      {activeTab === 'solutions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Concentration: Molarity & Molality */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Solution Concentration (Molarity & Molality)
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Moles of Solute (mol):</span>
                <input
                  type="number"
                  value={soluteMoles}
                  step="0.05"
                  onChange={e => setSoluteMoles(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Volume of Solution (L):</span>
                <input
                  type="number"
                  value={solVolumeL}
                  step="0.05"
                  onChange={e => setSolVolumeL(parseFloat(e.target.value) || 0.001)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Mass of Solvent (kg):</span>
                <input
                  type="number"
                  value={solventMassKg}
                  step="0.05"
                  onChange={e => setSolventMassKg(parseFloat(e.target.value) || 0.001)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs">Molarity (M)</span>
                <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                  {molarityResult} M
                </div>
                <span className="text-[10px] text-slate-500 font-mono">mol/L</span>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs">Molality (m)</span>
                <div className="text-2xl font-extrabold text-indigo-400 font-mono mt-1">
                  {molalityResult} m
                </div>
                <span className="text-[10px] text-slate-500 font-mono">mol/kg</span>
              </div>
            </div>
          </div>

          {/* Dilution Solver: M1 V1 = M2 V2 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-3">
                Dilution Calculator: M₁ V₁ = M₂ V₂
              </span>
              <p className="text-xs text-slate-400 mb-3">
                Leave exactly ONE field blank or empty to automatically solve for it:
              </p>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Initial Conc. M₁ (M):</span>
                  <input
                    type="number"
                    placeholder="Auto"
                    value={dilM1}
                    onChange={e => setDilM1(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Initial Vol. V₁ (L):</span>
                  <input
                    type="number"
                    placeholder="Auto"
                    value={dilV1}
                    onChange={e => setDilV1(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Final Conc. M₂ (M):</span>
                  <input
                    type="number"
                    placeholder="Auto"
                    value={dilM2}
                    onChange={e => setDilM2(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Final Vol. V₂ (L):</span>
                  <input
                    type="number"
                    placeholder="Auto"
                    value={dilV2}
                    onChange={e => setDilV2(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            {dilutionResult && (
              <div className="p-4 bg-slate-950 rounded-xl border border-indigo-900/40 flex flex-col gap-1">
                <span className="text-xs text-slate-400">{dilutionResult.solvedVar}:</span>
                <span className="text-2xl font-extrabold text-emerald-400 font-mono">
                  {dilutionResult.value}
                </span>
                <span className="text-xs text-slate-400 mt-1">
                  Solvent to Add (V₂ - V₁):{' '}
                  <strong className="text-white font-mono">{dilutionResult.solventToAdd.toFixed(4)} L</strong>
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: GAS LAWS (IDEAL GAS PV = nRT)
          ========================================================================= */}
      {activeTab === 'gas_laws' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">Ideal Gas Equation: PV = nRT</span>
              <span className="text-xs font-mono text-indigo-400">R = 0.08206 L·atm/(mol·K)</span>
            </div>

            {/* Choose Target Variable */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs text-slate-400">Variable to Solve For:</span>
              <div className="grid grid-cols-4 gap-1.5 text-xs font-mono font-semibold">
                {(['P', 'V', 'n', 'T'] as const).map(target => (
                  <button
                    key={target}
                    type="button"
                    onClick={() => setGasTarget(target)}
                    className={`py-2 rounded-xl transition-all ${
                      gasTarget === target
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                    }`}
                  >
                    {target === 'P' && 'Pressure (P)'}
                    {target === 'V' && 'Volume (V)'}
                    {target === 'n' && 'Moles (n)'}
                    {target === 'T' && 'Temp (T)'}
                  </button>
                ))}
              </div>
            </div>

            {/* Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              {gasTarget !== 'P' && (
                <div>
                  <span className="text-slate-400 block mb-1">Pressure P (atm)</span>
                  <input
                    type="number"
                    value={gasP}
                    step="0.1"
                    onChange={e => setGasP(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              )}
              {gasTarget !== 'V' && (
                <div>
                  <span className="text-slate-400 block mb-1">Volume V (L)</span>
                  <input
                    type="number"
                    value={gasV}
                    step="1"
                    onChange={e => setGasV(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              )}
              {gasTarget !== 'n' && (
                <div>
                  <span className="text-slate-400 block mb-1">Moles n (mol)</span>
                  <input
                    type="number"
                    value={gasN}
                    step="0.1"
                    onChange={e => setGasN(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              )}
              {gasTarget !== 'T' && (
                <div>
                  <span className="text-slate-400 block mb-1">Temperature T (K)</span>
                  <input
                    type="number"
                    value={gasT}
                    step="5"
                    onChange={e => setGasT(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-0.5">Combined Gas Law:</span>
              <span>(P₁ V₁) / T₁ = (P₂ V₂) / T₂</span>
            </div>
          </div>

          {/* Gas Result Banner */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Gas Solution Output
            </span>

            <div className="my-auto py-6 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 font-medium">
                Computed {gasTarget === 'P' ? 'Pressure (P)' : gasTarget === 'V' ? 'Volume (V)' : gasTarget === 'n' ? 'Moles (n)' : 'Temperature (T)'}:
              </span>
              <div className="text-4xl font-extrabold text-emerald-400 font-mono mt-2">
                {parseFloat(gasResult.toFixed(4))}
                <span className="text-lg font-normal text-slate-400 ml-2">
                  {gasTarget === 'P' ? 'atm' : gasTarget === 'V' ? 'L' : gasTarget === 'n' ? 'mol' : 'K'}
                </span>
              </div>
              {gasTarget === 'T' && (
                <span className="text-xs text-slate-400 font-mono mt-1">
                  = {(gasResult - 273.15).toFixed(2)} °C
                </span>
              )}
              {gasTarget === 'P' && (
                <span className="text-xs text-slate-400 font-mono mt-1">
                  = {(gasResult * 101.325).toFixed(2)} kPa
                </span>
              )}
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Universal Constant:</span>
                <span className="text-white font-bold">8.314 J/(mol·K)</span>
              </div>
              <div>
                <span className="text-slate-500 block">Standard STP:</span>
                <span className="text-white font-bold">1 atm, 273.15 K</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: pH, ACID-BASE & BUFFERS
          ========================================================================= */}
      {activeTab === 'acid_base' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Strong Acid / Base pH & pOH */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              pH, pOH & Ion Concentrations
            </span>

            <div className="flex items-center gap-2 text-xs">
              <select
                value={phType}
                onChange={e => setPhType(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
              >
                <option value="pH">pH</option>
                <option value="pOH">pOH</option>
                <option value="H+">[H⁺] (M)</option>
                <option value="OH-">[OH⁻] (M)</option>
              </select>
              <input
                type="number"
                step="0.1"
                value={phInput}
                onChange={e => setPhInput(parseFloat(e.target.value) || 0)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2 text-sm font-mono text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block">pH Value</span>
                <span className="text-2xl font-extrabold text-indigo-400 mt-1 block">{phResult.pH}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block">pOH Value</span>
                <span className="text-2xl font-extrabold text-indigo-400 mt-1 block">{phResult.pOH}</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block">[H⁺] Concentration</span>
                <span className="text-sm font-bold text-emerald-400 mt-0.5 block">{phResult.hConc} M</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block">[OH⁻] Concentration</span>
                <span className="text-sm font-bold text-emerald-400 mt-0.5 block">{phResult.ohConc} M</span>
              </div>
            </div>
          </div>

          {/* Weak Acid & Henderson-Hasselbalch Buffers */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Weak Acid Equilibrium & Buffer pH
            </span>

            {/* Weak Acid */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <span className="font-bold text-indigo-400">Weak Acid Ionization (Ka)</span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Ka Constant</span>
                  <input
                    type="number"
                    step="any"
                    value={weakKa}
                    onChange={e => setWeakKa(parseFloat(e.target.value) || 1e-5)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Initial Conc. (M)</span>
                  <input
                    type="number"
                    step="0.05"
                    value={weakConc}
                    onChange={e => setWeakConc(parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/80 font-mono">
                <span>Calculated pH: <strong className="text-emerald-400">{weakAcidResult.pH}</strong></span>
                <span>Ionization: <strong className="text-white">{weakAcidResult.percentIonization}%</strong></span>
              </div>
            </div>

            {/* Henderson-Hasselbalch */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <span className="font-bold text-amber-400">Henderson-Hasselbalch Buffer</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">pKa</span>
                  <input
                    type="number"
                    step="0.01"
                    value={bufPka}
                    onChange={e => setBufPka(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">[Base] (M)</span>
                  <input
                    type="number"
                    step="0.05"
                    value={bufBase}
                    onChange={e => setBufBase(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">[Acid] (M)</span>
                  <input
                    type="number"
                    step="0.05"
                    value={bufAcid}
                    onChange={e => setBufAcid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/80 font-mono">
                <span>Buffer pH = pKa + log([Base]/[Acid]):</span>
                <span className="text-emerald-400 font-bold text-sm">{bufferPH}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 6: KINETICS (ARRHENIUS) & NUCLEAR HALF-LIFE
          ========================================================================= */}
      {activeTab === 'kinetics_nuclear' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Arrhenius Equation */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Arrhenius Reaction Kinetics: k = A e^(-Ea / RT)
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Pre-exponential Frequency Factor A (s⁻¹):</span>
                <input
                  type="number"
                  value={arrA}
                  onChange={e => setArrA(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Activation Energy Ea (kJ/mol):</span>
                <input
                  type="number"
                  value={arrEa}
                  onChange={e => setArrEa(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Temperature T (Kelvin):</span>
                <input
                  type="number"
                  value={arrT}
                  onChange={e => setArrT(parseFloat(e.target.value) || 298.15)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-indigo-900/40 text-center">
              <span className="text-xs text-slate-400">Rate Constant k (s⁻¹):</span>
              <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                {arrResult.rateConstant}
              </div>
              <span className="text-[11px] text-slate-500 font-mono mt-1 block">
                Boltzmann Fraction e^(-Ea/RT) = {arrResult.factorExp}
              </span>
            </div>
          </div>

          {/* Radioactive Decay & Half-Life */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Radioactive Decay & Half-Life Law
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Initial Quantity N₀ (g or counts):</span>
                <input
                  type="number"
                  value={decayN0}
                  onChange={e => setDecayN0(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Half-life t₁/₂ (years / days / seconds):</span>
                <input
                  type="number"
                  value={decayHalfLife}
                  min="0.0001"
                  onChange={e => setDecayHalfLife(Math.max(0.0001, parseFloat(e.target.value) || 1))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Elapsed Time t (same units):</span>
                <input
                  type="number"
                  value={decayTime}
                  onChange={e => setDecayTime(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
              <div>
                <span className="text-slate-400 block">Remaining N(t):</span>
                <span className="text-xl font-bold text-emerald-400">{decayResult.remainingAmount}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Fraction Left:</span>
                <span className="text-xl font-bold text-indigo-400">{decayResult.fractionRemaining}%</span>
              </div>
              <div className="col-span-2 pt-2 border-t border-slate-800/80 flex justify-between">
                <span className="text-slate-500">Decay Constant λ: {decayResult.decayConstant}</span>
                <span className="text-slate-500">Decayed: {decayResult.decayEvents}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 7: PERIODIC TABLE & CHEMICAL CONSTANTS
          ========================================================================= */}
      {activeTab === 'periodic_table' && (
        <div className="flex flex-col gap-5">
          {/* Elements Filter & Search */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search element (e.g., Fe, Gold, 26)..."
                  value={elementSearch}
                  onChange={e => setElementSearch(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-mono focus:border-indigo-500 focus:outline-none w-64"
                />
              </div>

              <select
                value={elementCategory}
                onChange={e => setElementCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono focus:border-indigo-500 focus:outline-none"
              >
                <option value="All">All Families</option>
                <option value="Nonmetal">Nonmetals</option>
                <option value="Noble Gas">Noble Gases</option>
                <option value="Alkali Metal">Alkali Metals</option>
                <option value="Alkaline Earth">Alkaline Earth</option>
                <option value="Transition Metal">Transition Metals</option>
                <option value="Post-transition Metal">Post-transition Metals</option>
                <option value="Metalloid">Metalloids</option>
                <option value="Halogen">Halogens</option>
                <option value="Actinide">Actinides</option>
              </select>
            </div>

            <span className="text-xs text-slate-400 font-mono">
              Showing {filteredElements.length} elements
            </span>
          </div>

          {/* Periodic Elements Card Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {filteredElements.map(el => (
              <div
                key={el.number}
                className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl shadow-sm flex flex-col justify-between hover:border-indigo-500/50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-500 font-bold">#{el.number}</span>
                  <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-950 text-slate-400">
                    P{el.period}
                  </span>
                </div>

                <div className="my-1.5 text-center">
                  <div className="text-2xl font-black text-indigo-300 font-mono">{el.symbol}</div>
                  <div className="text-xs font-semibold text-white truncate">{el.name}</div>
                </div>

                <div className="pt-1.5 border-t border-slate-800/80 text-[10px] font-mono flex flex-col text-slate-400">
                  <span className="text-emerald-400 font-semibold">{el.mass} g/mol</span>
                  {el.electronegativity && <span>EN: {el.electronegativity}</span>}
                </div>
              </div>
            ))}
          </div>

          {/* Chemical Constants Reference Section */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-3">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Universal Chemical & Thermochemical Constants
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {CHEMICAL_CONSTANTS.map(c => (
                <div
                  key={c.symbol}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-between gap-1.5 font-mono text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-400">{c.symbol}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(c.value);
                        setCopiedConst(c.symbol);
                        setTimeout(() => setCopiedConst(null), 1500);
                      }}
                      className="text-slate-500 hover:text-white"
                      title="Copy Value"
                    >
                      {copiedConst === c.symbol ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                  <div className="font-sans font-medium text-slate-200 text-xs">{c.name}</div>
                  <div className="text-emerald-400 font-bold text-sm">{c.value} {c.unit}</div>
                  <p className="font-sans text-[11px] text-slate-500">{c.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
