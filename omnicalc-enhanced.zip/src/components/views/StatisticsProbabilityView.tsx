import React, { useState } from 'react';
import {
  calculateSummaryStats,
  linearRegression,
  normalPDF,
  normalCDF,
  binomialPMF,
  poissonPMF,
  zTestOneSample,
  runMonteCarlo,
  SummaryStats,
  LinearRegressionResult
} from '../../utils/statisticsEngine';
import { BarChart3, TrendingUp, Sparkles, Play } from 'lucide-react';

export const StatisticsProbabilityView: React.FC = () => {
  const [subTab, setSubTab] = useState<'summary' | 'regression' | 'distributions' | 'hypothesis' | 'montecarlo'>('summary');

  // 1-Var Data
  const [dataInput, setDataInput] = useState<string>('12, 15, 18, 22, 25, 25, 29, 31, 35, 40, 42');
  const [stats, setStats] = useState<SummaryStats | null>(null);

  // 2-Var Regression Data
  const [regX, setRegX] = useState<string>('1, 2, 3, 4, 5, 6, 7, 8');
  const [regY, setRegY] = useState<string>('2.2, 3.8, 5.1, 7.0, 8.9, 10.5, 12.8, 14.2');
  const [regResult, setRegResult] = useState<LinearRegressionResult | null>(null);

  // Distributions
  const [distType, setDistType] = useState<'normal' | 'binomial' | 'poisson'>('normal');
  const [normMu, setNormMu] = useState<number>(0);
  const [normSigma, setNormSigma] = useState<number>(1);
  const [normX, setNormX] = useState<number>(1.96);
  const [binomN, setBinomN] = useState<number>(20);
  const [binomP, setBinomP] = useState<number>(0.5);
  const [binomK, setBinomK] = useState<number>(10);
  const [poisLambda, setPoisLambda] = useState<number>(4);
  const [poisK, setPoisK] = useState<number>(3);
  const [distResult, setDistResult] = useState<string | null>(null);

  // Hypothesis Test
  const [hypSampleMean, setHypSampleMean] = useState<number>(102.5);
  const [hypPopMean, setHypPopMean] = useState<number>(100);
  const [hypPopStdev, setHypPopStdev] = useState<number>(15);
  const [hypN, setHypN] = useState<number>(50);
  const [hypResult, setHypResult] = useState<string | null>(null);

  // Monte Carlo
  const [mcTrials, setMcTrials] = useState<number>(5000);
  const [mcResult, setMcResult] = useState<{ mean: number; stdev: number; min: number; max: number } | null>(null);

  const handleCompute1Var = () => {
    const parsed = dataInput
      .split(/[\s,]+/)
      .map(v => parseFloat(v))
      .filter(v => !isNaN(v));
    const s = calculateSummaryStats(parsed);
    setStats(s);
  };

  const handleComputeRegression = () => {
    const xs = regX.split(/[\s,]+/).map(v => parseFloat(v)).filter(v => !isNaN(v));
    const ys = regY.split(/[\s,]+/).map(v => parseFloat(v)).filter(v => !isNaN(v));
    const r = linearRegression(xs, ys);
    setRegResult(r);
  };

  const handleComputeDist = () => {
    if (distType === 'normal') {
      const pdf = normalPDF(normX, normMu, normSigma);
      const cdf = normalCDF(normX, normMu, normSigma);
      setDistResult(`P(X = ${normX}) PDF = ${pdf.toFixed(5)}\nP(X ≤ ${normX}) CDF = ${(cdf * 100).toFixed(3)}% (${cdf.toFixed(5)})`);
    } else if (distType === 'binomial') {
      const pmf = binomialPMF(binomN, binomK, binomP);
      setDistResult(`Binomial(n=${binomN}, p=${binomP})\nP(X = ${binomK}) = ${(pmf * 100).toFixed(3)}% (${pmf.toFixed(5)})`);
    } else {
      const pmf = poissonPMF(poisLambda, poisK);
      setDistResult(`Poisson(λ=${poisLambda})\nP(X = ${poisK}) = ${(pmf * 100).toFixed(3)}% (${pmf.toFixed(5)})`);
    }
  };

  const handleComputeZTest = () => {
    const res = zTestOneSample(hypSampleMean, hypPopMean, hypPopStdev, hypN);
    const sig = res.pValueTwoTail < 0.05 ? 'Statistically Significant (p < 0.05)' : 'Fail to reject null (p ≥ 0.05)';
    setHypResult(`Z-Score: ${res.zScore}\nTwo-tailed p-value: ${res.pValueTwoTail}\nConclusion: ${sig}`);
  };

  const handleRunMonteCarlo = () => {
    // Simulates rolling 2 dice and summing them
    const res = runMonteCarlo(() => {
      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      return d1 + d2;
    }, mcTrials);
    setMcResult(res);
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Sub tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setSubTab('summary')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'summary' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          1-Var Summary Stats
        </button>
        <button
          type="button"
          onClick={() => setSubTab('regression')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'regression' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          2-Var Regression
        </button>
        <button
          type="button"
          onClick={() => setSubTab('distributions')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'distributions' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Probability Distributions
        </button>
        <button
          type="button"
          onClick={() => setSubTab('hypothesis')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'hypothesis' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Hypothesis Z-Test
        </button>
        <button
          type="button"
          onClick={() => setSubTab('montecarlo')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'montecarlo' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Monte Carlo Simulation
        </button>
      </div>

      {/* 1. Summary Stats */}
      {subTab === 'summary' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-400" />
              1-Variable Dataset
            </div>
            <p className="text-xs text-slate-400">
              Enter numbers separated by commas, spaces, or newlines:
            </p>
            <textarea
              rows={4}
              value={dataInput}
              onChange={e => setDataInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-sm font-mono text-white focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={handleCompute1Var}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Calculate Statistics
            </button>
          </div>

          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 mb-3">
              Statistical Summary
            </div>
            {stats ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 font-mono text-xs">
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Count (n)</div>
                  <div className="text-sm font-bold text-white">{stats.count}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Mean (x̄)</div>
                  <div className="text-sm font-bold text-indigo-300">{stats.mean}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Median</div>
                  <div className="text-sm font-bold text-white">{stats.median}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Sample Stdev (s)</div>
                  <div className="text-sm font-bold text-emerald-300">{stats.stdevSample}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Pop Stdev (σ)</div>
                  <div className="text-sm font-bold text-white">{stats.stdevPop}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Variance (s²)</div>
                  <div className="text-sm font-bold text-white">{stats.varianceSample}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Min</div>
                  <div className="text-sm font-bold text-white">{stats.min}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Q1 (25th %)</div>
                  <div className="text-sm font-bold text-white">{stats.q1}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Q3 (75th %)</div>
                  <div className="text-sm font-bold text-white">{stats.q3}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Max</div>
                  <div className="text-sm font-bold text-white">{stats.max}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">IQR</div>
                  <div className="text-sm font-bold text-white">{stats.iqr}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div className="text-slate-500">Sum (Σx)</div>
                  <div className="text-sm font-bold text-white">{stats.sum}</div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-slate-500">
                Click Calculate Statistics to view summary parameters.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. Regression */}
      {subTab === 'regression' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              Linear Regression (X, Y)
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-xs text-slate-400">X Data:</span>
              <input
                type="text"
                value={regX}
                onChange={e => setRegX(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm font-mono text-white"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-xs text-slate-400">Y Data:</span>
              <input
                type="text"
                value={regY}
                onChange={e => setRegY(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm font-mono text-white"
              />
            </div>

            <button
              type="button"
              onClick={handleComputeRegression}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Fit Regression Line
            </button>
          </div>

          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Regression Model
            </div>
            {regResult ? (
              <div className="w-full flex flex-col gap-3 font-mono">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                  <div className="text-xs text-slate-500 mb-1">Fitted Equation</div>
                  <div className="text-lg font-bold text-indigo-300">{regResult.equation}</div>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                    <div className="text-slate-500">Pearson r</div>
                    <div className="text-base font-bold text-emerald-300">{regResult.r}</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                    <div className="text-slate-500">R² Coefficient</div>
                    <div className="text-base font-bold text-emerald-300">{regResult.r2}</div>
                  </div>
                </div>
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Fit linear regression to compute slope, intercept, and R².
              </span>
            )}
          </div>
        </div>
      )}

      {/* 3. Distributions */}
      {subTab === 'distributions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              Distribution Parameters
            </div>

            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => setDistType('normal')}
                className={`flex-1 py-1.5 rounded-lg border transition-colors ${
                  distType === 'normal'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Normal (Gaussian)
              </button>
              <button
                type="button"
                onClick={() => setDistType('binomial')}
                className={`flex-1 py-1.5 rounded-lg border transition-colors ${
                  distType === 'binomial'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Binomial
              </button>
              <button
                type="button"
                onClick={() => setDistType('poisson')}
                className={`flex-1 py-1.5 rounded-lg border transition-colors ${
                  distType === 'poisson'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Poisson
              </button>
            </div>

            {distType === 'normal' && (
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-400">Mean μ:</span>
                  <input
                    type="number"
                    value={normMu}
                    onChange={e => setNormMu(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Stdev σ:</span>
                  <input
                    type="number"
                    value={normSigma}
                    onChange={e => setNormSigma(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Point X:</span>
                  <input
                    type="number"
                    value={normX}
                    onChange={e => setNormX(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {distType === 'binomial' && (
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-400">Trials n:</span>
                  <input
                    type="number"
                    value={binomN}
                    onChange={e => setBinomN(parseInt(e.target.value, 10) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Prob p:</span>
                  <input
                    type="number"
                    step="0.05"
                    value={binomP}
                    onChange={e => setBinomP(parseFloat(e.target.value) || 0.5)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Successes k:</span>
                  <input
                    type="number"
                    value={binomK}
                    onChange={e => setBinomK(parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {distType === 'poisson' && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-400">Rate λ:</span>
                  <input
                    type="number"
                    value={poisLambda}
                    onChange={e => setPoisLambda(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Events k:</span>
                  <input
                    type="number"
                    value={poisK}
                    onChange={e => setPoisK(parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={handleComputeDist}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Compute Probability
            </button>
          </div>

          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Distribution Result
            </div>
            {distResult ? (
              <pre className="text-sm font-mono font-bold text-white text-center whitespace-pre-wrap">
                {distResult}
              </pre>
            ) : (
              <span className="text-xs text-slate-500">
                Compute PDF, CDF, or PMF for the selected distribution.
              </span>
            )}
          </div>
        </div>
      )}

      {/* 4. Hypothesis Testing */}
      {subTab === 'hypothesis' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              1-Sample Z-Test
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400">Sample Mean (x̄):</span>
                <input
                  type="number"
                  value={hypSampleMean}
                  onChange={e => setHypSampleMean(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Hypothesized Mean (μ₀):</span>
                <input
                  type="number"
                  value={hypPopMean}
                  onChange={e => setHypPopMean(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Pop Stdev (σ):</span>
                <input
                  type="number"
                  value={hypPopStdev}
                  onChange={e => setHypPopStdev(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              <div>
                <span className="text-slate-400">Sample Size (n):</span>
                <input
                  type="number"
                  value={hypN}
                  onChange={e => setHypN(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleComputeZTest}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Run Hypothesis Test
            </button>
          </div>

          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Test Output
            </div>
            {hypResult ? (
              <pre className="text-sm font-mono font-bold text-white text-center whitespace-pre-wrap">
                {hypResult}
              </pre>
            ) : (
              <span className="text-xs text-slate-500">
                Run hypothesis test to evaluate Z-score and p-value.
              </span>
            )}
          </div>
        </div>
      )}

      {/* 5. Monte Carlo */}
      {subTab === 'montecarlo' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Play className="w-4 h-4 text-emerald-400" />
              Monte Carlo Experiment
            </div>
            <p className="text-xs text-slate-400">
              Simulates rolling 2 standard 6-sided dice and calculating their sum across thousands of randomized trials.
            </p>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-slate-400">Number of Trials:</span>
              <select
                value={mcTrials}
                onChange={e => setMcTrials(parseInt(e.target.value, 10))}
                className="bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
              >
                <option value={1000}>1,000 trials</option>
                <option value={5000}>5,000 trials</option>
                <option value={20000}>20,000 trials</option>
                <option value={50000}>50,000 trials</option>
              </select>
            </div>
            <button
              type="button"
              onClick={handleRunMonteCarlo}
              className="py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Run Simulation
            </button>
          </div>

          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Simulation Results
            </div>
            {mcResult ? (
              <div className="grid grid-cols-2 gap-3 w-full font-mono text-xs">
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                  <div className="text-slate-500">Sample Mean</div>
                  <div className="text-base font-bold text-emerald-300">{mcResult.mean} (Expected 7.00)</div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                  <div className="text-slate-500">Stdev</div>
                  <div className="text-base font-bold text-white">{mcResult.stdev}</div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                  <div className="text-slate-500">Min Observed</div>
                  <div className="text-base font-bold text-white">{mcResult.min}</div>
                </div>
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-center">
                  <div className="text-slate-500">Max Observed</div>
                  <div className="text-base font-bold text-white">{mcResult.max}</div>
                </div>
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Click Run Simulation to generate Monte Carlo sampling.
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
