import React, { useState } from 'react';
import {
  PHYSICS_FORMULAS,
  PHYSICS_CONSTANTS,
  PhysicsFormulaItem,
  simulateProjectile,
  calculateCollision,
  calculateDoppler
} from '../../utils/physicsSolvers';
import { MathView } from '../MathView';
import {
  Zap,
  Atom,
  Wind,
  Compass,
  Gauge,
  Activity,
  Flame,
  Globe,
  Radio,
  Eye,
  Bookmark,
  Calculator,
  Search,
  Check,
  Copy,
  ChevronRight,
  TrendingUp,
  Sparkles
} from 'lucide-react';

export type PhysicsTab = 'formula_solver' | 'projectile' | 'collisions' | 'doppler' | 'constants';

export const PhysicsSolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<PhysicsTab>('formula_solver');

  // 1. Universal Formula Solver State
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedFormulaId, setSelectedFormulaId] = useState<string>('kin_v');
  const selectedFormula: PhysicsFormulaItem =
    PHYSICS_FORMULAS.find(f => f.id === selectedFormulaId) || PHYSICS_FORMULAS[0];

  const [targetVar, setTargetVar] = useState<string>(selectedFormula.variables[0].symbol);
  const [varInputs, setVarInputs] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    selectedFormula.variables.forEach(v => {
      initial[v.symbol] = v.defaultValue;
    });
    return initial;
  });

  const handleSelectFormula = (formula: PhysicsFormulaItem) => {
    setSelectedFormulaId(formula.id);
    setTargetVar(formula.variables[0].symbol);
    const updated: Record<string, number> = {};
    formula.variables.forEach(v => {
      updated[v.symbol] = v.defaultValue;
    });
    setVarInputs(updated);
  };

  const handleInputChange = (sym: string, val: number) => {
    setVarInputs(prev => ({ ...prev, [sym]: val }));
  };

  // Solve formula
  const solvedValue = selectedFormula.solve(targetVar, varInputs);
  const targetVarObj = selectedFormula.variables.find(v => v.symbol === targetVar);

  // 2. Projectile Simulator State
  const [projV0, setProjV0] = useState<number>(30);
  const [projAngle, setProjAngle] = useState<number>(45);
  const [projH0, setProjH0] = useState<number>(0);
  const [projG, setProjG] = useState<number>(9.80665);

  const projResult = simulateProjectile(projV0, projAngle, projH0, projG);

  // 3. Collision Simulator State
  const [colM1, setColM1] = useState<number>(4);
  const [colU1, setColU1] = useState<number>(6);
  const [colM2, setColM2] = useState<number>(2);
  const [colU2, setColU2] = useState<number>(-3);
  const [colType, setColType] = useState<'elastic' | 'inelastic'>('elastic');

  const colResult = calculateCollision(colM1, colU1, colM2, colU2, colType);

  // 4. Doppler Effect State
  const [dopF, setDopF] = useState<number>(440);
  const [dopV, setDopV] = useState<number>(343);
  const [dopVo, setDopVo] = useState<number>(15);
  const [dopVoTowards, setDopVoTowards] = useState<boolean>(true);
  const [dopVs, setDopVs] = useState<number>(25);
  const [dopVsTowards, setDopVsTowards] = useState<boolean>(true);

  const dopResult = calculateDoppler(dopF, dopV, dopVo, dopVoTowards, dopVs, dopVsTowards);

  // 5. Constants Search & Copy
  const [constQuery, setConstQuery] = useState<string>('');
  const [constCategory, setConstCategory] = useState<string>('All');
  const [copiedConst, setCopiedConst] = useState<string | null>(null);

  const filteredConstants = PHYSICS_CONSTANTS.filter(c => {
    const matchesSearch =
      c.name.toLowerCase().includes(constQuery.toLowerCase()) ||
      c.symbol.toLowerCase().includes(constQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(constQuery.toLowerCase());
    const matchesCategory = constCategory === 'All' || c.category === constCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    'All',
    'Kinematics',
    "Newton's Laws",
    'Momentum',
    'Work & Energy',
    'Circular & Gravitation',
    'Fluids',
    'Waves & Sound',
    'Optics',
    'Electricity & Magnetism',
    'Thermodynamics',
    'Relativity',
    'Quantum Mechanics'
  ];

  const filteredFormulas =
    selectedCategory === 'All'
      ? PHYSICS_FORMULAS
      : PHYSICS_FORMULAS.filter(f => f.category === selectedCategory);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Module Subtabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('formula_solver')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'formula_solver'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Calculator className="w-3.5 h-3.5 text-indigo-300" />
          Interactive Formula Solver (20+ Equations)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('projectile')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'projectile'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-emerald-300" />
          Projectile Motion Simulator
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('collisions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'collisions'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-amber-300" />
          Collisions & Momentum
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('doppler')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'doppler'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Radio className="w-3.5 h-3.5 text-cyan-300" />
          Waves & Doppler Effect
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('constants')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'constants'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Atom className="w-3.5 h-3.5 text-purple-300" />
          Physics Constants Database
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: INTERACTIVE FORMULA SOLVER
          ========================================================================= */}
      {activeTab === 'formula_solver' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: Category Filter & Formula Selector (4 cols) */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                1. Select Physics Category
              </span>
              <div className="flex flex-wrap gap-1 max-h-36 overflow-y-auto pr-1">
                {categories.map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                      selectedCategory === cat
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-2 max-h-[480px] overflow-y-auto">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                2. Choose Equation ({filteredFormulas.length})
              </span>
              {filteredFormulas.map(f => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => handleSelectFormula(f)}
                  className={`text-left p-2.5 rounded-xl border transition-all flex flex-col gap-1 ${
                    selectedFormulaId === f.id
                      ? 'bg-indigo-950/70 border-indigo-500 text-white shadow-sm'
                      : 'bg-slate-950/70 border-slate-800/80 text-slate-400 hover:bg-slate-850 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-slate-200">{f.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400">
                      {f.category}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-indigo-300 pointer-events-none">
                    <MathView math={f.latex} />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Multi-Variable Solver Engine (8 cols) */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
              {/* Header */}
              <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-800 gap-2">
                <div>
                  <h3 className="font-bold text-base text-white">{selectedFormula.name}</h3>
                  <p className="text-xs text-slate-400">{selectedFormula.description}</p>
                </div>
                <span className="text-xs font-mono px-2 py-0.5 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {selectedFormula.category}
                </span>
              </div>

              {/* Math Display */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center text-lg overflow-x-auto">
                <MathView math={selectedFormula.latex} block copyable />
              </div>

              {/* Variable to solve for selection */}
              <div className="flex flex-col gap-2">
                <span className="text-xs font-semibold text-slate-300">
                  Choose Unknown Variable to Solve For:
                </span>
                <div className="flex flex-wrap gap-2">
                  {selectedFormula.variables.map(v => (
                    <button
                      key={v.symbol}
                      type="button"
                      onClick={() => setTargetVar(v.symbol)}
                      className={`px-3 py-1.5 rounded-xl font-mono text-xs font-semibold transition-all flex items-center gap-1.5 ${
                        targetVar === v.symbol
                          ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-400/30'
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      <span>{v.symbol}</span>
                      <span className="text-[10px] font-sans font-normal opacity-80">({v.name})</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Known Variables */}
              <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
                <span className="text-xs font-semibold text-slate-300">Input Known Values:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {selectedFormula.variables
                    .filter(v => v.symbol !== targetVar)
                    .map(v => (
                      <div key={v.symbol} className="flex flex-col gap-1 text-xs">
                        <span className="text-slate-400 flex justify-between font-medium">
                          <span>
                            {v.name} ({v.symbol})
                          </span>
                          <span className="text-slate-500 font-mono">{v.unit}</span>
                        </span>
                        <input
                          type="number"
                          step="any"
                          value={varInputs[v.symbol] ?? v.defaultValue}
                          onChange={e => handleInputChange(v.symbol, parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                    ))}
                </div>
              </div>

              {/* Computed Solution Banner */}
              <div className="p-5 bg-slate-950 rounded-2xl border border-indigo-900/50 shadow-inner flex flex-col gap-2">
                <span className="text-xs font-medium text-slate-400">Computed Result for {targetVarObj?.name}:</span>
                <div className="flex flex-wrap items-baseline gap-2">
                  <span className="text-3xl font-extrabold text-emerald-400 font-mono">
                    {solvedValue !== null && !isNaN(solvedValue)
                      ? Math.abs(solvedValue) > 1e6 || (Math.abs(solvedValue) < 1e-3 && solvedValue !== 0)
                        ? solvedValue.toExponential(4)
                        : parseFloat(solvedValue.toFixed(4)).toString()
                      : 'Undefined'}
                  </span>
                  <span className="text-sm font-bold text-slate-300 font-mono">{targetVarObj?.unit}</span>
                </div>
                <span className="text-[11px] text-slate-500 font-mono">
                  Solved using rigorous algebraic transformation of {selectedFormula.latex}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: PROJECTILE MOTION SIMULATOR
          ========================================================================= */}
      {activeTab === 'projectile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Controls */}
          <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Launch Parameters
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-400 mb-1 font-medium">
                  <span>Launch Speed v₀ (m/s)</span>
                  <span className="font-mono text-white">{projV0} m/s</span>
                </div>
                <input
                  type="number"
                  value={projV0}
                  min="0"
                  max="1000"
                  step="1"
                  onChange={e => setProjV0(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1 font-medium">
                  <span>Launch Angle θ (degrees)</span>
                  <span className="font-mono text-indigo-400">{projAngle}°</span>
                </div>
                <input
                  type="range"
                  value={projAngle}
                  min="0"
                  max="90"
                  step="1"
                  onChange={e => setProjAngle(parseFloat(e.target.value) || 0)}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Initial Elevation h₀ (m)</span>
                <input
                  type="number"
                  value={projH0}
                  min="0"
                  step="5"
                  onChange={e => setProjH0(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1 font-medium">Gravitational Field g</span>
                <select
                  value={projG}
                  onChange={e => setProjG(parseFloat(e.target.value) || 9.80665)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
                >
                  <option value={9.80665}>Earth (9.81 m/s²)</option>
                  <option value={1.62}>Moon (1.62 m/s²)</option>
                  <option value={3.72}>Mars (3.72 m/s²)</option>
                  <option value={24.79}>Jupiter (24.79 m/s²)</option>
                </select>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Trajectory Equation:</span>
              <MathView math="y(x) = h_0 + x \\tan(\\theta) - \\frac{g x^2}{2 v_0^2 \\cos^2(\\theta)}" block />
            </div>
          </div>

          {/* Results & Visual Trajectory */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            {/* Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl">
                <span className="text-slate-400 text-xs">Horizontal Range</span>
                <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                  {projResult.horizontalRange} m
                </div>
              </div>
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl">
                <span className="text-slate-400 text-xs">Max Apex Height</span>
                <div className="text-xl font-bold font-mono text-indigo-400 mt-0.5">
                  {projResult.maxHeight} m
                </div>
              </div>
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl">
                <span className="text-slate-400 text-xs">Flight Duration</span>
                <div className="text-xl font-bold font-mono text-white mt-0.5">
                  {projResult.flightTime} s
                </div>
              </div>
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl">
                <span className="text-slate-400 text-xs">Impact Velocity</span>
                <div className="text-xl font-bold font-mono text-amber-400 mt-0.5">
                  {projResult.vImpact} m/s
                </div>
              </div>
            </div>

            {/* SVG Visual Canvas */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-3">
              <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
                <span>Simulated Flight Trajectory Arc</span>
                <span className="font-mono">
                  Scale: {projResult.horizontalRange}m × {projResult.maxHeight}m
                </span>
              </div>

              <div className="h-56 w-full bg-slate-950 rounded-xl border border-slate-800/80 p-3 flex items-end">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 500 180" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="0" y1="170" x2="500" y2="170" stroke="#334155" strokeWidth="2" />
                  <line x1="10" y1="0" x2="10" y2="180" stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />

                  {/* Parabolic Polyline */}
                  {projResult.trajectory.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#6366f1"
                      strokeWidth="3"
                      points={projResult.trajectory
                        .map(p => {
                          const x = 10 + (p.x / Math.max(1, projResult.horizontalRange)) * 480;
                          const y = 170 - (p.y / Math.max(1, projResult.maxHeight)) * 150;
                          return `${x},${y}`;
                        })
                        .join(' ')}
                    />
                  )}

                  {/* Apex Point Marker */}
                  <circle
                    cx={10 + 240}
                    cy={170 - 150}
                    r="4"
                    fill="#34d399"
                  />
                </svg>
              </div>

              <div className="flex justify-between text-[11px] font-mono text-slate-500">
                <span>Origin (0, {projH0}m)</span>
                <span className="text-emerald-400 font-semibold">Apex ({projResult.maxHeight}m)</span>
                <span>Impact ({projResult.horizontalRange}m, 0m)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: COLLISIONS & MOMENTUM
          ========================================================================= */}
      {activeTab === 'collisions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Inputs */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">1D Collision Setup</span>
              <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setColType('elastic')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    colType === 'elastic' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Elastic (KE conserved)
                </button>
                <button
                  type="button"
                  onClick={() => setColType('inelastic')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    colType === 'inelastic' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Inelastic (Stick)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              {/* Body 1 */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-indigo-400">Body 1 (m₁)</span>
                <div>
                  <span className="text-slate-400 block mb-1">Mass m₁ (kg)</span>
                  <input
                    type="number"
                    value={colM1}
                    min="0.1"
                    step="0.5"
                    onChange={e => setColM1(Math.max(0.1, parseFloat(e.target.value) || 1))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Initial Velocity u₁ (m/s)</span>
                  <input
                    type="number"
                    value={colU1}
                    step="1"
                    onChange={e => setColU1(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>

              {/* Body 2 */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-amber-400">Body 2 (m₂)</span>
                <div>
                  <span className="text-slate-400 block mb-1">Mass m₂ (kg)</span>
                  <input
                    type="number"
                    value={colM2}
                    min="0.1"
                    step="0.5"
                    onChange={e => setColM2(Math.max(0.1, parseFloat(e.target.value) || 1))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Initial Velocity u₂ (m/s)</span>
                  <input
                    type="number"
                    value={colU2}
                    step="1"
                    onChange={e => setColU2(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Conservation Laws:</span>
              <div>• Total Momentum: P = m₁u₁ + m₂u₂ = m₁v₁ + m₂v₂</div>
              {colType === 'elastic' && <div>• Kinetic Energy: KE₁ + KE₂ = KE₁' + KE₂'</div>}
            </div>
          </div>

          {/* Results */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Post-Collision Dynamics
            </span>

            <div className="grid grid-cols-2 gap-4 my-auto py-3">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs">Body 1 Final Velocity (v₁)</span>
                <div className="text-2xl font-extrabold text-indigo-400 font-mono mt-1">
                  {colResult.v1Final} m/s
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-400 text-xs">Body 2 Final Velocity (v₂)</span>
                <div className="text-2xl font-extrabold text-amber-400 font-mono mt-1">
                  {colResult.v2Final} m/s
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Total Momentum:</span>
                <span className="text-emerald-400 font-bold">{colResult.finalMomentum} kg·m/s</span>
              </div>
              <div>
                <span className="text-slate-500 block">Kinetic Energy Lost:</span>
                <span className="text-rose-400 font-bold">{colResult.energyLoss} J</span>
              </div>
              <div>
                <span className="text-slate-500 block">Initial KE:</span>
                <span className="text-white font-bold">{colResult.initialKE} J</span>
              </div>
              <div>
                <span className="text-slate-500 block">Final KE:</span>
                <span className="text-white font-bold">{colResult.finalKE} J</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: WAVES & DOPPLER EFFECT
          ========================================================================= */}
      {activeTab === 'doppler' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Acoustic Doppler Parameters
            </span>

            <div className="flex flex-col gap-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Source Frequency f (Hz)</span>
                  <input
                    type="number"
                    value={dopF}
                    min="1"
                    step="10"
                    onChange={e => setDopF(Math.max(1, parseFloat(e.target.value) || 1))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Medium Sound Speed v (m/s)</span>
                  <input
                    type="number"
                    value={dopV}
                    min="100"
                    step="1"
                    onChange={e => setDopV(Math.max(10, parseFloat(e.target.value) || 343))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              {/* Observer */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-semibold text-indigo-400">Observer Speed & Motion</span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={dopVo}
                    min="0"
                    step="1"
                    onChange={e => setDopVo(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    placeholder="Speed m/s"
                  />
                  <select
                    value={dopVoTowards ? 'towards' : 'away'}
                    onChange={e => setDopVoTowards(e.target.value === 'towards')}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono text-xs"
                  >
                    <option value="towards">Towards Source</option>
                    <option value="away">Away from Source</option>
                  </select>
                </div>
              </div>

              {/* Source */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-semibold text-amber-400">Source Speed & Motion</span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={dopVs}
                    min="0"
                    step="1"
                    onChange={e => setDopVs(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    placeholder="Speed m/s"
                  />
                  <select
                    value={dopVsTowards ? 'towards' : 'away'}
                    onChange={e => setDopVsTowards(e.target.value === 'towards')}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono text-xs"
                  >
                    <option value="towards">Towards Observer</option>
                    <option value="away">Away from Observer</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="text-slate-300 font-semibold block mb-1">Equation:</span>
              <MathView math="f' = f \\cdot \\left(\\frac{v \\pm v_o}{v \\mp v_s}\\right)" block />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Observed Frequency Output
            </span>

            <div className="my-auto py-6 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 font-medium">Perceived Frequency (f')</span>
              <div className="text-4xl font-extrabold text-indigo-400 mt-2 font-mono">
                {dopResult.observedFrequency} Hz
              </div>
              <span
                className={`text-xs font-mono mt-1 font-semibold ${
                  dopResult.freqShift >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {dopResult.freqShift >= 0 ? `+${dopResult.freqShift} Hz (Pitch Up)` : `${dopResult.freqShift} Hz (Pitch Down)`}
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block">Original Pitch:</span>
                <span className="text-white font-bold">{dopF} Hz</span>
              </div>
              <div>
                <span className="text-slate-500 block">Sound Medium:</span>
                <span className="text-white font-bold">{dopV} m/s</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: PHYSICS CONSTANTS DATABASE
          ========================================================================= */}
      {activeTab === 'constants' && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search constant (e.g. Planck, c, G, ε₀)..."
                  value={constQuery}
                  onChange={e => setConstQuery(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-mono focus:border-indigo-500 focus:outline-none w-64"
                />
              </div>

              <select
                value={constCategory}
                onChange={e => setConstCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono focus:border-indigo-500 focus:outline-none"
              >
                <option value="All">All Categories</option>
                <option value="Fundamental">Fundamental</option>
                <option value="Gravitation">Gravitation</option>
                <option value="Quantum">Quantum</option>
                <option value="Electromagnetism">Electromagnetism</option>
                <option value="Thermodynamics">Thermodynamics</option>
                <option value="Fluids">Fluids</option>
              </select>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              Showing {filteredConstants.length} constants
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredConstants.map(c => (
              <div
                key={c.symbol}
                className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-sm flex flex-col justify-between gap-2 hover:border-slate-700 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-indigo-300 font-mono">{c.symbol}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                      {c.category}
                    </span>
                  </div>
                  <div className="font-semibold text-xs text-white mt-0.5">{c.name}</div>
                  <p className="text-[11px] text-slate-400 mt-1">{c.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between font-mono text-xs">
                  <div className="flex items-baseline gap-1 text-emerald-400 font-bold">
                    <span>
                      {Math.abs(c.value) < 1e-4 || Math.abs(c.value) > 1e5
                        ? c.value.toExponential(4)
                        : c.value}
                    </span>
                    <span className="text-[10px] text-slate-400 font-normal">{c.unit}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(c.value.toString());
                      setCopiedConst(c.symbol);
                      setTimeout(() => setCopiedConst(null), 1500);
                    }}
                    className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                    title="Copy Value"
                  >
                    {copiedConst === c.symbol ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
