import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AngleUnit } from '../../types/calc';
import { evalFunctionAt, evaluateExpression } from '../../utils/mathEngine';
import { numericalDerivative, numericalIntegrate } from '../../utils/calculusEngine';
import { ZoomIn, ZoomOut, RotateCcw, Crosshair, Sparkles, Layers, Eye, EyeOff } from 'lucide-react';

interface GraphingViewProps {
  angleUnit: AngleUnit;
}

interface FunctionItem {
  id: string;
  expr: string;
  color: string;
  enabled: boolean;
}

export const GraphingView: React.FC<GraphingViewProps> = ({ angleUnit }) => {
  const [graphMode, setGraphMode] = useState<'cartesian' | 'polar' | 'parametric' | '3d'>('cartesian');

  // Multi-function expressions
  const [functions, setFunctions] = useState<FunctionItem[]>([
    { id: 'f1', expr: 'sin(x)', color: '#38bdf8', enabled: true },
    { id: 'f2', expr: 'x^2 / 4 - 2', color: '#f43f5e', enabled: true },
    { id: 'f3', expr: '0.5 * x', color: '#10b981', enabled: false }
  ]);

  // Polar expression
  const [polarExpr, setPolarExpr] = useState<string>('2 * sin(4 * theta)');

  // Parametric expressions
  const [paramX, setParamX] = useState<string>('3 * cos(t)');
  const [paramY, setParamY] = useState<string>('2 * sin(t)');

  // 3D surface expression
  const [surfaceExpr, setSurfaceExpr] = useState<string>('cos(sqrt(x^2 + y^2))');
  const [rotX, setRotX] = useState<number>(30);
  const [rotY, setRotY] = useState<number>(45);

  // Viewport window
  const [xMin, setXMin] = useState<number>(-10);
  const [xMax, setXMax] = useState<number>(10);
  const [yMin, setYMin] = useState<number>(-6);
  const [yMax, setYMax] = useState<number>(6);

  // Analysis Tools
  const [traceActive, setTraceActive] = useState<boolean>(true);
  const [hoverCoords, setHoverCoords] = useState<{ x: number; y: number; slope: number } | null>(null);
  const [showRoots, setShowRoots] = useState<boolean>(false);
  const [detectedRoots, setDetectedRoots] = useState<{ x: number; y: number }[]>([]);

  // Definite integral shading
  const [shadeIntegral, setShadeIntegral] = useState<boolean>(false);
  const [intA, setIntA] = useState<number>(0);
  const [intB, setIntB] = useState<number>(Math.PI);
  const [intResult, setIntResult] = useState<number | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDragging = useRef<boolean>(false);
  const lastMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Update canvas sizing & draw
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    if (graphMode === '3d') {
      draw3DSurface(ctx, width, height);
      return;
    }

    // Coordinate transforms
    const toScreenX = (x: number) => ((x - xMin) / (xMax - xMin)) * width;
    const toScreenY = (y: number) => height - ((y - yMin) / (yMax - yMin)) * height;
    const toMathX = (px: number) => xMin + (px / width) * (xMax - xMin);
    const toMathY = (py: number) => yMax - (py / height) * (yMax - yMin);

    // Grid lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;

    // Step calculation
    const xRange = xMax - xMin;
    const yRange = yMax - yMin;
    const roughStep = Math.pow(10, Math.floor(Math.log10(xRange / 5)));
    const stepX = xRange / roughStep > 15 ? roughStep * 2 : roughStep;
    const stepY = stepX;

    const firstGridX = Math.floor(xMin / stepX) * stepX;
    for (let x = firstGridX; x <= xMax; x += stepX) {
      const sx = toScreenX(x);
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
      ctx.stroke();

      if (Math.abs(x) > 1e-9) {
        ctx.fillStyle = '#475569';
        ctx.font = '10px monospace';
        ctx.fillText(parseFloat(x.toFixed(2)).toString(), sx + 3, toScreenY(0) + 12);
      }
    }

    const firstGridY = Math.floor(yMin / stepY) * stepY;
    for (let y = firstGridY; y <= yMax; y += stepY) {
      const sy = toScreenY(y);
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
      ctx.stroke();

      if (Math.abs(y) > 1e-9) {
        ctx.fillStyle = '#475569';
        ctx.font = '10px monospace';
        ctx.fillText(parseFloat(y.toFixed(2)).toString(), toScreenX(0) + 4, sy - 3);
      }
    }

    // Main Axes
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.5;

    // X Axis
    const yAxisZero = toScreenY(0);
    ctx.beginPath();
    ctx.moveTo(0, yAxisZero);
    ctx.lineTo(width, yAxisZero);
    ctx.stroke();

    // Y Axis
    const xAxisZero = toScreenX(0);
    ctx.beginPath();
    ctx.moveTo(xAxisZero, 0);
    ctx.lineTo(xAxisZero, height);
    ctx.stroke();

    // Integral shading (if active)
    if (shadeIntegral && functions[0]?.enabled && intA < intB) {
      const activeExpr = functions[0].expr;
      ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
      ctx.beginPath();

      const startSx = toScreenX(intA);
      const endSx = toScreenX(intB);
      ctx.moveTo(startSx, toScreenY(0));

      const stepPx = 2;
      for (let sx = startSx; sx <= endSx; sx += stepPx) {
        const mx = toMathX(sx);
        const my = evalFunctionAt(activeExpr, mx, angleUnit);
        if (!isNaN(my) && isFinite(my)) {
          ctx.lineTo(sx, toScreenY(my));
        }
      }
      ctx.lineTo(endSx, toScreenY(0));
      ctx.closePath();
      ctx.fill();
    }

    // Plot Functions
    if (graphMode === 'cartesian') {
      const foundRoots: { x: number; y: number }[] = [];

      functions.forEach(fn => {
        if (!fn.enabled || !fn.expr.trim()) return;

        ctx.strokeStyle = fn.color;
        ctx.lineWidth = 2.2;
        ctx.beginPath();

        let started = false;
        let lastY = 0;

        for (let px = 0; px <= width; px += 1.5) {
          const x = toMathX(px);
          const y = evalFunctionAt(fn.expr, x, angleUnit);

          if (!isNaN(y) && isFinite(y)) {
            const py = toScreenY(y);

            // Check for root crossing
            if (showRoots && started && ((lastY > 0 && y < 0) || (lastY < 0 && y > 0))) {
              foundRoots.push({ x: parseFloat(x.toFixed(3)), y: 0 });
            }
            lastY = y;

            if (!started) {
              ctx.moveTo(px, py);
              started = true;
            } else {
              // Discontinuity prevention (e.g. tan(x))
              if (Math.abs(py - toScreenY(lastY)) < height * 0.8) {
                ctx.lineTo(px, py);
              } else {
                ctx.moveTo(px, py);
              }
            }
          } else {
            started = false;
          }
        }
        ctx.stroke();
      });

      if (showRoots) {
        setDetectedRoots(foundRoots.slice(0, 10));
        ctx.fillStyle = '#f59e0b';
        foundRoots.forEach(r => {
          const sx = toScreenX(r.x);
          const sy = toScreenY(0);
          ctx.beginPath();
          ctx.arc(sx, sy, 4, 0, 2 * Math.PI);
          ctx.fill();
        });
      }
    } else if (graphMode === 'polar') {
      // Polar coordinates r(theta)
      ctx.strokeStyle = '#ec4899';
      ctx.lineWidth = 2.2;
      ctx.beginPath();

      const thetaMax = 8 * Math.PI;
      const thetaStep = 0.02;
      let started = false;

      for (let th = 0; th <= thetaMax; th += thetaStep) {
        const r = evalFunctionAt(polarExpr.replace(/theta/g, 'x'), th, angleUnit);
        if (!isNaN(r) && isFinite(r)) {
          const x = r * Math.cos(th);
          const y = r * Math.sin(th);
          const sx = toScreenX(x);
          const sy = toScreenY(y);

          if (!started) {
            ctx.moveTo(sx, sy);
            started = true;
          } else {
            ctx.lineTo(sx, sy);
          }
        }
      }
      ctx.stroke();
    } else if (graphMode === 'parametric') {
      // Parametric x(t), y(t)
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 2.2;
      ctx.beginPath();

      const tMin = -10, tMax = 10, tStep = 0.02;
      let started = false;

      for (let t = tMin; t <= tMax; t += tStep) {
        const x = evalFunctionAt(paramX.replace(/t/g, 'x'), t, angleUnit);
        const y = evalFunctionAt(paramY.replace(/t/g, 'x'), t, angleUnit);
        if (!isNaN(x) && !isNaN(y) && isFinite(x) && isFinite(y)) {
          const sx = toScreenX(x);
          const sy = toScreenY(y);
          if (!started) {
            ctx.moveTo(sx, sy);
            started = true;
          } else {
            ctx.lineTo(sx, sy);
          }
        }
      }
      ctx.stroke();
    }

    // Hover / Trace Point
    if (traceActive && hoverCoords && graphMode === 'cartesian') {
      const sx = toScreenX(hoverCoords.x);
      const sy = toScreenY(hoverCoords.y);

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(sx, sy, 5, 0, 2 * Math.PI);
      ctx.fill();

      // Tangent line at hover point
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      const dx = 2;
      const dy = hoverCoords.slope * dx;
      ctx.moveTo(toScreenX(hoverCoords.x - dx), toScreenY(hoverCoords.y - dy));
      ctx.lineTo(toScreenX(hoverCoords.x + dx), toScreenY(hoverCoords.y + dy));
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }, [
    graphMode,
    functions,
    polarExpr,
    paramX,
    paramY,
    xMin,
    xMax,
    yMin,
    yMax,
    traceActive,
    hoverCoords,
    showRoots,
    shadeIntegral,
    intA,
    intB,
    angleUnit,
    rotX,
    rotY
  ]);

  // 3D wireframe surface drawing
  const draw3DSurface = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1;

    const radX = (rotX * Math.PI) / 180;
    const radY = (rotY * Math.PI) / 180;

    const cosX = Math.cos(radX), sinX = Math.sin(radX);
    const cosY = Math.cos(radY), sinY = Math.sin(radY);

    const project = (x: number, y: number, z: number) => {
      // 3D rotation
      const x1 = x * cosY + y * sinY;
      const y1 = -x * sinY + y * cosY;
      const y2 = y1 * cosX - z * sinX;
      const z2 = y1 * sinX + z * cosX;

      const scale = 28;
      const px = width / 2 + x1 * scale;
      const py = height / 2 - z2 * scale + y2 * 5;
      return { px, py };
    };

    const gridSize = 24;
    const span = 4;
    const step = (span * 2) / gridSize;

    // Draw mesh lines
    for (let i = 0; i <= gridSize; i++) {
      const x = -span + i * step;
      ctx.beginPath();
      let started = false;
      for (let j = 0; j <= gridSize; j++) {
        const y = -span + j * step;
        const z = evalFunctionAt(surfaceExpr.replace(/y/g, `${y}`), x, angleUnit) || 0;
        const p = project(x, y, z);
        if (!started) {
          ctx.moveTo(p.px, p.py);
          started = true;
        } else {
          ctx.lineTo(p.px, p.py);
        }
      }
      ctx.stroke();
    }

    for (let j = 0; j <= gridSize; j++) {
      const y = -span + j * step;
      ctx.beginPath();
      let started = false;
      for (let i = 0; i <= gridSize; i++) {
        const x = -span + i * step;
        const z = evalFunctionAt(surfaceExpr.replace(/y/g, `${y}`), x, angleUnit) || 0;
        const p = project(x, y, z);
        if (!started) {
          ctx.moveTo(p.px, p.py);
          started = true;
        } else {
          ctx.lineTo(p.px, p.py);
        }
      }
      ctx.stroke();
    }
  };

  useEffect(() => {
    draw();
  }, [draw]);

  // Handle Canvas mouse events (drag pan & trace)
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDragging.current = true;
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (isDragging.current) {
      const dx = e.clientX - lastMousePos.current.x;
      const dy = e.clientY - lastMousePos.current.y;
      lastMousePos.current = { x: e.clientX, y: e.clientY };

      if (graphMode === '3d') {
        setRotY(prev => prev + dx * 0.5);
        setRotX(prev => Math.max(-80, Math.min(80, prev - dy * 0.5)));
      } else {
        const xSpan = xMax - xMin;
        const ySpan = yMax - yMin;
        const shiftX = (dx / canvas.width) * xSpan;
        const shiftY = (dy / canvas.height) * ySpan;

        setXMin(prev => prev - shiftX);
        setXMax(prev => prev - shiftX);
        setYMin(prev => prev + shiftY);
        setYMax(prev => prev + shiftY);
      }
    } else if (traceActive && graphMode === 'cartesian') {
      const rect = canvas.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const mathX = xMin + (px / canvas.width) * (xMax - xMin);

      const activeFn = functions.find(f => f.enabled);
      if (activeFn) {
        const mathY = evalFunctionAt(activeFn.expr, mathX, angleUnit);
        const slope = numericalDerivative(activeFn.expr, mathX);
        if (!isNaN(mathY) && isFinite(mathY)) {
          setHoverCoords({
            x: parseFloat(mathX.toFixed(3)),
            y: parseFloat(mathY.toFixed(3)),
            slope: parseFloat(slope.toFixed(3))
          });
        }
      }
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 0.9 : 1.1;
    zoom(factor);
  };

  const zoom = (factor: number) => {
    const xCenter = (xMin + xMax) / 2;
    const yCenter = (yMin + yMax) / 2;
    const xHalf = ((xMax - xMin) * factor) / 2;
    const yHalf = ((yMax - yMin) * factor) / 2;

    setXMin(xCenter - xHalf);
    setXMax(xCenter + xHalf);
    setYMin(yCenter - yHalf);
    setYMax(yCenter + yHalf);
  };

  const handleResetView = () => {
    setXMin(-10);
    setXMax(10);
    setYMin(-6);
    setYMax(6);
    setRotX(30);
    setRotY(45);
  };

  // Calculate integral
  const handleCalculateIntegral = () => {
    if (!functions[0]?.enabled) return;
    const res = numericalIntegrate(functions[0].expr, intA, intB);
    setIntResult(parseFloat(res.toFixed(5)));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full">
      {/* Canvas Area */}
      <div className="lg:col-span-8 flex flex-col gap-3">
        <div className="relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
          {/* Top Canvas Controls */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
            <div className="flex items-center gap-1.5 pointer-events-auto bg-slate-900/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setGraphMode('cartesian')}
                className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                  graphMode === 'cartesian' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                2D Cartesian
              </button>
              <button
                type="button"
                onClick={() => setGraphMode('polar')}
                className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                  graphMode === 'polar' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Polar r(θ)
              </button>
              <button
                type="button"
                onClick={() => setGraphMode('parametric')}
                className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                  graphMode === 'parametric' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Parametric
              </button>
              <button
                type="button"
                onClick={() => setGraphMode('3d')}
                className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                  graphMode === '3d' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                3D Surface
              </button>
            </div>

            {/* Navigation & Zoom Tools */}
            <div className="flex items-center gap-1 pointer-events-auto bg-slate-900/90 backdrop-blur-md p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => zoom(0.8)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => zoom(1.25)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleResetView}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Reset View"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Canvas */}
          <canvas
            ref={canvasRef}
            width={760}
            height={460}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
            className="w-full h-[460px] cursor-grab active:cursor-grabbing block"
          />

          {/* Live Trace Banner */}
          {traceActive && hoverCoords && graphMode === 'cartesian' && (
            <div className="absolute bottom-3 left-3 pointer-events-none bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-200 flex items-center gap-3 shadow-lg">
              <div className="flex items-center gap-1.5">
                <Crosshair className="w-3.5 h-3.5 text-indigo-400" />
                <span>
                  x: <strong className="text-white">{hoverCoords.x}</strong>, y:{' '}
                  <strong className="text-white">{hoverCoords.y}</strong>
                </span>
              </div>
              <span className="text-slate-400">
                dy/dx: <strong className="text-amber-300">{hoverCoords.slope}</strong>
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Function Panel & Analysis Tools */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* Equations Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-sm font-semibold text-slate-200">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              Function Inputs
            </div>
          </div>

          {graphMode === 'cartesian' && (
            <div className="space-y-2.5">
              {functions.map((fn, idx) => (
                <div key={fn.id} className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFunctions(prev =>
                        prev.map(f => (f.id === fn.id ? { ...f, enabled: !f.enabled } : f))
                      );
                    }}
                    className="p-1 rounded text-slate-400 hover:text-white"
                  >
                    {fn.enabled ? (
                      <Eye className="w-4 h-4" style={{ color: fn.color }} />
                    ) : (
                      <EyeOff className="w-4 h-4 text-slate-600" />
                    )}
                  </button>
                  <span className="text-xs font-mono font-bold" style={{ color: fn.color }}>
                    f{idx + 1}(x) =
                  </span>
                  <input
                    type="text"
                    value={fn.expr}
                    onChange={e => {
                      const val = e.target.value;
                      setFunctions(prev =>
                        prev.map(f => (f.id === fn.id ? { ...f, expr: val } : f))
                      );
                    }}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-sm font-mono text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              ))}
            </div>
          )}

          {graphMode === 'polar' && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-pink-400">r(θ) =</span>
              <input
                type="text"
                value={polarExpr}
                onChange={e => setPolarExpr(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-sm font-mono text-white focus:outline-none focus:border-pink-500"
              />
            </div>
          )}

          {graphMode === 'parametric' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-purple-400">x(t) =</span>
                <input
                  type="text"
                  value={paramX}
                  onChange={e => setParamX(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-sm font-mono text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-purple-400">y(t) =</span>
                <input
                  type="text"
                  value={paramY}
                  onChange={e => setParamY(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-sm font-mono text-white focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>
          )}

          {graphMode === '3d' && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-sky-400">z(x,y) =</span>
                <input
                  type="text"
                  value={surfaceExpr}
                  onChange={e => setSurfaceExpr(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-sm font-mono text-white focus:outline-none focus:border-sky-500"
                />
              </div>
              <div className="text-[11px] text-slate-500">
                Drag to rotate view. Pitch: {Math.round(rotX)}°, Yaw: {Math.round(rotY)}°
              </div>
            </div>
          )}
        </div>

        {/* Calculus & Analysis Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Calculus & Curve Analysis
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowRoots(!showRoots)}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium border transition-colors ${
                showRoots
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              Find Roots (Zeros)
            </button>
            <button
              type="button"
              onClick={() => setShadeIntegral(!shadeIntegral)}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium border transition-colors ${
                shadeIntegral
                  ? 'bg-sky-500/20 text-sky-300 border-sky-500/60'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              Shade Integral
            </button>
          </div>

          {showRoots && detectedRoots.length > 0 && (
            <div className="text-xs font-mono text-slate-300 bg-slate-950 p-2 rounded-lg border border-slate-800">
              <div className="text-slate-500 mb-1">Detected Roots:</div>
              <div className="flex flex-wrap gap-1.5">
                {detectedRoots.map((r, i) => (
                  <span key={i} className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300">
                    x ≈ {r.x}
                  </span>
                ))}
              </div>
            </div>
          )}

          {shadeIntegral && (
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
              <div className="text-slate-400 font-medium">Definite Integral ∫ [a, b] f₁(x) dx:</div>
              <div className="flex items-center gap-2">
                <span>a:</span>
                <input
                  type="number"
                  value={intA}
                  onChange={e => setIntA(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-800 rounded px-2 py-0.5 text-white font-mono"
                />
                <span>b:</span>
                <input
                  type="number"
                  value={intB}
                  onChange={e => setIntB(parseFloat(e.target.value) || 0)}
                  className="w-16 bg-slate-900 border border-slate-800 rounded px-2 py-0.5 text-white font-mono"
                />
                <button
                  type="button"
                  onClick={handleCalculateIntegral}
                  className="ml-auto px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium transition-colors"
                >
                  Compute
                </button>
              </div>

              {intResult !== null && (
                <div className="font-mono text-emerald-400 pt-1 border-t border-slate-800/80">
                  ∫ = <strong>{intResult}</strong>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
