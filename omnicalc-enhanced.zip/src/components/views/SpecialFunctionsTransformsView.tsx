import React, { useState } from 'react';
import {
  gamma,
  beta,
  erf,
  erfc,
  besselJ0,
  besselJ1,
  riemannZeta,
  lambertW,
  discreteFourierTransform,
  discreteConvolution,
  DFTPoint
} from '../../utils/specialFunctionsAndTransforms';
import { Activity, Waves, Sparkles } from 'lucide-react';

export const SpecialFunctionsTransformsView: React.FC = () => {
  const [subTab, setSubTab] = useState<'special' | 'dft' | 'convolution'>('special');

  // Special Functions
  const [selectedFn, setSelectedFn] = useState<'gamma' | 'beta' | 'erf' | 'bessel0' | 'bessel1' | 'zeta' | 'lambert'>('gamma');
  const [paramX, setParamX] = useState<number>(5);
  const [paramY, setParamY] = useState<number>(3);
  const [fnResult, setFnResult] = useState<string | null>(null);

  // DFT State
  const [dftInput, setDftInput] = useState<string>('1, 0, -1, 0, 1, 0, -1, 0');
  const [dftPoints, setDftPoints] = useState<DFTPoint[] | null>(null);

  // Convolution State
  const [convX, setConvX] = useState<string>('1, 2, 3, 1');
  const [convH, setConvH] = useState<string>('1, -1');
  const [convResult, setConvResult] = useState<number[] | null>(null);

  const handleComputeSpecial = () => {
    let res = 0;
    let label = '';
    switch (selectedFn) {
      case 'gamma':
        res = gamma(paramX);
        label = `Γ(${paramX}) = ${res.toFixed(8)}`;
        break;
      case 'beta':
        res = beta(paramX, paramY);
        label = `B(${paramX}, ${paramY}) = ${res.toFixed(8)}`;
        break;
      case 'erf':
        res = erf(paramX);
        label = `erf(${paramX}) = ${res.toFixed(8)} (erfc: ${erfc(paramX).toFixed(8)})`;
        break;
      case 'bessel0':
        res = besselJ0(paramX);
        label = `J₀(${paramX}) = ${res.toFixed(8)}`;
        break;
      case 'bessel1':
        res = besselJ1(paramX);
        label = `J₁(${paramX}) = ${res.toFixed(8)}`;
        break;
      case 'zeta':
        res = riemannZeta(paramX);
        label = `ζ(${paramX}) = ${res.toFixed(8)}`;
        break;
      case 'lambert':
        res = lambertW(paramX);
        label = `W₀(${paramX}) = ${res.toFixed(8)}`;
        break;
    }
    setFnResult(label);
  };

  const handleComputeDFT = () => {
    const samples = dftInput
      .split(/[\s,]+/)
      .map(v => parseFloat(v))
      .filter(v => !isNaN(v));
    const spectrum = discreteFourierTransform(samples);
    setDftPoints(spectrum);
  };

  const handleComputeConv = () => {
    const x = convX.split(/[\s,]+/).map(v => parseFloat(v)).filter(v => !isNaN(v));
    const h = convH.split(/[\s,]+/).map(v => parseFloat(v)).filter(v => !isNaN(v));
    const out = discreteConvolution(x, h);
    setConvResult(out);
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Sub tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setSubTab('special')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'special' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Special Functions
        </button>
        <button
          type="button"
          onClick={() => setSubTab('dft')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'dft' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Fourier Transform (DFT)
        </button>
        <button
          type="button"
          onClick={() => setSubTab('convolution')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'convolution' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Signal Convolution
        </button>
      </div>

      {/* 1. Special Functions */}
      {subTab === 'special' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Advanced Mathematical Functions
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-xs">
              {[
                { id: 'gamma', name: 'Gamma Γ(x)' },
                { id: 'beta', name: 'Beta B(x,y)' },
                { id: 'erf', name: 'Error erf(x)' },
                { id: 'bessel0', name: 'Bessel J₀(x)' },
                { id: 'bessel1', name: 'Bessel J₁(x)' },
                { id: 'zeta', name: 'Zeta ζ(s)' },
                { id: 'lambert', name: 'Lambert W₀(x)' }
              ].map(f => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setSelectedFn(f.id as any)}
                  className={`py-2 px-2.5 rounded-lg border font-mono transition-colors text-center ${
                    selectedFn === f.id
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {f.name}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs pt-2">
              <div>
                <span className="text-slate-400">Parameter x (or s):</span>
                <input
                  type="number"
                  step="0.1"
                  value={paramX}
                  onChange={e => setParamX(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                />
              </div>
              {selectedFn === 'beta' && (
                <div>
                  <span className="text-slate-400">Parameter y:</span>
                  <input
                    type="number"
                    step="0.1"
                    value={paramY}
                    onChange={e => setParamY(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleComputeSpecial}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Evaluate Function
            </button>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Function Output
            </div>
            {fnResult ? (
              <div className="text-lg font-mono font-bold text-emerald-300 text-center">
                {fnResult}
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Select a function and compute its analytical value.
              </span>
            )}
          </div>
        </div>
      )}

      {/* 2. Fourier Transform */}
      {subTab === 'dft' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Waves className="w-4 h-4 text-indigo-400" />
              Time-Domain Input Samples
            </div>
            <p className="text-xs text-slate-400">
              Enter discrete samples separated by commas or spaces:
            </p>
            <input
              type="text"
              value={dftInput}
              onChange={e => setDftInput(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm font-mono text-white"
            />
            <button
              type="button"
              onClick={handleComputeDFT}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Compute Discrete Fourier Transform
            </button>
          </div>

          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 mb-3">
              Frequency Spectrum (|X[k]|)
            </div>
            {dftPoints ? (
              <div className="flex-1 flex flex-col gap-3">
                {/* Visual spectrum bars */}
                <div className="h-36 flex items-end gap-1.5 p-3 bg-slate-950 rounded-xl border border-slate-800">
                  {dftPoints.map(p => {
                    const maxMag = Math.max(...dftPoints.map(pt => pt.magnitude), 1);
                    const heightPercent = Math.min(100, Math.max(5, (p.magnitude / maxMag) * 100));
                    return (
                      <div key={p.k} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                        <div
                          className="w-full bg-indigo-500 rounded-t transition-all hover:bg-indigo-400"
                          style={{ height: `${heightPercent}%` }}
                          title={`k=${p.k}, Mag=${p.magnitude.toFixed(3)}`}
                        />
                        <span className="text-[9px] font-mono text-slate-500">{p.k}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono max-h-36 overflow-y-auto">
                  {dftPoints.map(p => (
                    <div key={p.k} className="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
                      <span className="text-slate-400">k = {p.k}:</span>
                      <span className="text-indigo-300 font-bold">|X| = {p.magnitude.toFixed(3)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-slate-500">
                Click Compute DFT to observe the frequency spectrum.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. Convolution */}
      {subTab === 'convolution' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-400" />
              1D Discrete Convolution (x * h)
            </div>
            <div className="flex flex-col gap-1 text-xs">
              <span className="text-slate-400">Signal x[n]:</span>
              <input
                type="text"
                value={convX}
                onChange={e => setConvX(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
              />
            </div>
            <div className="flex flex-col gap-1 text-xs">
              <span className="text-slate-400">Impulse Response h[n]:</span>
              <input
                type="text"
                value={convH}
                onChange={e => setConvH(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono"
              />
            </div>
            <button
              type="button"
              onClick={handleComputeConv}
              className="py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Convolve Signals
            </button>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Convolved Output y[n]
            </div>
            {convResult ? (
              <div className="text-center font-mono">
                <span className="text-xs text-slate-400">y[n] = [ {convResult.join(', ')} ]</span>
                <div className="text-xs text-slate-500 mt-2">
                  Length: {convResult.length} samples
                </div>
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Convolve x[n] and h[n] to calculate linear filtering output.
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
