import React, { useState } from 'react';
import {
  calculateCircle,
  calculateTriangle,
  calculateRegularPolygon,
  calculateTrapezoid,
  calculateEllipse,
  calculateSphere,
  calculateCylinder,
  calculateCone,
  calculateCuboid,
  calculateTorus,
  calculate2DCoordinates,
  calculate3DCoordinates,
  pointToPlaneDistance,
  calculateLineIntersection2D,
  calculateHaversineDistance,
  calculateSphericalTriangle
} from '../../utils/geometrySolvers';
import {
  Shapes,
  Box,
  Compass,
  Crosshair,
  Globe,
  Circle,
  Triangle,
  Layers,
  Sparkles,
  Maximize2,
  TrendingUp,
  MapPin,
  Check
} from 'lucide-react';

export type GeometryTab =
  | '2d_shapes'
  | '3d_solids'
  | 'coordinate'
  | 'intersections'
  | 'spherical';

export const GeometrySolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<GeometryTab>('2d_shapes');

  // ==========================================
  // 1. 2D Shapes State
  // ==========================================
  const [shape2D, setShape2D] = useState<'circle' | 'triangle' | 'polygon' | 'trapezoid' | 'ellipse'>('circle');

  // Circle
  const [circleR, setCircleR] = useState<number>(5);
  const [circleAngle, setCircleAngle] = useState<number>(360);
  const circleMetrics = calculateCircle(circleR, circleAngle);

  // Triangle
  const [triA, setTriA] = useState<number>(3);
  const [triB, setTriB] = useState<number>(4);
  const [triC, setTriC] = useState<number>(5);
  const triMetrics = calculateTriangle(triA, triB, triC);

  // Polygon
  const [polyN, setPolyN] = useState<number>(6);
  const [polyS, setPolyS] = useState<number>(4);
  const polyMetrics = calculateRegularPolygon(polyN, polyS);

  // Trapezoid
  const [trapB1, setTrapB1] = useState<number>(8);
  const [trapB2, setTrapB2] = useState<number>(5);
  const [trapH, setTrapH] = useState<number>(4);
  const trapMetrics = calculateTrapezoid(trapB1, trapB2, trapH);

  // Ellipse
  const [ellA, setEllA] = useState<number>(6);
  const [ellB, setEllB] = useState<number>(4);
  const ellMetrics = calculateEllipse(ellA, ellB);

  // ==========================================
  // 2. 3D Solids State
  // ==========================================
  const [solid3D, setSolid3D] = useState<'sphere' | 'cylinder' | 'cone' | 'cuboid' | 'torus'>('sphere');

  // Sphere
  const [sphereR, setSphereR] = useState<number>(4);
  const sphereMetrics = calculateSphere(sphereR);

  // Cylinder
  const [cylR, setCylR] = useState<number>(3);
  const [cylH, setCylH] = useState<number>(7);
  const cylMetrics = calculateCylinder(cylR, cylH);

  // Cone
  const [coneR, setConeR] = useState<number>(3);
  const [coneH, setConeH] = useState<number>(5);
  const coneMetrics = calculateCone(coneR, coneH);

  // Cuboid
  const [cubL, setCubL] = useState<number>(6);
  const [cubW, setCubW] = useState<number>(4);
  const [cubH, setCubH] = useState<number>(3);
  const cubMetrics = calculateCuboid(cubL, cubW, cubH);

  // Torus
  const [torusR, setTorusR] = useState<number>(5);
  const [torusr, setTorusr] = useState<number>(1.5);
  const torusMetrics = calculateTorus(torusR, torusr);

  // ==========================================
  // 3. Coordinate Geometry State
  // ==========================================
  const [coordMode, setCoordMode] = useState<'2d' | '3d' | 'plane'>('2d');

  // 2D Points
  const [p2_x1, setP2_x1] = useState<number>(2);
  const [p2_y1, setP2_y1] = useState<number>(3);
  const [p2_x2, setP2_x2] = useState<number>(6);
  const [p2_y2, setP2_y2] = useState<number>(8);
  const coord2DMetrics = calculate2DCoordinates(p2_x1, p2_y1, p2_x2, p2_y2);

  // 3D Points
  const [p3_x1, setP3_x1] = useState<number>(1);
  const [p3_y1, setP3_y1] = useState<number>(2);
  const [p3_z1, setP3_z1] = useState<number>(3);
  const [p3_x2, setP3_x2] = useState<number>(4);
  const [p3_y2, setP3_y2] = useState<number>(6);
  const [p3_z2, setP3_z2] = useState<number>(8);
  const coord3DMetrics = calculate3DCoordinates(p3_x1, p3_y1, p3_z1, p3_x2, p3_y2, p3_z2);

  // Point to Plane
  const [ptP_x, setPtP_x] = useState<number>(2);
  const [ptP_y, setPtP_y] = useState<number>(3);
  const [ptP_z, setPtP_z] = useState<number>(4);
  const [plA, setPlA] = useState<number>(1);
  const [plB, setPlB] = useState<number>(-2);
  const [plC, setPlC] = useState<number>(2);
  const [plD, setPlD] = useState<number>(-5);
  const ptToPlane = pointToPlaneDistance(ptP_x, ptP_y, ptP_z, plA, plB, plC, plD);

  // ==========================================
  // 4. Line Intersections State
  // ==========================================
  const [l1_a, setL1_a] = useState<number>(2);
  const [l1_b, setL1_b] = useState<number>(3);
  const [l1_c, setL1_c] = useState<number>(6); // 2x + 3y = 6

  const [l2_a, setL2_a] = useState<number>(1);
  const [l2_b, setL2_b] = useState<number>(-1);
  const [l2_c, setL2_c] = useState<number>(1); // x - y = 1

  const lineIntersection = calculateLineIntersection2D(l1_a, l1_b, l1_c, l2_a, l2_b, l2_c);

  // ==========================================
  // 5. Spherical Geometry State
  // ==========================================
  const [lat1, setLat1] = useState<number>(37.7749); // San Francisco
  const [lon1, setLon1] = useState<number>(-122.4194);
  const [lat2, setLat2] = useState<number>(40.7128); // New York City
  const [lon2, setLon2] = useState<number>(-74.0060);
  const [sphereRadiusKm, setSphereRadiusKm] = useState<number>(6371); // Earth

  const haversine = calculateHaversineDistance(lat1, lon1, lat2, lon2, sphereRadiusKm);

  // Spherical Triangle
  const [sphAngleA, setSphAngleA] = useState<number>(90);
  const [sphAngleB, setSphAngleB] = useState<number>(90);
  const [sphAngleC, setSphAngleC] = useState<number>(90);
  const sphTri = calculateSphericalTriangle(sphAngleA, sphAngleB, sphAngleC, sphereRadiusKm);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Top Module Subtabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('2d_shapes')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === '2d_shapes'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Shapes className="w-3.5 h-3.5 text-indigo-300" />
          2D Shapes, Areas & Perimeters
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('3d_solids')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === '3d_solids'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Box className="w-3.5 h-3.5 text-emerald-300" />
          3D Solids, Volumes & Surfaces
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('coordinate')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'coordinate'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-cyan-300" />
          Coordinate Geometry (2D & 3D)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('intersections')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'intersections'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5 text-amber-300" />
          Lines & Planes Intersections
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('spherical')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'spherical'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-sky-300" />
          Spherical Geometry & Navigation
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: 2D SHAPES, AREAS & PERIMETERS
          ========================================================================= */}
      {activeTab === '2d_shapes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Shape Selector & Inputs (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">2D Geometric Shapes</span>
              <span className="text-[11px] font-mono text-slate-400">Area & Perimeter Engines</span>
            </div>

            {/* Shape Category Pills */}
            <div className="flex flex-wrap gap-1.5 text-xs font-mono">
              {(['circle', 'triangle', 'polygon', 'trapezoid', 'ellipse'] as const).map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShape2D(s)}
                  className={`px-3 py-1.5 rounded-xl capitalize font-medium transition-all ${
                    shape2D === s
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Circle / Sector */}
            {shape2D === 'circle' && (
              <div className="flex flex-col gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Radius r:</span>
                  <input
                    type="number"
                    value={circleR}
                    min="0"
                    onChange={e => setCircleR(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Sector Angle θ (degrees, 360 = full circle):</span>
                  <input
                    type="number"
                    value={circleAngle}
                    min="0"
                    max="360"
                    onChange={e => setCircleAngle(parseFloat(e.target.value) || 360)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Triangle */}
            {shape2D === 'triangle' && (
              <div className="flex flex-col gap-3 text-xs">
                <span className="text-slate-400">Enter 3 sides (Heron's Formula):</span>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <span className="text-slate-400 block mb-1">Side a:</span>
                    <input
                      type="number"
                      value={triA}
                      onChange={e => setTriA(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Side b:</span>
                    <input
                      type="number"
                      value={triB}
                      onChange={e => setTriB(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Side c:</span>
                    <input
                      type="number"
                      value={triC}
                      onChange={e => setTriC(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Regular Polygon */}
            {shape2D === 'polygon' && (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Number of Sides (n ≥ 3):</span>
                  <input
                    type="number"
                    min="3"
                    value={polyN}
                    onChange={e => setPolyN(Math.max(3, parseInt(e.target.value, 10) || 3))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Side Length s:</span>
                  <input
                    type="number"
                    value={polyS}
                    min="0"
                    onChange={e => setPolyS(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Trapezoid */}
            {shape2D === 'trapezoid' && (
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Base 1 (a):</span>
                  <input
                    type="number"
                    value={trapB1}
                    onChange={e => setTrapB1(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Base 2 (b):</span>
                  <input
                    type="number"
                    value={trapB2}
                    onChange={e => setTrapB2(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Height (h):</span>
                  <input
                    type="number"
                    value={trapH}
                    onChange={e => setTrapH(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Ellipse */}
            {shape2D === 'ellipse' && (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Semi-major axis (a):</span>
                  <input
                    type="number"
                    value={ellA}
                    onChange={e => setEllA(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Semi-minor axis (b):</span>
                  <input
                    type="number"
                    value={ellB}
                    onChange={e => setEllB(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Results Display (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Computed Geometric Metrics
            </span>

            {/* Circle Output */}
            {shape2D === 'circle' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-xs">Area (Full Circle)</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{circleMetrics.area}</div>
                  <span className="text-[10px] text-slate-500">π r²</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-xs">Circumference</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{circleMetrics.circumference}</div>
                  <span className="text-[10px] text-slate-500">2 π r</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Sector Area ({circleAngle}°):</span>
                  <div className="text-base font-bold text-sky-400 mt-0.5">{circleMetrics.sectorArea}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Arc Length:</span>
                  <div className="text-base font-bold text-amber-400 mt-0.5">{circleMetrics.arcLength}</div>
                </div>
              </div>
            )}

            {/* Triangle Output */}
            {shape2D === 'triangle' && (
              triMetrics ? (
                <div className="flex flex-col gap-3 font-mono text-xs">
                  <div className="p-3 bg-slate-950 rounded-xl border border-indigo-900/40 flex justify-between items-center">
                    <span className="text-slate-400 font-sans font-medium">Triangle Classification:</span>
                    <span className="text-indigo-300 font-bold px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20">
                      {triMetrics.type}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400">Area (Heron's):</span>
                      <div className="text-xl font-bold text-emerald-400 mt-1">{triMetrics.area}</div>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400">Perimeter:</span>
                      <div className="text-xl font-bold text-white mt-1">{triMetrics.perimeter}</div>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400">Inradius r:</span>
                      <div className="text-base font-bold text-sky-400 mt-1">{triMetrics.inradius}</div>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400">Circumradius R:</span>
                      <div className="text-base font-bold text-amber-400 mt-1">{triMetrics.circumradius}</div>
                    </div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex justify-between">
                    <span>∠A = {triMetrics.angleA}°</span>
                    <span>∠B = {triMetrics.angleB}°</span>
                    <span>∠C = {triMetrics.angleC}°</span>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-slate-950 rounded-xl border border-rose-900/40 text-rose-400 text-xs font-mono">
                  Invalid Triangle: The sum of any two sides must be strictly greater than the third side (a + b &gt; c).
                </div>
              )
            )}

            {/* Polygon Output */}
            {shape2D === 'polygon' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Area</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{polyMetrics.area}</div>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Perimeter</span>
                  <div className="text-xl font-bold text-white mt-1">{polyMetrics.perimeter}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Apothem:</span>
                  <div className="text-base font-bold text-sky-400 mt-0.5">{polyMetrics.apothem}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Interior Angle:</span>
                  <div className="text-base font-bold text-amber-400 mt-0.5">{polyMetrics.interiorAngle}°</div>
                </div>
              </div>
            )}

            {/* Trapezoid Output */}
            {shape2D === 'trapezoid' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Area</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{trapMetrics.area}</div>
                  <span className="text-[10px] text-slate-500">½(a + b)h</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Median Length</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{trapMetrics.median}</div>
                  <span className="text-[10px] text-slate-500">½(a + b)</span>
                </div>
              </div>
            )}

            {/* Ellipse Output */}
            {shape2D === 'ellipse' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Area</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{ellMetrics.area}</div>
                  <span className="text-[10px] text-slate-500">π a b</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Perimeter (Ramanujan)</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{ellMetrics.perimeterApprox}</div>
                </div>
                <div className="col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Eccentricity e:</span>
                  <span className="text-base font-bold text-amber-400">{ellMetrics.eccentricity}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: 3D SOLIDS, VOLUMES & SURFACE AREAS
          ========================================================================= */}
      {activeTab === '3d_solids' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Solid Inputs (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="font-semibold text-sm text-slate-200">3D Polyhedra & Curved Solids</span>
              <span className="text-[11px] font-mono text-slate-400">Volume & Surface Area</span>
            </div>

            {/* Solid Type Selector */}
            <div className="flex flex-wrap gap-1.5 text-xs font-mono">
              {(['sphere', 'cylinder', 'cone', 'cuboid', 'torus'] as const).map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSolid3D(s)}
                  className={`px-3 py-1.5 rounded-xl capitalize font-medium transition-all ${
                    solid3D === s
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Sphere */}
            {solid3D === 'sphere' && (
              <div className="text-xs">
                <span className="text-slate-400 block mb-1">Radius r:</span>
                <input
                  type="number"
                  value={sphereR}
                  min="0"
                  onChange={e => setSphereR(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            )}

            {/* Cylinder */}
            {solid3D === 'cylinder' && (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Radius r:</span>
                  <input
                    type="number"
                    value={cylR}
                    min="0"
                    onChange={e => setCylR(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Height h:</span>
                  <input
                    type="number"
                    value={cylH}
                    min="0"
                    onChange={e => setCylH(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Cone */}
            {solid3D === 'cone' && (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Base Radius r:</span>
                  <input
                    type="number"
                    value={coneR}
                    min="0"
                    onChange={e => setConeR(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Vertical Height h:</span>
                  <input
                    type="number"
                    value={coneH}
                    min="0"
                    onChange={e => setConeH(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Cuboid / Rectangular Prism */}
            {solid3D === 'cuboid' && (
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Length l:</span>
                  <input
                    type="number"
                    value={cubL}
                    min="0"
                    onChange={e => setCubL(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Width w:</span>
                  <input
                    type="number"
                    value={cubW}
                    min="0"
                    onChange={e => setCubW(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Height h:</span>
                  <input
                    type="number"
                    value={cubH}
                    min="0"
                    onChange={e => setCubH(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}

            {/* Torus */}
            {solid3D === 'torus' && (
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Major Radius R (tube center):</span>
                  <input
                    type="number"
                    value={torusR}
                    min="0"
                    onChange={e => setTorusR(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Minor Radius r (tube cross-section):</span>
                  <input
                    type="number"
                    value={torusr}
                    min="0"
                    onChange={e => setTorusr(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Solid Results (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              3D Solid Metrics
            </span>

            {/* Sphere Output */}
            {solid3D === 'sphere' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Volume V</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{sphereMetrics.volume}</div>
                  <span className="text-[10px] text-slate-500">⁴/₃ π r³</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Surface Area A</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{sphereMetrics.surfaceArea}</div>
                  <span className="text-[10px] text-slate-500">4 π r²</span>
                </div>
                <div className="col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Hemisphere Volume (½V):</span>
                  <span className="text-base font-bold text-sky-400">{sphereMetrics.hemisphereVolume}</span>
                </div>
              </div>
            )}

            {/* Cylinder Output */}
            {solid3D === 'cylinder' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Volume</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{cylMetrics.volume}</div>
                  <span className="text-[10px] text-slate-500">π r² h</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Surface Area</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{cylMetrics.totalSurfaceArea}</div>
                  <span className="text-[10px] text-slate-500">2π r(r + h)</span>
                </div>
                <div className="col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Lateral Surface Area (sides only):</span>
                  <span className="text-base font-bold text-amber-400">{cylMetrics.lateralArea}</span>
                </div>
              </div>
            )}

            {/* Cone Output */}
            {solid3D === 'cone' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Volume</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{coneMetrics.volume}</div>
                  <span className="text-[10px] text-slate-500">⅓ π r² h</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Total Surface Area</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{coneMetrics.totalSurfaceArea}</div>
                  <span className="text-[10px] text-slate-500">π r(r + l)</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Slant Height l:</span>
                  <div className="text-base font-bold text-sky-400 mt-0.5">{coneMetrics.slantHeight}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Lateral Area:</span>
                  <div className="text-base font-bold text-amber-400 mt-0.5">{coneMetrics.lateralArea}</div>
                </div>
              </div>
            )}

            {/* Cuboid Output */}
            {solid3D === 'cuboid' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Volume</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{cubMetrics.volume}</div>
                  <span className="text-[10px] text-slate-500">l · w · h</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Surface Area</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{cubMetrics.surfaceArea}</div>
                  <span className="text-[10px] text-slate-500">2(lw + lh + wh)</span>
                </div>
                <div className="col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Space Diagonal d:</span>
                  <span className="text-base font-bold text-sky-400">
                    {cubMetrics.spaceDiagonal}
                  </span>
                </div>
              </div>
            )}

            {/* Torus Output */}
            {solid3D === 'torus' && (
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Volume</span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">{torusMetrics.volume}</div>
                  <span className="text-[10px] text-slate-500">2π² R r²</span>
                </div>
                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Surface Area</span>
                  <div className="text-xl font-bold text-indigo-400 mt-1">{torusMetrics.surfaceArea}</div>
                  <span className="text-[10px] text-slate-500">4π² R r</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: COORDINATE GEOMETRY (2D & 3D)
          ========================================================================= */}
      {activeTab === 'coordinate' && (
        <div className="flex flex-col gap-5">
          {/* Sub-mode pills */}
          <div className="flex gap-2 text-xs font-mono">
            <button
              type="button"
              onClick={() => setCoordMode('2d')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                coordMode === '2d'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              2D Points & Line Metrics
            </button>
            <button
              type="button"
              onClick={() => setCoordMode('3d')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                coordMode === '3d'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              3D Points & Vectors
            </button>
            <button
              type="button"
              onClick={() => setCoordMode('plane')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                coordMode === 'plane'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              Point to 3D Plane Distance
            </button>
          </div>

          {/* 2D Coordinates */}
          {coordMode === '2d' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  2D Coordinates Input
                </span>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-indigo-400">Point 1 (x₁, y₁)</span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-slate-400 block mb-1">x₁:</span>
                      <input
                        type="number"
                        value={p2_x1}
                        onChange={e => setP2_x1(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-1">y₁:</span>
                      <input
                        type="number"
                        value={p2_y1}
                        onChange={e => setP2_y1(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-emerald-400">Point 2 (x₂, y₂)</span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-slate-400 block mb-1">x₂:</span>
                      <input
                        type="number"
                        value={p2_x2}
                        onChange={e => setP2_x2(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-1">y₂:</span>
                      <input
                        type="number"
                        value={p2_y2}
                        onChange={e => setP2_y2(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* 2D Results */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-3 font-mono text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  2D Line & Distance Results
                </span>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400">Euclidean Distance</span>
                    <div className="text-2xl font-extrabold text-emerald-400 mt-1">{coord2DMetrics.distance}</div>
                    <span className="text-[10px] text-slate-500">√((Δx)² + (Δy)²)</span>
                  </div>
                  <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400">Midpoint M</span>
                    <div className="text-xl font-bold text-indigo-400 mt-1">
                      ({coord2DMetrics.midpoint.x}, {coord2DMetrics.midpoint.y})
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Line Equation:</span>
                  <span className="text-white font-bold">{coord2DMetrics.equation}</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400">Slope m:</span>
                    <div className="text-base font-bold text-sky-400 mt-0.5">
                      {coord2DMetrics.slope !== null ? coord2DMetrics.slope : 'Undefined (Vertical)'}
                    </div>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400">Angle of Inclination:</span>
                    <div className="text-base font-bold text-amber-400 mt-0.5">{coord2DMetrics.angleDeg}°</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 3D Coordinates */}
          {coordMode === '3d' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  3D Coordinates Input
                </span>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-indigo-400">Point 1 (x₁, y₁, z₁)</span>
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="number"
                      value={p3_x1}
                      onChange={e => setP3_x1(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={p3_y1}
                      onChange={e => setP3_y1(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={p3_z1}
                      onChange={e => setP3_z1(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-emerald-400">Point 2 (x₂, y₂, z₂)</span>
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="number"
                      value={p3_x2}
                      onChange={e => setP3_x2(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={p3_y2}
                      onChange={e => setP3_y2(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={p3_z2}
                      onChange={e => setP3_z2(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* 3D Results */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-3 font-mono text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  3D Distance & Vector Outputs
                </span>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">3D Euclidean Distance:</span>
                  <div className="text-3xl font-extrabold text-emerald-400 mt-1">{coord3DMetrics.distance}</div>
                  <span className="text-[10px] text-slate-500">√((Δx)² + (Δy)² + (Δz)²)</span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">3D Midpoint:</span>
                  <span className="text-indigo-300 font-bold">
                    ({coord3DMetrics.midpoint.x}, {coord3DMetrics.midpoint.y}, {coord3DMetrics.midpoint.z})
                  </span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Displacement Vector:</span>
                  <span className="text-white font-bold">
                    ⟨{coord3DMetrics.vector.x}, {coord3DMetrics.vector.y}, {coord3DMetrics.vector.z}⟩
                  </span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Unit Vector û:</span>
                  <span className="text-sky-300 font-bold">
                    ⟨{coord3DMetrics.unitVector.x}, {coord3DMetrics.unitVector.y}, {coord3DMetrics.unitVector.z}⟩
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Point to 3D Plane */}
          {coordMode === 'plane' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  Point & Plane Equation Input
                </span>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-indigo-400">Point (x₀, y₀, z₀)</span>
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="number"
                      value={ptP_x}
                      onChange={e => setPtP_x(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={ptP_y}
                      onChange={e => setPtP_y(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                    <input
                      type="number"
                      value={ptP_z}
                      onChange={e => setPtP_z(parseFloat(e.target.value) || 0)}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <span className="font-bold text-emerald-400">Plane: Ax + By + Cz + D = 0</span>
                  <div className="grid grid-cols-4 gap-2">
                    <div>
                      <span className="text-[10px] text-slate-500 block">A:</span>
                      <input
                        type="number"
                        value={plA}
                        onChange={e => setPlA(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">B:</span>
                      <input
                        type="number"
                        value={plB}
                        onChange={e => setPlB(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">C:</span>
                      <input
                        type="number"
                        value={plC}
                        onChange={e => setPlC(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">D:</span>
                      <input
                        type="number"
                        value={plD}
                        onChange={e => setPlD(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 font-mono text-xs">
                <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
                  Perpendicular Distance & Projection
                </span>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-slate-400">Shortest Perpendicular Distance d:</span>
                  <div className="text-3xl font-extrabold text-emerald-400 mt-1">{ptToPlane.distance}</div>
                  <span className="text-[10px] text-slate-500">|Ax₀ + By₀ + Cz₀ + D| / √(A² + B² + C²)</span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Foot of Perpendicular:</span>
                  <span className="text-indigo-300 font-bold">
                    ({ptToPlane.projection.x}, {ptToPlane.projection.y}, {ptToPlane.projection.z})
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          MODULE 4: LINES & PLANES INTERSECTIONS
          ========================================================================= */}
      {activeTab === 'intersections' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              2D Linear Equations Setup
            </span>

            {/* Line 1 */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
              <span className="font-bold text-indigo-400">Line 1: A₁x + B₁y = C₁</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-500 block mb-1">A₁</span>
                  <input
                    type="number"
                    value={l1_a}
                    onChange={e => setL1_a(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">B₁</span>
                  <input
                    type="number"
                    value={l1_b}
                    onChange={e => setL1_b(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">C₁</span>
                  <input
                    type="number"
                    value={l1_c}
                    onChange={e => setL1_c(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Line 2 */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
              <span className="font-bold text-emerald-400">Line 2: A₂x + B₂y = C₂</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-500 block mb-1">A₂</span>
                  <input
                    type="number"
                    value={l2_a}
                    onChange={e => setL2_a(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">B₂</span>
                  <input
                    type="number"
                    value={l2_b}
                    onChange={e => setL2_b(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">C₂</span>
                  <input
                    type="number"
                    value={l2_c}
                    onChange={e => setL2_c(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Intersection Output */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 font-mono text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Intersection Status & Solution
            </span>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Relative Status:</span>
              <span
                className={`font-bold px-2.5 py-1 rounded-lg text-xs uppercase ${
                  lineIntersection.status === 'intersecting'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : lineIntersection.status === 'parallel'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                }`}
              >
                {lineIntersection.status}
              </span>
            </div>

            {lineIntersection.point ? (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="text-slate-400">Intersection Coordinate (x, y):</span>
                <div className="text-2xl font-extrabold text-white">
                  x = <span className="text-emerald-400">{lineIntersection.point.x}</span>, y ={' '}
                  <span className="text-indigo-400">{lineIntersection.point.y}</span>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-slate-400">
                {lineIntersection.status === 'parallel'
                  ? 'Lines are parallel (no unique intersection point exists).'
                  : 'Lines are coincident (infinite intersection points).'}
              </div>
            )}

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Angle Between Lines:</span>
              <span className="text-amber-400 font-bold text-base">
                {lineIntersection.angleBetweenDeg}°
              </span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: SPHERICAL GEOMETRY & HAVERSINE
          ========================================================================= */}
      {activeTab === 'spherical' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Haversine Distance */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Great-Circle Distance (Haversine Formula)
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-1.5">
                <span className="font-bold text-indigo-400">Point 1 (Lat, Lon)</span>
                <input
                  type="number"
                  value={lat1}
                  step="0.01"
                  onChange={e => setLat1(parseFloat(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white font-mono"
                  placeholder="Lat 1"
                />
                <input
                  type="number"
                  value={lon1}
                  step="0.01"
                  onChange={e => setLon1(parseFloat(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white font-mono"
                  placeholder="Lon 1"
                />
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-1.5">
                <span className="font-bold text-emerald-400">Point 2 (Lat, Lon)</span>
                <input
                  type="number"
                  value={lat2}
                  step="0.01"
                  onChange={e => setLat2(parseFloat(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white font-mono"
                  placeholder="Lat 2"
                />
                <input
                  type="number"
                  value={lon2}
                  step="0.01"
                  onChange={e => setLon2(parseFloat(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white font-mono"
                  placeholder="Lon 2"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-indigo-900/40 font-mono flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Great-Circle Arc Distance:</span>
                <span className="text-2xl font-extrabold text-emerald-400">
                  {haversine.distanceKm} km
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Distance in Miles:</span>
                <span className="text-white font-bold">{haversine.distanceMiles} mi</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Initial Navigation Bearing:</span>
                <span className="text-sky-400 font-bold">{haversine.initialBearingDeg}°</span>
              </div>
            </div>
          </div>

          {/* Spherical Triangle & Girard's Theorem */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Spherical Triangle & Girard's Theorem
            </span>

            <div className="flex flex-col gap-2">
              <span className="text-slate-400">Interior Angles (degrees, sum &gt; 180°):</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-500 block mb-1">Angle α:</span>
                  <input
                    type="number"
                    value={sphAngleA}
                    onChange={e => setSphAngleA(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Angle β:</span>
                  <input
                    type="number"
                    value={sphAngleB}
                    onChange={e => setSphAngleB(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Angle γ:</span>
                  <input
                    type="number"
                    value={sphAngleC}
                    onChange={e => setSphAngleC(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Spherical Excess E = (α+β+γ) - π:</span>
                <span className="text-xl font-bold text-amber-400">{sphTri.excessRad} rad</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                <span className="text-slate-400">Spherical Surface Area (A = R² · E):</span>
                <span className="text-2xl font-extrabold text-emerald-400">{sphTri.area} km²</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
