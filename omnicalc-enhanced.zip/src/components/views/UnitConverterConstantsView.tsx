import React, { useState } from 'react';
import { UNIT_CATEGORIES, convertUnits, UnitCategory } from '../../utils/unitConverterData';
import { CONSTANTS_DATABASE } from '../../utils/constantsDatabase';
import { FORMULA_LIBRARY } from '../../utils/formulaLibrary';
import { MathView } from '../MathView';
import { Copy, Check, Search, ArrowRightLeft, Database, BookOpen, Calculator, ChevronDown, ChevronUp } from 'lucide-react';

interface UnitConverterConstantsViewProps {
  onInsertExpression?: (expr: string) => void;
}

export const UnitConverterConstantsView: React.FC<UnitConverterConstantsViewProps> = ({ onInsertExpression }) => {
  const [mainTab, setMainTab] = useState<'converter' | 'constants' | 'formulas'>('converter');

  // Converter state
  const [activeCategoryName, setActiveCategoryName] = useState<string>(UNIT_CATEGORIES[0].name);
  const [fromUnit, setFromUnit] = useState<string>(UNIT_CATEGORIES[0].units[0].symbol);
  const [toUnit, setToUnit] = useState<string>(UNIT_CATEGORIES[0].units[1].symbol);
  const [inputVal, setInputVal] = useState<number>(10);
  const [convertedVal, setConvertedVal] = useState<number>(
    convertUnits(UNIT_CATEGORIES[0].name, UNIT_CATEGORIES[0].units[0].symbol, UNIT_CATEGORIES[0].units[1].symbol, 10) ?? 0
  );

  // Constants state
  const [constSearch, setConstSearch] = useState<string>('');
  const [constCategory, setConstCategory] = useState<string>('all');
  const [copiedSymbol, setCopiedSymbol] = useState<string | null>(null);

  // Formulas state
  const [formulaCat, setFormulaCat] = useState<string>('all');
  const [formulaSearch, setFormulaSearch] = useState<string>('');
  const [solvingFormulaId, setSolvingFormulaId] = useState<string | null>(null);
  const [solveTargetVar, setSolveTargetVar] = useState<string>('');
  const [solveVarValues, setSolveVarValues] = useState<Record<string, number>>({});

  const currentCategory = UNIT_CATEGORIES.find(c => c.name === activeCategoryName) || UNIT_CATEGORIES[0];

  // Handle conversion
  const handleConvert = (val: number, from: string, to: string, catName: string = activeCategoryName) => {
    setInputVal(val);
    const result = convertUnits(catName, from, to, val);
    if (result !== null) {
      setConvertedVal(result);
    }
  };

  const handleCategoryChange = (cat: UnitCategory) => {
    setActiveCategoryName(cat.name);
    const f = cat.units[0].symbol;
    const t = cat.units[1]?.symbol || cat.units[0].symbol;
    setFromUnit(f);
    setToUnit(t);
    handleConvert(inputVal, f, t, cat.name);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSymbol(id);
    setTimeout(() => setCopiedSymbol(null), 1500);
  };

  // Open solver for a formula
  const handleToggleSolver = (f: typeof FORMULA_LIBRARY[0]) => {
    if (solvingFormulaId === f.id) {
      setSolvingFormulaId(null);
    } else {
      setSolvingFormulaId(f.id);
      const firstTarget = f.variables[0]?.symbol || '';
      setSolveTargetVar(firstTarget);
      const initialVals: Record<string, number> = {};
      f.variables.forEach(v => {
        initialVals[v.symbol] = v.defaultValue ?? 0;
      });
      setSolveVarValues(initialVals);
    }
  };

  // Filtered Constants
  const filteredConstants = CONSTANTS_DATABASE.filter(c => {
    const matchCat = constCategory === 'all' || c.category.toLowerCase() === constCategory.toLowerCase();
    const matchSearch =
      constSearch === '' ||
      c.name.toLowerCase().includes(constSearch.toLowerCase()) ||
      c.symbol.toLowerCase().includes(constSearch.toLowerCase());
    return matchCat && matchSearch;
  });

  // Filtered Formulas
  const filteredFormulas = FORMULA_LIBRARY.filter(f => {
    const matchCat = formulaCat === 'all' || f.category.toLowerCase() === formulaCat.toLowerCase();
    const q = formulaSearch.toLowerCase();
    const matchSearch =
      formulaSearch === '' ||
      f.name.toLowerCase().includes(q) ||
      f.formula.toLowerCase().includes(q) ||
      (f.subcategory && f.subcategory.toLowerCase().includes(q)) ||
      f.description.toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Tab bar */}
      <div className="flex items-center gap-2 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setMainTab('converter')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            mainTab === 'converter' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ArrowRightLeft className="w-3.5 h-3.5" />
          Unit Converter
        </button>
        <button
          type="button"
          onClick={() => setMainTab('constants')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            mainTab === 'constants' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          Constants Database
        </button>
        <button
          type="button"
          onClick={() => setMainTab('formulas')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
            mainTab === 'formulas' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Formula Library
        </button>
      </div>

      {/* 1. Unit Converter */}
      {mainTab === 'converter' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            {UNIT_CATEGORIES.map(cat => (
              <button
                key={cat.name}
                type="button"
                onClick={() => handleCategoryChange(cat)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors capitalize shrink-0 ${
                  activeCategoryName === cat.name
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
            {/* From Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col gap-3">
              <span className="text-xs font-semibold text-slate-400 uppercase">From</span>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  value={inputVal}
                  onChange={e => {
                    const v = parseFloat(e.target.value) || 0;
                    handleConvert(v, fromUnit, toUnit);
                  }}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-lg font-mono text-white focus:outline-none focus:border-indigo-500"
                />
                <select
                  value={fromUnit}
                  onChange={e => {
                    const u = e.target.value;
                    setFromUnit(u);
                    handleConvert(inputVal, u, toUnit);
                  }}
                  className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-sm font-mono text-white"
                >
                  {currentCategory.units.map(u => (
                    <option key={u.symbol} value={u.symbol}>
                      {u.name} ({u.symbol})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* To Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col gap-3">
              <span className="text-xs font-semibold text-slate-400 uppercase">To (Converted)</span>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  value={convertedVal}
                  readOnly
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-lg font-mono text-emerald-300 focus:outline-none"
                />
                <select
                  value={toUnit}
                  onChange={e => {
                    const u = e.target.value;
                    setToUnit(u);
                    handleConvert(inputVal, fromUnit, u);
                  }}
                  className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-sm font-mono text-white"
                >
                  {currentCategory.units.map(u => (
                    <option key={u.symbol} value={u.symbol}>
                      {u.name} ({u.symbol})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Constants Database */}
      {mainTab === 'constants' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={constSearch}
                onChange={e => setConstSearch(e.target.value)}
                placeholder="Search constants (e.g. Planck, c, G, electron, pi)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {['all', 'mathematics', 'physics', 'electromagnetism', 'thermodynamics', 'quantum', 'astronomy'].map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setConstCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg capitalize transition-colors ${
                    constCategory === cat ? 'bg-indigo-600 text-white' : 'bg-slate-950 text-slate-400 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Constants Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[480px] overflow-y-auto pr-1">
            {filteredConstants.map(c => (
              <div
                key={c.symbol + c.name}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-between gap-2 hover:border-slate-700 transition-colors"
              >
                <div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-semibold text-slate-200 text-sm">{c.name}</span>
                    <span className="font-mono text-indigo-400 font-bold text-base">{c.symbol}</span>
                  </div>
                  <div className="text-xs font-mono text-slate-300 mt-1">{c.value}</div>
                  <div className="text-[11px] text-slate-500 font-mono">{c.unit}</div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] uppercase font-mono text-slate-500">{c.category}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleCopy(String(c.value), c.symbol)}
                      className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
                      title="Copy numeric value"
                    >
                      {copiedSymbol === c.symbol ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {onInsertExpression && (
                      <button
                        type="button"
                        onClick={() => onInsertExpression(c.symbol)}
                        className="px-2 py-0.5 rounded bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-medium"
                      >
                        Insert
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Formula Reference Library */}
      {mainTab === 'formulas' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={formulaSearch}
                onChange={e => setFormulaSearch(e.target.value)}
                placeholder="Search formulas (e.g. Velocity, Kinematics, Energy)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {['all', 'physics', 'chemistry', 'mathematics', 'finance'].map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setFormulaCat(cat)}
                  className={`px-2.5 py-1 rounded-lg capitalize font-medium transition-colors ${
                    formulaCat === cat ? 'bg-indigo-600 text-white shadow' : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Formulas Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 max-h-[580px] overflow-y-auto pr-1">
            {filteredFormulas.map(f => {
              const isSolving = solvingFormulaId === f.id;
              const solvedVal = isSolving ? f.solveFor(solveTargetVar, solveVarValues) : null;
              const targetVarObj = f.variables.find(v => v.symbol === solveTargetVar);

              return (
                <div
                  key={f.id}
                  className={`p-4 bg-slate-950 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                    isSolving ? 'border-indigo-500/80 shadow-lg shadow-indigo-950/30' : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-semibold text-slate-200 text-sm">{f.name}</span>
                      <span className="text-[10px] uppercase font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40 shrink-0">
                        {f.category}{f.subcategory ? ` • ${f.subcategory}` : ''}
                      </span>
                    </div>

                    <div className="my-2.5 p-2.5 bg-slate-900 rounded-xl border border-slate-800/80 overflow-x-auto">
                      <MathView math={f.latex} rawText={f.formula} />
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">{f.description}</p>
                  </div>

                  {/* Interactive Solver Drawer */}
                  {isSolving && (
                    <div className="p-3 bg-slate-900/90 rounded-xl border border-indigo-800/50 flex flex-col gap-2.5 text-xs font-mono">
                      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                        <span className="text-slate-400 font-sans font-medium text-[11px]">Solve for Variable:</span>
                        <div className="flex gap-1">
                          {f.variables.map(v => (
                            <button
                              key={v.symbol}
                              type="button"
                              onClick={() => setSolveTargetVar(v.symbol)}
                              className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                                solveTargetVar === v.symbol
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                              }`}
                            >
                              {v.symbol}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Inputs for non-target variables */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {f.variables
                          .filter(v => v.symbol !== solveTargetVar)
                          .map(v => (
                            <div key={v.symbol} className="flex flex-col gap-0.5">
                              <span className="text-slate-400 text-[10px] truncate">
                                {v.name} ({v.symbol}){v.unit ? ` [${v.unit}]` : ''}:
                              </span>
                              <input
                                type="number"
                                step="any"
                                value={solveVarValues[v.symbol] ?? v.defaultValue ?? 0}
                                onChange={e => {
                                  const val = parseFloat(e.target.value) || 0;
                                  setSolveVarValues(prev => ({ ...prev, [v.symbol]: val }));
                                }}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1 text-white text-xs font-mono"
                              />
                            </div>
                          ))}
                      </div>

                      {/* Solved Output */}
                      <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between mt-1">
                        <span className="text-slate-400 text-[11px]">
                          Calculated <strong className="text-white">{solveTargetVar}</strong>:
                        </span>
                        <span className="text-sm font-bold text-emerald-400">
                          {solvedVal !== null && !isNaN(solvedVal)
                            ? `${parseFloat(solvedVal.toFixed(6))} ${targetVarObj?.unit || ''}`
                            : 'Undefined / Out of Range'}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 gap-2">
                    <span className="text-[11px] font-mono text-indigo-400 truncate">{f.formula}</span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleSolver(f)}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                          isSolving
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800'
                        }`}
                      >
                        <Calculator className="w-3 h-3" />
                        {isSolving ? 'Close Solver' : 'Solve'}
                      </button>

                      {onInsertExpression && (
                        <button
                          type="button"
                          onClick={() => onInsertExpression(f.formula)}
                          className="px-2.5 py-1 rounded bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-medium"
                        >
                          Use
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
