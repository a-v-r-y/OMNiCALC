import React, { useState } from 'react';
import { getMathInstance } from '../../utils/mathEngine';
import { Play, RotateCcw, Code2, Sparkles, Terminal } from 'lucide-react';

interface ScriptExample {
  title: string;
  code: string;
}

const EXAMPLES: ScriptExample[] = [
  {
    title: 'Fibonacci Sequence',
    code: `# Fibonacci Sequence Calculator\nn = 10\na = 0\nb = 1\nfib = [0, 1]\nfor (i = 2; i <= n; i++) {\n  c = a + b\n  a = b\n  b = c\n  fib = concat(fib, [c])\n}\nfib`
  },
  {
    title: 'Newton-Raphson Root Finder',
    code: `# Newton-Raphson approximation for sqrt(2)\n# Solves f(x) = x^2 - 2 = 0\nx = 1.0\nfor (iter = 1; iter <= 5; iter++) {\n  fx = x^2 - 2\n  dfx = 2 * x\n  x = x - (fx / dfx)\n}\nx`
  },
  {
    title: 'Vector & Matrix Transformation',
    code: `# Linear Transformation on 2D Vector\nA = [[cos(pi/4), -sin(pi/4)], [sin(pi/4), cos(pi/4)]]\nv = [1; 0]\nv_rotated = A * v\nv_rotated`
  },
  {
    title: 'Statistical Mean & Variance',
    code: `# Calculate Mean & Variance manually\ndata = [12, 15, 18, 22, 30]\nn = size(data)[1]\nmean_val = sum(data) / n\nvariance_val = sum((data - mean_val).^2) / (n - 1)\n[mean_val, variance_val]`
  }
];

export const ProgrammerScriptingView: React.FC = () => {
  const [script, setScript] = useState<string>(EXAMPLES[1].code);
  const [outputLogs, setOutputLogs] = useState<string[]>([]);
  const [scopeVariables, setScopeVariables] = useState<Record<string, string>>({});
  const [execTime, setExecTime] = useState<number | null>(null);
  const [isError, setIsError] = useState<boolean>(false);

  const handleRunScript = () => {
    setIsError(false);
    setOutputLogs([]);
    const startTime = performance.now();

    try {
      const math = getMathInstance();
      // Remove comment lines starting with #
      const lines = script
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 0 && !l.startsWith('#'));

      const cleanCode = lines.join('\n');
      const parser = math.parser();
      
      // Execute the lines sequentially
      let lastResult: any = undefined;
      const logs: string[] = [];

      lines.forEach((line) => {
        try {
          const res = parser.evaluate(line);
          if (res !== undefined) {
            lastResult = res;
            logs.push(`> ${line}\n  ${math.format(res, { precision: 10 })}`);
          } else {
            logs.push(`> ${line}`);
          }
        } catch (lineErr: any) {
          logs.push(`> ${line}\n  [Error]: ${lineErr.message}`);
        }
      });

      // Extract scope variables
      const vars: Record<string, string> = {};
      const allScope = parser.getAll();
      for (const [k, v] of Object.entries(allScope)) {
        if (typeof v !== 'function') {
          vars[k] = math.format(v, { precision: 8 });
        }
      }

      setScopeVariables(vars);
      setOutputLogs(logs);
      setExecTime(parseFloat((performance.now() - startTime).toFixed(2)));
    } catch (err: any) {
      setIsError(true);
      setOutputLogs([`Execution Error: ${err.message}`]);
      setExecTime(parseFloat((performance.now() - startTime).toFixed(2)));
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full">
      {/* Script Editor Panel */}
      <div className="lg:col-span-7 flex flex-col gap-3">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
              <Code2 className="w-4 h-4 text-indigo-400" />
              Multi-Statement Script Editor
            </div>

            {/* Presets */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-slate-500 mr-1">Templates:</span>
              {EXAMPLES.map(ex => (
                <button
                  key={ex.title}
                  type="button"
                  onClick={() => setScript(ex.code)}
                  className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  {ex.title}
                </button>
              ))}
            </div>
          </div>

          {/* Code Textarea */}
          <textarea
            rows={14}
            value={script}
            onChange={e => setScript(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm font-mono text-indigo-100 focus:outline-none focus:border-indigo-500 leading-relaxed resize-none"
            placeholder="# Enter your mathematical code here..."
            spellCheck={false}
          />

          {/* Action Button */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs text-slate-500 font-mono">
              Supports mathjs matrix, loops, functions, and arrays
            </span>
            <button
              type="button"
              onClick={handleRunScript}
              className="flex items-center gap-2 py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-xl text-xs transition-colors shadow-lg shadow-indigo-900/30"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Execute Script
            </button>
          </div>
        </div>
      </div>

      {/* Output Console & Variable Inspector */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Output Console */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col h-72">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400 font-mono">
            <span className="flex items-center gap-1.5 font-bold text-slate-200">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              Console Output
            </span>
            {execTime !== null && <span>{execTime} ms</span>}
          </div>

          <div className="flex-1 overflow-y-auto font-mono text-xs p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 mt-2.5 space-y-2">
            {outputLogs.length === 0 ? (
              <span className="text-slate-600">Click Execute Script to run code.</span>
            ) : (
              outputLogs.map((log, i) => (
                <div
                  key={i}
                  className={`whitespace-pre-wrap ${
                    isError ? 'text-rose-400' : 'text-slate-300'
                  }`}
                >
                  {log}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Variable Inspector */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col">
          <div className="text-xs font-bold text-slate-200 pb-2 border-b border-slate-800 font-mono">
            Scope Variable Inspector ({Object.keys(scopeVariables).length})
          </div>

          <div className="max-h-40 overflow-y-auto mt-2 space-y-1 font-mono text-xs">
            {Object.keys(scopeVariables).length === 0 ? (
              <span className="text-slate-600 text-[11px]">No active variables in memory.</span>
            ) : (
              Object.entries(scopeVariables).map(([v, val]) => (
                <div
                  key={v}
                  className="flex items-center justify-between p-1.5 bg-slate-950 rounded border border-slate-800"
                >
                  <span className="text-indigo-300 font-bold">{v}</span>
                  <span className="text-white truncate max-w-[180px]">{val}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
