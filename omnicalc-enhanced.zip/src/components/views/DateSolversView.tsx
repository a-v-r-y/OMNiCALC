import React, { useState } from 'react';
import {
  calculateDateDifference,
  calculateDateArithmetic,
  calculateTimeDifference,
  convertTimeUnits,
  calculateAge,
  calculateDayOfWeekAndCalendar,
  checkLeapYear
} from '../../utils/dateSolvers';
import {
  Calendar,
  Clock,
  CalendarPlus,
  UserCheck,
  CalendarSearch,
  Sunrise,
  ArrowRight
} from 'lucide-react';

export type DateTab =
  | 'date_diff'
  | 'add_sub_dates'
  | 'time_diff'
  | 'hms_converter'
  | 'age_calculator'
  | 'calendar_tools';

export const DateSolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<DateTab>('date_diff');

  // ==========================================
  // 1. Date Differences State
  // ==========================================
  const todayStr = new Date().toISOString().split('T')[0];
  const [diffDate1, setDiffDate1] = useState<string>('2026-01-01');
  const [diffDate2, setDiffDate2] = useState<string>('2026-12-31');
  const diffResult = calculateDateDifference(diffDate1, diffDate2);

  // ==========================================
  // 2. Add / Subtract Dates State
  // ==========================================
  const [arithBaseDate, setArithBaseDate] = useState<string>(todayStr);
  const [arithOp, setArithOp] = useState<'add' | 'subtract'>('add');
  const [arithYears, setArithYears] = useState<number>(0);
  const [arithMonths, setArithMonths] = useState<number>(3);
  const [arithWeeks, setArithWeeks] = useState<number>(2);
  const [arithDays, setArithDays] = useState<number>(10);
  const arithResult = calculateDateArithmetic(
    arithBaseDate,
    arithOp,
    arithYears,
    arithMonths,
    arithWeeks,
    arithDays
  );

  // ==========================================
  // 3. Time Differences State
  // ==========================================
  const [timeStart, setTimeStart] = useState<string>('08:30:00');
  const [timeEnd, setTimeEnd] = useState<string>('17:15:30');
  const [crossesMidnight, setCrossesMidnight] = useState<boolean>(false);
  const timeDiffResult = calculateTimeDifference(timeStart, timeEnd, crossesMidnight);

  // ==========================================
  // 4. Hours / Minutes / Seconds Converter
  // ==========================================
  const [hmsVal, setHmsVal] = useState<number>(125.75);
  const [hmsUnit, setHmsUnit] = useState<'hours' | 'minutes' | 'seconds'>('minutes');
  const hmsResult = convertTimeUnits(hmsVal, hmsUnit);

  // ==========================================
  // 5. Age Calculator State
  // ==========================================
  const [birthDate, setBirthDate] = useState<string>('2000-05-15');
  const [targetAgeDate, setTargetAgeDate] = useState<string>(todayStr);
  const ageResult = calculateAge(birthDate, targetAgeDate);

  // ==========================================
  // 6. Day-of-Week & Calendar Calculations
  // ==========================================
  const [calDate, setCalDate] = useState<string>(todayStr);
  const calResult = calculateDayOfWeekAndCalendar(calDate);

  const [testYear, setTestYear] = useState<number>(new Date().getFullYear());
  const leapResult = checkLeapYear(testYear);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Subtab Navigation */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('date_diff')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'date_diff'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 text-amber-300" />
          Date Differences
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('add_sub_dates')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'add_sub_dates'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <CalendarPlus className="w-3.5 h-3.5 text-emerald-300" />
          Add / Subtract Dates
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('time_diff')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'time_diff'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-sky-300" />
          Time Differences
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('hms_converter')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'hms_converter'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Sunrise className="w-3.5 h-3.5 text-purple-300" />
          Hours / Minutes / Seconds
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('age_calculator')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'age_calculator'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5 text-rose-300" />
          Age Calculator
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('calendar_tools')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'calendar_tools'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <CalendarSearch className="w-3.5 h-3.5 text-teal-300" />
          Day-of-Week & Calendar
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: DATE DIFFERENCES
          ========================================================================= */}
      {activeTab === 'date_diff' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Controls (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Calculate Interval Between Two Dates
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Start Date:</span>
                <input
                  type="date"
                  value={diffDate1}
                  onChange={e => setDiffDate1(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">End Date:</span>
                <input
                  type="date"
                  value={diffDate2}
                  onChange={e => setDiffDate2(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setDiffDate1(todayStr);
                    const nextYear = new Date();
                    nextYear.setFullYear(nextYear.getFullYear() + 1);
                    setDiffDate2(nextYear.toISOString().split('T')[0]);
                  }}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 rounded border border-slate-800 text-[11px]"
                >
                  +1 Year
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDiffDate1(todayStr);
                    const nextMonth = new Date();
                    nextMonth.setMonth(nextMonth.getMonth() + 1);
                    setDiffDate2(nextMonth.toISOString().split('T')[0]);
                  }}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 rounded border border-slate-800 text-[11px]"
                >
                  +1 Month
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDiffDate1(todayStr);
                    const next100 = new Date();
                    next100.setDate(next100.getDate() + 100);
                    setDiffDate2(next100.toISOString().split('T')[0]);
                  }}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 rounded border border-slate-800 text-[11px]"
                >
                  +100 Days
                </button>
              </div>
            </div>

            {/* Quick Summary Banner */}
            <div className="p-3 bg-indigo-950/40 rounded-xl border border-indigo-800/40 text-indigo-300 font-mono text-center">
              <span className="text-xs block text-indigo-400/80 mb-0.5">Primary Span</span>
              <span className="font-bold text-sm text-white">
                {diffResult.years}y {diffResult.months}m {diffResult.days}d
              </span>
            </div>
          </div>

          {/* Detailed Breakdown (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Interval & Workdays Breakdown
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-500 block text-[11px]">Total Days</span>
                <span className="text-lg font-bold text-amber-400">{diffResult.totalDays}</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-500 block text-[11px]">Weeks</span>
                <span className="text-lg font-bold text-emerald-400">
                  {diffResult.weeks}w {diffResult.remainingDays}d
                </span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-500 block text-[11px]">Workdays (M-F)</span>
                <span className="text-lg font-bold text-sky-400">{diffResult.weekdays}</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <span className="text-slate-500 block text-[11px]">Weekend Days</span>
                <span className="text-lg font-bold text-purple-400">{diffResult.weekendDays}</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 font-mono text-xs">
              <span className="font-bold text-slate-300">Equivalent Duration in Time Units:</span>
              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Hours</span>
                  <span className="font-bold text-slate-200">{diffResult.totalHours.toLocaleString()} h</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Minutes</span>
                  <span className="font-bold text-slate-200">{diffResult.totalMinutes.toLocaleString()} m</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Seconds</span>
                  <span className="font-bold text-slate-200">{diffResult.totalSeconds.toLocaleString()} s</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: ADD / SUBTRACT DATES
          ========================================================================= */}
      {activeTab === 'add_sub_dates' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Inputs (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Date Arithmetic Parameters
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Starting Date:</span>
                <input
                  type="date"
                  value={arithBaseDate}
                  onChange={e => setArithBaseDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Operation:</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setArithOp('add')}
                    className={`py-2 rounded-lg font-bold transition-all ${
                      arithOp === 'add'
                        ? 'bg-emerald-600 text-white shadow'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    + Add Time
                  </button>
                  <button
                    type="button"
                    onClick={() => setArithOp('subtract')}
                    className={`py-2 rounded-lg font-bold transition-all ${
                      arithOp === 'subtract'
                        ? 'bg-rose-600 text-white shadow'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    − Subtract Time
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div>
                  <span className="text-slate-400 block mb-1">Years:</span>
                  <input
                    type="number"
                    min="0"
                    value={arithYears}
                    onChange={e => setArithYears(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Months:</span>
                  <input
                    type="number"
                    min="0"
                    value={arithMonths}
                    onChange={e => setArithMonths(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Weeks:</span>
                  <input
                    type="number"
                    min="0"
                    value={arithWeeks}
                    onChange={e => setArithWeeks(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Days:</span>
                  <input
                    type="number"
                    min="0"
                    value={arithDays}
                    onChange={e => setArithDays(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Results (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Calculated Target Date
            </span>

            <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col items-center justify-center gap-3 text-center my-auto">
              <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Resulting Date
              </span>
              <div className="text-3xl font-extrabold text-white font-mono tracking-tight">
                {arithResult.resultDateStr}
              </div>
              <div className="text-sm font-medium text-emerald-400">
                {arithResult.formattedDisplay}
              </div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-900 rounded-full border border-slate-800 text-xs font-mono text-slate-300 mt-2">
                <span>Day of Week:</span>
                <span className="font-bold text-amber-300">{arithResult.dayOfWeek}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: TIME DIFFERENCES
          ========================================================================= */}
      {activeTab === 'time_diff' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Time Inputs (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Time Span Calculator
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Start Time (HH:MM:SS):</span>
                <input
                  type="time"
                  step="1"
                  value={timeStart}
                  onChange={e => setTimeStart(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">End Time (HH:MM:SS):</span>
                <input
                  type="time"
                  step="1"
                  value={timeEnd}
                  onChange={e => setTimeEnd(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="pt-1">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={crossesMidnight}
                    onChange={e => setCrossesMidnight(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-800 text-indigo-600 focus:ring-0"
                  />
                  <span>Crosses midnight into the next day</span>
                </label>
              </div>
            </div>
          </div>

          {/* Time Difference Outputs (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Elapsed Time Breakdown
            </span>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col items-center justify-center gap-2">
              <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Formatted Elapsed Duration
              </span>
              <div className="text-3xl font-extrabold text-sky-400 font-mono">
                {timeDiffResult.formattedDuration}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 font-mono text-xs text-center">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[11px]">Decimal Hours</span>
                <span className="text-lg font-bold text-white">{timeDiffResult.totalHoursDecimal} h</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[11px]">Total Minutes</span>
                <span className="text-lg font-bold text-amber-400">{timeDiffResult.totalMinutes} m</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[11px]">Total Seconds</span>
                <span className="text-lg font-bold text-emerald-400">
                  {timeDiffResult.totalSeconds.toLocaleString()} s
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: HOURS / MINUTES / SECONDS CONVERTER
          ========================================================================= */}
      {activeTab === 'hms_converter' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Converter Input (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Time Unit Conversion
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Time Quantity:</span>
                <input
                  type="number"
                  step="any"
                  value={hmsVal}
                  onChange={e => setHmsVal(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Unit:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setHmsUnit('hours')}
                    className={`py-1.5 rounded-lg font-medium transition-all ${
                      hmsUnit === 'hours'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    Hours
                  </button>
                  <button
                    type="button"
                    onClick={() => setHmsUnit('minutes')}
                    className={`py-1.5 rounded-lg font-medium transition-all ${
                      hmsUnit === 'minutes'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    Minutes
                  </button>
                  <button
                    type="button"
                    onClick={() => setHmsUnit('seconds')}
                    className={`py-1.5 rounded-lg font-medium transition-all ${
                      hmsUnit === 'seconds'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    Seconds
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Unit Conversion Results (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Equivalent Units & Standard Notation
            </span>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-center font-mono">
              <span className="text-xs text-slate-500 block mb-1">Standard Notation (HH:MM:SS)</span>
              <div className="text-3xl font-extrabold text-purple-400">{hmsResult.standardHms}</div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs text-center">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Decimal Hours</span>
                <span className="text-base font-bold text-white">{hmsResult.decimalHours} h</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Minutes</span>
                <span className="text-base font-bold text-sky-400">{hmsResult.totalMinutes} m</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Seconds</span>
                <span className="text-base font-bold text-emerald-400">{hmsResult.totalSeconds} s</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Milliseconds</span>
                <span className="text-base font-bold text-amber-400">
                  {hmsResult.totalMilliseconds.toLocaleString()} ms
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: AGE CALCULATOR
          ========================================================================= */}
      {activeTab === 'age_calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Age Inputs (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Birth Date Parameters
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Date of Birth:</span>
                <input
                  type="date"
                  value={birthDate}
                  onChange={e => setBirthDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <span className="text-slate-400 block mb-1">Target Date (Defaults to Today):</span>
                <input
                  type="date"
                  value={targetAgeDate}
                  onChange={e => setTargetAgeDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 font-mono">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Born on:</span>
                <span className="text-amber-300 font-bold">{ageResult.dayOfWeekBorn}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Zodiac Sign:</span>
                <span className="text-purple-300 font-bold">{ageResult.zodiacSign}</span>
              </div>
            </div>
          </div>

          {/* Age Result Outputs (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Exact Age & Milestones
            </span>

            {/* Primary Age Display */}
            <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col items-center justify-center gap-1.5 text-center">
              <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Current Age
              </span>
              <div className="text-3xl font-extrabold text-white font-mono">
                {ageResult.years} <span className="text-base font-normal text-slate-400">years</span>{' '}
                {ageResult.months} <span className="text-base font-normal text-slate-400">months</span>{' '}
                {ageResult.days} <span className="text-base font-normal text-slate-400">days</span>
              </div>
            </div>

            {/* Next Birthday Countdown */}
            <div className="p-3.5 bg-emerald-950/30 border border-emerald-800/40 rounded-xl flex items-center justify-between font-mono text-xs">
              <span className="text-emerald-300">Next Birthday Countdown:</span>
              <span className="text-white font-bold">
                {ageResult.nextBirthdayDays} days left ({ageResult.nextBirthdayDayOfWeek})
              </span>
            </div>

            {/* Cumulative Lifetime Units */}
            <div className="grid grid-cols-3 gap-2.5 font-mono text-xs text-center">
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Days Lived</span>
                <span className="text-base font-bold text-sky-400">
                  {ageResult.totalDays.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Weeks Lived</span>
                <span className="text-base font-bold text-indigo-400">
                  {ageResult.totalWeeks.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Hours Lived</span>
                <span className="text-base font-bold text-emerald-400">
                  {ageResult.totalHours.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 6: DAY-OF-WEEK & CALENDAR CALCULATIONS
          ========================================================================= */}
      {activeTab === 'calendar_tools' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Day of week finder (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Day-of-Week & Calendar Metadata
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Pick Any Date:</span>
                <input
                  type="date"
                  value={calDate}
                  onChange={e => setCalDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-center font-mono">
                <span className="text-slate-500 text-[11px] block">Day of the Week</span>
                <span className="text-2xl font-bold text-amber-400">{calResult.dayName}</span>
                <div className="mt-1">
                  <span
                    className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                      calResult.isWeekend
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}
                  >
                    {calResult.isWeekend ? 'Weekend (Saturday/Sunday)' : 'Weekday (Monday–Friday)'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Day of Year</span>
                  <span className="text-base font-bold text-white">Day {calResult.dayOfYear} of 365/366</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">ISO Week #</span>
                  <span className="text-base font-bold text-sky-400">Week {calResult.isoWeekNumber}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Days in Month</span>
                  <span className="text-base font-bold text-emerald-400">{calResult.daysInMonth} days</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Julian Day Number</span>
                  <span className="text-base font-bold text-purple-400">{calResult.julianDayNumber}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Leap Year & Astronomical Year Checker (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Leap Year & Gregorian Calendar Rules
            </span>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
              <div>
                <span className="text-slate-400 block mb-1">Enter Year (e.g. 2024, 2026, 2100):</span>
                <input
                  type="number"
                  value={testYear}
                  onChange={e => setTestYear(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div
                className={`p-4 rounded-xl border text-center font-mono ${
                  leapResult.isLeap
                    ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="text-xl font-bold mb-1">
                  {testYear} {leapResult.isLeap ? 'is a LEAP YEAR' : 'is a COMMON YEAR'}
                </div>
                <div className="text-xs text-slate-400">{leapResult.reason}</div>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-slate-400 text-xs">
                <span className="font-bold text-slate-200 block mb-1">Gregorian Leap Year Rule:</span>
                A year is a leap year if it is divisible by 4, except for end-of-century years which must also be divisible by 400.
                (e.g., 2000 was a leap year, but 1900 and 2100 are not).
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center font-mono">
              <span className="text-slate-400">Total Days in Year:</span>
              <span className="text-base font-bold text-amber-400">{leapResult.totalDays} Days</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
