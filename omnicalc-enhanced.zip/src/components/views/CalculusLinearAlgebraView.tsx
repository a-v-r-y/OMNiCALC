import React, { useState } from 'react';
import { AngleUnit } from '../../types/calc';
import {
  computeRREF,
  matrixDeterminant,
  matrixInverse,
  matrixTranspose,
  matrixMultiply,
  matrixTrace,
  eigen2x2,
  vectorDot,
  vectorCross3D,
  vectorMagnitude,
  vectorUnit,
  vectorAngle,
  vectorProjection
} from '../../utils/linearAlgebra';
import {
  numericalDerivative,
  numericalSecondDerivative,
  numericalIntegrate,
  numericalDoubleIntegral,
  numericalLimit,
  taylorSeries
} from '../../utils/calculusEngine';
import { symbolicDerivative } from '../../utils/mathEngine';
import { MathView } from '../MathView';
import { Grid, Layers, Sparkles, ArrowRight } from 'lucide-react';

interface CalculusLinearAlgebraViewProps {
  angleUnit: AngleUnit;
}

export const CalculusLinearAlgebraView: React.FC<CalculusLinearAlgebraViewProps> = ({ angleUnit }) => {
  const [subTab, setSubTab] = useState<'matrices' | 'vectors' | 'calculus'>('matrices');

  // Matrix State (default 3x3)
  const [matrixSize, setMatrixSize] = useState<number>(3);
  const [matrixA, setMatrixA] = useState<number[][]>([
    [2, 1, -1],
    [-3, -1, 2],
    [-2, 1, 2]
  ]);
  const [matrixB, setMatrixB] = useState<number[][]>([
    [1, 0, 2],
    [0, 1, 1],
    [3, -1, 0]
  ]);
  const [vectorB, setVectorB] = useState<number[]>([8, -11, -3]);
  const [matrixOutput, setMatrixOutput] = useState<{ label: string; value: any; isMatrix?: boolean } | null>(null);

  // Vector State
  const [vecU, setVecU] = useState<number[]>([1, 2, 3]);
  const [vecV, setVecV] = useState<number[]>([4, -5, 6]);
  const [vectorOutput, setVectorOutput] = useState<string | null>(null);

  // Calculus State
  const [calcFunc, setCalcFunc] = useState<string>('x^3 - 3*x + 2');
  const [calcX0, setCalcX0] = useState<number>(2);
  const [calcA, setCalcA] = useState<number>(0);
  const [calcB, setCalcB] = useState<number>(3);
  const [calcOutput, setCalcOutput] = useState<{ title: string; result: string; latex?: string } | null>(null);

  // Matrix Resize
  const handleResize = (newSize: number) => {
    setMatrixSize(newSize);
    const newA = Array(newSize)
      .fill(0)
      .map((_, r) =>
        Array(newSize)
          .fill(0)
          .map((_, c) => matrixA[r]?.[c] ?? (r === c ? 1 : 0))
      );
    const newB = Array(newSize)
      .fill(0)
      .map((_, r) =>
        Array(newSize)
          .fill(0)
          .map((_, c) => matrixB[r]?.[c] ?? (r === c ? 1 : 0))
      );
    const newVec = Array(newSize)
      .fill(0)
      .map((_, i) => vectorB[i] ?? 1);
    setMatrixA(newA);
    setMatrixB(newB);
    setVectorB(newVec);
  };

  // Matrix Actions
  const handleDetA = () => {
    const d = matrixDeterminant(matrixA);
    setMatrixOutput({ label: 'det(A)', value: d !== null ? d.toFixed(6) : 'Undefined' });
  };

  const handleInvA = () => {
    const inv = matrixInverse(matrixA);
    if (inv) {
      setMatrixOutput({ label: 'Inverse A⁻¹', value: inv, isMatrix: true });
    } else {
      setMatrixOutput({ label: 'Inverse A⁻¹', value: 'Singular Matrix (det = 0, no inverse)' });
    }
  };

  const handleRREFA = () => {
    const res = computeRREF(matrixA);
    setMatrixOutput({ label: `RREF(A) (Rank: ${res.rank})`, value: res.rref, isMatrix: true });
  };

  const handleMultAB = () => {
    const res = matrixMultiply(matrixA, matrixB);
    if (res) {
      setMatrixOutput({ label: 'A × B', value: res, isMatrix: true });
    } else {
      setMatrixOutput({ label: 'A × B', value: 'Dimension mismatch' });
    }
  };

  const handleAddAB = () => {
    const res = matrixA.map((row, i) => row.map((val, j) => val + matrixB[i][j]));
    setMatrixOutput({ label: 'A + B', value: res, isMatrix: true });
  };

  const handleEigenA = () => {
    if (matrixSize === 2) {
      const e = eigen2x2(matrixA);
      if (e) {
        setMatrixOutput({
          label: 'Eigenvalues (2x2)',
          value: `λ₁ = ${e.lambda1},  λ₂ = ${e.lambda2} (Trace: ${e.trace}, Det: ${e.det})`
        });
      }
    } else {
      setMatrixOutput({ label: 'Eigenvalues', value: 'Full characteristic polynomial solver available in CAS' });
    }
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Sub Tabs */}
      <div className="flex items-center gap-2 p-1 bg-slate-900/90 rounded-xl border border-slate-800 w-fit text-xs">
        <button
          type="button"
          onClick={() => setSubTab('matrices')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'matrices' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Matrices & Linear Systems
        </button>
        <button
          type="button"
          onClick={() => setSubTab('vectors')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'vectors' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Vector Analysis (2D/3D)
        </button>
        <button
          type="button"
          onClick={() => setSubTab('calculus')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            subTab === 'calculus' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Calculus & Series
        </button>
      </div>

      {/* 1. Matrices Tab */}
      {subTab === 'matrices' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Matrix Editor */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-sm font-semibold text-slate-200">
                <div className="flex items-center gap-2">
                  <Grid className="w-4 h-4 text-indigo-400" />
                  Matrix A & Matrix B Editor
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-400">Dimensions:</span>
                  {[2, 3, 4].map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => handleResize(s)}
                      className={`px-2 py-0.5 rounded font-mono ${
                        matrixSize === s
                          ? 'bg-indigo-600 text-white font-bold'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {s}×{s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Matrices side by side */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Matrix A */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <div className="text-xs font-semibold text-indigo-300">Matrix A</div>
                  <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${matrixSize}, minmax(0, 1fr))` }}>
                    {matrixA.map((row, r) =>
                      row.map((val, c) => (
                        <input
                          key={`a-${r}-${c}`}
                          type="number"
                          value={val}
                          onChange={e => {
                            const v = parseFloat(e.target.value) || 0;
                            const newA = matrixA.map(rowArr => [...rowArr]);
                            newA[r][c] = v;
                            setMatrixA(newA);
                          }}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded py-1 px-1.5 text-center text-sm font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      ))
                    )}
                  </div>
                </div>

                {/* Matrix B */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col gap-2">
                  <div className="text-xs font-semibold text-emerald-300">Matrix B</div>
                  <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${matrixSize}, minmax(0, 1fr))` }}>
                    {matrixB.map((row, r) =>
                      row.map((val, c) => (
                        <input
                          key={`b-${r}-${c}`}
                          type="number"
                          value={val}
                          onChange={e => {
                            const v = parseFloat(e.target.value) || 0;
                            const newB = matrixB.map(rowArr => [...rowArr]);
                            newB[r][c] = v;
                            setMatrixB(newB);
                          }}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded py-1 px-1.5 text-center text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
                        />
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Actions Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pt-2">
                <button
                  type="button"
                  onClick={handleDetA}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  det(A)
                </button>
                <button
                  type="button"
                  onClick={handleInvA}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  A⁻¹
                </button>
                <button
                  type="button"
                  onClick={handleRREFA}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  RREF(A)
                </button>
                <button
                  type="button"
                  onClick={handleMultAB}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  A × B
                </button>
                <button
                  type="button"
                  onClick={handleAddAB}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  A + B
                </button>
                <button
                  type="button"
                  onClick={handleEigenA}
                  className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                >
                  Eigenvalues
                </button>
              </div>
            </div>
          </div>

          {/* Matrix Output Panel */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col h-full min-h-[300px]">
              <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
                Matrix Operation Result
              </div>

              <div className="flex-1 flex flex-col justify-center items-center p-4">
                {matrixOutput ? (
                  <div className="w-full flex flex-col items-center gap-3">
                    <span className="text-xs text-indigo-400 font-mono font-bold">
                      {matrixOutput.label}
                    </span>
                    {matrixOutput.isMatrix ? (
                      <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-1 font-mono text-sm">
                        {matrixOutput.value.map((row: number[], r: number) => (
                          <div key={r} className="flex items-center gap-3 justify-center">
                            {row.map((val: number, c: number) => (
                              <span key={c} className="w-14 text-center text-white">
                                {typeof val === 'number' ? val.toFixed(3) : val}
                              </span>
                            ))}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-lg font-mono font-bold text-white text-center">
                        {String(matrixOutput.value)}
                      </div>
                    )}
                  </div>
                ) : (
                  <span className="text-xs text-slate-500 text-center">
                    Select any matrix operation button above to compute determinant, inverse, RREF, product, or eigenvalues.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Vectors Tab */}
      {subTab === 'vectors' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              Vector Definition (3D)
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold text-indigo-300 w-8">u =</span>
                {[0, 1, 2].map(i => (
                  <input
                    key={`u-${i}`}
                    type="number"
                    value={vecU[i]}
                    onChange={e => {
                      const newU = [...vecU];
                      newU[i] = parseFloat(e.target.value) || 0;
                      setVecU(newU);
                    }}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded py-1 px-2 text-sm font-mono text-white text-center"
                  />
                ))}
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold text-emerald-300 w-8">v =</span>
                {[0, 1, 2].map(i => (
                  <input
                    key={`v-${i}`}
                    type="number"
                    value={vecV[i]}
                    onChange={e => {
                      const newV = [...vecV];
                      newV[i] = parseFloat(e.target.value) || 0;
                      setVecV(newV);
                    }}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded py-1 px-2 text-sm font-mono text-white text-center"
                  />
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3">
              <button
                type="button"
                onClick={() => {
                  const dot = vectorDot(vecU, vecV);
                  setVectorOutput(`Dot Product (u · v) = ${dot}`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                u · v (Dot)
              </button>
              <button
                type="button"
                onClick={() => {
                  const cross = vectorCross3D(vecU, vecV);
                  setVectorOutput(`Cross Product (u × v) = [${cross.join(', ')}]`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                u × v (Cross)
              </button>
              <button
                type="button"
                onClick={() => {
                  const magU = vectorMagnitude(vecU);
                  const magV = vectorMagnitude(vecV);
                  setVectorOutput(`|u| = ${magU.toFixed(4)},  |v| = ${magV.toFixed(4)}`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                Magnitudes
              </button>
              <button
                type="button"
                onClick={() => {
                  const angle = vectorAngle(vecU, vecV);
                  setVectorOutput(`Angle θ = ${angle.degrees}° (${angle.radians} rad)`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                Angle θ
              </button>
              <button
                type="button"
                onClick={() => {
                  const unitU = vectorUnit(vecU);
                  setVectorOutput(`Unit vector û = [${unitU.join(', ')}]`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                Unit Vector û
              </button>
              <button
                type="button"
                onClick={() => {
                  const proj = vectorProjection(vecU, vecV);
                  setVectorOutput(`proj_v(u) = [${proj.join(', ')}]`);
                }}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white"
              >
                Projection
              </button>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-4">
              Vector Result
            </div>
            <div className="text-base font-mono font-bold text-white text-center">
              {vectorOutput || 'Select an operation on vectors u and v.'}
            </div>
          </div>
        </div>
      )}

      {/* 3. Calculus Tab */}
      {subTab === 'calculus' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-6 flex flex-col gap-3 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800">
              Function & Parameters
            </div>

            <div className="flex flex-col gap-1.5">
              <span className="text-xs text-slate-400">Function f(x):</span>
              <input
                type="text"
                value={calcFunc}
                onChange={e => setCalcFunc(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="flex flex-col gap-1">
                <span className="text-xs text-slate-400">Point x₀:</span>
                <input
                  type="number"
                  value={calcX0}
                  onChange={e => setCalcX0(parseFloat(e.target.value) || 0)}
                  className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-sm font-mono text-white"
                />
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-xs text-slate-400">Lower bound a:</span>
                <input
                  type="number"
                  value={calcA}
                  onChange={e => setCalcA(parseFloat(e.target.value) || 0)}
                  className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-sm font-mono text-white"
                />
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-xs text-slate-400">Upper bound b:</span>
                <input
                  type="number"
                  value={calcB}
                  onChange={e => setCalcB(parseFloat(e.target.value) || 0)}
                  className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-sm font-mono text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  const sym = symbolicDerivative(calcFunc, 'x');
                  const num = numericalDerivative(calcFunc, calcX0);
                  setCalcOutput({
                    title: `Derivative f'(x) at x = ${calcX0}`,
                    result: `Symbolic: f'(x) = ${sym}\nNumerical at x₀ = ${num.toFixed(6)}`
                  });
                }}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white font-medium"
              >
                Derivative f'(x)
              </button>
              <button
                type="button"
                onClick={() => {
                  const num2 = numericalSecondDerivative(calcFunc, calcX0);
                  setCalcOutput({
                    title: `2nd Derivative f''(x) at x = ${calcX0}`,
                    result: `f''(${calcX0}) ≈ ${num2.toFixed(6)}`
                  });
                }}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white font-medium"
              >
                2nd Derivative f''(x)
              </button>
              <button
                type="button"
                onClick={() => {
                  const intVal = numericalIntegrate(calcFunc, calcA, calcB);
                  setCalcOutput({
                    title: `Definite Integral ∫[${calcA}, ${calcB}] f(x) dx`,
                    result: `Area = ${intVal.toFixed(6)}`
                  });
                }}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white font-medium"
              >
                Definite Integral ∫
              </button>
              <button
                type="button"
                onClick={() => {
                  const ser = taylorSeries(calcFunc, calcX0, 4);
                  setCalcOutput({
                    title: `Taylor Series at x₀ = ${calcX0} (order 4)`,
                    result: ser
                  });
                }}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white font-medium"
              >
                Taylor Series
              </button>
              <button
                type="button"
                onClick={() => {
                  const lim = numericalLimit(calcFunc, calcX0, 'both');
                  setCalcOutput({
                    title: `Limit lim (x → ${calcX0}) f(x)`,
                    result: `Limit = ${lim.limit} (Left: ${lim.left?.toFixed(4)}, Right: ${lim.right?.toFixed(4)})`
                  });
                }}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-white font-medium col-span-2"
              >
                Limit (x → x₀)
              </button>
            </div>
          </div>

          <div className="md:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-center items-center min-h-[250px]">
            <div className="text-sm font-semibold text-slate-200 pb-2 border-b border-slate-800 w-full mb-3">
              Calculus Output
            </div>
            {calcOutput ? (
              <div className="flex flex-col items-center gap-2 text-center">
                <span className="text-xs text-indigo-400 font-mono font-bold">
                  {calcOutput.title}
                </span>
                <pre className="text-sm font-mono font-bold text-white whitespace-pre-wrap">
                  {calcOutput.result}
                </pre>
              </div>
            ) : (
              <span className="text-xs text-slate-500">
                Click any calculus operation above to calculate derivatives, definite integrals, series, or limits.
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
