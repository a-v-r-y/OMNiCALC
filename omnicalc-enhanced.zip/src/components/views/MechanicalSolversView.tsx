import React, { useState } from 'react';
import {
  calculateForce,
  calculateWeight,
  calculateFriction,
  calculateHookeSpring,
  calculateCentripetalForce,
  calculateTorque,
  calculateTorqueFromPower,
  calculateWork,
  calculateKineticEnergy,
  calculateRotationalKineticEnergy,
  calculatePotentialEnergy,
  calculateMechanicalPower,
  calculateEfficiency,
  calculateStress,
  calculateStrain,
  calculateYoungsModulus,
  calculateFactorOfSafety,
  calculatePressure,
  calculateHydrostaticPressure,
  calculateHydraulicPress,
  calculateLinearKinematics,
  calculateRotationalMotion,
  calculateGearTrain,
  calculateFlowRate,
  calculateContinuity,
  calculateReynoldsNumber,
  calculateDarcyWeisbach,
  calculateBernoulli
} from '../../utils/mechanicalSolvers';
import {
  Wrench,
  RotateCw,
  Zap,
  ShieldAlert,
  Gauge,
  Workflow,
  Waves,
  ArrowRight,
  Maximize2
} from 'lucide-react';

export type MechanicalTab =
  | 'force_torque'
  | 'work_energy_power'
  | 'stress_strain_pressure'
  | 'motion_gears'
  | 'fluid_mechanics';

export const MechanicalSolversView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<MechanicalTab>('force_torque');

  // ==========================================
  // 1. Force & Torque State
  // ==========================================
  // Newton's 2nd Law
  const [fMass, setFMass] = useState<number>(15);
  const [fAccel, setFAccel] = useState<number>(9.81);
  const fRes = calculateForce(fMass, fAccel);

  // Friction & Hooke
  const [fricMu, setFricMu] = useState<number>(0.35);
  const [fricNormal, setFricNormal] = useState<number>(147.15);
  const fricRes = calculateFriction(fricMu, fricNormal);

  const [springK, setSpringK] = useState<number>(2500); // N/m
  const [springX, setSpringX] = useState<number>(0.08); // 8 cm = 0.08 m
  const springRes = calculateHookeSpring(springK, springX);

  // Torque
  const [tRadius, setTRadius] = useState<number>(0.45); // m
  const [tForce, setTForce] = useState<number>(120); // N
  const [tAngle, setTAngle] = useState<number>(90); // deg
  const torqueRes = calculateTorque(tRadius, tForce, tAngle);

  // Torque from Motor Power
  const [motorPowerW, setMotorPowerW] = useState<number>(3000); // 3 kW
  const [motorRpm, setMotorRpm] = useState<number>(1500); // 1500 RPM
  const motorRes = calculateTorqueFromPower(motorPowerW, motorRpm);

  // ==========================================
  // 2. Work, Energy & Power State
  // ==========================================
  const [workF, setWorkF] = useState<number>(250);
  const [workD, setWorkD] = useState<number>(12);
  const [workAngle, setWorkAngle] = useState<number>(0);
  const workRes = calculateWork(workF, workD, workAngle);

  const [pWork, setPWork] = useState<number>(3000);
  const [pTime, setPTime] = useState<number>(4);
  const powerRes = calculateMechanicalPower(pWork, pTime);

  const [keM, setKeM] = useState<number>(80);
  const [keV, setKeV] = useState<number>(15);
  const keRes = calculateKineticEnergy(keM, keV);

  const [peM, setPeM] = useState<number>(80);
  const [peH, setPeH] = useState<number>(25);
  const peRes = calculatePotentialEnergy(peM, peH);

  const [effPIn, setEffPIn] = useState<number>(5000);
  const [effPOut, setEffPOut] = useState<number>(4350);
  const effRes = calculateEfficiency(effPOut, effPIn);

  // ==========================================
  // 3. Stress, Strain & Pressure State
  // ==========================================
  // Stress
  const [stressForce, setStressForce] = useState<number>(45000); // 45 kN
  const [stressArea, setStressArea] = useState<number>(0.0005); // 500 mm2 = 0.0005 m2
  const stressRes = calculateStress(stressForce, stressArea);

  // Strain
  const [strainDeltaL, setStrainDeltaL] = useState<number>(0.0012); // 1.2 mm
  const [strainL0, setStrainL0] = useState<number>(0.8); // 800 mm
  const strainRes = calculateStrain(strainDeltaL, strainL0);

  // Young's Modulus & Factor of Safety
  const [yieldStressMPa, setYieldStressMPa] = useState<number>(250); // Steel yield ~250 MPa
  const [workingStressMPa, setWorkingStressMPa] = useState<number>(90); // 90 MPa
  const fosRes = calculateFactorOfSafety(yieldStressMPa, workingStressMPa);

  // Pressure & Hydraulics
  const [pressF, setPressF] = useState<number>(1500);
  const [pressA, setPressA] = useState<number>(0.02);
  const pressRes = calculatePressure(pressF, pressA);

  const [hydF1, setHydF1] = useState<number>(250); // N
  const [hydD1, setHydD1] = useState<number>(0.05); // 50 mm
  const [hydD2, setHydD2] = useState<number>(0.25); // 250 mm
  const hydRes = calculateHydraulicPress(hydF1, hydD1, hydD2);

  // ==========================================
  // 4. Motion & Gears State
  // ==========================================
  // Linear Kinematics
  const [kinV0, setKinV0] = useState<number>(5);
  const [kinA, setKinA] = useState<number>(2.5);
  const [kinT, setKinT] = useState<number>(8);
  const linKin = calculateLinearKinematics(kinV0, kinA, kinT);

  // Rotational Motion
  const [rotRpm0, setRotRpm0] = useState<number>(600);
  const [rotAlpha, setRotAlpha] = useState<number>(4.2);
  const [rotT, setRotT] = useState<number>(10);
  const rotMotion = calculateRotationalMotion(rotRpm0, rotAlpha, rotT);

  // Gear Train
  const [gearN1, setGearN1] = useState<number>(18); // Driver teeth
  const [gearN2, setGearN2] = useState<number>(72); // Driven teeth
  const [gearRpmIn, setGearRpmIn] = useState<number>(1800);
  const [gearTorqueIn, setGearTorqueIn] = useState<number>(15);
  const gearRes = calculateGearTrain(gearN1, gearN2, gearRpmIn, gearTorqueIn);

  // ==========================================
  // 5. Fluid Dynamics State
  // ==========================================
  // Flow Rate
  const [flowDia, setFlowDia] = useState<number>(0.05); // 50 mm = 0.05 m
  const [flowVel, setFlowVel] = useState<number>(2.4); // 2.4 m/s
  const flowRes = calculateFlowRate(flowDia, flowVel);

  // Continuity
  const [contD1, setContD1] = useState<number>(0.1);
  const [contV1, setContV1] = useState<number>(1.5);
  const [contD2, setContD2] = useState<number>(0.05);
  const contRes = calculateContinuity(contD1, contV1, contD2);

  // Reynolds Number
  const [reyDensity, setReyDensity] = useState<number>(1000); // water
  const [reyVel, setReyVel] = useState<number>(1.8);
  const [reyDia, setReyDia] = useState<number>(0.05);
  const [reyVisc, setReyVisc] = useState<number>(0.001); // Pa.s
  const reyRes = calculateReynoldsNumber(reyDensity, reyVel, reyDia, reyVisc);

  // Darcy-Weisbach
  const [dwFric, setDwFric] = useState<number>(0.02);
  const [dwLen, setDwLen] = useState<number>(50); // 50 m
  const [dwDia, setDwDia] = useState<number>(0.08); // 80 mm
  const [dwVel, setDwVel] = useState<number>(2.0);
  const dwRes = calculateDarcyWeisbach(dwFric, dwLen, dwDia, dwVel);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Subtab Navigation */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs shadow-md">
        <button
          type="button"
          onClick={() => setActiveTab('force_torque')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'force_torque'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Wrench className="w-3.5 h-3.5 text-amber-300" />
          Force & Torque
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('work_energy_power')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'work_energy_power'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-emerald-300" />
          Work, Energy & Power
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('stress_strain_pressure')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'stress_strain_pressure'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Gauge className="w-3.5 h-3.5 text-sky-300" />
          Stress, Strain & Pressure
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('motion_gears')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'motion_gears'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Workflow className="w-3.5 h-3.5 text-purple-300" />
          Motion & Gear Trains
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fluid_mechanics')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all ${
            activeTab === 'fluid_mechanics'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <Waves className="w-3.5 h-3.5 text-cyan-300" />
          Fluid Calculations
        </button>
      </div>

      {/* =========================================================================
          MODULE 1: FORCE & TORQUE
          ========================================================================= */}
      {activeTab === 'force_torque' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Force Solvers (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Forces (Newton's 2nd Law, Friction, Hooke's Spring)
            </span>

            {/* Newton 2nd Law */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5 text-xs">
              <span className="font-bold text-amber-400">Newton's 2nd Law: F = m · a</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Mass m (kg):</span>
                  <input
                    type="number"
                    value={fMass}
                    onChange={e => setFMass(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Acceleration a (m/s²):</span>
                  <input
                    type="number"
                    value={fAccel}
                    onChange={e => setFAccel(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="p-2 bg-slate-900 rounded border border-slate-800 font-mono flex justify-between items-center">
                <span className="text-slate-400">Resulting Force F:</span>
                <span className="text-amber-400 font-bold text-base">{fRes} N</span>
              </div>
            </div>

            {/* Friction & Springs */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-sky-400">Friction: F_f = μ · N</span>
                <div>
                  <span className="text-slate-400 block mb-1">Friction Coeff μ:</span>
                  <input
                    type="number"
                    step="0.05"
                    value={fricMu}
                    onChange={e => setFricMu(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Normal Force N (N):</span>
                  <input
                    type="number"
                    value={fricNormal}
                    onChange={e => setFricNormal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between">
                  <span className="text-slate-500">F_f:</span>
                  <span className="text-sky-300 font-bold">{fricRes} N</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-emerald-400">Spring: F = k · x</span>
                <div>
                  <span className="text-slate-400 block mb-1">Stiffness k (N/m):</span>
                  <input
                    type="number"
                    value={springK}
                    onChange={e => setSpringK(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Deflection x (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={springX}
                    onChange={e => setSpringX(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between">
                  <span className="text-slate-500">Force:</span>
                  <span className="text-emerald-300 font-bold">{springRes.force} N</span>
                </div>
              </div>
            </div>
          </div>

          {/* Torque Solvers (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-4">
                Torque (Lever Arm & Motor Power)
              </span>

              {/* Lever Arm Torque */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5 text-xs mb-3">
                <span className="font-bold text-indigo-400">Lever Arm: τ = r · F · sin(θ)</span>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <span className="text-slate-400 block mb-1">Radius r (m):</span>
                    <input
                      type="number"
                      step="0.05"
                      value={tRadius}
                      onChange={e => setTRadius(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Force F (N):</span>
                    <input
                      type="number"
                      value={tForce}
                      onChange={e => setTForce(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Angle θ (°):</span>
                    <input
                      type="number"
                      value={tAngle}
                      onChange={e => setTAngle(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800 font-mono flex justify-between items-center">
                  <span className="text-slate-400">Torque τ:</span>
                  <span className="text-indigo-400 font-bold text-base">{torqueRes} N·m</span>
                </div>
              </div>

              {/* Torque from Motor Power */}
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5 text-xs">
                <span className="font-bold text-purple-400">Motor Torque: τ = P / ω = 9.549 · P / RPM</span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-400 block mb-1">Power P (Watts):</span>
                    <input
                      type="number"
                      value={motorPowerW}
                      onChange={e => setMotorPowerW(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Speed (RPM):</span>
                    <input
                      type="number"
                      value={motorRpm}
                      onChange={e => setMotorRpm(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 font-mono">
                  <div className="p-2 bg-slate-900 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px]">Torque</span>
                    <div className="text-base font-bold text-purple-400">{motorRes.torqueNm} N·m</div>
                  </div>
                  <div className="p-2 bg-slate-900 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px]">Angular Velocity ω</span>
                    <div className="text-base font-bold text-white">{motorRes.omegaRadS} rad/s</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 2: WORK, ENERGY & POWER
          ========================================================================= */}
      {activeTab === 'work_energy_power' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Work & Power (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Mechanical Work & Power Output
            </span>

            {/* Work */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-emerald-400">Work Done: W = F · d · cos(θ)</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Force F (N):</span>
                  <input
                    type="number"
                    value={workF}
                    onChange={e => setWorkF(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Distance d (m):</span>
                  <input
                    type="number"
                    value={workD}
                    onChange={e => setWorkD(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Angle θ (°):</span>
                  <input
                    type="number"
                    value={workAngle}
                    onChange={e => setWorkAngle(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="p-2 bg-slate-900 rounded border border-slate-800 font-mono flex justify-between items-center">
                <span className="text-slate-400">Work Done:</span>
                <span className="text-emerald-400 font-bold text-base">{workRes} Joules (J)</span>
              </div>
            </div>

            {/* Power */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-sky-400">Power: P = W / t = F · v</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Work W (Joules):</span>
                  <input
                    type="number"
                    value={pWork}
                    onChange={e => setPWork(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Time t (sec):</span>
                  <input
                    type="number"
                    value={pTime}
                    onChange={e => setPTime(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Power in Watts</span>
                  <div className="text-base font-bold text-sky-400">{powerRes.watts} W</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Horsepower (HP)</span>
                  <div className="text-base font-bold text-amber-400">{powerRes.horsepower} HP</div>
                </div>
              </div>
            </div>
          </div>

          {/* Kinetic, Potential Energy & Efficiency (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Kinetic / Potential Energy & Efficiency
            </span>

            {/* Kinetic & Potential Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-amber-400">Kinetic: ½ m v²</span>
                <div>
                  <span className="text-slate-400 block mb-1">Mass m (kg):</span>
                  <input
                    type="number"
                    value={keM}
                    onChange={e => setKeM(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Velocity v (m/s):</span>
                  <input
                    type="number"
                    value={keV}
                    onChange={e => setKeV(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between">
                  <span className="text-slate-500">KE:</span>
                  <span className="text-amber-400 font-bold">{keRes} J</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-indigo-400">Potential: m g h</span>
                <div>
                  <span className="text-slate-400 block mb-1">Mass m (kg):</span>
                  <input
                    type="number"
                    value={peM}
                    onChange={e => setPeM(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Height h (m):</span>
                  <input
                    type="number"
                    value={peH}
                    onChange={e => setPeH(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between">
                  <span className="text-slate-500">PE:</span>
                  <span className="text-indigo-300 font-bold">{peRes} J</span>
                </div>
              </div>
            </div>

            {/* Efficiency */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-purple-400">Mechanical Efficiency: η = (P_out / P_in) × 100%</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Input Power P_in (W):</span>
                  <input
                    type="number"
                    value={effPIn}
                    onChange={e => setEffPIn(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Output Power P_out (W):</span>
                  <input
                    type="number"
                    value={effPOut}
                    onChange={e => setEffPOut(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Efficiency (η)</span>
                  <div className="text-base font-bold text-purple-400">{effRes.efficiencyPercent}%</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Power Loss</span>
                  <div className="text-base font-bold text-rose-400">{effRes.powerLoss} W</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 3: STRESS, STRAIN & PRESSURE
          ========================================================================= */}
      {activeTab === 'stress_strain_pressure' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Stress & Strain (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Stress, Strain & Safety Factor
            </span>

            {/* Stress */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-sky-400">Normal Stress: σ = F / A</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Applied Force F (N):</span>
                  <input
                    type="number"
                    value={stressForce}
                    onChange={e => setStressForce(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Cross-Section Area A (m²):</span>
                  <input
                    type="number"
                    step="0.0001"
                    value={stressArea}
                    onChange={e => setStressArea(parseFloat(e.target.value) || 0.0001)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 font-mono text-center">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">MPa</span>
                  <div className="text-sky-400 font-bold">{stressRes.stressMPa}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">psi</span>
                  <div className="text-white font-bold">{stressRes.stressPsi}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Pascal</span>
                  <div className="text-slate-300 font-bold">{stressRes.stressPa}</div>
                </div>
              </div>
            </div>

            {/* Strain & Safety Factor */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-emerald-400">Strain: ε = ΔL / L₀</span>
                <div>
                  <span className="text-slate-400 block mb-1">Elongation ΔL (m):</span>
                  <input
                    type="number"
                    step="0.0001"
                    value={strainDeltaL}
                    onChange={e => setStrainDeltaL(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Initial Length L₀ (m):</span>
                  <input
                    type="number"
                    value={strainL0}
                    onChange={e => setStrainL0(parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between">
                  <span className="text-slate-500">Microstrain:</span>
                  <span className="text-emerald-400 font-bold">{strainRes.microstrain} µε</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2">
                <span className="font-bold text-amber-400">Safety Factor: σ_y / σ_w</span>
                <div>
                  <span className="text-slate-400 block mb-1">Yield Strength (MPa):</span>
                  <input
                    type="number"
                    value={yieldStressMPa}
                    onChange={e => setYieldStressMPa(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Working Stress (MPa):</span>
                  <input
                    type="number"
                    value={workingStressMPa}
                    onChange={e => setWorkingStressMPa(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1 text-white font-mono text-xs"
                  />
                </div>
                <div className="p-1.5 bg-slate-900 rounded font-mono text-xs mt-1 flex justify-between items-center">
                  <span className="text-slate-500">FoS:</span>
                  <span className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                    fosRes.status === 'Safe' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                  }`}>
                    {fosRes.factorOfSafety} ({fosRes.status})
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Pressure & Hydraulics (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Pressure & Hydraulic Mechanical Advantage
            </span>

            {/* Pressure */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-indigo-400">Pressure Definition: P = F / A</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Force F (N):</span>
                  <input
                    type="number"
                    value={pressF}
                    onChange={e => setPressF(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Area A (m²):</span>
                  <input
                    type="number"
                    step="0.005"
                    value={pressA}
                    onChange={e => setPressA(parseFloat(e.target.value) || 0.001)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 font-mono text-center">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">bar</span>
                  <div className="text-indigo-300 font-bold">{pressRes.bar}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">psi</span>
                  <div className="text-sky-300 font-bold">{pressRes.psi}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">atm</span>
                  <div className="text-white font-bold">{pressRes.atm}</div>
                </div>
              </div>
            </div>

            {/* Hydraulic Press */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-emerald-400">Hydraulic Press (Pascal's Principle): F₂ = F₁ · (d₂ / d₁)²</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Input Force F₁ (N):</span>
                  <input
                    type="number"
                    value={hydF1}
                    onChange={e => setHydF1(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Piston 1 Dia d₁ (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={hydD1}
                    onChange={e => setHydD1(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Piston 2 Dia d₂ (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={hydD2}
                    onChange={e => setHydD2(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Output Force F₂</span>
                  <div className="text-base font-bold text-emerald-400">{hydRes.f2} N</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Mechanical Advantage</span>
                  <div className="text-base font-bold text-indigo-300">{hydRes.mechanicalAdvantage}x</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: MOTION & GEARS
          ========================================================================= */}
      {activeTab === 'motion_gears' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Linear & Rotational Motion (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Linear & Rotational Kinematics
            </span>

            {/* Linear */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-sky-400">Linear Motion: v = v₀ + at, d = v₀t + ½at²</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Initial Vel v₀ (m/s):</span>
                  <input
                    type="number"
                    value={kinV0}
                    onChange={e => setKinV0(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Accel a (m/s²):</span>
                  <input
                    type="number"
                    value={kinA}
                    onChange={e => setKinA(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Time t (sec):</span>
                  <input
                    type="number"
                    value={kinT}
                    onChange={e => setKinT(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Final Velocity v</span>
                  <div className="text-base font-bold text-sky-400">{linKin.finalVelocity} m/s</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Displacement d</span>
                  <div className="text-base font-bold text-emerald-400">{linKin.displacement} m</div>
                </div>
              </div>
            </div>

            {/* Rotational Motion */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-purple-400">Rotational Motion: ω = ω₀ + αt</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Initial Speed (RPM):</span>
                  <input
                    type="number"
                    value={rotRpm0}
                    onChange={e => setRotRpm0(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Ang. Accel α (rad/s²):</span>
                  <input
                    type="number"
                    value={rotAlpha}
                    onChange={e => setRotAlpha(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Time t (sec):</span>
                  <input
                    type="number"
                    value={rotT}
                    onChange={e => setRotT(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Final RPM</span>
                  <div className="text-base font-bold text-purple-400">{rotMotion.omegaFinalRpm} RPM</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Total Revolutions</span>
                  <div className="text-base font-bold text-amber-400">{rotMotion.revolutions} revs</div>
                </div>
              </div>
            </div>
          </div>

          {/* Gear Train & Mechanical Advantage (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <div>
              <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800 block mb-4">
                Gear Ratio, Torque & Speed Multiplication
              </span>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-3">
                <span className="font-bold text-amber-400">Gear Train: GR = N_driven / N_driver = ω_in / ω_out = τ_out / τ_in</span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-400 block mb-1">Driver Teeth N₁:</span>
                    <input
                      type="number"
                      value={gearN1}
                      onChange={e => setGearN1(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Driven Teeth N₂:</span>
                    <input
                      type="number"
                      value={gearN2}
                      onChange={e => setGearN2(parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Input Speed (RPM):</span>
                    <input
                      type="number"
                      value={gearRpmIn}
                      onChange={e => setGearRpmIn(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-1">Input Torque (N·m):</span>
                    <input
                      type="number"
                      value={gearTorqueIn}
                      onChange={e => setGearTorqueIn(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-amber-900/30 flex justify-between items-center font-mono">
                  <span className="text-slate-400">Gear Ratio (GR):</span>
                  <span className="text-amber-400 font-bold text-lg">{gearRes.gearRatio} : 1</span>
                </div>

                <div className="grid grid-cols-2 gap-3 font-mono">
                  <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-500 text-[10px]">Output Speed</span>
                    <div className="text-base font-bold text-sky-400">{gearRes.speedOutRpm} RPM</div>
                  </div>
                  <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-500 text-[10px]">Output Torque</span>
                    <div className="text-base font-bold text-emerald-400">{gearRes.torqueOutNm} N·m</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 5: FLUID MECHANICS & FLOW
          ========================================================================= */}
      {activeTab === 'fluid_mechanics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Volumetric Flow & Continuity (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Pipe Flow Rate & Continuity
            </span>

            {/* Flow Rate */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-cyan-400">Pipe Volumetric Flow: Q = A · v = (π d² / 4) · v</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Pipe Inner Diameter d (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={flowDia}
                    onChange={e => setFlowDia(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                  <span className="text-[10px] text-slate-500">{(flowDia * 1000).toFixed(0)} mm</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Flow Velocity v (m/s):</span>
                  <input
                    type="number"
                    value={flowVel}
                    onChange={e => setFlowVel(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 font-mono text-center">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">m³/s</span>
                  <div className="text-cyan-300 font-bold">{flowRes.flowRateM3S}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">L/min</span>
                  <div className="text-white font-bold">{flowRes.flowRateLPerMin}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">GPM</span>
                  <div className="text-emerald-400 font-bold">{flowRes.flowRateGPM}</div>
                </div>
              </div>
            </div>

            {/* Continuity */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-indigo-400">Continuity: A₁ v₁ = A₂ v₂ ⟹ v₂ = v₁ · (d₁ / d₂)²</span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Dia 1 d₁ (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={contD1}
                    onChange={e => setContD1(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Vel 1 v₁ (m/s):</span>
                  <input
                    type="number"
                    value={contV1}
                    onChange={e => setContV1(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Dia 2 d₂ (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={contD2}
                    onChange={e => setContD2(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="p-2 bg-slate-900 rounded border border-slate-800 font-mono flex justify-between items-center">
                <span className="text-slate-400">Constricted Velocity v₂:</span>
                <span className="text-indigo-400 font-bold text-base">{contRes.v2MPerS} m/s</span>
              </div>
            </div>
          </div>

          {/* Reynolds Number & Darcy-Weisbach (6 cols) */}
          <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between gap-4 text-xs">
            <span className="font-semibold text-sm text-slate-200 pb-2 border-b border-slate-800">
              Reynolds Number & Head Loss
            </span>

            {/* Reynolds Number */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-amber-400">Reynolds Number: Re = ρ · v · D / μ</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block mb-1">Density ρ (kg/m³):</span>
                  <input
                    type="number"
                    value={reyDensity}
                    onChange={e => setReyDensity(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Dynamic Viscosity μ (Pa·s):</span>
                  <input
                    type="number"
                    step="0.0001"
                    value={reyVisc}
                    onChange={e => setReyVisc(parseFloat(e.target.value) || 0.0001)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 font-mono flex justify-between items-center">
                <div>
                  <span className="text-slate-500 text-[10px] block">Reynolds Number</span>
                  <span className="text-base font-bold text-amber-400">{reyRes.reynoldsNumber}</span>
                </div>
                <span className={`font-bold px-2.5 py-1 rounded text-xs ${
                  reyRes.regime.startsWith('Laminar') ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                }`}>
                  {reyRes.regime}
                </span>
              </div>
            </div>

            {/* Darcy-Weisbach Head Loss */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2.5">
              <span className="font-bold text-sky-400">Darcy-Weisbach Head Loss: h_f = f · (L/D) · (v² / 2g)</span>
              <div className="grid grid-cols-4 gap-2">
                <div>
                  <span className="text-slate-400 block mb-1">Friction f:</span>
                  <input
                    type="number"
                    step="0.005"
                    value={dwFric}
                    onChange={e => setDwFric(parseFloat(e.target.value) || 0.001)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Length L (m):</span>
                  <input
                    type="number"
                    value={dwLen}
                    onChange={e => setDwLen(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Dia D (m):</span>
                  <input
                    type="number"
                    step="0.01"
                    value={dwDia}
                    onChange={e => setDwDia(parseFloat(e.target.value) || 0.01)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Vel v (m/s):</span>
                  <input
                    type="number"
                    value={dwVel}
                    onChange={e => setDwVel(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Head Loss (h_f)</span>
                  <div className="text-base font-bold text-sky-400">{dwRes.headLossM} meters</div>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px]">Pressure Drop (ΔP)</span>
                  <div className="text-base font-bold text-emerald-400">{dwRes.pressureDropPa} Pa</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
