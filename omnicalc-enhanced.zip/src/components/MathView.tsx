import React, { useEffect, useRef, useState } from 'react';
import katex from 'katex';
import { Copy, Check } from 'lucide-react';

interface MathViewProps {
  math: string;
  block?: boolean;
  className?: string;
  copyable?: boolean;
  rawText?: string;
}

export const MathView: React.FC<MathViewProps> = ({
  math: mathExpr,
  block = false,
  className = '',
  copyable = false,
  rawText
}) => {
  const containerRef = useRef<HTMLSpanElement>(null);
  const [copied, setCopied] = useState(false);
  const [renderError, setRenderError] = useState(false);

  useEffect(() => {
    if (!containerRef.current || !mathExpr) return;
    try {
      katex.render(mathExpr, containerRef.current, {
        displayMode: block,
        throwOnError: false,
        strict: false
      });
      setRenderError(false);
    } catch {
      setRenderError(true);
    }
  }, [mathExpr, block]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const textToCopy = rawText || mathExpr;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <span className={`inline-flex items-center gap-1.5 group relative ${className}`}>
      {renderError ? (
        <span className="font-mono text-sm">{rawText || mathExpr}</span>
      ) : (
        <span ref={containerRef} className="overflow-x-auto max-w-full" />
      )}
      {copyable && (
        <button
          type="button"
          onClick={handleCopy}
          title="Copy LaTeX"
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded text-xs"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
        </button>
      )}
    </span>
  );
};
