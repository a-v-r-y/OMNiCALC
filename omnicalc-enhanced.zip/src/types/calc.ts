export type AngleUnit = 'deg' | 'rad' | 'grad';
export type PrecisionMode = 6 | 10 | 14 | 16 | 18 | 32 | 64 | 128;
export type ResultDisplayFormat = 'auto' | 'fraction' | 'scientific' | 'engineering';

export type AppTheme = 'dark' | 'light' | 'oled' | 'solarized';
export type DisplayFontSize = 'compact' | 'normal' | 'large';
export type KeypadStyle = 'glass' | 'flat' | 'raised' | 'full' | 'basic' | 'compact';

export interface AppSettings {
  theme: AppTheme;
  fontSize: DisplayFontSize;
  keypadStyle: KeypadStyle;
  soundEnabled: boolean;
  hapticFeedback?: boolean;
  soundFeedback?: boolean;
  autoSaveHistory?: boolean;
  showTextbookPreview?: boolean;
}

export interface StepSolutionItem {
  label: string;
  math: string;
  explanation?: string;
}

export interface StepSolution {
  title: string;
  problem: string;
  problemLatex?: string;
  category: string;
  steps: StepSolutionItem[];
  finalResult: string;
  finalMath?: string;
}

export interface FunctionDef {
  name: string;
  syntax: string;
  category:
    | 'Arithmetic & Basic'
    | 'Algebra & Polynomials'
    | 'Trigonometry'
    | 'Hyperbolic'
    | 'Exponential & Log'
    | 'Calculus & Analysis'
    | 'Probability & Statistics'
    | 'Linear Algebra & Matrices'
    | 'Complex Numbers'
    | 'Discrete & Bitwise'
    | 'Constants';
  description: string;
  example: string;
  tags: string[];
}

export interface MultiLineStatement {
  id: string;
  expression: string;
  result: string;
  latex?: string;
  error?: string;
  assignedVar?: string;
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  expression: string;
  result: string;
  latex?: string;
  numericValue?: number | string;
  exactFraction?: string;
  angleUnit: AngleUnit;
  category?: string;
}

export interface VariableItem {
  name: string;
  value: string;
  numericValue?: number;
  isConstant?: boolean;
  description?: string;
}

export interface PhysicalConstant {
  symbol: string;
  name: string;
  value: number;
  unit: string;
  category: 'Physics' | 'Electromagnetism' | 'Thermodynamics' | 'Quantum' | 'Astronomy' | 'Mathematics';
  description: string;
}

export interface FormulaItem {
  id: string;
  name: string;
  category: 'Physics' | 'Chemistry' | 'Engineering' | 'Geometry' | 'Finance' | 'Mathematics';
  subcategory?: string;
  formula: string;
  latex: string;
  variables: {
    symbol: string;
    name: string;
    unit?: string;
    defaultValue?: number;
  }[];
  solveFor: (targetVar: string, values: Record<string, number>) => number | null;
  description: string;
}

export type ActiveTab =
  | 'calculator'
  | 'graphing'
  | 'calculus_matrices'
  | 'statistics'
  | 'stem_solvers'
  | 'numerical_transforms'
  | 'formula_scripts'
  | 'constants_units';
