# OmniCalc — Ultimate Scientific Calculator

A full-featured scientific calculator suite for the browser: expression evaluation with degree/radian/gradian modes, graphing, statistics & probability, calculus, linear algebra, and dedicated solvers for finance, physics, chemistry, geometry, electronics, and more. Everything runs locally — no account, no server, no data leaves your device.

## Features

- **Scientific calculator** — full expression parser (mathjs), angle modes, precision control, history
- **Graphing** — plot functions with zoomable canvas rendering
- **Statistics & probability** — distributions, hypothesis tests, regression
- **Calculus & linear algebra** — numerical integration/differentiation, matrix ops, equation solvers
- **STEM solvers** — finance (TVM, NPV/IRR/XIRR, amortization, depreciation), physics, chemistry, geometry, electronics, unit converter with constants database
- **Programmer tools** — base-N conversion, bitwise ops, scripting console
- **Multi-line notebook** — scratchpad with persistent state
- **Extras** — formula library, function catalog, step-by-step solutions, shareable calculation links, dark mode

## Run locally

**Prerequisites:** Node.js 18+

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

Other scripts:

```bash
npm run build    # production build
npm run preview  # preview the production build
npm run test     # run the math test suite (vitest)
npm run lint     # typecheck (tsc --noEmit)
```

## Tech stack

React 19 · TypeScript · Vite · Tailwind CSS 4 · mathjs · KaTeX
